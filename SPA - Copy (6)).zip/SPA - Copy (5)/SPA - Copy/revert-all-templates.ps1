# PowerShell script to revert all template files to their original state
# This removes all fragment references and restores inline header/footer code

Write-Host "Starting template reversion process..."

# Get all HTML template files except dashboard.html (already reverted)
$templateFiles = Get-ChildItem -Path "src/main/resources/templates" -Recurse -Filter "*.html" | 
    Where-Object { $_.Name -ne "dashboard.html" }

$processedCount = 0
$totalFiles = $templateFiles.Count

foreach ($template in $templateFiles) {
    $processedCount++
    Write-Host "[$processedCount/$totalFiles] Reverting: $($template.FullName.Replace((Get-Location).Path + '\', ''))"
    
    try {
        $content = Get-Content $template.FullName -Raw -Encoding UTF8
        $originalContent = $content
        
        # Step 1: Remove fragment head references and restore basic head structure
        $content = $content -replace '<head th:replace="~\{fragments/header :: (?:head|auth-head)\}"[^>]*>', '<head>'
        
        # Step 2: Remove fragment bubble references and restore simple structure
        $content = $content -replace '<div th:replace="~\{fragments/header :: bubbles\}"></div>', ''
        
        # Step 3: Remove fragment navbar references
        $content = $content -replace '<nav th:replace="~\{fragments/header :: navbar\}"></nav>', ''
        
        # Step 4: Remove fragment footer references and restore simple footer
        $content = $content -replace '<footer th:replace="~\{fragments/footer :: footer\}"></footer>', ''
        
        # Step 5: Remove fragment script references and restore basic Bootstrap scripts
        $content = $content -replace '<div th:replace="~\{fragments/footer :: (?:scripts|auth-scripts)\}"></div>', '<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>'
        
        # Step 6: Clean up any remaining fragment comments
        $content = $content -replace '<!-- Page-specific styles -->\s*', ''
        
        # Step 7: Fix any broken HTML structure
        # Ensure proper head closing
        if ($content -match '<head>' -and $content -notmatch '</head>') {
            $content = $content -replace '(<head>.*?)<body>', '$1</head>`n<body>'
        }
        
        # Step 8: Clean up extra whitespace
        $content = $content -replace '\n\s*\n\s*\n+', "`n`n"
        
        # Step 9: For auth templates, ensure they have minimal structure
        if ($template.Directory.Name -eq "auth") {
            # Ensure auth templates have basic head structure
            if ($content -notmatch '<meta charset="UTF-8">') {
                $content = $content -replace '<head>', '<head>`n    <meta charset="UTF-8">'
            }
            if ($content -notmatch '<title>') {
                $content = $content -replace '<head>', '<head>`n    <title>SpaZone</title>'
            }
        }
        
        # Only write if content changed
        if ($content -ne $originalContent) {
            Set-Content $template.FullName -Value $content -Encoding UTF8
            Write-Host "  ✓ Reverted successfully"
        } else {
            Write-Host "  - No changes needed"
        }

    } catch {
        Write-Host "  ✗ Error reverting: $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host "`nTemplate reversion completed!"
Write-Host "Processed: $processedCount files"
Write-Host "Dashboard.html was already in original state"
Write-Host "Fragments directory has been removed"
