# Phase 0: Analysis & Planning - Detailed Findings

## Task 0.1: User Entity and Role System Analysis ✅

### Current Role Hierarchy
The SpaZone application implements a comprehensive role-based access control system:

1. **ADMIN** - System administrators with full access
2. **MANAGER** - Branch managers with branch-level management capabilities
3. **TECHNICIAN** - Service providers/therapists
4. **RECEPTIONIST** - Front desk staff handling appointments and customer service
5. **CUSTOMER** - Regular customers
6. **VIP** - Premium customers with enhanced privileges

### User Entity Structure
**Key Fields for Chat System:**
- `userId` (Integer) - Primary key for user identification
- `username` (String) - Unique username for authentication
- `fullName` (String) - Display name for chat interface
- `email` (String) - For email notifications
- `phone` (String) - Contact information
- `status` (String) - "active", "inactive", "suspended" (affects chat access)
- `enabled` (Boolean) - Account activation status
- `profilePicture` (String) - Avatar for chat interface
- `lastLogin` (LocalDateTime) - For online status tracking
- `branch` (Branch) - ManyToOne relationship for branch-based chat rooms

### Role-Based Relationships
**Many-to-Many Role Assignment:**
- Users can have multiple roles (though typically one primary role)
- Roles are stored in `user_roles` junction table
- Role names are used for security authorization

**Branch Relationships:**
- Users are assigned to specific branches via `User.branch` field
- Branch managers oversee staff within their branch
- Cross-branch communication requires special handling

### Security Configuration Analysis
**Current Access Control:**
- Role-based URL patterns: `/admin/**`, `/manager/**`, `/technician/**`, `/receptionist/**`
- Method-level security enabled with `@PreAuthorize`
- Session management with single session per user
- CSRF protection enabled (important for WebSocket security)

### Repository Query Patterns
**Existing Role-Based Queries:**
- `findUsersByRoleName(String roleName)` - Get users by specific role
- `findByRoleNames(List<String> roleNames)` - Get users by multiple roles
- `findByBranchIdAndRoleName(Integer branchId, String roleName)` - Branch + role filtering
- `findActiveUsersByBranch(Integer branchId)` - Active staff in specific branch

### Chat System Integration Points
**User Management Integration:**
1. **Authentication**: Leverage existing Spring Security with CustomUserDetailsService
2. **Authorization**: Use existing role hierarchy for chat room access
3. **Branch Isolation**: Use User.branch relationship for branch-specific chats
4. **Status Checking**: Respect user.status and user.enabled for chat access
5. **Profile Integration**: Use existing profilePicture and fullName for chat UI

**Key Considerations for Chat:**
- Staff members (MANAGER, TECHNICIAN, RECEPTIONIST) are primary chat users
- CUSTOMER and VIP roles may need separate customer support chat (future feature)
- Branch-based isolation is critical for manager-staff communication
- Existing notification system can be extended for chat notifications

### Database Naming Conventions
**Observed Patterns:**
- Table names: lowercase with underscores (`users`, `user_roles`, `notifications`)
- Column names: snake_case (`user_id`, `full_name`, `created_at`)
- Foreign keys: `{table}_id` pattern (`branch_id`, `user_id`)
- Boolean fields: `is_` prefix or descriptive names (`enabled`, `is_active`)

### Vietnamese Language Support
**Current Implementation:**
- Vietnamese error messages in validation
- Vietnamese content in notification system
- UI templates support Vietnamese text
- Database uses NVARCHAR for Unicode support

---

## Task 0.2: Notification System Analysis ✅

### Current Notification System Architecture
**Comprehensive Implementation:**
- `NotificationService` with full CRUD operations
- `NotificationRepository` with advanced queries
- `NotificationController` with REST API endpoints
- Vietnamese language support throughout

### Notification Entity Structure
**Key Fields for Chat Integration:**
- `notificationId` (Integer) - Primary key
- `user` (User) - Recipient (ManyToOne relationship)
- `sender` (User) - Optional sender (ManyToOne relationship)
- `title` (String, 255) - Notification title
- `message` (String, 4000) - Notification content
- `type` (NotificationType enum) - Categorization
- `isRead` (Boolean) - Read status tracking
- `actionUrl` (String, 500) - Optional action link
- `createdAt`, `readAt`, `expiresAt` (LocalDateTime) - Timestamps

### Notification Types (Enum)
**Current Types:**
- `SCHEDULE_CHANGE` - Work schedule updates
- `APPOINTMENT_UPDATE` - Customer appointment changes
- `TREATMENT_RECORD_UPDATE` - Treatment record modifications
- `USER_ROLE_CHANGE` - Role assignment changes
- `PASSWORD_CHANGE` - Security notifications
- `SYSTEM_ALERT` - System-wide announcements
- `REMINDER` - Time-based reminders
- `APPROVAL_REQUEST` - Workflow approvals
- `GENERAL` - General notifications

**Chat Integration Plan:**
- Add `CHAT_MESSAGE` type for new chat messages
- Add `CHAT_MENTION` type for @mentions in chat
- Add `CHAT_ROOM_INVITE` type for room invitations

### Current Delivery Mechanisms
**Frontend Implementation:**
- AJAX polling every 30 seconds for unread count
- Dropdown notification center in navigation
- Manual refresh when dropdown is opened
- No real-time WebSocket notifications currently

**Backend Capabilities:**
- Role-based notification broadcasting
- Branch-specific notification targeting
- Individual user notifications
- Email integration via `EmailService`

### Vietnamese Language Support
**Current Implementation:**
- All notification titles and messages in Vietnamese
- Proper Unicode support with NVARCHAR fields
- Consistent Vietnamese terminology across system
- Email templates support Vietnamese content

### Integration Strategy for Chat System
**Extend Existing System:**
1. **Add Chat Notification Types**: Extend NotificationType enum
2. **Leverage Existing Service**: Use NotificationService for offline chat notifications
3. **Enhance with WebSocket**: Add real-time delivery for online users
4. **Maintain Consistency**: Follow existing Vietnamese language patterns

**Hybrid Approach:**
- **Real-time**: WebSocket for online users (instant chat messages)
- **Offline**: Traditional notifications for offline users (chat summaries)
- **Email**: Digest emails for extended offline periods
- **Mobile**: Prepare for future push notification integration

### Existing API Endpoints
**Notification Management:**
- `GET /notifications` - List notifications with pagination
- `GET /notifications/recent` - Recent notifications for dropdown
- `POST /notifications/mark-read/{id}` - Mark single notification as read
- `POST /notifications/mark-all-read` - Mark all as read
- `DELETE /notifications/{id}` - Delete notification
- `POST /notifications/manager/team-notification` - Manager team notifications
- `POST /notifications/manager/system-alert` - Admin system alerts

**Chat Integration Points:**
- Extend existing endpoints for chat notifications
- Add chat-specific notification filtering
- Implement chat notification preferences
- Add bulk operations for chat room notifications

---

## Task 0.3: UI/UX Pattern Analysis ✅

### Template Structure & Framework
**Thymeleaf Template Patterns:**
- Standard HTML5 with Thymeleaf namespaces
- Vietnamese language support (`lang="vi"`)
- Consistent meta tags for viewport and CSRF
- Role-based content rendering with Spring Security

**CSS Framework Stack:**
- **Bootstrap 5.3.0** - Primary UI framework
- **Font Awesome 6.x** - Icon library
- **Poppins Font** - Primary typography from Google Fonts
- **Custom CSS** - Glassmorphism effects and animations

**JavaScript Libraries:**
- **Bootstrap Bundle** - UI interactions
- **Chart.js** - Data visualization
- **Custom JavaScript** - Animations and AJAX calls

### Design System & Visual Identity
**Color Scheme:**
- Primary: Pink/Purple gradients (`#ff69b4`, `#667eea`, `#764ba2`)
- Background: Soft gradients (`linear-gradient(120deg, #fff0f6 0%, #ffe4ec 60%, #fdfbfb 100%)`)
- Role-based color variations (green for receptionist, blue for technician)

**Glassmorphism Design:**
- Semi-transparent backgrounds with backdrop blur
- Subtle shadows and borders
- Floating bubble animations
- Glass-like card components

### Reusable UI Components
**Navigation System:**
- Role-based dropdown menus
- Notification dropdown with badge counter
- Responsive navbar with collapse functionality
- Consistent icon usage with FontAwesome

**Card Components:**
- Glass-effect cards with hover animations
- Consistent padding and border radius
- Shadow effects and transitions
- Responsive grid layouts

**Interactive Elements:**
- Ripple effect buttons
- Hover animations with transform effects
- Loading states with spinners
- Form validation with visual feedback

**Notification System UI:**
- Dropdown notification center
- Badge counters for unread notifications
- Real-time AJAX updates every 30 seconds
- Vietnamese language notifications

### Responsive Design Patterns
**Breakpoints:**
- Mobile: `@media (max-width: 768px)`
- Tablet: Intermediate responsive adjustments
- Desktop: Full layout with sidebars

**Mobile Optimizations:**
- Collapsible navigation
- Hidden decorative elements (bubbles)
- Adjusted padding and font sizes
- Touch-friendly button sizes

### Animation & Interaction Patterns
**Micro-interactions:**
- Stagger animations for card lists
- Hover effects with scale and translate
- Ripple effects on button clicks
- Smooth transitions (0.3s ease)

**Loading States:**
- Spinner animations
- Skeleton loading patterns
- Progressive content loading
- Error state handling

### Accessibility Features
**Current Implementation:**
- ARIA labels and roles
- Keyboard navigation support
- Screen reader compatibility
- High contrast considerations
- Reduced motion preferences

### Chat UI Integration Strategy
**Leverage Existing Patterns:**
1. **Navigation**: Add chat menu item to existing role-based navigation
2. **Glassmorphism**: Use existing glass-card styles for chat interface
3. **Colors**: Follow role-based color scheme for chat rooms
4. **Typography**: Use Poppins font for consistency
5. **Animations**: Apply existing hover and transition patterns

**Chat-Specific Components:**
- **Chat Sidebar**: Adapt existing navigation dropdown patterns
- **Message Bubbles**: Create new component following glass-card design
- **Input Area**: Use existing form styling with glassmorphism
- **File Upload**: Integrate with existing file upload patterns
- **Notifications**: Extend existing notification dropdown for chat alerts

**Responsive Chat Design:**
- **Desktop**: Sidebar + main chat area layout
- **Tablet**: Collapsible sidebar with overlay
- **Mobile**: Full-screen chat with navigation drawer

---

## Task 0.4: WebSocket Architecture Design ✅

### Message Broker Strategy
**Phase 1: Simple In-Memory Broker**
- Use Spring's built-in simple message broker
- Suitable for single-server deployment
- No external dependencies required
- Easy to implement and debug

**Future Scaling: External Message Broker**
- Plan migration to RabbitMQ for multi-server deployment
- Support for message persistence and reliability
- Better scalability for high-traffic scenarios
- Message routing across server instances

### Connection Management Strategy
**Session-Based Connection Tracking:**
```java
// Connection mapping structure
Map<String, Set<String>> userSessions; // userId -> Set of sessionIds
Map<String, String> sessionUsers;      // sessionId -> userId
Map<String, String> sessionRooms;      // sessionId -> current roomId
```

**Connection Lifecycle:**
1. **Connect**: Authenticate user, map session to user ID
2. **Subscribe**: Join specific chat rooms based on permissions
3. **Heartbeat**: Maintain connection with periodic ping/pong
4. **Disconnect**: Clean up session mappings, notify room participants

**Security Integration:**
- Leverage existing Spring Security authentication
- Validate user permissions for each room subscription
- Implement session timeout and cleanup
- Rate limiting per user/session

### Message Routing Logic
**Room-Based Routing:**
```
/topic/chat/{roomId}           - Room-specific messages
/topic/chat/{roomId}/typing    - Typing indicators
/user/queue/notifications      - Personal notifications
/app/chat/send                 - Send message endpoint
/app/chat/typing               - Typing indicator endpoint
```

**Message Flow:**
1. **Send Message**: Client → `/app/chat/send` → Validate → Persist → Broadcast to `/topic/chat/{roomId}`
2. **Typing Indicator**: Client → `/app/chat/typing` → Broadcast to `/topic/chat/{roomId}/typing`
3. **Notifications**: Server → `/user/queue/notifications` → Specific user

**Role-Based Access Control:**
- Validate user permissions before allowing room subscription
- Filter messages based on user's branch and role
- Implement room-level moderation capabilities

### WebSocket Configuration Design
**Endpoint Configuration:**
```java
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        config.enableSimpleBroker("/topic", "/user");
        config.setApplicationDestinationPrefixes("/app");
        config.setUserDestinationPrefix("/user");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws/chat")
                .setAllowedOriginPatterns("*")
                .withSockJS();
    }
}
```

**Security Configuration:**
```java
@Configuration
public class WebSocketSecurityConfig {

    @Bean
    public AuthorizationManager<Message<?>> messageAuthorizationManager() {
        // Implement message-level authorization
    }
}
```

### Scalability Considerations
**Current Architecture (Phase 1):**
- Single server deployment
- In-memory session management
- Simple message broker
- Suitable for 100+ concurrent users

**Future Scaling (Phase 2+):**
- Load balancer with sticky sessions
- Redis for shared session storage
- RabbitMQ for message distribution
- Horizontal scaling capability

### Error Handling & Resilience
**Connection Resilience:**
- Automatic reconnection on client side
- Message queuing for temporary disconnections
- Graceful degradation to polling if WebSocket fails

**Error Scenarios:**
- Network interruptions
- Server restarts
- Invalid message formats
- Permission violations
- Rate limit exceeded

---

## Task 0.5: Database Schema Design ✅

### Chat Rooms Table
```sql
CREATE TABLE [dbo].[chat_rooms](
    [room_id] [int] IDENTITY(1,1) NOT NULL,
    [room_name] [nvarchar](100) NOT NULL,
    [room_type] [nvarchar](20) NOT NULL, -- 'DIRECT', 'GROUP', 'BRANCH'
    [branch_id] [int] NULL,
    [created_by] [int] NOT NULL,
    [created_at] [datetime2] DEFAULT GETDATE(),
    [updated_at] [datetime2] DEFAULT GETDATE(),
    [is_active] [bit] DEFAULT 1,
    [room_description] [nvarchar](500) NULL,
    [max_participants] [int] DEFAULT 50,
    CONSTRAINT [PK_chat_rooms] PRIMARY KEY ([room_id]),
    CONSTRAINT [FK_chat_rooms_branch] FOREIGN KEY ([branch_id])
        REFERENCES [dbo].[branches]([branch_id]),
    CONSTRAINT [FK_chat_rooms_creator] FOREIGN KEY ([created_by])
        REFERENCES [dbo].[users]([user_id])
);
```

### Chat Participants Table
```sql
CREATE TABLE [dbo].[chat_participants](
    [participant_id] [int] IDENTITY(1,1) NOT NULL,
    [room_id] [int] NOT NULL,
    [user_id] [int] NOT NULL,
    [joined_at] [datetime2] DEFAULT GETDATE(),
    [last_read_at] [datetime2] NULL,
    [is_active] [bit] DEFAULT 1,
    [role] [nvarchar](20) DEFAULT 'MEMBER', -- 'ADMIN', 'MODERATOR', 'MEMBER'
    [notifications_enabled] [bit] DEFAULT 1,
    CONSTRAINT [PK_chat_participants] PRIMARY KEY ([participant_id]),
    CONSTRAINT [FK_chat_participants_room] FOREIGN KEY ([room_id])
        REFERENCES [dbo].[chat_rooms]([room_id]),
    CONSTRAINT [FK_chat_participants_user] FOREIGN KEY ([user_id])
        REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [UQ_chat_participants_room_user] UNIQUE([room_id], [user_id])
);
```

### Chat Messages Table
```sql
CREATE TABLE [dbo].[chat_messages](
    [message_id] [int] IDENTITY(1,1) NOT NULL,
    [room_id] [int] NOT NULL,
    [sender_id] [int] NOT NULL,
    [message_content] [nvarchar](4000) NOT NULL,
    [message_type] [nvarchar](20) DEFAULT 'TEXT', -- 'TEXT', 'FILE', 'IMAGE', 'SYSTEM'
    [file_url] [nvarchar](500) NULL,
    [file_name] [nvarchar](255) NULL,
    [file_size] [bigint] NULL,
    [reply_to_message_id] [int] NULL,
    [sent_at] [datetime2] DEFAULT GETDATE(),
    [edited_at] [datetime2] NULL,
    [is_deleted] [bit] DEFAULT 0,
    [is_system_message] [bit] DEFAULT 0,
    CONSTRAINT [PK_chat_messages] PRIMARY KEY ([message_id]),
    CONSTRAINT [FK_chat_messages_room] FOREIGN KEY ([room_id])
        REFERENCES [dbo].[chat_rooms]([room_id]),
    CONSTRAINT [FK_chat_messages_sender] FOREIGN KEY ([sender_id])
        REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_chat_messages_reply] FOREIGN KEY ([reply_to_message_id])
        REFERENCES [dbo].[chat_messages]([message_id])
);
```

### Performance Indexes
```sql
-- Room-based message queries (most common)
CREATE INDEX [IX_chat_messages_room_sent] ON [dbo].[chat_messages]
    ([room_id], [sent_at] DESC);

-- User-based message queries
CREATE INDEX [IX_chat_messages_sender_sent] ON [dbo].[chat_messages]
    ([sender_id], [sent_at] DESC);

-- Reply threading
CREATE INDEX [IX_chat_messages_reply] ON [dbo].[chat_messages]
    ([reply_to_message_id]);

-- Room management queries
CREATE INDEX [IX_chat_rooms_branch_active] ON [dbo].[chat_rooms]
    ([branch_id], [is_active]);

CREATE INDEX [IX_chat_rooms_type_active] ON [dbo].[chat_rooms]
    ([room_type], [is_active]);

-- Participant queries
CREATE INDEX [IX_chat_participants_user_active] ON [dbo].[chat_participants]
    ([user_id], [is_active]);

CREATE INDEX [IX_chat_participants_room_active] ON [dbo].[chat_participants]
    ([room_id], [is_active]);
```

### Data Retention & Cleanup Policies
**Message Retention:**
- **Active Messages**: Keep for 2 years for audit purposes
- **Deleted Messages**: Soft delete with audit trail
- **System Messages**: Keep indefinitely for compliance

**File Retention:**
- **Shared Files**: Keep for 1 year after last access
- **File Metadata**: Keep with message history
- **Cleanup Process**: Monthly automated cleanup job

**Cleanup Procedures:**
```sql
-- Archive old messages (older than 2 years)
CREATE PROCEDURE [dbo].[ArchiveOldChatMessages]
AS
BEGIN
    -- Move to archive table or mark for deletion
    UPDATE [dbo].[chat_messages]
    SET [is_deleted] = 1
    WHERE [sent_at] < DATEADD(YEAR, -2, GETDATE())
    AND [is_system_message] = 0;
END
```

### Integration with Existing Schema
**Foreign Key Relationships:**
- `chat_rooms.branch_id` → `branches.branch_id`
- `chat_rooms.created_by` → `users.user_id`
- `chat_participants.user_id` → `users.user_id`
- `chat_messages.sender_id` → `users.user_id`

**Naming Convention Compliance:**
- Table names: lowercase with underscores
- Column names: snake_case format
- Primary keys: `{table}_id` pattern
- Foreign keys: `{referenced_table}_id` pattern
- Boolean fields: `is_` prefix
- Timestamp fields: `_at` suffix

**Data Types Alignment:**
- IDs: `[int] IDENTITY(1,1)`
- Text: `[nvarchar]` for Unicode support (Vietnamese)
- Timestamps: `[datetime2]` for precision
- Booleans: `[bit]` with default values
- Large text: `[nvarchar](4000)` for message content

---

## Task 0.6: Security Integration Planning ✅

### WebSocket Authentication Flow
**Integration with Existing Spring Security:**
```java
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void configureClientInboundChannel(ChannelRegistration registration) {
        registration.interceptors(new ChannelInterceptor() {
            @Override
            public Message<?> preSend(Message<?> message, MessageChannel channel) {
                StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);

                if (StompCommand.CONNECT.equals(accessor.getCommand())) {
                    // Authenticate using existing Spring Security context
                    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
                    if (auth != null && auth.isAuthenticated()) {
                        accessor.setUser(auth);
                    } else {
                        throw new AccessDeniedException("Authentication required");
                    }
                }
                return message;
            }
        });
    }
}
```

**Session-Based Authentication:**
- Leverage existing HTTP session authentication
- No additional token management required
- Seamless integration with current login system
- Automatic session timeout handling

### Role-Based Access Control
**Chat Room Access Matrix:**
```
Room Type    | ADMIN | MANAGER | TECHNICIAN | RECEPTIONIST
-------------|-------|---------|------------|-------------
DIRECT       | ✓     | ✓       | ✓          | ✓
BRANCH       | ✓     | ✓(own)  | ✓(own)     | ✓(own)
GROUP        | ✓     | ✓(create)| ✓(join)   | ✓(join)
SYSTEM       | ✓     | ✗       | ✗          | ✗
```

**Permission Validation:**
```java
@Service
public class ChatSecurityService {

    public boolean canAccessRoom(User user, ChatRoom room) {
        switch (room.getRoomType()) {
            case "DIRECT":
                return isParticipant(user, room);
            case "BRANCH":
                return user.getBranch().equals(room.getBranch());
            case "GROUP":
                return isParticipant(user, room) || canJoinGroup(user, room);
            case "SYSTEM":
                return hasRole(user, "ADMIN");
            default:
                return false;
        }
    }

    public boolean canCreateRoom(User user, String roomType) {
        switch (roomType) {
            case "DIRECT":
                return true; // All staff can create direct messages
            case "BRANCH":
                return false; // Auto-created
            case "GROUP":
                return hasRole(user, "MANAGER");
            case "SYSTEM":
                return hasRole(user, "ADMIN");
            default:
                return false;
        }
    }
}
```

**Branch-Based Isolation:**
- Staff can only access chats within their assigned branch
- Managers can create group chats for their branch
- Cross-branch communication requires admin approval
- Branch transfers update chat access automatically

### Audit Logging Strategy
**Comprehensive Audit Trail:**
```java
@Entity
@Table(name = "chat_audit_log")
public class ChatAuditLog {
    private Integer auditId;
    private Integer userId;
    private String action; // "MESSAGE_SENT", "ROOM_CREATED", "USER_ADDED", etc.
    private Integer roomId;
    private Integer messageId;
    private String details; // JSON with additional context
    private String ipAddress;
    private String userAgent;
    private LocalDateTime timestamp;
}
```

**Logged Actions:**
- Message sending/editing/deletion
- Room creation/modification
- User joining/leaving rooms
- File uploads/downloads
- Permission changes
- Failed access attempts

**Audit Service Implementation:**
```java
@Service
public class ChatAuditService {

    public void logMessageSent(User user, ChatRoom room, ChatMessage message) {
        ChatAuditLog log = new ChatAuditLog();
        log.setUserId(user.getUserId());
        log.setAction("MESSAGE_SENT");
        log.setRoomId(room.getRoomId());
        log.setMessageId(message.getMessageId());
        log.setDetails(createMessageDetails(message));
        log.setTimestamp(LocalDateTime.now());
        auditRepository.save(log);
    }

    public void logRoomAccess(User user, ChatRoom room, String action) {
        // Log room access attempts
    }

    public void logSecurityViolation(User user, String violation, String details) {
        // Log security violations for monitoring
    }
}
```

### Rate Limiting & Abuse Prevention
**Message Rate Limiting:**
```java
@Component
public class ChatRateLimiter {
    private final Map<Integer, RateLimiter> userLimiters = new ConcurrentHashMap<>();

    public boolean allowMessage(Integer userId) {
        RateLimiter limiter = userLimiters.computeIfAbsent(userId,
            k -> RateLimiter.create(10.0)); // 10 messages per second
        return limiter.tryAcquire();
    }

    public boolean allowFileUpload(Integer userId) {
        // Separate rate limiting for file uploads
        return true; // Implement based on requirements
    }
}
```

**Abuse Prevention Measures:**
- Message content validation and sanitization
- File upload virus scanning
- Spam detection algorithms
- Automatic temporary bans for violations
- Manual moderation tools for managers

### Input Validation & Sanitization
**Message Content Validation:**
```java
@Service
public class MessageValidationService {

    public String sanitizeMessage(String content) {
        // Remove potentially harmful content
        // Preserve Vietnamese characters
        // Limit message length
        return Jsoup.clean(content, Whitelist.basic());
    }

    public boolean isValidFileType(String fileName) {
        String[] allowedTypes = {".jpg", ".png", ".gif", ".pdf", ".doc", ".docx"};
        return Arrays.stream(allowedTypes)
                .anyMatch(type -> fileName.toLowerCase().endsWith(type));
    }
}
```

**CSRF Protection:**
- Extend existing CSRF protection to WebSocket endpoints
- Validate CSRF tokens in WebSocket handshake
- Maintain token validation for REST API calls

### Monitoring & Alerting
**Security Monitoring:**
- Failed authentication attempts
- Unusual message patterns
- Large file uploads
- Cross-branch access attempts
- Rapid message sending (potential spam)

**Alert Triggers:**
- Multiple failed login attempts
- Suspicious file uploads
- Rate limit violations
- Security policy violations
- System errors or exceptions

---

## Task 0.7 & 0.8: Business Requirements Finalization ✅

### Chat Room Types & Access Rules

#### 1. Direct Messages (DIRECT)
**Purpose**: One-on-one communication between staff members
**Access Rules**:
- Any staff member can initiate direct messages
- Limited to users within the same branch
- Managers can message any staff in their branch
- Cross-branch direct messages require admin approval

**Auto-Creation Logic**:
```java
// Create direct message room when first message is sent
public ChatRoom createDirectMessageRoom(User user1, User user2) {
    // Validate both users are in same branch or user1 is manager
    if (!canCommunicateDirectly(user1, user2)) {
        throw new AccessDeniedException("Cross-branch communication not allowed");
    }

    ChatRoom room = new ChatRoom();
    room.setRoomType("DIRECT");
    room.setRoomName(user1.getFullName() + " & " + user2.getFullName());
    room.setCreatedBy(user1.getUserId());
    room.setBranch(user1.getBranch());
    return chatRoomRepository.save(room);
}
```

#### 2. Branch Group Chats (BRANCH)
**Purpose**: Branch-wide communication for all staff in a branch
**Access Rules**:
- Automatically created for each active branch
- All staff assigned to the branch are auto-participants
- Branch manager is the default administrator
- Used for announcements, coordination, and team discussions

**Auto-Creation & Management**:
```java
@EventListener
public void onBranchCreated(BranchCreatedEvent event) {
    ChatRoom branchRoom = new ChatRoom();
    branchRoom.setRoomType("BRANCH");
    branchRoom.setRoomName("Chi nhánh " + event.getBranch().getName());
    branchRoom.setBranch(event.getBranch());
    branchRoom.setCreatedBy(event.getBranch().getManagerId());

    // Add all branch staff as participants
    List<User> branchStaff = userRepository.findActiveUsersByBranch(event.getBranch().getBranchId());
    for (User staff : branchStaff) {
        addParticipant(branchRoom, staff, "MEMBER");
    }
}
```

#### 3. Department-Specific Chats (GROUP)
**Purpose**: Role-based communication within a branch
**Access Rules**:
- Created by branch managers for specific roles
- Examples: "Technicians - Chi nhánh 1", "Receptionists - Chi nhánh 2"
- Participants added based on role and branch
- Used for role-specific training, updates, and coordination

**Creation Examples**:
- "Kỹ thuật viên - Chi nhánh Quận 1" (Technicians - District 1 Branch)
- "Lễ tân - Chi nhánh Quận 7" (Receptionists - District 7 Branch)
- "Quản lý - Toàn hệ thống" (Managers - System-wide)

#### 4. System Alert Channels (SYSTEM)
**Purpose**: Company-wide announcements and emergency communications
**Access Rules**:
- Created only by system administrators
- All users are automatically participants
- Read-only for non-admin users
- Used for system maintenance, policy updates, emergency alerts

### User Interaction Workflows

#### Manager-to-Staff Communication Flows
**Daily Operations**:
1. **Direct Instructions**: Manager → Staff (Direct messages)
2. **Team Announcements**: Manager → Branch group chat
3. **Role-Specific Updates**: Manager → Department group chat
4. **Performance Feedback**: Manager → Staff (Direct messages)

**Workflow Example**:
```
Manager needs to update work schedule:
1. Open branch group chat
2. Send announcement: "Lịch làm việc tuần tới đã được cập nhật..."
3. Tag specific staff if needed: "@TechnicianName"
4. Follow up with direct messages for individual clarifications
```

#### Staff-to-Staff Communication Rules
**Peer Communication**:
- Direct messages between colleagues in same branch
- Group discussions in department chats
- File sharing for work-related documents
- Coordination for customer appointments

**Escalation Path**:
```
Staff Issue → Peer Discussion → Department Group → Manager (Direct) → Admin (if needed)
```

#### Cross-Branch Communication Policies
**Restricted Access**:
- Staff cannot directly message staff from other branches
- Managers can communicate across branches
- System-wide communications through admin channels only

**Approval Process for Cross-Branch**:
1. Staff requests cross-branch communication through manager
2. Manager evaluates business need
3. Manager facilitates communication or escalates to admin
4. Admin can create temporary cross-branch groups if needed

#### Escalation & Moderation Workflows
**Moderation Hierarchy**:
```
Level 1: Peer self-moderation
Level 2: Department group moderation (senior staff)
Level 3: Manager moderation (branch level)
Level 4: Admin intervention (system level)
```

**Moderation Actions**:
- **Warning**: Informal reminder about communication policies
- **Message Deletion**: Remove inappropriate content
- **Temporary Mute**: Restrict posting for specified period
- **Room Removal**: Remove user from specific chat rooms
- **Account Suspension**: Escalate to admin for serious violations

**Escalation Triggers**:
- Inappropriate language or behavior
- Sharing confidential information
- Harassment or discrimination
- Spam or excessive messaging
- Technical issues or system abuse

### Vietnamese Language Communication Standards
**Message Guidelines**:
- Professional Vietnamese language required
- Respectful tone in all communications
- Clear and concise messaging
- Proper use of titles and honorifics

**Common Phrases & Templates**:
- "Chào anh/chị" - Professional greeting
- "Cảm ơn anh/chị" - Thank you
- "Xin lỗi vì sự bất tiện" - Apology for inconvenience
- "Vui lòng xác nhận" - Please confirm

### Emergency Communication Protocols
**Urgent Message Types**:
- Customer emergencies
- Equipment failures
- Safety incidents
- Schedule changes
- System outages

**Emergency Escalation**:
1. **Immediate**: Direct message to manager
2. **Branch Alert**: Branch group notification
3. **System Alert**: Admin system-wide announcement
4. **External**: Phone/email backup if chat unavailable

---

## Phase 0 Completion Summary ✅

All Phase 0 analysis and planning tasks have been completed:

✅ **Task 0.1**: User entity and role system analysis
✅ **Task 0.2**: Notification system integration analysis
✅ **Task 0.3**: UI/UX patterns analysis
✅ **Task 0.4**: WebSocket architecture design
✅ **Task 0.5**: Database schema design
✅ **Task 0.6**: Security integration planning
✅ **Task 0.7**: Chat room types and rules definition
✅ **Task 0.8**: User interaction workflows definition

**Ready to proceed to Phase 1: Core Chat Infrastructure**
