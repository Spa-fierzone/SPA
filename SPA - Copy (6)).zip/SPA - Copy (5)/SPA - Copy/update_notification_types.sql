-- =============================================
-- Update Notification Types for Chat Module
-- Add new chat notification types to the CHECK constraint
-- =============================================

USE [spa_management];
GO

-- First, let's check the current constraint
SELECT 
    cc.name AS constraint_name,
    cc.definition
FROM sys.check_constraints cc
INNER JOIN sys.tables t ON cc.parent_object_id = t.object_id
WHERE t.name = 'notifications' AND cc.name LIKE '%type%';

-- Drop the existing CHECK constraint
DECLARE @ConstraintName NVARCHAR(128);
SELECT @ConstraintName = cc.name
FROM sys.check_constraints cc
INNER JOIN sys.tables t ON cc.parent_object_id = t.object_id
WHERE t.name = 'notifications' AND cc.name LIKE '%type%';

IF @ConstraintName IS NOT NULL
BEGIN
    DECLARE @SQL NVARCHAR(MAX) = 'ALTER TABLE [dbo].[notifications] DROP CONSTRAINT [' + @ConstraintName + ']';
    EXEC sp_executesql @SQL;
    PRINT 'Dropped constraint: ' + @ConstraintName;
END

-- Create new CHECK constraint with chat notification types
ALTER TABLE [dbo].[notifications] 
ADD CONSTRAINT [CK_notifications_type] 
CHECK ([type] IN (
    'SCHEDULE_CHANGE',
    'APPOINTMENT_UPDATE', 
    'TREATMENT_RECORD_UPDATE',
    'USER_ROLE_CHANGE',
    'PASSWORD_CHANGE',
    'SYSTEM_ALERT',
    'REMINDER',
    'APPROVAL_REQUEST',
    'GENERAL',
    'CHAT_MESSAGE',
    'CHAT_MENTION',
    'CHAT_ROOM_INVITE'
));

PRINT 'Added new CHECK constraint with chat notification types';

-- Verify the new constraint
SELECT 
    cc.name AS constraint_name,
    cc.definition
FROM sys.check_constraints cc
INNER JOIN sys.tables t ON cc.parent_object_id = t.object_id
WHERE t.name = 'notifications' AND cc.name = 'CK_notifications_type';

PRINT 'Notification types constraint updated successfully!';
GO
