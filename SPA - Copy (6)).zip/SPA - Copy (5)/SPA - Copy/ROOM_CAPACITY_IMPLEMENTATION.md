# Room Capacity Management Implementation

## Tổng quan
Đã thực hiện tính năng tự động trừ capacity trong room khi tạo appointment và hoàn lại capacity khi hủy/xóa appointment.

## Các thay đổi đã thực hiện

### 1. RoomService.java
**Thêm các methods:**
- `autoAssignRoom()` - Tự động assign room có capacity > 0
- `decreaseCapacity()` - Giảm capacity của room đi 1
- `increaseCapacity()` - Tăng capacity của room lên 1
- `hasAvailableCapacity()` - Kiểm tra room có capacity khả dụng không

### 2. AppointmentServiceImpl.java
**Cập nhật methods:**
- `create()` - Thêm logic auto-assign room và decrease capacity
- `createAppointment()` - Thêm logic auto-assign room và decrease capacity
- `update()` - Handle capacity khi room được thay đổi
- `cancelAppointment()` - Hoàn lại capacity khi hủy appointment
- `deleteAppointment()` - Hoàn lại capacity khi xóa appointment

**Thêm annotations:**
- `@Transactional` để đảm bảo data consistency

### 3. AppointmentService.java
**Thêm interface methods:**
- `cancelAppointment(Integer appointmentId, String cancellationReason)`
- `deleteAppointment(Integer appointmentId)`

### 4. AppointmentController.java
**Thêm endpoints:**
- `POST /appointments/cancel/{id}` - Hủy appointment
- `POST /appointments/delete/{id}` - Xóa appointment

### 5. ReceptionController.java
**Thêm endpoint:**
- `POST /reception/appointments/{id}/cancel` - Receptionist có thể hủy appointment
**Cập nhật logic:**
- Checkout appointment tự động hoàn lại room capacity

### 6. RoomRepository.java
**Cập nhật queries:**
- `findAvailableRooms()` - Chỉ trả về rooms có capacity > 0
- `findOneAvailableRoom()` - Chỉ trả về room có capacity > 0

## Logic hoạt động

### Khi tạo appointment:
1. Kiểm tra xem appointment đã có room chưa
2. Nếu chưa có room, tự động assign room khả dụng có capacity > 0
3. Validate room có capacity khả dụng không
4. Save appointment
5. Decrease capacity của room đi 1

### Khi hủy appointment:
1. Tìm appointment theo ID
2. Nếu appointment có room, increase capacity của room lên 1
3. Cập nhật status thành "cancelled"
4. Lưu cancellation reason

### Khi xóa appointment:
1. Tìm appointment theo ID
2. Nếu appointment có room, increase capacity của room lên 1
3. Xóa appointment khỏi database

### Khi checkout appointment:
1. Tìm appointment theo ID
2. Nếu appointment có room, increase capacity của room lên 1
3. Cập nhật checkout time và status thành "CHECKED_OUT"

### Khi cập nhật appointment:
1. So sánh room cũ và room mới
2. Nếu room thay đổi:
   - Hoàn lại capacity cho room cũ
   - Kiểm tra và trừ capacity cho room mới
3. Nếu room được assign lần đầu: trừ capacity
4. Nếu room bị remove: hoàn lại capacity

## Validation và Error Handling
- Kiểm tra room có tồn tại không
- Kiểm tra room có capacity khả dụng không
- Kiểm tra room thuộc đúng branch không
- Throw exception với message rõ ràng khi có lỗi
- Sử dụng @Transactional để rollback khi có lỗi

## Testing
Đã tạo `RoomCapacityTest.java` với các test cases:
- `testCreateAppointmentWithAutoAssignRoom()` - Test auto-assign room
- `testCreateAppointmentWithNoAvailableRoom()` - Test khi không có room khả dụng
- `testCreateAppointmentWithRoomNoCapacity()` - Test khi room hết capacity
- `testCancelAppointmentRestoresCapacity()` - Test restore capacity khi hủy
- `testDeleteAppointmentRestoresCapacity()` - Test restore capacity khi xóa
- `testCheckOutRestoresCapacity()` - Test restore capacity khi checkout

Đã tạo `ReceptionControllerTest.java` với các test cases:
- `testCancelAppointmentSuccess()` - Test receptionist hủy appointment thành công
- `testCancelAppointmentFailure()` - Test receptionist hủy appointment thất bại
- `testCheckOutAppointment()` - Test receptionist checkout appointment

Tất cả tests đã pass thành công.

## Các điểm cần lưu ý
1. Capacity được quản lý tự động, không cần can thiệp thủ công
2. Mọi thao tác đều được wrap trong transaction để đảm bảo consistency
3. Room chỉ được assign nếu có capacity > 0
4. Capacity được restore ngay lập tức khi appointment bị hủy/xóa
5. Hệ thống sẽ tự động chọn room khả dụng nếu không được chỉ định cụ thể

## Cách sử dụng

### Cho Customer/General:
1. **Tạo appointment:** Hệ thống tự động assign room và trừ capacity
2. **Hủy appointment:** Gọi endpoint `/appointments/cancel/{id}` với cancellation reason
3. **Xóa appointment:** Gọi endpoint `/appointments/delete/{id}`
4. **Cập nhật appointment:** Sử dụng method `update()` như bình thường, capacity sẽ được handle tự động

### Cho Receptionist:
1. **Tạo appointment:** Sử dụng `/reception/appointments/create` - tự động assign room và trừ capacity
2. **Hủy appointment:** Gọi endpoint `/reception/appointments/{id}/cancel` với cancellation reason
3. **Check-in appointment:** Sử dụng `/reception/appointments/{id}/checkin` - không ảnh hưởng capacity
4. **Check-out appointment:** Sử dụng `/reception/appointments/{id}/checkout` - tự động hoàn lại capacity

### Lưu ý quan trọng:
- **Check-out sẽ hoàn lại room capacity** - khách hàng đã sử dụng xong phòng
- **Cancel sẽ hoàn lại room capacity** - lịch hẹn bị hủy, phòng có thể được sử dụng cho khách khác
- **Check-in không ảnh hưởng capacity** - chỉ xác nhận khách hàng đã đến
