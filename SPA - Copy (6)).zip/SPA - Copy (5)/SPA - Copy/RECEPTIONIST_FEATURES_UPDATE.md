# Receptionist Features Update

## Tổng quan
Đã thêm các chức năng cho receptionist có thể hủy lịch và tự động hoàn lại room capacity khi checkout.

## Các tính năng mới

### 1. Receptionist có thể hủy appointment
**Endpoint:** `POST /reception/appointments/{id}/cancel`
**Parameters:**
- `id` - ID của appointment cần hủy
- `cancellationReason` - Lý do hủy lịch

**Chức năng:**
- Hủy appointment và set status thành "cancelled"
- Tự động hoàn lại room capacity
- Cập nhật KPI metrics cho receptionist
- Hiển thị thông báo thành công/thất bại

### 2. Checkout tự động hoàn lại room capacity
**Endpoint:** `POST /reception/appointments/{id}/checkout`
**Chức năng:**
- Set checkout time và status thành "CHECKED_OUT"
- **Tự động hoàn lại room capacity** (tính năng mới)
- Khách hàng đã sử dụng xong phòng, phòng có thể được assign cho appointment khác

## Logic hoạt động

### Khi receptionist hủy appointment:
1. Gọi `appointmentService.cancelAppointment()`
2. Service tự động:
   - Hoàn lại room capacity (+1)
   - Set status thành "cancelled"
   - Lưu cancellation reason
3. Cập nhật KPI metrics cho receptionist
4. Redirect về trang appointments với thông báo

### Khi receptionist checkout appointment:
1. Gọi `appointmentService.checkOut()`
2. Service tự động:
   - **Hoàn lại room capacity (+1)** (tính năng mới)
   - Set checkout time
   - Set status thành "CHECKED_OUT"
3. Redirect về trang appointments

## Files đã thay đổi

### 1. ReceptionController.java
- Thêm method `cancelAppointment()` với endpoint `/reception/appointments/{id}/cancel`
- Method checkout hiện tại không thay đổi, nhưng logic bên trong service đã được cập nhật

### 2. AppointmentServiceImpl.java
- Cập nhật method `checkOut()` để hoàn lại room capacity
- Thêm `@Transactional` để đảm bảo data consistency

### 3. Testing
- Thêm test `testCheckOutRestoresCapacity()` trong `RoomCapacityTest.java`
- Tạo `ReceptionControllerTest.java` với 3 test cases cho receptionist features

## Lợi ích

### 1. Quản lý capacity hiệu quả
- Room capacity được hoàn lại ngay khi khách hàng checkout
- Không cần chờ đến cuối ngày để reset capacity
- Tối ưu hóa việc sử dụng phòng

### 2. Quyền hạn cho receptionist
- Receptionist có thể hủy appointment khi cần thiết
- Tự động handle capacity, không cần can thiệp thủ công
- KPI được cập nhật tự động

### 3. Data consistency
- Sử dụng `@Transactional` để đảm bảo atomicity
- Nếu có lỗi, toàn bộ operation sẽ được rollback
- Capacity luôn chính xác

## Cách sử dụng

### Hủy appointment:
```
POST /reception/appointments/123/cancel
Body: cancellationReason=Customer request
```

### Checkout appointment:
```
POST /reception/appointments/123/checkout
```

## Kết quả
- ✅ Receptionist có thể hủy appointment và hoàn lại capacity
- ✅ Checkout tự động hoàn lại room capacity
- ✅ Tất cả tests pass thành công
- ✅ Data consistency được đảm bảo
- ✅ KPI tracking hoạt động đúng

## Lưu ý
- Checkout sẽ hoàn lại capacity ngay lập tức
- Cancel cũng hoàn lại capacity ngay lập tức
- Check-in không ảnh hưởng đến capacity (chỉ xác nhận khách đã đến)
- Capacity được quản lý tự động, không cần can thiệp thủ công
