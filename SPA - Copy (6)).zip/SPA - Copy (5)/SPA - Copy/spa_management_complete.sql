-- =============================================
-- SPA MANAGEMENT SYSTEM - COMPLETE DATABASE SCRIPT
-- Description: Creates database, tables, relationships, and sample data
-- Date: 2025-07-12
-- =============================================

-- Drop database if exists and create new one
USE [master]
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = N'spa_management')
BEGIN
    ALTER DATABASE [spa_management] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
    DROP DATABASE [spa_management]
END
GO

-- Create Database
CREATE DATABASE [spa_management]

GO

-- Use the created database
USE [spa_management]
GO

-- =============================================
-- SEQUENCES
-- =============================================

-- Sequence for appointment_handled table
CREATE SEQUENCE [dbo].[appointment_handled_seq]
    AS [bigint]
    START WITH 1
    INCREMENT BY 50
    MINVALUE -9223372036854775808
    MAXVALUE 9223372036854775807
    CACHE
GO

-- =============================================
-- CORE TABLES CREATION
-- =============================================

-- =============================================
-- 1. ROLES TABLE (Referenced by other tables)
-- =============================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[roles](
    [role_id] [int] IDENTITY(1,1) NOT NULL,
    [role_name] [nvarchar](50) NOT NULL,
    [description] [nvarchar](255) NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_roles] PRIMARY KEY CLUSTERED ([role_id] ASC),
    CONSTRAINT [UK_roles_role_name] UNIQUE ([role_name])
) ON [PRIMARY]
GO

-- =============================================
-- 2. BRANCHES TABLE (Referenced by other tables)
-- =============================================
CREATE TABLE [dbo].[branches](
    [branch_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](255) NOT NULL,
    [address] [nvarchar](255) NULL,
    [phone] [nvarchar](255) NULL,
    [email] [nvarchar](255) NULL,
    [manager_id] [int] NULL,
    [opening_hours] [nvarchar](255) NULL,
    [operating_hours] [nvarchar](255) NULL,
    [holiday_schedule] [nvarchar](255) NULL,
    [capacity] [int] NULL,
    [status] [nvarchar](255) DEFAULT 'ACTIVE',
    [is_active] [bit] DEFAULT 1,
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_branches] PRIMARY KEY CLUSTERED ([branch_id] ASC)
) ON [PRIMARY]
GO

-- =============================================
-- 3. SERVICE CATEGORIES TABLE
-- =============================================
CREATE TABLE [dbo].[service_categories](
    [category_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](255) NOT NULL,
    [description] [nvarchar](4000) NULL,
    [parent_category_id] [int] NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_service_categories] PRIMARY KEY CLUSTERED ([category_id] ASC),
    CONSTRAINT [FK_service_categories_parent] FOREIGN KEY ([parent_category_id]) REFERENCES [dbo].[service_categories]([category_id])
) ON [PRIMARY]
GO

-- =============================================
-- 4. USERS TABLE (Customers, Technicians, Managers, etc.)
-- =============================================
CREATE TABLE [dbo].[users](
    [user_id] [int] IDENTITY(1,1) NOT NULL,
    [username] [nvarchar](50) NOT NULL,
    [password] [nvarchar](255) NOT NULL,
    [email] [nvarchar](100) NOT NULL,
    [full_name] [nvarchar](100) NOT NULL,
    [phone] [nvarchar](20) NULL,
    [date_of_birth] [date] NULL,
    [gender] [nvarchar](10) NULL,
    [address] [nvarchar](4000) NULL,
    [status] [nvarchar](20) DEFAULT 'ACTIVE',
    [enabled] [bit] DEFAULT 1,
    [verification_token] [nvarchar](255) NULL,
    [verification_token_expiry] [datetime] NULL,
    [reset_password_token] [nvarchar](255) NULL,
    [reset_password_token_expiry] [datetime] NULL,
    [last_login] [datetime] NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    [last_check_in] [datetime] NULL,
    [last_check_out] [datetime] NULL,
    [total_working_hours] [decimal](10, 2) NULL,
    [performance_score] [decimal](5, 2) NULL,
    [vip_level] [nvarchar](20) NULL,
    [total_spent] [decimal](10, 2) NULL,
    [last_visit_date] [datetime] NULL,
    [preferred_branch_id] [int] NULL,
    [last_password_change] [datetime] NULL,
    [email_verified] [bit] DEFAULT 0,
    [phone_verified] [bit] DEFAULT 0,
    [two_factor_enabled] [bit] DEFAULT 0,
    [two_factor_secret] [nvarchar](100) NULL,
    [login_attempts] [int] DEFAULT 0,
    [last_login_attempt] [datetime] NULL,
    [profile_picture] [nvarchar](255) NULL,
    [otp_code] [nvarchar](10) NULL,
    [otp_expiry] [datetime2](6) NULL,
    [branch_id] [int] NULL,
    [base_salary] [numeric](10, 2) NULL,
    CONSTRAINT [PK_users] PRIMARY KEY CLUSTERED ([user_id] ASC),
    CONSTRAINT [UK_users_username] UNIQUE ([username]),
    CONSTRAINT [UK_users_email] UNIQUE ([email]),
    CONSTRAINT [FK_users_branch] FOREIGN KEY ([branch_id]) REFERENCES [dbo].[branches]([branch_id]),
    CONSTRAINT [FK_users_preferred_branch] FOREIGN KEY ([preferred_branch_id]) REFERENCES [dbo].[branches]([branch_id])
) ON [PRIMARY]
GO

-- =============================================
-- 5. USER ROLES JUNCTION TABLE
-- =============================================
CREATE TABLE [dbo].[user_roles](
    [user_id] [int] NOT NULL,
    [role_id] [int] NOT NULL,
    [assigned_at] [datetime] DEFAULT GETDATE(),
    [assigned_by] [int] NULL,
    CONSTRAINT [PK_user_roles] PRIMARY KEY CLUSTERED ([user_id] ASC, [role_id] ASC),
    CONSTRAINT [FK_user_roles_user] FOREIGN KEY ([user_id]) REFERENCES [dbo].[users]([user_id]) ON DELETE CASCADE,
    CONSTRAINT [FK_user_roles_role] FOREIGN KEY ([role_id]) REFERENCES [dbo].[roles]([role_id]) ON DELETE CASCADE,
    CONSTRAINT [FK_user_roles_assigned_by] FOREIGN KEY ([assigned_by]) REFERENCES [dbo].[users]([user_id])
) ON [PRIMARY]
GO

-- =============================================
-- 6. SERVICES TABLE
-- =============================================
CREATE TABLE [dbo].[services](
    [service_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](255) NOT NULL,
    [description] [nvarchar](4000) NULL,
    [duration] [int] NOT NULL, -- Duration in minutes
    [price] [numeric](38, 2) NOT NULL,
    [category_id] [int] NULL,
    [image_url] [nvarchar](255) NULL,
    [status] [nvarchar](255) DEFAULT 'ACTIVE',
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_services] PRIMARY KEY CLUSTERED ([service_id] ASC),
    CONSTRAINT [FK_services_category] FOREIGN KEY ([category_id]) REFERENCES [dbo].[service_categories]([category_id])
) ON [PRIMARY]
GO

-- =============================================
-- 7. ROOMS TABLE
-- =============================================
CREATE TABLE [dbo].[rooms](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](100) NOT NULL,
    [description] [nvarchar](1000) NULL,
    [capacity] [int] NULL,
    [status] [nvarchar](20) DEFAULT 'AVAILABLE',
    [branch_id] [int] NOT NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_rooms] PRIMARY KEY CLUSTERED ([id] ASC),
    CONSTRAINT [FK_rooms_branch] FOREIGN KEY ([branch_id]) REFERENCES [dbo].[branches]([branch_id])
) ON [PRIMARY]
GO

-- =============================================
-- 8. APPOINTMENTS TABLE
-- =============================================
CREATE TABLE [dbo].[appointments](
    [appointment_id] [int] IDENTITY(1,1) NOT NULL,
    [customer_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [service_id] [int] NOT NULL,
    [technician_id] [int] NULL,
    [room_id] [int] NULL,
    [appointment_date] [datetime2](6) NOT NULL,
    [start_time] [datetime2](6) NOT NULL,
    [end_time] [datetime2](6) NOT NULL,
    [status] [nvarchar](255) DEFAULT 'SCHEDULED',
    [notes] [nvarchar](4000) NULL,
    [special_requests] [nvarchar](4000) NULL,
    [cancellation_reason] [nvarchar](4000) NULL,
    [preferred_technician_id] [int] NULL,
    [reminder_sent] [bit] DEFAULT 0,
    [reminder_sent_at] [datetime] NULL,
    [reminder_method] [nvarchar](255) NULL,
    [check_in_time] [datetime] NULL,
    [check_out_time] [datetime] NULL,
    [checkin_time] [datetime2](6) NULL,
    [checkout_time] [datetime2](6) NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_appointments] PRIMARY KEY CLUSTERED ([appointment_id] ASC),
    CONSTRAINT [FK_appointments_customer] FOREIGN KEY ([customer_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_appointments_branch] FOREIGN KEY ([branch_id]) REFERENCES [dbo].[branches]([branch_id]),
    CONSTRAINT [FK_appointments_service] FOREIGN KEY ([service_id]) REFERENCES [dbo].[services]([service_id]),
    CONSTRAINT [FK_appointments_technician] FOREIGN KEY ([technician_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_appointments_room] FOREIGN KEY ([room_id]) REFERENCES [dbo].[rooms]([id]),
    CONSTRAINT [FK_appointments_preferred_technician] FOREIGN KEY ([preferred_technician_id]) REFERENCES [dbo].[users]([user_id])
) ON [PRIMARY]
GO

-- =============================================
-- 9. APPOINTMENT HANDLED TABLE
-- =============================================
CREATE TABLE [dbo].[appointment_handled](
    [id] [bigint] NOT NULL DEFAULT NEXT VALUE FOR [dbo].[appointment_handled_seq],
    [handled_at] [datetime2](6) DEFAULT GETDATE(),
    [appointment_appointment_id] [int] NULL,
    [receptionist_user_id] [int] NULL,
    CONSTRAINT [PK_appointment_handled] PRIMARY KEY CLUSTERED ([id] ASC),
    CONSTRAINT [FK_appointment_handled_appointment] FOREIGN KEY ([appointment_appointment_id]) REFERENCES [dbo].[appointments]([appointment_id]),
    CONSTRAINT [FK_appointment_handled_receptionist] FOREIGN KEY ([receptionist_user_id]) REFERENCES [dbo].[users]([user_id])
) ON [PRIMARY]
GO

-- =============================================
-- 10. ATTENDANCES TABLE
-- =============================================
CREATE TABLE [dbo].[attendances](
    [attendance_id] [int] IDENTITY(1,1) NOT NULL,
    [user_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [work_date] [date] NOT NULL,
    [check_in_time] [datetime2](6) NULL,
    [check_out_time] [datetime2](6) NULL,
    [break_start] [datetime2](6) NULL,
    [break_end] [datetime2](6) NULL,
    [total_hours] [numeric](5, 2) NULL,
    [overtime_hours] [numeric](5, 2) NULL,
    [late_minutes] [int] NULL,
    [early_leave_minutes] [int] NULL,
    [status] [nvarchar](20) DEFAULT 'PRESENT',
    [ip_address] [nvarchar](45) NULL,
    [location] [nvarchar](255) NULL,
    [notes] [nvarchar](4000) NULL,
    [created_at] [datetime2](6) DEFAULT GETDATE(),
    [updated_at] [datetime2](6) DEFAULT GETDATE(),
    CONSTRAINT [PK_attendances] PRIMARY KEY CLUSTERED ([attendance_id] ASC),
    CONSTRAINT [FK_attendances_user] FOREIGN KEY ([user_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_attendances_branch] FOREIGN KEY ([branch_id]) REFERENCES [dbo].[branches]([branch_id])
) ON [PRIMARY]
GO

-- =============================================
-- 11. USER KPI TABLE
-- =============================================
CREATE TABLE [dbo].[user_kpi](
    [kpi_id] [int] IDENTITY(1,1) NOT NULL,
    [technician_id] [int] NOT NULL,
    [manager_id] [int] NOT NULL,
    [year] [int] NOT NULL,
    [month] [int] NOT NULL,
    [target_appointments] [int] NOT NULL,
    [actual_appointments] [int] NULL DEFAULT 0,
    [status] [nvarchar](20) DEFAULT 'ACTIVE',
    [created_at] [datetime2](6) NOT NULL DEFAULT GETDATE(),
    [updated_at] [datetime2](6) NOT NULL DEFAULT GETDATE(),
    CONSTRAINT [PK_user_kpi] PRIMARY KEY CLUSTERED ([kpi_id] ASC),
    CONSTRAINT [FK_user_kpi_technician] FOREIGN KEY ([technician_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_user_kpi_manager] FOREIGN KEY ([manager_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [UK_user_kpi_unique] UNIQUE ([technician_id], [year], [month])
) ON [PRIMARY]
GO

-- =============================================
-- 12. INVOICES TABLE
-- =============================================
CREATE TABLE [dbo].[invoices](
    [invoice_id] [int] IDENTITY(1,1) NOT NULL,
    [invoice_number] [nvarchar](255) NULL,
    [appointment_id] [int] NULL,
    [customer_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [total_amount] [numeric](38, 2) NULL,
    [discount_amount] [numeric](38, 2) NULL,
    [tax_amount] [numeric](38, 2) NULL,
    [final_amount] [numeric](38, 2) NULL,
    [payment_status] [nvarchar](255) DEFAULT 'PENDING',
    [payment_method] [nvarchar](255) NULL,
    [payment_date] [datetime] NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_invoices] PRIMARY KEY CLUSTERED ([invoice_id] ASC),
    CONSTRAINT [FK_invoices_appointment] FOREIGN KEY ([appointment_id]) REFERENCES [dbo].[appointments]([appointment_id]),
    CONSTRAINT [FK_invoices_customer] FOREIGN KEY ([customer_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_invoices_branch] FOREIGN KEY ([branch_id]) REFERENCES [dbo].[branches]([branch_id])
) ON [PRIMARY]
GO

-- =============================================
-- 13. SERVICE RATING TABLE
-- =============================================
CREATE TABLE [dbo].[service_rating](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [customer_id] [int] NULL,
    [service_id] [int] NULL,
    [rating] [int] NOT NULL,
    [comment] [nvarchar](255) NULL,
    [created_at] [datetime2](6) DEFAULT GETDATE(),
    CONSTRAINT [PK_service_rating] PRIMARY KEY CLUSTERED ([id] ASC),
    CONSTRAINT [FK_service_rating_customer] FOREIGN KEY ([customer_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_service_rating_service] FOREIGN KEY ([service_id]) REFERENCES [dbo].[services]([service_id]),
    CONSTRAINT [CHK_service_rating_rating] CHECK ([rating] >= 1 AND [rating] <= 5)
) ON [PRIMARY]
GO

-- =============================================
-- FOREIGN KEY CONSTRAINTS (Added after table creation)
-- =============================================

-- Add foreign key constraint for branches.manager_id (references users table)
ALTER TABLE [dbo].[branches]
ADD CONSTRAINT [FK_branches_manager] FOREIGN KEY ([manager_id]) REFERENCES [dbo].[users]([user_id])
GO

-- =============================================
-- SAMPLE DATA INSERTION
-- =============================================

-- Insert Roles
INSERT INTO [dbo].[roles] ([role_name], [description]) VALUES
('ADMIN', 'System Administrator'),
('MANAGER', 'Branch Manager'),
('TECHNICIAN', 'Service Technician'),
('RECEPTIONIST', 'Front Desk Receptionist'),
('CUSTOMER', 'Customer/Client')
GO

-- Insert Branches (without manager_id first)
INSERT INTO [dbo].[branches] ([name], [address], [phone], [email], [opening_hours], [capacity], [status], [is_active]) VALUES
('Downtown Spa', '123 Main Street, Downtown', '+1-555-0101', 'downtown@spa.com', '9:00 AM - 9:00 PM', 50, 'ACTIVE', 1),
('Uptown Wellness', '456 Oak Avenue, Uptown', '+1-555-0102', 'uptown@spa.com', '8:00 AM - 8:00 PM', 40, 'ACTIVE', 1),
('Suburban Retreat', '789 Pine Road, Suburbs', '+1-555-0103', 'suburban@spa.com', '10:00 AM - 7:00 PM', 30, 'ACTIVE', 1)
GO

-- Insert Service Categories
INSERT INTO [dbo].[service_categories] ([name], [description]) VALUES
('Facial Treatments', 'Various facial care and beauty treatments'),
('Body Treatments', 'Full body wellness and therapeutic treatments'),
('Massage Therapy', 'Relaxation and therapeutic massage services'),
('Hair Services', 'Hair styling, cutting, and treatment services'),
('Nail Care', 'Manicure, pedicure, and nail art services')
GO

-- Insert Services
INSERT INTO [dbo].[services] ([name], [description], [duration], [price], [category_id], [status]) VALUES
('Classic Facial', 'Deep cleansing facial with moisturizing treatment', 60, 75.00, 1, 'ACTIVE'),
('Anti-Aging Facial', 'Advanced facial treatment for mature skin', 90, 120.00, 1, 'ACTIVE'),
('Swedish Massage', 'Relaxing full body massage', 60, 85.00, 3, 'ACTIVE'),
('Deep Tissue Massage', 'Therapeutic massage for muscle tension', 90, 110.00, 3, 'ACTIVE'),
('Hot Stone Massage', 'Relaxing massage with heated stones', 75, 95.00, 3, 'ACTIVE'),
('Body Wrap', 'Detoxifying full body treatment', 120, 150.00, 2, 'ACTIVE'),
('Manicure', 'Complete nail care and polish', 45, 35.00, 5, 'ACTIVE'),
('Pedicure', 'Foot care and nail treatment', 60, 45.00, 5, 'ACTIVE'),
('Hair Cut & Style', 'Professional hair cutting and styling', 75, 65.00, 4, 'ACTIVE'),
('Hair Color', 'Professional hair coloring service', 120, 120.00, 4, 'ACTIVE')
GO

-- Insert Users (Admin, Managers, Technicians, Receptionists, Customers)
INSERT INTO [dbo].[users] ([username], [password], [email], [full_name], [phone], [gender], [status], [enabled], [branch_id], [base_salary]) VALUES
-- Admin
('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'admin@spa.com', 'System Administrator', '+1-555-0001', 'Other', 'ACTIVE', 1, 1, 5000.00),
-- Managers
('manager1', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'manager1@spa.com', 'John Manager', '+1-555-0011', 'Male', 'ACTIVE', 1, 1, 4000.00),
('manager2', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'manager2@spa.com', 'Sarah Wilson', '+1-555-0012', 'Female', 'ACTIVE', 1, 2, 4000.00),
-- Technicians
('tech1', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'tech1@spa.com', 'Emily Johnson', '+1-555-0021', 'Female', 'ACTIVE', 1, 1, 2500.00),
('tech2', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'tech2@spa.com', 'Michael Brown', '+1-555-0022', 'Male', 'ACTIVE', 1, 1, 2500.00),
('tech3', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'tech3@spa.com', 'Lisa Davis', '+1-555-0023', 'Female', 'ACTIVE', 1, 2, 2500.00),
-- Receptionists
('reception1', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'reception1@spa.com', 'Anna Smith', '+1-555-0031', 'Female', 'ACTIVE', 1, 1, 2000.00),
('reception2', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'reception2@spa.com', 'David Lee', '+1-555-0032', 'Male', 'ACTIVE', 1, 2, 2000.00),
-- Customers
('customer1', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'customer1@email.com', 'Jennifer White', '+1-555-0101', 'Female', 'ACTIVE', 1, NULL, NULL),
('customer2', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'customer2@email.com', 'Robert Taylor', '+1-555-0102', 'Male', 'ACTIVE', 1, NULL, NULL),
('customer3', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'customer3@email.com', 'Maria Garcia', '+1-555-0103', 'Female', 'ACTIVE', 1, NULL, NULL)
GO

-- Insert User Roles
INSERT INTO [dbo].[user_roles] ([user_id], [role_id]) VALUES
(1, 1), -- admin -> ADMIN
(2, 2), -- manager1 -> MANAGER
(3, 2), -- manager2 -> MANAGER
(4, 3), -- tech1 -> TECHNICIAN
(5, 3), -- tech2 -> TECHNICIAN
(6, 3), -- tech3 -> TECHNICIAN
(7, 4), -- reception1 -> RECEPTIONIST
(8, 4), -- reception2 -> RECEPTIONIST
(9, 5), -- customer1 -> CUSTOMER
(10, 5), -- customer2 -> CUSTOMER
(11, 5) -- customer3 -> CUSTOMER
GO

-- Update branches with manager_id
UPDATE [dbo].[branches] SET [manager_id] = 2 WHERE [branch_id] = 1
UPDATE [dbo].[branches] SET [manager_id] = 3 WHERE [branch_id] = 2
UPDATE [dbo].[branches] SET [manager_id] = 2 WHERE [branch_id] = 3
GO

-- Insert Rooms
INSERT INTO [dbo].[rooms] ([name], [description], [capacity], [status], [branch_id]) VALUES
('Room 1A', 'Facial treatment room with natural lighting', 1, 'AVAILABLE', 1),
('Room 1B', 'Massage therapy room with relaxing ambiance', 1, 'AVAILABLE', 1),
('Room 1C', 'Multi-purpose treatment room', 1, 'AVAILABLE', 1),
('Room 2A', 'Premium spa suite', 1, 'AVAILABLE', 2),
('Room 2B', 'Couples massage room', 2, 'AVAILABLE', 2),
('Room 3A', 'Standard treatment room', 1, 'AVAILABLE', 3)
GO

-- Insert Sample Appointments
INSERT INTO [dbo].[appointments] ([customer_id], [branch_id], [service_id], [technician_id], [room_id], [appointment_date], [start_time], [end_time], [status], [notes]) VALUES
(9, 1, 1, 4, 1, '2025-07-15', '2025-07-15 10:00:00', '2025-07-15 11:00:00', 'SCHEDULED', 'First time customer'),
(10, 1, 3, 5, 2, '2025-07-15', '2025-07-15 14:00:00', '2025-07-15 15:00:00', 'SCHEDULED', 'Regular customer'),
(11, 2, 2, 6, 4, '2025-07-16', '2025-07-16 11:00:00', '2025-07-16 12:30:00', 'SCHEDULED', 'Anti-aging treatment'),
(9, 1, 7, 4, 1, '2025-07-17', '2025-07-17 09:00:00', '2025-07-17 09:45:00', 'COMPLETED', 'Manicure completed successfully'),
(10, 1, 4, 5, 2, '2025-07-18', '2025-07-18 16:00:00', '2025-07-18 17:30:00', 'SCHEDULED', 'Deep tissue massage')
GO

-- Insert Sample Invoices
INSERT INTO [dbo].[invoices] ([invoice_number], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method]) VALUES
('INV-2025-001', 4, 9, 1, 35.00, 0.00, 3.50, 38.50, 'PAID', 'CREDIT_CARD'),
('INV-2025-002', 1, 9, 1, 75.00, 7.50, 6.75, 74.25, 'PENDING', NULL),
('INV-2025-003', 2, 10, 1, 85.00, 0.00, 8.50, 93.50, 'PENDING', NULL)
GO

-- Insert Service Ratings
INSERT INTO [dbo].[service_rating] ([customer_id], [service_id], [rating], [comment]) VALUES
(9, 7, 5, 'Excellent manicure service, very professional'),
(10, 3, 4, 'Great massage, very relaxing'),
(11, 2, 5, 'Amazing anti-aging facial, highly recommend')
GO

-- Insert User KPI Records
INSERT INTO [dbo].[user_kpi] ([technician_id], [manager_id], [year], [month], [target_appointments], [actual_appointments], [status]) VALUES
(4, 2, 2025, 7, 50, 15, 'ACTIVE'),
(5, 2, 2025, 7, 45, 12, 'ACTIVE'),
(6, 3, 2025, 7, 40, 8, 'ACTIVE'),
(4, 2, 2025, 6, 50, 48, 'COMPLETED'),
(5, 2, 2025, 6, 45, 52, 'COMPLETED'),
(6, 3, 2025, 6, 40, 38, 'COMPLETED')
GO

-- Insert Attendance Records
INSERT INTO [dbo].[attendances] ([user_id], [branch_id], [work_date], [check_in_time], [check_out_time], [total_hours], [status]) VALUES
(4, 1, '2025-07-14', '2025-07-14 09:00:00', '2025-07-14 17:00:00', 8.00, 'PRESENT'),
(5, 1, '2025-07-14', '2025-07-14 10:05:00', '2025-07-14 18:00:00', 7.92, 'PRESENT'),
(6, 2, '2025-07-14', '2025-07-14 08:00:00', '2025-07-14 16:00:00', 8.00, 'PRESENT'),
(7, 1, '2025-07-14', '2025-07-14 08:00:00', '2025-07-14 16:00:00', 8.00, 'PRESENT'),
(8, 2, '2025-07-14', '2025-07-14 12:00:00', '2025-07-14 20:00:00', 8.00, 'PRESENT')
GO

-- Insert Appointment Handled Records
INSERT INTO [dbo].[appointment_handled] ([handled_at], [appointment_appointment_id], [receptionist_user_id]) VALUES
('2025-07-14 09:30:00', 4, 7),
('2025-07-14 10:00:00', 1, 7),
('2025-07-14 14:00:00', 2, 7)
GO

-- =============================================
-- INDEXES FOR PERFORMANCE
-- =============================================

-- Indexes on frequently queried columns
CREATE INDEX [IX_appointments_date] ON [dbo].[appointments] ([appointment_date])
GO
CREATE INDEX [IX_appointments_status] ON [dbo].[appointments] ([status])
GO
CREATE INDEX [IX_appointments_customer] ON [dbo].[appointments] ([customer_id])
GO
CREATE INDEX [IX_appointments_technician] ON [dbo].[appointments] ([technician_id])
GO
CREATE INDEX [IX_user_kpi_technician_date] ON [dbo].[user_kpi] ([technician_id], [year], [month])
GO
CREATE INDEX [IX_attendances_user_date] ON [dbo].[attendances] ([user_id], [work_date])
GO
CREATE INDEX [IX_invoices_customer] ON [dbo].[invoices] ([customer_id])
GO
CREATE INDEX [IX_invoices_status] ON [dbo].[invoices] ([payment_status])
GO

-- =============================================
-- COMPLETION MESSAGE
-- =============================================

PRINT '=================================================='
PRINT 'SPA MANAGEMENT DATABASE SETUP COMPLETED'
PRINT '=================================================='
PRINT 'Database: spa_management'
PRINT 'Tables Created: 13 core tables'
PRINT 'Sample Data: Inserted for all major entities'
PRINT 'Relationships: All foreign keys established'
PRINT 'Indexes: Performance indexes created'
PRINT '=================================================='
PRINT 'Ready for use!'
PRINT '=================================================='

-- Set database to read-write mode
USE [master]
GO
ALTER DATABASE [spa_management] SET READ_WRITE
GO
