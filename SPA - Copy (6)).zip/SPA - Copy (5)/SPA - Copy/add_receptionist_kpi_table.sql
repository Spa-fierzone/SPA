-- =============================================
-- ADD RECEPTIONIST KPI TABLE TO EXISTING DATABASE
-- Run this script on your existing spa_management database
-- =============================================

USE [spa_management]
GO

-- Check if table already exists
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='receptionist_kpi' AND xtype='U')
BEGIN
    PRINT 'Creating receptionist_kpi table...'
    
    -- Create sequence for receptionist_kpi table
    IF NOT EXISTS (SELECT * FROM sys.sequences WHERE name = 'receptionist_kpi_seq')
    BEGIN
        CREATE SEQUENCE [dbo].[receptionist_kpi_seq] 
            START WITH 1 
            INCREMENT BY 1 
            NO MAXVALUE 
            NO CYCLE 
            CACHE 1;
        PRINT 'Created sequence: receptionist_kpi_seq'
    END

    -- Create receptionist_kpi table
    CREATE TABLE [dbo].[receptionist_kpi](
        [kpi_id] [int] NOT NULL DEFAULT NEXT VALUE FOR [dbo].[receptionist_kpi_seq],
        [receptionist_id] [int] NOT NULL,
        [manager_id] [int] NOT NULL,
        [month] [int] NOT NULL,
        [year] [int] NOT NULL,
        
        -- Appointment Handling KPIs
        [target_appointments] [int] NOT NULL,
        [actual_appointments] [int] DEFAULT 0,
        [target_checkins] [int] NULL,
        [actual_checkins] [int] DEFAULT 0,
        [target_checkouts] [int] NULL,
        [actual_checkouts] [int] DEFAULT 0,
        
        -- Invoice and Revenue KPIs
        [target_invoices] [int] NULL,
        [actual_invoices] [int] DEFAULT 0,
        [target_revenue] [decimal](12, 2) NULL,
        [actual_revenue] [decimal](12, 2) DEFAULT 0,
        
        -- Performance Metrics
        [average_handling_time] [decimal](8, 2) NULL,
        [customer_satisfaction_score] [decimal](5, 2) NULL,
        [error_rate] [decimal](5, 2) NULL,
        
        -- System Fields
        [status] [nvarchar](20) DEFAULT 'active',
        [created_at] [datetime2](6) DEFAULT GETDATE(),
        [updated_at] [datetime2](6) DEFAULT GETDATE(),
        [notes] [nvarchar](1000) NULL,
        
        CONSTRAINT [PK_receptionist_kpi] PRIMARY KEY CLUSTERED ([kpi_id] ASC),
        CONSTRAINT [FK_receptionist_kpi_receptionist] FOREIGN KEY ([receptionist_id]) REFERENCES [dbo].[users]([user_id]),
        CONSTRAINT [FK_receptionist_kpi_manager] FOREIGN KEY ([manager_id]) REFERENCES [dbo].[users]([user_id]),
        CONSTRAINT [CHK_receptionist_kpi_month] CHECK ([month] >= 1 AND [month] <= 12),
        CONSTRAINT [CHK_receptionist_kpi_year] CHECK ([year] >= 2020 AND [year] <= 2030),
        CONSTRAINT [CHK_receptionist_kpi_targets] CHECK ([target_appointments] > 0),
        CONSTRAINT [CHK_receptionist_kpi_status] CHECK ([status] IN ('active', 'inactive')),
        CONSTRAINT [UQ_receptionist_kpi_month_year] UNIQUE ([receptionist_id], [month], [year])
    ) ON [PRIMARY]
    
    PRINT 'Created table: receptionist_kpi'

    -- Create indexes for better performance
    CREATE INDEX [IX_receptionist_kpi_receptionist_month_year] ON [dbo].[receptionist_kpi] ([receptionist_id], [month], [year]);
    CREATE INDEX [IX_receptionist_kpi_manager] ON [dbo].[receptionist_kpi] ([manager_id]);
    CREATE INDEX [IX_receptionist_kpi_month_year] ON [dbo].[receptionist_kpi] ([month], [year]);
    CREATE INDEX [IX_receptionist_kpi_status] ON [dbo].[receptionist_kpi] ([status]);
    
    PRINT 'Created indexes for receptionist_kpi table'

    -- Insert sample data for testing (only if there are users with appropriate roles)
    IF EXISTS (SELECT 1 FROM [dbo].[users] u JOIN [dbo].[user_roles] ur ON u.user_id = ur.user_id 
               JOIN [dbo].[roles] r ON ur.role_id = r.role_id WHERE r.role_name = 'RECEPTIONIST')
       AND EXISTS (SELECT 1 FROM [dbo].[users] u JOIN [dbo].[user_roles] ur ON u.user_id = ur.user_id 
                   JOIN [dbo].[roles] r ON ur.role_id = r.role_id WHERE r.role_name = 'MANAGER')
    BEGIN
        DECLARE @receptionist_id INT, @manager_id INT
        
        -- Get first receptionist
        SELECT TOP 1 @receptionist_id = u.user_id 
        FROM [dbo].[users] u 
        JOIN [dbo].[user_roles] ur ON u.user_id = ur.user_id 
        JOIN [dbo].[roles] r ON ur.role_id = r.role_id 
        WHERE r.role_name = 'RECEPTIONIST' AND u.status = 'active'
        
        -- Get first manager
        SELECT TOP 1 @manager_id = u.user_id 
        FROM [dbo].[users] u 
        JOIN [dbo].[user_roles] ur ON u.user_id = ur.user_id 
        JOIN [dbo].[roles] r ON ur.role_id = r.role_id 
        WHERE r.role_name = 'MANAGER' AND u.status = 'active'
        
        IF @receptionist_id IS NOT NULL AND @manager_id IS NOT NULL
        BEGIN
            INSERT INTO [dbo].[receptionist_kpi] (
                [receptionist_id], [manager_id], [month], [year], 
                [target_appointments], [actual_appointments], 
                [target_invoices], [actual_invoices], 
                [target_revenue], [actual_revenue],
                [status], [notes]
            ) VALUES
            (@receptionist_id, @manager_id, 7, 2024, 50, 45, 50, 42, 25000000, 21000000, 'active', 'Good performance, slightly below target'),
            (@receptionist_id, @manager_id, 6, 2024, 45, 48, 45, 46, 22500000, 23000000, 'active', 'Exceeded targets'),
            (@receptionist_id, @manager_id, 5, 2024, 40, 38, 40, 35, 20000000, 17500000, 'active', 'Below target, needs improvement')
            
            PRINT 'Inserted sample KPI data'
        END
        ELSE
        BEGIN
            PRINT 'No sample data inserted - missing receptionist or manager users'
        END
    END
    ELSE
    BEGIN
        PRINT 'No sample data inserted - missing required user roles'
    END

    PRINT 'Receptionist KPI table setup completed successfully!'
END
ELSE
BEGIN
    PRINT 'Table receptionist_kpi already exists - skipping creation'
END
GO

-- Verify the table was created
IF EXISTS (SELECT * FROM sysobjects WHERE name='receptionist_kpi' AND xtype='U')
BEGIN
    PRINT 'SUCCESS: receptionist_kpi table is ready for use'
    
    -- Show table structure
    SELECT 
        COLUMN_NAME,
        DATA_TYPE,
        IS_NULLABLE,
        COLUMN_DEFAULT
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'receptionist_kpi'
    ORDER BY ORDINAL_POSITION
END
ELSE
BEGIN
    PRINT 'ERROR: Failed to create receptionist_kpi table'
END
GO
