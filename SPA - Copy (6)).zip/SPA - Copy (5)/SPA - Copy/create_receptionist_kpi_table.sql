-- =============================================
-- RECEPTIONIST KPI TABLE CREATION SCRIPT
-- =============================================

-- Create sequence for receptionist_kpi table
CREATE SEQUENCE [dbo].[receptionist_kpi_seq] 
    START WITH 1 
    INCREMENT BY 1 
    NO MAXVALUE 
    NO CYCLE 
    CACHE 1;
GO

-- Create receptionist_kpi table
CREATE TABLE [dbo].[receptionist_kpi](
    [kpi_id] [int] NOT NULL DEFAULT NEXT VALUE FOR [dbo].[receptionist_kpi_seq],
    [receptionist_id] [int] NOT NULL,
    [manager_id] [int] NOT NULL,
    [month] [int] NOT NULL,
    [year] [int] NOT NULL,
    
    -- Appointment Handling KPIs
    [target_appointments] [int] NOT NULL,
    [actual_appointments] [int] DEFAULT 0,
    [target_checkins] [int] NULL,
    [actual_checkins] [int] DEFAULT 0,
    [target_checkouts] [int] NULL,
    [actual_checkouts] [int] DEFAULT 0,
    
    -- Invoice and Revenue KPIs
    [target_invoices] [int] NULL,
    [actual_invoices] [int] DEFAULT 0,
    [target_revenue] [decimal](12, 2) NULL,
    [actual_revenue] [decimal](12, 2) DEFAULT 0,
    
    -- Performance Metrics
    [average_handling_time] [decimal](8, 2) NULL,
    [customer_satisfaction_score] [decimal](5, 2) NULL,
    [error_rate] [decimal](5, 2) NULL,
    
    -- System Fields
    [status] [nvarchar](20) DEFAULT 'active',
    [created_at] [datetime2](6) DEFAULT GETDATE(),
    [updated_at] [datetime2](6) DEFAULT GETDATE(),
    [notes] [nvarchar](1000) NULL,
    
    CONSTRAINT [PK_receptionist_kpi] PRIMARY KEY CLUSTERED ([kpi_id] ASC),
    CONSTRAINT [FK_receptionist_kpi_receptionist] FOREIGN KEY ([receptionist_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_receptionist_kpi_manager] FOREIGN KEY ([manager_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [CHK_receptionist_kpi_month] CHECK ([month] >= 1 AND [month] <= 12),
    CONSTRAINT [CHK_receptionist_kpi_year] CHECK ([year] >= 2020 AND [year] <= 2030),
    CONSTRAINT [CHK_receptionist_kpi_targets] CHECK ([target_appointments] > 0),
    CONSTRAINT [CHK_receptionist_kpi_status] CHECK ([status] IN ('active', 'inactive')),
    CONSTRAINT [UQ_receptionist_kpi_month_year] UNIQUE ([receptionist_id], [month], [year])
) ON [PRIMARY]
GO

-- Create indexes for better performance
CREATE INDEX [IX_receptionist_kpi_receptionist_month_year] ON [dbo].[receptionist_kpi] ([receptionist_id], [month], [year]);
GO

CREATE INDEX [IX_receptionist_kpi_manager] ON [dbo].[receptionist_kpi] ([manager_id]);
GO

CREATE INDEX [IX_receptionist_kpi_month_year] ON [dbo].[receptionist_kpi] ([month], [year]);
GO

CREATE INDEX [IX_receptionist_kpi_status] ON [dbo].[receptionist_kpi] ([status]);
GO

-- Insert sample data for testing
INSERT INTO [dbo].[receptionist_kpi] (
    [receptionist_id], [manager_id], [month], [year], 
    [target_appointments], [actual_appointments], 
    [target_invoices], [actual_invoices], 
    [target_revenue], [actual_revenue],
    [status], [notes]
) VALUES
-- Sample KPIs for July 2024 (assuming user_id 7 is a receptionist and user_id 3 is a manager)
(7, 3, 7, 2024, 50, 45, 50, 42, 25000000, 21000000, 'active', 'Good performance, slightly below target'),
(7, 3, 6, 2024, 45, 48, 45, 46, 22500000, 23000000, 'active', 'Exceeded targets'),
(7, 3, 5, 2024, 40, 38, 40, 35, 20000000, 17500000, 'active', 'Below target, needs improvement');
GO

-- Create a view for easy KPI reporting
CREATE VIEW [dbo].[vw_receptionist_kpi_report] AS
SELECT 
    k.kpi_id,
    r.full_name AS receptionist_name,
    r.email AS receptionist_email,
    m.full_name AS manager_name,
    k.month,
    k.year,
    k.target_appointments,
    k.actual_appointments,
    CASE 
        WHEN k.target_appointments > 0 
        THEN CAST(k.actual_appointments * 100.0 / k.target_appointments AS DECIMAL(5,2))
        ELSE 0 
    END AS appointment_completion_percentage,
    k.target_invoices,
    k.actual_invoices,
    CASE 
        WHEN k.target_invoices > 0 
        THEN CAST(k.actual_invoices * 100.0 / k.target_invoices AS DECIMAL(5,2))
        ELSE 0 
    END AS invoice_completion_percentage,
    k.target_revenue,
    k.actual_revenue,
    CASE 
        WHEN k.target_revenue > 0 
        THEN CAST(k.actual_revenue * 100.0 / k.target_revenue AS DECIMAL(5,2))
        ELSE 0 
    END AS revenue_completion_percentage,
    -- Overall performance score (weighted average)
    CASE 
        WHEN k.target_appointments > 0 AND k.target_invoices > 0 AND k.target_revenue > 0
        THEN CAST(
            (k.actual_appointments * 100.0 / k.target_appointments * 0.4) +
            (k.actual_invoices * 100.0 / k.target_invoices * 0.3) +
            (k.actual_revenue * 100.0 / k.target_revenue * 0.3)
            AS DECIMAL(5,2))
        ELSE 0 
    END AS overall_performance_score,
    k.status,
    k.created_at,
    k.updated_at,
    k.notes
FROM [dbo].[receptionist_kpi] k
INNER JOIN [dbo].[users] r ON k.receptionist_id = r.user_id
INNER JOIN [dbo].[users] m ON k.manager_id = m.user_id;
GO

-- Create stored procedure for updating actual metrics
CREATE PROCEDURE [dbo].[sp_update_receptionist_kpi_metrics]
    @receptionist_id INT,
    @month INT,
    @year INT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @start_date DATETIME2, @end_date DATETIME2;
    DECLARE @actual_appointments INT, @actual_invoices INT, @actual_revenue DECIMAL(12,2);
    
    -- Calculate date range for the month
    SET @start_date = DATEFROMPARTS(@year, @month, 1);
    SET @end_date = EOMONTH(@start_date);
    
    -- Count actual appointments handled
    SELECT @actual_appointments = COUNT(*)
    FROM [dbo].[appointment_handled] ah
    WHERE ah.receptionist_user_id = @receptionist_id
      AND ah.handled_at >= @start_date 
      AND ah.handled_at <= @end_date;
    
    -- Count actual invoices created (this would need to be tracked separately)
    -- For now, we'll assume it's the same as appointments handled
    SET @actual_invoices = @actual_appointments;
    
    -- Calculate actual revenue (this would need to be tracked separately)
    -- For now, we'll use a default calculation
    SET @actual_revenue = @actual_appointments * 500000; -- 500k per appointment
    
    -- Update the KPI record
    UPDATE [dbo].[receptionist_kpi]
    SET actual_appointments = @actual_appointments,
        actual_invoices = @actual_invoices,
        actual_revenue = @actual_revenue,
        actual_checkins = @actual_appointments,
        actual_checkouts = @actual_appointments,
        updated_at = GETDATE()
    WHERE receptionist_id = @receptionist_id
      AND month = @month
      AND year = @year;
      
    -- Return the updated record
    SELECT * FROM [dbo].[vw_receptionist_kpi_report]
    WHERE receptionist_name = (SELECT full_name FROM [dbo].[users] WHERE user_id = @receptionist_id)
      AND month = @month
      AND year = @year;
END;
GO

-- Create function to get performance rating
CREATE FUNCTION [dbo].[fn_get_performance_rating](@performance_score DECIMAL(5,2))
RETURNS NVARCHAR(20)
AS
BEGIN
    DECLARE @rating NVARCHAR(20);
    
    IF @performance_score >= 90
        SET @rating = 'Excellent';
    ELSE IF @performance_score >= 75
        SET @rating = 'Good';
    ELSE IF @performance_score >= 60
        SET @rating = 'Needs Improvement';
    ELSE
        SET @rating = 'Poor';
    
    RETURN @rating;
END;
GO

-- Grant permissions (adjust as needed for your security model)
-- GRANT SELECT, INSERT, UPDATE, DELETE ON [dbo].[receptionist_kpi] TO [spa_app_role];
-- GRANT SELECT ON [dbo].[vw_receptionist_kpi_report] TO [spa_app_role];
-- GRANT EXECUTE ON [dbo].[sp_update_receptionist_kpi_metrics] TO [spa_app_role];
-- GRANT EXECUTE ON [dbo].[fn_get_performance_rating] TO [spa_app_role];

PRINT 'Receptionist KPI table and related objects created successfully!';
GO
