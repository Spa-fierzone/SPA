# Manager Room Management Implementation

## Tổng quan
Đã thực hiện chức năng cho manager quản lý room của branch mình, bao gồm CRUD operations và báo cáo capacity.

## Các tính năng đã thêm

### 1. ManagerRoomController
**Endpoint base:** `/manager/rooms`
**Security:** `@PreAuthorize("hasRole('MANAGER')")`

**Các endpoints:**
- `GET /manager/rooms` - Danh sách rooms của branch
- `GET /manager/rooms/create` - Form tạo room mới
- `POST /manager/rooms/create` - Xử lý tạo room
- `GET /manager/rooms/edit/{id}` - Form chỉnh sửa room
- `POST /manager/rooms/edit/{id}` - Xử lý cập nhật room
- `POST /manager/rooms/delete/{id}` - Xóa room
- `POST /manager/rooms/change-status/{id}` - Thay đổi trạng thái room
- `GET /manager/rooms/capacity-report` - Báo cáo capacity

### 2. Security và Validation
**Branch Validation:**
- Manager chỉ được quản lý rooms thuộc branch của mình
- Tự động lấy branch từ `user.getBranch()`
- Validate room thuộc branch trước mọi thao tác

**Capacity Validation:**
- Capacity phải > 0 khi tạo room
- Capacity không được âm khi cập nhật
- Hiển thị cảnh báo khi capacity thấp

### 3. Templates

#### `/manager/rooms.html`
- Dashboard với statistics cards
- Bảng danh sách rooms với thông tin chi tiết
- Dropdown thay đổi status nhanh
- Modal xác nhận xóa
- Responsive design với Bootstrap

#### `/manager/room-form.html`
- Form tạo/chỉnh sửa room
- Validation client-side và server-side
- Hướng dẫn sử dụng
- Auto-fill branch information

#### `/manager/room-capacity-report.html`
- Báo cáo tổng quan với charts
- Bảng chi tiết capacity từng phòng
- Progress bars hiển thị tỷ lệ sử dụng
- Khuyến nghị và cảnh báo

## Logic hoạt động

### Xác định Branch của Manager
```java
private Branch getManagerBranch(Authentication authentication) {
    User manager = userService.findByUsername(authentication.getName());
    return manager.getBranch();
}
```

### Validation Security
```java
private boolean isRoomInManagerBranch(Integer roomId, Branch managerBranch) {
    Room room = roomService.findById(roomId);
    return room != null && room.getBranch() != null && 
           room.getBranch().getBranchId().equals(managerBranch.getBranchId());
}
```

### Tạo Room
1. Validate manager có branch
2. Set room.branch = manager.branch
3. Validate capacity > 0
4. Set default status = "available"
5. Save room

### Cập nhật Room
1. Validate room thuộc branch của manager
2. Validate capacity >= 0
3. Giữ nguyên branch assignment
4. Save room

### Xóa Room
1. Validate room thuộc branch của manager
2. Lưu tên room để hiển thị message
3. Delete room
4. Hiển thị thông báo thành công

## Features nổi bật

### 1. Dashboard với Statistics
- Tổng số phòng
- Phòng khả dụng
- Phòng bảo trì
- Tổng capacity
- Real-time calculations

### 2. Quick Status Change
- Dropdown menu để thay đổi status nhanh
- Available, Maintenance, Unavailable
- Không cần vào form edit

### 3. Capacity Report
- Charts hiển thị phân bố status
- Bar chart capacity theo phòng
- Progress bars tỷ lệ sử dụng
- Khuyến nghị tối ưu hóa

### 4. Responsive Design
- Bootstrap 5 responsive layout
- Mobile-friendly interface
- Icon-rich UI với FontAwesome
- Consistent color scheme

## Security Features

### 1. Role-based Access
- Chỉ MANAGER role mới truy cập được
- `@PreAuthorize("hasRole('MANAGER')")`

### 2. Branch Isolation
- Manager chỉ thấy rooms của branch mình
- Không thể truy cập rooms của branch khác
- Tự động filter theo branch

### 3. Validation
- Server-side validation cho tất cả inputs
- Client-side validation với Bootstrap
- Error handling và user feedback

## Testing
**ManagerRoomControllerTest.java** - 10 test cases:
- `testListRooms()` - Test hiển thị danh sách rooms
- `testListRoomsWithoutBranch()` - Test manager chưa có branch
- `testShowCreateForm()` - Test form tạo room
- `testCreateRoom()` - Test tạo room thành công
- `testCreateRoomWithInvalidCapacity()` - Test validation capacity
- `testShowEditForm()` - Test form chỉnh sửa
- `testUpdateRoom()` - Test cập nhật room
- `testDeleteRoom()` - Test xóa room
- `testChangeRoomStatus()` - Test thay đổi status
- `testCapacityReport()` - Test báo cáo capacity

**Tất cả tests đã pass thành công.**

## Integration với Room Capacity System

### 1. Tương thích với Capacity Management
- Rooms được tạo với capacity ban đầu
- Capacity tự động giảm khi có appointment
- Capacity được restore khi checkout/cancel
- Manager có thể điều chỉnh capacity khi cần

### 2. Status Management
- Available: Có thể đặt lịch
- Maintenance: Tạm ngừng hoạt động
- Unavailable: Ngừng hoạt động hoàn toàn

### 3. Reporting
- Theo dõi capacity real-time
- Cảnh báo khi capacity thấp
- Khuyến nghị tối ưu hóa

## Cách sử dụng

### Cho Manager:
1. **Truy cập:** `/manager/rooms`
2. **Xem danh sách:** Tất cả rooms của branch
3. **Tạo room mới:** Click "Thêm phòng mới"
4. **Chỉnh sửa:** Click icon edit
5. **Thay đổi status:** Sử dụng dropdown
6. **Xóa room:** Click icon trash và xác nhận
7. **Xem báo cáo:** `/manager/rooms/capacity-report`

### Lưu ý:
- Manager phải được assign vào branch trước
- Chỉ có thể quản lý rooms của branch mình
- Capacity phải > 0 khi tạo room mới
- Xóa room sẽ không thể hoàn tác

## Kết quả
✅ Manager có thể quản lý rooms của branch mình
✅ Security đảm bảo isolation giữa các branch
✅ UI/UX thân thiện và responsive
✅ Integration hoàn hảo với capacity system
✅ Comprehensive testing với 10 test cases
✅ Real-time reporting và analytics
