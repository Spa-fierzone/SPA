# User Management Enhancement Implementation

## Overview
This implementation enhances the user management system to allow admins to select branch assignments when creating users and adds comprehensive validation for user creation/update operations.

## Features Implemented

### 1. Branch Selection for User Creation
- **Admin Branch Selection**: Admins can now select which branch to assign users to during creation
- **Role-Based Branch Requirements**: Branch assignment is required for staff roles (Manager, Technician, Receptionist) but not for customers
- **Dynamic UI**: Form fields show/hide based on selected role
- **Active Branch Validation**: Only active branches can be assigned to users

### 2. Comprehensive User Validation
- **Username Validation**: 3-50 characters, alphanumeric and underscore only, unique
- **Email Validation**: Valid format, case-insensitive uniqueness check
- **Phone Validation**: Vietnamese format (10-11 digits starting with 0), unique
- **Password Validation**: Uses existing PasswordValidator for strength requirements
- **Age Validation**: 18-65 years for employees
- **Role-Based Validation**: Different rules for staff vs customer roles
- **Salary Validation**: Role-specific salary ranges with Vietnamese currency formatting

### 3. Enhanced User Interface
- **Dynamic Form Fields**: Branch and salary fields show/hide based on role selection
- **Client-Side Validation**: JavaScript validation before form submission
- **Better Error Handling**: Vietnamese error messages with specific validation details
- **Improved UX**: Clear field labels, help text, and visual indicators

## Technical Implementation

### Backend Changes

#### 1. CreateUserDto Enhancement
```java
// Added branch selection field
private Integer branchId;
```

#### 2. UserValidationUtil (New)
Comprehensive validation utility with methods for:
- `validateUserForCreate(CreateUserDto)` - Full validation for new users
- `validateUserForUpdate(User, CreateUserDto)` - Validation for user updates
- Individual field validators for username, email, phone, etc.
- Role-specific business rules validation
- Vietnamese error messages

#### 3. UserValidationException (New)
Custom exception for user validation errors with HTTP 400 status.

#### 4. UserRepository Enhancement
```java
// Added case-insensitive email check
@Query("SELECT COUNT(u) > 0 FROM User u WHERE LOWER(TRIM(u.email)) = LOWER(TRIM(:email))")
boolean existsByEmailIgnoreCase(@Param("email") String email);

// Added phone number uniqueness check
@Query("SELECT COUNT(u) > 0 FROM User u WHERE u.phone = :phone")
boolean existsByPhone(@Param("phone") String phone);
```

#### 5. UserService Enhancement
- Updated `createUserWithRoleAndSalary()` with comprehensive validation
- Added `updateUser()` method for user updates
- Branch assignment logic for staff roles
- Improved error handling with Vietnamese messages

#### 6. UserController Enhancement
- Added `BranchService` dependency for branch selection
- Enhanced error handling with specific exception types
- Added update user endpoint
- Improved logging for admin actions

### Frontend Changes

#### 1. Enhanced User Management Form
- **Branch Selection Dropdown**: Populated with active branches
- **Role-Based Field Visibility**: Branch and salary fields show/hide based on role
- **Improved Field Labels**: Clear labels with required field indicators
- **Help Text**: Explanatory text for complex fields

#### 2. JavaScript Enhancements
```javascript
function updateSalaryAndBranch() {
    // Dynamic field visibility based on role selection
    // Automatic salary suggestions for staff roles
    // Required field validation
}

function validateUserForm() {
    // Client-side validation before submission
    // Vietnamese error messages
    // Role-specific validation rules
}
```

## Validation Rules

### Username
- **Length**: 3-50 characters
- **Format**: Alphanumeric and underscore only
- **Uniqueness**: Must be unique in system

### Email
- **Format**: Valid email format
- **Uniqueness**: Case-insensitive uniqueness check
- **Normalization**: Stored in lowercase

### Phone Number
- **Format**: Vietnamese format (10-11 digits starting with 0)
- **Pattern**: `^0[0-9]{9,10}$`
- **Uniqueness**: Must be unique if provided

### Age Requirements
- **Minimum Age**: 18 years for all employees
- **Maximum Age**: 65 years for all employees
- **Future Date Check**: Birth date cannot be in the future

### Role-Based Rules

#### Staff Roles (Manager, Technician, Receptionist)
- **Branch Assignment**: Required
- **Salary**: Required with role-specific ranges
  - Manager: 10M - 50M VNĐ
  - Technician: 8M - 25M VNĐ
  - Receptionist: 6M - 15M VNĐ

#### Customer Roles (Customer, VIP)
- **Branch Assignment**: Not allowed
- **Salary**: Not applicable

### Salary Validation
- **Minimum**: Must be greater than 0 for staff
- **Role-Specific Ranges**: Enforced based on role
- **Currency Format**: Vietnamese dong with proper formatting

## Database Schema Impact

### Existing Tables Used
- `users` table with `branch_id` foreign key
- `branches` table for branch selection
- `roles` table for role validation

### New Validation Queries
- Case-insensitive email uniqueness check
- Phone number uniqueness check
- Active branch validation

## Error Handling

### Validation Errors
- **UserValidationException**: Specific validation errors with Vietnamese messages
- **Field-Level Validation**: Individual field validation with clear error messages
- **Business Rule Validation**: Role-specific and cross-field validation

### User-Friendly Messages
```
Examples:
- "Tên đăng nhập 'username' đã tồn tại trong hệ thống"
- "Email 'email@domain.com' đã được sử dụng bởi tài khoản khác"
- "Số điện thoại phải có 10-11 chữ số và bắt đầu bằng số 0"
- "Nhân viên phải được phân công vào chi nhánh"
- "Lương quản lý phải từ 10,000,000 đến 50,000,000 VNĐ"
```

## Testing

### Unit Tests
- **UserValidationUtilTest**: Comprehensive test coverage for all validation rules
- **Edge Cases**: Testing boundary conditions and error scenarios
- **Role-Based Testing**: Validation for different user roles
- **Integration Testing**: End-to-end validation flow

### Test Coverage
- ✅ Username validation (format, length, uniqueness)
- ✅ Email validation (format, case-insensitive uniqueness)
- ✅ Phone validation (Vietnamese format, uniqueness)
- ✅ Age validation (minimum, maximum, future dates)
- ✅ Role validation (valid roles, business rules)
- ✅ Branch validation (staff requirements, customer restrictions)
- ✅ Salary validation (role-specific ranges, currency formatting)

## Usage Instructions

### For Admins:
1. **Creating Users**: Select role first, then branch and salary fields will appear/hide automatically
2. **Staff Users**: Must select a branch and enter appropriate salary
3. **Customer Users**: Branch and salary fields are hidden and not required
4. **Validation**: Form validates both client-side and server-side with clear error messages

### For Developers:
1. **Validation**: Use `UserValidationUtil` for consistent validation across the application
2. **Error Handling**: Catch `UserValidationException` for user-friendly error messages
3. **Branch Assignment**: Use `BranchService.findAllActive()` for branch selection
4. **Testing**: Follow existing test patterns in `UserValidationUtilTest`

## Security Considerations

### Data Validation
- **Input Sanitization**: All user inputs are trimmed and validated
- **SQL Injection Prevention**: Using parameterized queries
- **XSS Prevention**: Proper HTML escaping in templates

### Business Rules
- **Role-Based Access**: Different validation rules for different roles
- **Branch Security**: Only active branches can be assigned
- **Data Integrity**: Comprehensive uniqueness checks

## Future Enhancements

### Potential Improvements
- **Bulk User Import**: CSV/Excel import with validation
- **User Profile Pictures**: Image upload and validation
- **Advanced Role Management**: Custom role creation and permissions
- **Audit Trail**: Track user creation and modification history
- **Email Verification**: Send verification emails for new accounts

### Integration Opportunities
- **LDAP/Active Directory**: External authentication integration
- **SMS Verification**: Phone number verification via SMS
- **Two-Factor Authentication**: Enhanced security for admin accounts
