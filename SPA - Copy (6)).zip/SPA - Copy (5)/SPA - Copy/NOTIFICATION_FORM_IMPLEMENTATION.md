# Notification Form Implementation

## Tổng quan
Đã tạo form tạo thông báo cho Manager và Admin với 3 loại thông báo khác nhau: Team Notification, System Alert, và Individual Notification.

## Files đã tạo/cập nhật

### 1. Template Form
**File:** `src/main/resources/templates/notifications/create.html`
- Form tạo thông báo với 3 tabs
- Glassmorphism design phù hợp với theme SPA
- AJAX form submission
- Real-time validation và feedback

### 2. API Controller
**File:** `src/main/java/com/spazone/controller/api/UserApiController.java`
- `/api/users/list` - Lấy danh sách tất cả users
- `/api/users/by-role/{roleName}` - Lấy users theo role
- `/api/users/by-branch/{branchId}` - Lấy users theo branch

### 3. Notification Controller Updates
**File:** `src/main/java/com/spazone/controller/NotificationController.java`
- `GET /notifications/create` - Hiển thị form tạo thông báo
- `POST /notifications/individual` - Gửi thông báo cá nhân
- Cập nhật team notification để hỗ trợ actionUrl

### 4. Navigation Updates
**File:** `src/main/resources/templates/notifications/list.html`
- Thêm link "Tạo thông báo" trong navbar
- Thêm button "Tạo thông báo" trong header

## Các loại thông báo

### 1. Team Notification (Thông báo nhóm)
**Endpoint:** `POST /notifications/manager/team-notification`
**Quyền:** MANAGER, ADMIN
**Chức năng:** Gửi thông báo đến tất cả thành viên trong cùng branch

**Parameters:**
- `title` - Tiêu đề thông báo
- `message` - Nội dung thông báo
- `type` - Loại thông báo (GENERAL, SCHEDULE_CHANGE, REMINDER, APPROVAL_REQUEST)
- `actionUrl` - URL hành động (tùy chọn)

### 2. System Alert (Thông báo hệ thống)
**Endpoint:** `POST /notifications/manager/system-alert`
**Quyền:** MANAGER, ADMIN
**Chức năng:** Gửi thông báo hệ thống đến tất cả users hoặc users theo role

**Parameters:**
- `title` - Tiêu đề thông báo
- `message` - Nội dung thông báo
- `role` - Role nhận thông báo (tùy chọn, để trống = tất cả users)

### 3. Individual Notification (Thông báo cá nhân)
**Endpoint:** `POST /notifications/individual`
**Quyền:** MANAGER, ADMIN
**Chức năng:** Gửi thông báo đến một user cụ thể

**Parameters:**
- `title` - Tiêu đề thông báo
- `message` - Nội dung thông báo
- `type` - Loại thông báo (GENERAL, REMINDER, APPROVAL_REQUEST)
- `userId` - ID của user nhận thông báo
- `actionUrl` - URL hành động (tùy chọn)

## UI Features

### Form Design
- **Glassmorphism Style:** Phù hợp với theme SPA
- **Tabbed Interface:** 3 tabs cho 3 loại thông báo
- **Responsive Design:** Hoạt động tốt trên mobile và desktop
- **Real-time Validation:** Validate form trước khi submit

### Interactive Elements
- **Auto-complete User Selection:** Dropdown với search cho individual notification
- **Role-based Filtering:** Chỉ hiển thị form cho Manager/Admin
- **Action URL Support:** Tùy chọn thêm link hành động
- **Success/Error Alerts:** Feedback ngay lập tức sau khi gửi

### Form Validation
- **Required Fields:** Title, message, type
- **URL Validation:** ActionUrl phải là URL hợp lệ
- **User Selection:** Bắt buộc chọn user cho individual notification

## Security

### Authorization
- **Role-based Access:** Chỉ MANAGER và ADMIN có thể truy cập
- **Branch Restriction:** Team notification chỉ gửi trong cùng branch
- **User Verification:** Kiểm tra user tồn tại trước khi gửi

### Data Validation
- **Input Sanitization:** Validate tất cả input parameters
- **XSS Prevention:** Escape HTML trong message content
- **CSRF Protection:** Sử dụng Spring Security CSRF token

## API Endpoints Summary

| Method | Endpoint | Description | Access |
|--------|----------|-------------|---------|
| GET | `/notifications/create` | Hiển thị form tạo thông báo | MANAGER, ADMIN |
| POST | `/notifications/manager/team-notification` | Gửi thông báo nhóm | MANAGER, ADMIN |
| POST | `/notifications/manager/system-alert` | Gửi thông báo hệ thống | MANAGER, ADMIN |
| POST | `/notifications/individual` | Gửi thông báo cá nhân | MANAGER, ADMIN |
| GET | `/api/users/list` | Lấy danh sách users | MANAGER, ADMIN |
| GET | `/api/users/by-role/{role}` | Lấy users theo role | MANAGER, ADMIN |
| GET | `/api/users/by-branch/{branchId}` | Lấy users theo branch | MANAGER, ADMIN |

## Usage Examples

### 1. Team Notification
```javascript
// Gửi thông báo thay đổi lịch làm việc đến team
{
    title: "Thay đổi lịch làm việc",
    message: "Lịch làm việc tuần tới đã được cập nhật. Vui lòng kiểm tra lại.",
    type: "SCHEDULE_CHANGE",
    actionUrl: "/schedules/my-schedule"
}
```

### 2. System Alert
```javascript
// Gửi thông báo bảo trì hệ thống đến tất cả users
{
    title: "Bảo trì hệ thống",
    message: "Hệ thống sẽ bảo trì từ 2:00 - 4:00 sáng ngày mai.",
    role: "" // Gửi đến tất cả
}
```

### 3. Individual Notification
```javascript
// Gửi nhắc nhở cá nhân
{
    title: "Nhắc nhở hoàn thành báo cáo",
    message: "Bạn cần hoàn thành báo cáo tháng trước ngày 30.",
    type: "REMINDER",
    userId: 123,
    actionUrl: "/reports/monthly"
}
```

## Testing

### Manual Testing
1. **Access Control:** Verify chỉ Manager/Admin có thể truy cập form
2. **Form Validation:** Test required fields và URL validation
3. **Notification Delivery:** Verify thông báo được gửi đến đúng recipients
4. **UI Responsiveness:** Test trên các device khác nhau

### Integration Testing
1. **API Endpoints:** Test tất cả notification endpoints
2. **User Loading:** Test API lấy danh sách users
3. **Database Integration:** Verify notifications được lưu đúng
4. **Security:** Test authorization và input validation

## Future Enhancements

### Planned Features
1. **Scheduled Notifications:** Lên lịch gửi thông báo
2. **Template System:** Tạo template thông báo có sẵn
3. **Rich Text Editor:** WYSIWYG editor cho message content
4. **File Attachments:** Đính kèm file trong thông báo
5. **Push Notifications:** Real-time push notifications
6. **Email Integration:** Gửi thông báo qua email
7. **Notification Analytics:** Thống kê đọc/chưa đọc

### Technical Improvements
1. **WebSocket Integration:** Real-time notifications
2. **Caching:** Cache user lists và role data
3. **Batch Operations:** Gửi nhiều thông báo cùng lúc
4. **API Rate Limiting:** Giới hạn số lượng thông báo gửi
5. **Audit Logging:** Log tất cả notification activities

## Conclusion

Form tạo thông báo đã được implement hoàn chỉnh với:
- ✅ 3 loại thông báo khác nhau
- ✅ UI/UX thân thiện và responsive
- ✅ Security và validation đầy đủ
- ✅ API endpoints hoàn chỉnh
- ✅ Integration với hệ thống notification hiện tại

Hệ thống notification giờ đây cho phép Manager và Admin dễ dàng tạo và gửi thông báo đến users một cách hiệu quả và an toàn.
