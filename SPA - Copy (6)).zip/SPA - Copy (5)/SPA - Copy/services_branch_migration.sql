-- =============================================
-- SERVICES BRANCH RELATIONSHIP MIGRATION
-- Adds branch_id column to services table
-- =============================================

-- Check if the column already exists before adding it
IF NOT EXISTS (
    SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'services' 
    AND COLUMN_NAME = 'branch_id'
)
BEGIN
    -- Add branch_id column to services table
    ALTER TABLE [dbo].[services] 
    ADD [branch_id] [int] NULL;
    
    PRINT 'Added branch_id column to services table';
END
ELSE
BEGIN
    PRINT 'branch_id column already exists in services table';
END
GO

-- Update existing services to have a default branch (assuming branch ID 1 exists)
-- You may need to adjust this based on your actual branch data
UPDATE [dbo].[services] 
SET [branch_id] = 1 
WHERE [branch_id] IS NULL 
AND EXISTS (SELECT 1 FROM [dbo].[branches] WHERE [branch_id] = 1);
GO

-- Add foreign key constraint if it doesn't exist
IF NOT EXISTS (
    SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
    WHERE CONSTRAINT_NAME = 'FK_services_branch'
)
BEGIN
    ALTER TABLE [dbo].[services] 
    ADD CONSTRAINT [FK_services_branch] 
    FOREIGN KEY ([branch_id]) REFERENCES [dbo].[branches]([branch_id]);
    
    PRINT 'Added foreign key constraint FK_services_branch';
END
ELSE
BEGIN
    PRINT 'Foreign key constraint FK_services_branch already exists';
END
GO

-- Create index for better performance on branch queries
IF NOT EXISTS (
    SELECT * FROM sys.indexes 
    WHERE name = 'IX_services_branch_id' 
    AND object_id = OBJECT_ID('dbo.services')
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_services_branch_id] 
    ON [dbo].[services] ([branch_id]);
    
    PRINT 'Created index IX_services_branch_id';
END
ELSE
BEGIN
    PRINT 'Index IX_services_branch_id already exists';
END
GO

-- Update the main database script to reflect the new structure
-- Update sql.md file to include branch_id in services table
PRINT 'Migration completed successfully!';
PRINT 'Services now belong to branches and service names are unique within each branch.';
GO

-- Verification queries
PRINT 'Verification:';
SELECT 
    s.service_id,
    s.name AS service_name,
    b.name AS branch_name,
    s.status
FROM [dbo].[services] s
LEFT JOIN [dbo].[branches] b ON s.branch_id = b.branch_id
ORDER BY b.name, s.name;
GO
