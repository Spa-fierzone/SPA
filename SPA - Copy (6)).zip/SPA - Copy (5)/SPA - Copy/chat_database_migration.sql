-- =============================================
-- Chat Module Database Migration Script
-- SpaZone Real-time Chat System
-- Created: Phase 1 Implementation
-- =============================================

USE [spa_management];
GO

-- =============================================
-- 1. CHAT ROOMS TABLE
-- =============================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='chat_rooms' AND xtype='U')
BEGIN
    CREATE TABLE [dbo].[chat_rooms](
        [room_id] [int] IDENTITY(1,1) NOT NULL,
        [room_name] [nvarchar](100) NOT NULL,
        [room_type] [nvarchar](20) NOT NULL, -- 'DIRECT', 'GROUP', 'BRANCH', 'SYSTEM'
        [branch_id] [int] NULL,
        [created_by] [int] NOT NULL,
        [created_at] [datetime2] DEFAULT GETDATE(),
        [updated_at] [datetime2] DEFAULT GETDATE(),
        [is_active] [bit] DEFAULT 1,
        [room_description] [nvarchar](500) NULL,
        [max_participants] [int] DEFAULT 50,
        CONSTRAINT [PK_chat_rooms] PRIMARY KEY ([room_id]),
        CONSTRAINT [FK_chat_rooms_branch] FOREIGN KEY ([branch_id]) 
            REFERENCES [dbo].[branches]([branch_id]),
        CONSTRAINT [FK_chat_rooms_creator] FOREIGN KEY ([created_by]) 
            REFERENCES [dbo].[users]([user_id])
    );
    
    PRINT 'Created table: chat_rooms';
END
ELSE
BEGIN
    PRINT 'Table chat_rooms already exists';
END
GO

-- =============================================
-- 2. CHAT PARTICIPANTS TABLE
-- =============================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='chat_participants' AND xtype='U')
BEGIN
    CREATE TABLE [dbo].[chat_participants](
        [participant_id] [int] IDENTITY(1,1) NOT NULL,
        [room_id] [int] NOT NULL,
        [user_id] [int] NOT NULL,
        [joined_at] [datetime2] DEFAULT GETDATE(),
        [last_read_at] [datetime2] NULL,
        [is_active] [bit] DEFAULT 1,
        [role] [nvarchar](20) DEFAULT 'MEMBER', -- 'ADMIN', 'MODERATOR', 'MEMBER'
        [notifications_enabled] [bit] DEFAULT 1,
        CONSTRAINT [PK_chat_participants] PRIMARY KEY ([participant_id]),
        CONSTRAINT [FK_chat_participants_room] FOREIGN KEY ([room_id]) 
            REFERENCES [dbo].[chat_rooms]([room_id]),
        CONSTRAINT [FK_chat_participants_user] FOREIGN KEY ([user_id]) 
            REFERENCES [dbo].[users]([user_id]),
        CONSTRAINT [UQ_chat_participants_room_user] UNIQUE([room_id], [user_id])
    );
    
    PRINT 'Created table: chat_participants';
END
ELSE
BEGIN
    PRINT 'Table chat_participants already exists';
END
GO

-- =============================================
-- 3. CHAT MESSAGES TABLE
-- =============================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='chat_messages' AND xtype='U')
BEGIN
    CREATE TABLE [dbo].[chat_messages](
        [message_id] [int] IDENTITY(1,1) NOT NULL,
        [room_id] [int] NOT NULL,
        [sender_id] [int] NOT NULL,
        [message_content] [nvarchar](4000) NOT NULL,
        [message_type] [nvarchar](20) DEFAULT 'TEXT', -- 'TEXT', 'FILE', 'IMAGE', 'SYSTEM'
        [file_url] [nvarchar](500) NULL,
        [file_name] [nvarchar](255) NULL,
        [file_size] [bigint] NULL,
        [reply_to_message_id] [int] NULL,
        [sent_at] [datetime2] DEFAULT GETDATE(),
        [edited_at] [datetime2] NULL,
        [is_deleted] [bit] DEFAULT 0,
        [is_system_message] [bit] DEFAULT 0,
        CONSTRAINT [PK_chat_messages] PRIMARY KEY ([message_id]),
        CONSTRAINT [FK_chat_messages_room] FOREIGN KEY ([room_id]) 
            REFERENCES [dbo].[chat_rooms]([room_id]),
        CONSTRAINT [FK_chat_messages_sender] FOREIGN KEY ([sender_id]) 
            REFERENCES [dbo].[users]([user_id]),
        CONSTRAINT [FK_chat_messages_reply] FOREIGN KEY ([reply_to_message_id]) 
            REFERENCES [dbo].[chat_messages]([message_id])
    );
    
    PRINT 'Created table: chat_messages';
END
ELSE
BEGIN
    PRINT 'Table chat_messages already exists';
END
GO

-- =============================================
-- 4. PERFORMANCE INDEXES
-- =============================================

-- Room-based message queries (most common)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_chat_messages_room_sent')
BEGIN
    CREATE INDEX [IX_chat_messages_room_sent] ON [dbo].[chat_messages] 
        ([room_id], [sent_at] DESC);
    PRINT 'Created index: IX_chat_messages_room_sent';
END

-- User-based message queries
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_chat_messages_sender_sent')
BEGIN
    CREATE INDEX [IX_chat_messages_sender_sent] ON [dbo].[chat_messages] 
        ([sender_id], [sent_at] DESC);
    PRINT 'Created index: IX_chat_messages_sender_sent';
END

-- Reply threading
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_chat_messages_reply')
BEGIN
    CREATE INDEX [IX_chat_messages_reply] ON [dbo].[chat_messages] 
        ([reply_to_message_id]);
    PRINT 'Created index: IX_chat_messages_reply';
END

-- Room management queries
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_chat_rooms_branch_active')
BEGIN
    CREATE INDEX [IX_chat_rooms_branch_active] ON [dbo].[chat_rooms] 
        ([branch_id], [is_active]);
    PRINT 'Created index: IX_chat_rooms_branch_active';
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_chat_rooms_type_active')
BEGIN
    CREATE INDEX [IX_chat_rooms_type_active] ON [dbo].[chat_rooms] 
        ([room_type], [is_active]);
    PRINT 'Created index: IX_chat_rooms_type_active';
END

-- Participant queries
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_chat_participants_user_active')
BEGIN
    CREATE INDEX [IX_chat_participants_user_active] ON [dbo].[chat_participants] 
        ([user_id], [is_active]);
    PRINT 'Created index: IX_chat_participants_user_active';
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_chat_participants_room_active')
BEGIN
    CREATE INDEX [IX_chat_participants_room_active] ON [dbo].[chat_participants] 
        ([room_id], [is_active]);
    PRINT 'Created index: IX_chat_participants_room_active';
END

-- =============================================
-- 5. INITIAL DATA SETUP
-- =============================================

-- Create system-wide announcement room (if not exists)
IF NOT EXISTS (SELECT * FROM [dbo].[chat_rooms] WHERE [room_type] = 'SYSTEM' AND [room_name] = 'Thông báo hệ thống')
BEGIN
    DECLARE @adminUserId INT;
    SELECT TOP 1 @adminUserId = u.[user_id] FROM [dbo].[users] u
    INNER JOIN [dbo].[user_roles] ur ON u.[user_id] = ur.[user_id]
    INNER JOIN [dbo].[roles] r ON ur.[role_id] = r.[role_id]
    WHERE r.[role_name] = 'ADMIN' AND u.[status] = 'active';
    
    IF @adminUserId IS NOT NULL
    BEGIN
        INSERT INTO [dbo].[chat_rooms] ([room_name], [room_type], [created_by], [room_description], [max_participants])
        VALUES ('Thông báo hệ thống', 'SYSTEM', @adminUserId, 'Kênh thông báo chính thức của hệ thống SpaZone', 1000);
        
        PRINT 'Created system announcement room';
    END
END

-- Create branch-specific rooms for existing branches
DECLARE @branchId INT, @managerId INT, @branchName NVARCHAR(100);
DECLARE branch_cursor CURSOR FOR 
    SELECT [branch_id], [manager_id], [name] FROM [dbo].[branches] WHERE [status] = 'active';

OPEN branch_cursor;
FETCH NEXT FROM branch_cursor INTO @branchId, @managerId, @branchName;

WHILE @@FETCH_STATUS = 0
BEGIN
    -- Check if branch room already exists
    IF NOT EXISTS (SELECT * FROM [dbo].[chat_rooms] WHERE [room_type] = 'BRANCH' AND [branch_id] = @branchId)
    BEGIN
        INSERT INTO [dbo].[chat_rooms] ([room_name], [room_type], [branch_id], [created_by], [room_description])
        VALUES ('Chi nhánh ' + @branchName, 'BRANCH', @branchId, @managerId, 'Kênh thảo luận chính của chi nhánh ' + @branchName);
        
        PRINT 'Created branch room for: ' + @branchName;
    END
    
    FETCH NEXT FROM branch_cursor INTO @branchId, @managerId, @branchName;
END

CLOSE branch_cursor;
DEALLOCATE branch_cursor;

PRINT 'Chat module database migration completed successfully!';
GO
