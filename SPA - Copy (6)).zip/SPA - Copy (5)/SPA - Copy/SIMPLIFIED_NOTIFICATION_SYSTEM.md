# Simplified Notification System

## Overview
Đã cập nhật hệ thống notification để chỉ có 2 loại thông báo với phân quyền rõ ràng:
- **Team Notification** - Chỉ dành cho Manager
- **System Alert** - Chỉ dành cho Admin

## Changes Made

### 1. Removed Individual Notification
- ❌ Xóa tab "Thông báo cá nhân"
- ❌ Xóa endpoint `/notifications/individual`
- ❌ Xóa JavaScript functions liên quan
- ❌ Xóa UserApiController (không còn cần thiết)

### 2. Updated Role-based Access Control

#### **Manager Role:**
- ✅ **Team Notification Only**
- ✅ Endpoint: `POST /notifications/manager/team-notification`
- ✅ Gửi thông báo đến tất cả thành viên trong cùng branch
- ✅ Hỗ trợ action URL

#### **Admin Role:**
- ✅ **System Alert Only**
- ✅ Endpoint: `POST /notifications/manager/system-alert`
- ✅ Gửi thông báo đến tất cả users hoặc users theo role
- ✅ Broadcast system-wide notifications

### 3. UI Updates

#### **Form Tabs:**
```html
<!-- Manager sees this -->
<li sec:authorize="hasRole('MANAGER')">
    <button class="nav-link active" id="team-tab">
        <i class="fas fa-users me-2"></i>Thông báo nhóm
    </button>
</li>

<!-- Admin sees this -->
<li sec:authorize="hasRole('ADMIN')">
    <button class="nav-link active" id="system-tab">
        <i class="fas fa-broadcast-tower me-2"></i>Thông báo hệ thống
    </button>
</li>
```

#### **Tab Content:**
- **Manager:** Chỉ thấy Team Notification form
- **Admin:** Chỉ thấy System Alert form
- **Auto-active:** Tab tương ứng với role được active tự động

## API Endpoints

### Team Notification (Manager Only)
```
POST /notifications/manager/team-notification
Authorization: MANAGER role required

Parameters:
- title: String (required)
- message: String (required) 
- type: String (required) - GENERAL, SCHEDULE_CHANGE, REMINDER, APPROVAL_REQUEST
- actionUrl: String (optional)

Response:
{
    "status": "success",
    "message": "Thông báo nhóm đã được gửi thành công"
}
```

### System Alert (Admin Only)
```
POST /notifications/manager/system-alert
Authorization: ADMIN role required

Parameters:
- title: String (required)
- message: String (required)
- role: String (optional) - CUSTOMER, TECHNICIAN, RECEPTIONIST, MANAGER, ADMIN

Response:
{
    "status": "success", 
    "message": "Thông báo hệ thống đã được gửi thành công"
}
```

## Business Logic

### Team Notification Flow:
1. **Manager** accesses `/notifications/create`
2. Sees only "Thông báo nhóm" tab
3. Fills form with title, message, type, optional action URL
4. System sends notification to all users in same branch
5. Excludes sender from recipients

### System Alert Flow:
1. **Admin** accesses `/notifications/create`
2. Sees only "Thông báo hệ thống" tab
3. Fills form with title, message, optional role filter
4. System broadcasts to all users or filtered by role
5. Reaches all users across all branches

## Security Implementation

### Controller Level:
```java
// Team Notification - Manager Only
@PostMapping("/manager/team-notification")
@PreAuthorize("hasRole('MANAGER')")
public ResponseEntity<Map<String, String>> sendTeamNotification(...)

// System Alert - Admin Only  
@PostMapping("/manager/system-alert")
@PreAuthorize("hasRole('ADMIN')")
public ResponseEntity<Map<String, String>> sendSystemAlert(...)
```

### Template Level:
```html
<!-- Manager Tab -->
<div sec:authorize="hasRole('MANAGER')">
    Team Notification Form
</div>

<!-- Admin Tab -->
<div sec:authorize="hasRole('ADMIN')">
    System Alert Form
</div>
```

## User Experience

### Manager Experience:
1. Clicks "Tạo thông báo"
2. Sees clean form with team notification options
3. Can notify team about:
   - Schedule changes
   - General announcements
   - Reminders
   - Approval requests
4. Can add action links for follow-up

### Admin Experience:
1. Clicks "Tạo thông báo"
2. Sees system-wide notification form
3. Can broadcast to:
   - All users
   - Specific roles (Customer, Technician, etc.)
4. Handles system-wide communications

## Benefits of Simplified System

### 1. **Clear Role Separation:**
- ✅ Managers handle team communications
- ✅ Admins handle system-wide alerts
- ✅ No overlap or confusion

### 2. **Improved Security:**
- ✅ Strict role-based access control
- ✅ No unauthorized cross-team messaging
- ✅ Clear audit trail

### 3. **Better UX:**
- ✅ Single-purpose forms
- ✅ No complex user selection
- ✅ Faster notification creation

### 4. **Reduced Complexity:**
- ✅ Fewer endpoints to maintain
- ✅ Simpler permission logic
- ✅ Less code to test

## Files Modified

### Templates:
- `src/main/resources/templates/notifications/create.html`
  - Removed individual notification tab
  - Updated role-based tab visibility
  - Simplified JavaScript

### Controllers:
- `src/main/java/com/spazone/controller/NotificationController.java`
  - Updated role restrictions
  - Removed individual notification endpoint
  - Improved error messages

### Removed Files:
- `src/main/java/com/spazone/controller/api/UserApiController.java`
  - No longer needed for user selection

## Testing Scenarios

### Manager Testing:
1. ✅ Can access `/notifications/create`
2. ✅ Sees only team notification tab
3. ✅ Can send team notifications
4. ❌ Cannot access system alert features
5. ✅ Notifications reach team members only

### Admin Testing:
1. ✅ Can access `/notifications/create`
2. ✅ Sees only system alert tab
3. ✅ Can send system-wide notifications
4. ✅ Can filter by role
5. ✅ Notifications reach all users

### Security Testing:
1. ✅ Manager cannot POST to system-alert endpoint
2. ✅ Admin cannot POST to team-notification endpoint
3. ✅ Unauthorized users get 403 Forbidden
4. ✅ CSRF protection works correctly

## Future Considerations

### Potential Enhancements:
1. **Scheduled Notifications:** Time-delayed sending
2. **Notification Templates:** Pre-defined message templates
3. **Rich Text Support:** HTML formatting in messages
4. **Read Receipts:** Track who has read notifications
5. **Push Notifications:** Real-time browser notifications

### Scalability:
1. **Batch Processing:** Handle large user lists efficiently
2. **Queue System:** Async notification processing
3. **Rate Limiting:** Prevent notification spam
4. **Analytics:** Track notification effectiveness

## Conclusion

✅ **Simplified notification system successfully implemented**
✅ **Clear role-based separation: Manager → Team, Admin → System**
✅ **Improved security and user experience**
✅ **Reduced complexity while maintaining functionality**

The notification system now provides a clean, secure, and efficient way for managers and admins to communicate with their respective audiences.
