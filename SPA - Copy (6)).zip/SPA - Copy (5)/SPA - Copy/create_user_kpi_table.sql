-- =============================================
-- SPA MANAGEMENT SYSTEM - COMPLETE DATABASE SCRIPT
-- Description: Creates database, tables, relationships, and sample data
-- Date: 2025-07-12
-- =============================================

-- Drop database if exists and create new one
USE [master]
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = N'spa_management')
BEGIN
    ALTER DATABASE [spa_management] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
    DROP DATABASE [spa_management]
END
GO

-- Create Database
CREATE DATABASE [spa_management]

-- Configure Database Settings
ALTER DATABASE [spa_management] SET COMPATIBILITY_LEVEL = 160
GO
ALTER DATABASE [spa_management] SET ANSI_NULL_DEFAULT OFF
GO
ALTER DATABASE [spa_management] SET ANSI_NULLS ON
GO
ALTER DATABASE [spa_management] SET ANSI_PADDING ON
GO
ALTER DATABASE [spa_management] SET ANSI_WARNINGS ON
GO
ALTER DATABASE [spa_management] SET ARITHABORT ON
GO
ALTER DATABASE [spa_management] SET AUTO_CLOSE OFF
GO
ALTER DATABASE [spa_management] SET AUTO_SHRINK OFF
GO
ALTER DATABASE [spa_management] SET AUTO_UPDATE_STATISTICS ON
GO
ALTER DATABASE [spa_management] SET CURSOR_CLOSE_ON_COMMIT OFF
GO
ALTER DATABASE [spa_management] SET CURSOR_DEFAULT GLOBAL
GO
ALTER DATABASE [spa_management] SET CONCAT_NULL_YIELDS_NULL OFF
GO
ALTER DATABASE [spa_management] SET NUMERIC_ROUNDABORT OFF
GO
ALTER DATABASE [spa_management] SET QUOTED_IDENTIFIER ON
GO
ALTER DATABASE [spa_management] SET RECURSIVE_TRIGGERS OFF
GO
ALTER DATABASE [spa_management] SET ENABLE_BROKER
GO
ALTER DATABASE [spa_management] SET AUTO_UPDATE_STATISTICS_ASYNC OFF
GO
ALTER DATABASE [spa_management] SET DATE_CORRELATION_OPTIMIZATION OFF
GO
ALTER DATABASE [spa_management] SET TRUSTWORTHY OFF
GO
ALTER DATABASE [spa_management] SET ALLOW_SNAPSHOT_ISOLATION OFF
GO
ALTER DATABASE [spa_management] SET PARAMETERIZATION SIMPLE
GO
ALTER DATABASE [spa_management] SET READ_COMMITTED_SNAPSHOT OFF
GO
ALTER DATABASE [spa_management] SET HONOR_BROKER_PRIORITY OFF
GO
ALTER DATABASE [spa_management] SET RECOVERY SIMPLE
GO
ALTER DATABASE [spa_management] SET MULTI_USER
GO
ALTER DATABASE [spa_management] SET PAGE_VERIFY CHECKSUM
GO
ALTER DATABASE [spa_management] SET DB_CHAINING OFF
GO
ALTER DATABASE [spa_management] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF )
GO
ALTER DATABASE [spa_management] SET TARGET_RECOVERY_TIME = 60 SECONDS
GO
ALTER DATABASE [spa_management] SET DELAYED_DURABILITY = DISABLED
GO
ALTER DATABASE [spa_management] SET ACCELERATED_DATABASE_RECOVERY = OFF
GO
ALTER DATABASE [spa_management] SET QUERY_STORE = ON
GO
ALTER DATABASE [spa_management] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 1000, QUERY_CAPTURE_MODE = AUTO, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
-- Use the created database
USE [spa_management]
GO

-- =============================================
-- SEQUENCES
-- =============================================

-- Sequence for appointment_handled table
CREATE SEQUENCE [dbo].[appointment_handled_seq]
    AS [bigint]
    START WITH 1
    INCREMENT BY 50
    MINVALUE -9223372036854775808
    MAXVALUE 9223372036854775807
    CACHE
GO

-- =============================================
-- CORE TABLES CREATION
-- =============================================
-- =============================================
-- 1. ROLES TABLE (Referenced by other tables)
-- =============================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[roles](
    [role_id] [int] IDENTITY(1,1) NOT NULL,
    [role_name] [nvarchar](50) NOT NULL,
    [description] [nvarchar](255) NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_roles] PRIMARY KEY CLUSTERED ([role_id] ASC),
    CONSTRAINT [UK_roles_role_name] UNIQUE ([role_name])
) ON [PRIMARY]
GO

-- =============================================
-- 2. BRANCHES TABLE (Referenced by other tables)
-- =============================================
CREATE TABLE [dbo].[branches](
    [branch_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](255) NOT NULL,
    [address] [nvarchar](255) NULL,
    [phone] [nvarchar](255) NULL,
    [email] [nvarchar](255) NULL,
    [manager_id] [int] NULL,
    [opening_hours] [nvarchar](255) NULL,
    [operating_hours] [nvarchar](255) NULL,
    [holiday_schedule] [nvarchar](255) NULL,
    [capacity] [int] NULL,
    [status] [nvarchar](255) DEFAULT 'ACTIVE',
    [is_active] [bit] DEFAULT 1,
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_branches] PRIMARY KEY CLUSTERED ([branch_id] ASC)
) ON [PRIMARY]
GO

-- =============================================
-- 3. SERVICE CATEGORIES TABLE
-- =============================================
CREATE TABLE [dbo].[service_categories](
    [category_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](255) NOT NULL,
    [description] [nvarchar](4000) NULL,
    [parent_category_id] [int] NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_service_categories] PRIMARY KEY CLUSTERED ([category_id] ASC),
    CONSTRAINT [FK_service_categories_parent] FOREIGN KEY ([parent_category_id]) REFERENCES [dbo].[service_categories]([category_id])
) ON [PRIMARY]
GO
-- =============================================
-- 4. USERS TABLE (Customers, Technicians, Managers, etc.)
-- =============================================
CREATE TABLE [dbo].[users](
    [user_id] [int] IDENTITY(1,1) NOT NULL,
    [username] [nvarchar](50) NOT NULL,
    [password] [nvarchar](255) NOT NULL,
    [email] [nvarchar](100) NOT NULL,
    [full_name] [nvarchar](100) NOT NULL,
    [phone] [nvarchar](20) NULL,
    [date_of_birth] [date] NULL,
    [gender] [nvarchar](10) NULL,
    [address] [nvarchar](4000) NULL,
    [status] [nvarchar](20) DEFAULT 'ACTIVE',
    [enabled] [bit] DEFAULT 1,
    [verification_token] [nvarchar](255) NULL,
    [verification_token_expiry] [datetime] NULL,
    [reset_password_token] [nvarchar](255) NULL,
    [reset_password_token_expiry] [datetime] NULL,
    [last_login] [datetime] NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    [last_check_in] [datetime] NULL,
    [last_check_out] [datetime] NULL,
    [total_working_hours] [decimal](10, 2) NULL,
    [performance_score] [decimal](5, 2) NULL,
    [vip_level] [nvarchar](20) NULL,
    [total_spent] [decimal](10, 2) NULL,
    [last_visit_date] [datetime] NULL,
    [preferred_branch_id] [int] NULL,
    [last_password_change] [datetime] NULL,
    [email_verified] [bit] DEFAULT 0,
    [phone_verified] [bit] DEFAULT 0,
    [two_factor_enabled] [bit] DEFAULT 0,
    [two_factor_secret] [nvarchar](100) NULL,
    [login_attempts] [int] DEFAULT 0,
    [last_login_attempt] [datetime] NULL,
    [profile_picture] [nvarchar](255) NULL,
    [otp_code] [nvarchar](10) NULL,
    [otp_expiry] [datetime2](6) NULL,
    [branch_id] [int] NULL,
    [base_salary] [numeric](10, 2) NULL,
    CONSTRAINT [PK_users] PRIMARY KEY CLUSTERED ([user_id] ASC),
    CONSTRAINT [UK_users_username] UNIQUE ([username]),
    CONSTRAINT [UK_users_email] UNIQUE ([email]),
    CONSTRAINT [FK_users_branch] FOREIGN KEY ([branch_id]) REFERENCES [dbo].[branches]([branch_id]),
    CONSTRAINT [FK_users_preferred_branch] FOREIGN KEY ([preferred_branch_id]) REFERENCES [dbo].[branches]([branch_id])
) ON [PRIMARY]
GO

-- =============================================
-- 5. USER ROLES JUNCTION TABLE
-- =============================================
CREATE TABLE [dbo].[user_roles](
    [user_id] [int] NOT NULL,
    [role_id] [int] NOT NULL,
    [assigned_at] [datetime] DEFAULT GETDATE(),
    [assigned_by] [int] NULL,
    CONSTRAINT [PK_user_roles] PRIMARY KEY CLUSTERED ([user_id] ASC, [role_id] ASC),
    CONSTRAINT [FK_user_roles_user] FOREIGN KEY ([user_id]) REFERENCES [dbo].[users]([user_id]) ON DELETE CASCADE,
    CONSTRAINT [FK_user_roles_role] FOREIGN KEY ([role_id]) REFERENCES [dbo].[roles]([role_id]) ON DELETE CASCADE,
    CONSTRAINT [FK_user_roles_assigned_by] FOREIGN KEY ([assigned_by]) REFERENCES [dbo].[users]([user_id])
) ON [PRIMARY]
GO
-- =============================================
-- 6. SERVICES TABLE
-- =============================================
CREATE TABLE [dbo].[services](
    [service_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](255) NOT NULL,
    [description] [nvarchar](4000) NULL,
    [duration] [int] NOT NULL, -- Duration in minutes
    [price] [numeric](38, 2) NOT NULL,
    [category_id] [int] NULL,
    [image_url] [nvarchar](255) NULL,
    [status] [nvarchar](255) DEFAULT 'ACTIVE',
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_services] PRIMARY KEY CLUSTERED ([service_id] ASC),
    CONSTRAINT [FK_services_category] FOREIGN KEY ([category_id]) REFERENCES [dbo].[service_categories]([category_id])
) ON [PRIMARY]
GO

-- =============================================
-- 7. ROOMS TABLE
-- =============================================
CREATE TABLE [dbo].[rooms](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](100) NOT NULL,
    [description] [nvarchar](1000) NULL,
    [capacity] [int] NULL,
    [status] [nvarchar](20) DEFAULT 'AVAILABLE',
    [branch_id] [int] NOT NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_rooms] PRIMARY KEY CLUSTERED ([id] ASC),
    CONSTRAINT [FK_rooms_branch] FOREIGN KEY ([branch_id]) REFERENCES [dbo].[branches]([branch_id])
) ON [PRIMARY]
GO

-- =============================================
-- 8. APPOINTMENTS TABLE
-- =============================================
CREATE TABLE [dbo].[appointments](
    [appointment_id] [int] IDENTITY(1,1) NOT NULL,
    [customer_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [service_id] [int] NOT NULL,
    [technician_id] [int] NULL,
    [room_id] [int] NULL,
    [appointment_date] [datetime2](6) NOT NULL,
    [start_time] [datetime2](6) NOT NULL,
    [end_time] [datetime2](6) NOT NULL,
    [status] [nvarchar](255) DEFAULT 'SCHEDULED',
    [notes] [nvarchar](4000) NULL,
    [special_requests] [nvarchar](4000) NULL,
    [cancellation_reason] [nvarchar](4000) NULL,
    [preferred_technician_id] [int] NULL,
    [reminder_sent] [bit] DEFAULT 0,
    [reminder_sent_at] [datetime] NULL,
    [reminder_method] [nvarchar](255) NULL,
    [check_in_time] [datetime] NULL,
    [check_out_time] [datetime] NULL,
    [checkin_time] [datetime2](6) NULL,
    [checkout_time] [datetime2](6) NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_appointments] PRIMARY KEY CLUSTERED ([appointment_id] ASC),
    CONSTRAINT [FK_appointments_customer] FOREIGN KEY ([customer_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_appointments_branch] FOREIGN KEY ([branch_id]) REFERENCES [dbo].[branches]([branch_id]),
    CONSTRAINT [FK_appointments_service] FOREIGN KEY ([service_id]) REFERENCES [dbo].[services]([service_id]),
    CONSTRAINT [FK_appointments_technician] FOREIGN KEY ([technician_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_appointments_room] FOREIGN KEY ([room_id]) REFERENCES [dbo].[rooms]([id]),
    CONSTRAINT [FK_appointments_preferred_technician] FOREIGN KEY ([preferred_technician_id]) REFERENCES [dbo].[users]([user_id])
) ON [PRIMARY]
GO
-- =============================================
-- 9. APPOINTMENT HANDLED TABLE
-- =============================================
CREATE TABLE [dbo].[appointment_handled](
    [id] [bigint] NOT NULL DEFAULT NEXT VALUE FOR [dbo].[appointment_handled_seq],
    [handled_at] [datetime2](6) DEFAULT GETDATE(),
    [appointment_appointment_id] [int] NULL,
    [receptionist_user_id] [int] NULL,
    CONSTRAINT [PK_appointment_handled] PRIMARY KEY CLUSTERED ([id] ASC),
    CONSTRAINT [FK_appointment_handled_appointment] FOREIGN KEY ([appointment_appointment_id]) REFERENCES [dbo].[appointments]([appointment_id]),
    CONSTRAINT [FK_appointment_handled_receptionist] FOREIGN KEY ([receptionist_user_id]) REFERENCES [dbo].[users]([user_id])
) ON [PRIMARY]
GO

-- =============================================
-- 10. ATTENDANCES TABLE
-- =============================================
CREATE TABLE [dbo].[attendances](
    [attendance_id] [int] IDENTITY(1,1) NOT NULL,
    [user_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [work_date] [date] NOT NULL,
    [check_in_time] [datetime2](6) NULL,
    [check_out_time] [datetime2](6) NULL,
    [break_start] [datetime2](6) NULL,
    [break_end] [datetime2](6) NULL,
    [total_hours] [numeric](5, 2) NULL,
    [overtime_hours] [numeric](5, 2) NULL,
    [late_minutes] [int] NULL,
    [early_leave_minutes] [int] NULL,
    [status] [nvarchar](20) DEFAULT 'PRESENT',
    [ip_address] [nvarchar](45) NULL,
    [location] [nvarchar](255) NULL,
    [notes] [nvarchar](4000) NULL,
    [created_at] [datetime2](6) DEFAULT GETDATE(),
    [updated_at] [datetime2](6) DEFAULT GETDATE(),
    CONSTRAINT [PK_attendances] PRIMARY KEY CLUSTERED ([attendance_id] ASC),
    CONSTRAINT [FK_attendances_user] FOREIGN KEY ([user_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_attendances_branch] FOREIGN KEY ([branch_id]) REFERENCES [dbo].[branches]([branch_id])
) ON [PRIMARY]
GO

-- =============================================
-- 11. AUDIT LOGS TABLE
-- =============================================
CREATE TABLE [dbo].[audit_logs](
    [log_id] [int] IDENTITY(1,1) NOT NULL,
    [user_id] [int] NULL,
    [action] [nvarchar](100) NOT NULL,
    [entity_type] [nvarchar](50) NOT NULL,
    [entity_id] [int] NULL,
    [old_value] [nvarchar](4000) NULL,
    [new_value] [nvarchar](4000) NULL,
    [ip_address] [nvarchar](50) NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_audit_logs] PRIMARY KEY CLUSTERED ([log_id] ASC),
    CONSTRAINT [FK_audit_logs_user] FOREIGN KEY ([user_id]) REFERENCES [dbo].[users]([user_id])
) ON [PRIMARY]
GO
-- =============================================
-- 12. INVOICES TABLE
-- =============================================
CREATE TABLE [dbo].[invoices](
    [invoice_id] [int] IDENTITY(1,1) NOT NULL,
    [invoice_number] [nvarchar](255) NULL,
    [appointment_id] [int] NULL,
    [customer_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [total_amount] [numeric](38, 2) NULL,
    [discount_amount] [numeric](38, 2) NULL,
    [tax_amount] [numeric](38, 2) NULL,
    [final_amount] [numeric](38, 2) NULL,
    [payment_status] [nvarchar](255) DEFAULT 'PENDING',
    [payment_method] [nvarchar](255) NULL,
    [payment_channel] [nvarchar](255) NULL,
    [payment_reference] [nvarchar](255) NULL,
    [payment_date] [datetime] NULL,
    [payment_notes] [nvarchar](4000) NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_invoices] PRIMARY KEY CLUSTERED ([invoice_id] ASC),
    CONSTRAINT [FK_invoices_appointment] FOREIGN KEY ([appointment_id]) REFERENCES [dbo].[appointments]([appointment_id]),
    CONSTRAINT [FK_invoices_customer] FOREIGN KEY ([customer_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_invoices_branch] FOREIGN KEY ([branch_id]) REFERENCES [dbo].[branches]([branch_id])
) ON [PRIMARY]
GO

-- =============================================
-- 13. INVOICE DETAILS TABLE
-- =============================================
CREATE TABLE [dbo].[invoice_details](
    [detail_id] [int] IDENTITY(1,1) NOT NULL,
    [invoice_id] [int] NOT NULL,
    [service_id] [int] NOT NULL,
    [quantity] [int] NOT NULL DEFAULT 1,
    [unit_price] [decimal](10, 2) NOT NULL,
    [discount_percentage] [decimal](5, 2) NULL,
    [total_price] [decimal](10, 2) NOT NULL,
    CONSTRAINT [PK_invoice_details] PRIMARY KEY CLUSTERED ([detail_id] ASC),
    CONSTRAINT [FK_invoice_details_invoice] FOREIGN KEY ([invoice_id]) REFERENCES [dbo].[invoices]([invoice_id]) ON DELETE CASCADE,
    CONSTRAINT [FK_invoice_details_service] FOREIGN KEY ([service_id]) REFERENCES [dbo].[services]([service_id])
) ON [PRIMARY]
GO

-- =============================================
-- 14. SERVICE RATING TABLE
-- =============================================
CREATE TABLE [dbo].[service_rating](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [customer_id] [int] NULL,
    [service_id] [int] NULL,
    [rating] [int] NOT NULL,
    [comment] [nvarchar](255) NULL,
    [created_at] [datetime2](6) DEFAULT GETDATE(),
    CONSTRAINT [PK_service_rating] PRIMARY KEY CLUSTERED ([id] ASC),
    CONSTRAINT [FK_service_rating_customer] FOREIGN KEY ([customer_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_service_rating_service] FOREIGN KEY ([service_id]) REFERENCES [dbo].[services]([service_id]),
    CONSTRAINT [CHK_service_rating_rating] CHECK ([rating] >= 1 AND [rating] <= 5)
) ON [PRIMARY]
GO
-- =============================================
-- 15. USER KPI TABLE
-- =============================================
CREATE TABLE [dbo].[user_kpi](
    [kpi_id] [int] IDENTITY(1,1) NOT NULL,
    [technician_id] [int] NOT NULL,
    [manager_id] [int] NOT NULL,
    [year] [int] NOT NULL,
    [month] [int] NOT NULL,
    [target_appointments] [int] NOT NULL,
    [actual_appointments] [int] NULL DEFAULT 0,
    [status] [nvarchar](20) DEFAULT 'ACTIVE',
    [created_at] [datetime2](6) NOT NULL DEFAULT GETDATE(),
    [updated_at] [datetime2](6) NOT NULL DEFAULT GETDATE(),
    CONSTRAINT [PK_user_kpi] PRIMARY KEY CLUSTERED ([kpi_id] ASC),
    CONSTRAINT [FK_user_kpi_technician] FOREIGN KEY ([technician_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_user_kpi_manager] FOREIGN KEY ([manager_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [UK_user_kpi_unique] UNIQUE ([technician_id], [year], [month])
) ON [PRIMARY]
GO

-- =============================================
-- 16. WORK SCHEDULES TABLE
-- =============================================
CREATE TABLE [dbo].[work_schedules](
    [schedule_id] [int] IDENTITY(1,1) NOT NULL,
    [user_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [work_date] [date] NOT NULL,
    [start_time] [time](7) NOT NULL,
    [end_time] [time](7) NOT NULL,
    [break_start] [time](7) NULL,
    [break_end] [time](7) NULL,
    [shift_type] [nvarchar](255) NOT NULL,
    [status] [nvarchar](255) DEFAULT 'SCHEDULED',
    [notes] [nvarchar](1000) NULL,
    [is_recurring] [bit] DEFAULT 0,
    [recurring_pattern] [nvarchar](50) NULL,
    [recurring_end_date] [date] NULL,
    [created_at] [datetime] DEFAULT GETDATE(),
    [updated_at] [datetime] DEFAULT GETDATE(),
    [created_by] [int] NULL,
    [updated_by] [int] NULL,
    CONSTRAINT [PK_work_schedules] PRIMARY KEY CLUSTERED ([schedule_id] ASC),
    CONSTRAINT [FK_work_schedules_user] FOREIGN KEY ([user_id]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_work_schedules_branch] FOREIGN KEY ([branch_id]) REFERENCES [dbo].[branches]([branch_id]),
    CONSTRAINT [FK_work_schedules_created_by] FOREIGN KEY ([created_by]) REFERENCES [dbo].[users]([user_id]),
    CONSTRAINT [FK_work_schedules_updated_by] FOREIGN KEY ([updated_by]) REFERENCES [dbo].[users]([user_id])
) ON [PRIMARY]
GO

-- =============================================
-- 17. MEMBERSHIPS TABLE
-- =============================================
CREATE TABLE [dbo].[memberships](
    [membership_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](255) NOT NULL,
    [description] [nvarchar](4000) NULL,
    [price] [numeric](38, 2) NOT NULL,
    [duration_months] [int] NULL,
    [discount_percent] [int] NULL,
    [max_bookings_per_month] [int] NULL,
    [benefits] [nvarchar](4000) NULL,
    [priority_booking] [bit] DEFAULT 0,
    [free_consultation] [bit] DEFAULT 0,
    [status] [nvarchar](255) DEFAULT 'ACTIVE',
    [created_at] [datetime2](6) DEFAULT GETDATE(),
    [updated_at] [datetime2](6) DEFAULT GETDATE(),
    CONSTRAINT [PK_memberships] PRIMARY KEY CLUSTERED ([membership_id] ASC)
) ON [PRIMARY]
GO
-- =============================================
-- FOREIGN KEY CONSTRAINTS (Added after table creation)
-- =============================================

-- Add foreign key constraint for branches.manager_id (references users table)
ALTER TABLE [dbo].[branches]
ADD CONSTRAINT [FK_branches_manager] FOREIGN KEY ([manager_id]) REFERENCES [dbo].[users]([user_id])
GO

-- =============================================
-- SAMPLE DATA INSERTION
-- =============================================

-- Insert Roles
INSERT INTO [dbo].[roles] ([role_name], [description]) VALUES
('ADMIN', 'System Administrator'),
('MANAGER', 'Branch Manager'),
('TECHNICIAN', 'Service Technician'),
('RECEPTIONIST', 'Front Desk Receptionist'),
('CUSTOMER', 'Customer/Client')
GO

-- Insert Branches (without manager_id first)
INSERT INTO [dbo].[branches] ([name], [address], [phone], [email], [opening_hours], [capacity], [status], [is_active]) VALUES
('Downtown Spa', '123 Main Street, Downtown', '+1-555-0101', 'downtown@spa.com', '9:00 AM - 9:00 PM', 50, 'ACTIVE', 1),
('Uptown Wellness', '456 Oak Avenue, Uptown', '+1-555-0102', 'uptown@spa.com', '8:00 AM - 8:00 PM', 40, 'ACTIVE', 1),
('Suburban Retreat', '789 Pine Road, Suburbs', '+1-555-0103', 'suburban@spa.com', '10:00 AM - 7:00 PM', 30, 'ACTIVE', 1)
GO

-- Insert Service Categories
INSERT INTO [dbo].[service_categories] ([name], [description]) VALUES
('Facial Treatments', 'Various facial care and beauty treatments'),
('Body Treatments', 'Full body wellness and therapeutic treatments'),
('Massage Therapy', 'Relaxation and therapeutic massage services'),
('Hair Services', 'Hair styling, cutting, and treatment services'),
('Nail Care', 'Manicure, pedicure, and nail art services')
GO

-- Insert Services
INSERT INTO [dbo].[services] ([name], [description], [duration], [price], [category_id], [status]) VALUES
('Classic Facial', 'Deep cleansing facial with moisturizing treatment', 60, 75.00, 1, 'ACTIVE'),
('Anti-Aging Facial', 'Advanced facial treatment for mature skin', 90, 120.00, 1, 'ACTIVE'),
('Swedish Massage', 'Relaxing full body massage', 60, 85.00, 3, 'ACTIVE'),
('Deep Tissue Massage', 'Therapeutic massage for muscle tension', 90, 110.00, 3, 'ACTIVE'),
('Hot Stone Massage', 'Relaxing massage with heated stones', 75, 95.00, 3, 'ACTIVE'),
('Body Wrap', 'Detoxifying full body treatment', 120, 150.00, 2, 'ACTIVE'),
('Manicure', 'Complete nail care and polish', 45, 35.00, 5, 'ACTIVE'),
('Pedicure', 'Foot care and nail treatment', 60, 45.00, 5, 'ACTIVE'),
('Hair Cut & Style', 'Professional hair cutting and styling', 75, 65.00, 4, 'ACTIVE'),
('Hair Color', 'Professional hair coloring service', 120, 120.00, 4, 'ACTIVE')
GO

-- Insert Users (Admin, Managers, Technicians, Receptionists, Customers)
INSERT INTO [dbo].[users] ([username], [password], [email], [full_name], [phone], [gender], [status], [enabled], [branch_id], [base_salary]) VALUES
-- Admin
('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'admin@spa.com', 'System Administrator', '+1-555-0001', 'Other', 'ACTIVE', 1, 1, 5000.00),
-- Managers
('manager1', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'manager1@spa.com', 'John Manager', '+1-555-0011', 'Male', 'ACTIVE', 1, 1, 4000.00),
('manager2', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'manager2@spa.com', 'Sarah Wilson', '+1-555-0012', 'Female', 'ACTIVE', 1, 2, 4000.00),
-- Technicians
('tech1', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'tech1@spa.com', 'Emily Johnson', '+1-555-0021', 'Female', 'ACTIVE', 1, 1, 2500.00),
('tech2', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'tech2@spa.com', 'Michael Brown', '+1-555-0022', 'Male', 'ACTIVE', 1, 1, 2500.00),
('tech3', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'tech3@spa.com', 'Lisa Davis', '+1-555-0023', 'Female', 'ACTIVE', 1, 2, 2500.00),
-- Receptionists
('reception1', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'reception1@spa.com', 'Anna Smith', '+1-555-0031', 'Female', 'ACTIVE', 1, 1, 2000.00),
('reception2', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'reception2@spa.com', 'David Lee', '+1-555-0032', 'Male', 'ACTIVE', 1, 2, 2000.00),
-- Customers
('customer1', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'customer1@email.com', 'Jennifer White', '+1-555-0101', 'Female', 'ACTIVE', 1, NULL, NULL),
('customer2', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'customer2@email.com', 'Robert Taylor', '+1-555-0102', 'Male', 'ACTIVE', 1, NULL, NULL),
('customer3', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'customer3@email.com', 'Maria Garcia', '+1-555-0103', 'Female', 'ACTIVE', 1, NULL, NULL)
GO

-- Insert User Roles
INSERT INTO [dbo].[user_roles] ([user_id], [role_id]) VALUES
(1, 1), -- admin -> ADMIN
(2, 2), -- manager1 -> MANAGER
(3, 2), -- manager2 -> MANAGER
(4, 3), -- tech1 -> TECHNICIAN
(5, 3), -- tech2 -> TECHNICIAN
(6, 3), -- tech3 -> TECHNICIAN
(7, 4), -- reception1 -> RECEPTIONIST
(8, 4), -- reception2 -> RECEPTIONIST
(9, 5), -- customer1 -> CUSTOMER
(10, 5), -- customer2 -> CUSTOMER
(11, 5) -- customer3 -> CUSTOMER
GO

-- Update branches with manager_id
UPDATE [dbo].[branches] SET [manager_id] = 2 WHERE [branch_id] = 1
UPDATE [dbo].[branches] SET [manager_id] = 3 WHERE [branch_id] = 2
UPDATE [dbo].[branches] SET [manager_id] = 2 WHERE [branch_id] = 3
GO

/****** Object:  Table [dbo].[customer_density]    Script Date: 7/12/2025 2:16:40 PM ******/
-- Insert Rooms
INSERT INTO [dbo].[rooms] ([name], [description], [capacity], [status], [branch_id]) VALUES
('Room 1A', 'Facial treatment room with natural lighting', 1, 'AVAILABLE', 1),
('Room 1B', 'Massage therapy room with relaxing ambiance', 1, 'AVAILABLE', 1),
('Room 1C', 'Multi-purpose treatment room', 1, 'AVAILABLE', 1),
('Room 2A', 'Premium spa suite', 1, 'AVAILABLE', 2),
('Room 2B', 'Couples massage room', 2, 'AVAILABLE', 2),
('Room 3A', 'Standard treatment room', 1, 'AVAILABLE', 3)
GO

-- Insert Memberships
INSERT INTO [dbo].[memberships] ([name], [description], [price], [duration_months], [discount_percent], [max_bookings_per_month], [benefits], [priority_booking], [free_consultation]) VALUES
('Basic Membership', 'Entry level membership with basic benefits', 100000, 12, 10, 2, 'Monthly newsletter, birthday discount', 0, 1),
('Premium Membership', 'Enhanced membership with additional perks', 200000, 12, 15, 4, 'Priority booking, complimentary refreshments, birthday discount', 1, 1),
('VIP Membership', 'Exclusive membership with premium benefits', 400000, 12, 20, 8, 'Priority booking, complimentary services, personal consultant, birthday discount', 1, 1)
GO

-- Insert Sample Appointments
INSERT INTO [dbo].[appointments] ([customer_id], [branch_id], [service_id], [technician_id], [room_id], [appointment_date], [start_time], [end_time], [status], [notes]) VALUES
(9, 1, 1, 4, 1, '2025-07-15', '2025-07-15 10:00:00', '2025-07-15 11:00:00', 'SCHEDULED', 'First time customer'),
(10, 1, 3, 5, 2, '2025-07-15', '2025-07-15 14:00:00', '2025-07-15 15:00:00', 'SCHEDULED', 'Regular customer'),
(11, 2, 2, 6, 4, '2025-07-16', '2025-07-16 11:00:00', '2025-07-16 12:30:00', 'SCHEDULED', 'Anti-aging treatment'),
(9, 1, 7, 4, 1, '2025-07-17', '2025-07-17 09:00:00', '2025-07-17 09:45:00', 'COMPLETED', 'Manicure completed successfully'),
(10, 1, 4, 5, 2, '2025-07-18', '2025-07-18 16:00:00', '2025-07-18 17:30:00', 'SCHEDULED', 'Deep tissue massage')
GO

-- Insert Sample Invoices
INSERT INTO [dbo].[invoices] ([invoice_number], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method]) VALUES
('INV-2025-001', 4, 9, 1, 35.00, 0.00, 3.50, 38.50, 'PAID', 'CREDIT_CARD'),
('INV-2025-002', 1, 9, 1, 75.00, 7.50, 6.75, 74.25, 'PENDING', NULL),
('INV-2025-003', 2, 10, 1, 85.00, 0.00, 8.50, 93.50, 'PENDING', NULL)
GO

-- Insert Invoice Details
INSERT INTO [dbo].[invoice_details] ([invoice_id], [service_id], [quantity], [unit_price], [discount_percentage], [total_price]) VALUES
(1, 7, 1, 35.00, 0.00, 35.00),
(2, 1, 1, 75.00, 10.00, 67.50),
(3, 3, 1, 85.00, 0.00, 85.00)
GO

-- Insert Service Ratings
INSERT INTO [dbo].[service_rating] ([customer_id], [service_id], [rating], [comment]) VALUES
(9, 7, 5, 'Excellent manicure service, very professional'),
(10, 3, 4, 'Great massage, very relaxing'),
(11, 2, 5, 'Amazing anti-aging facial, highly recommend')
GO

-- Insert User KPI Records
INSERT INTO [dbo].[user_kpi] ([technician_id], [manager_id], [year], [month], [target_appointments], [actual_appointments], [status]) VALUES
(4, 2, 2025, 7, 50, 15, 'ACTIVE'),
(5, 2, 2025, 7, 45, 12, 'ACTIVE'),
(6, 3, 2025, 7, 40, 8, 'ACTIVE'),
(4, 2, 2025, 6, 50, 48, 'COMPLETED'),
(5, 2, 2025, 6, 45, 52, 'COMPLETED'),
(6, 3, 2025, 6, 40, 38, 'COMPLETED')
GO

-- Insert Work Schedules
INSERT INTO [dbo].[work_schedules] ([user_id], [branch_id], [work_date], [start_time], [end_time], [shift_type], [status], [created_by]) VALUES
(4, 1, '2025-07-15', '09:00:00', '17:00:00', 'FULL_TIME', 'SCHEDULED', 2),
(5, 1, '2025-07-15', '10:00:00', '18:00:00', 'FULL_TIME', 'SCHEDULED', 2),
(6, 2, '2025-07-15', '08:00:00', '16:00:00', 'FULL_TIME', 'SCHEDULED', 3),
(7, 1, '2025-07-15', '08:00:00', '16:00:00', 'FULL_TIME', 'SCHEDULED', 2),
(8, 2, '2025-07-15', '12:00:00', '20:00:00', 'PART_TIME', 'SCHEDULED', 3)
GO

-- Insert Attendance Records
INSERT INTO [dbo].[attendances] ([user_id], [branch_id], [work_date], [check_in_time], [check_out_time], [total_hours], [status]) VALUES
(4, 1, '2025-07-14', '2025-07-14 09:00:00', '2025-07-14 17:00:00', 8.00, 'PRESENT'),
(5, 1, '2025-07-14', '2025-07-14 10:05:00', '2025-07-14 18:00:00', 7.92, 'PRESENT'),
(6, 2, '2025-07-14', '2025-07-14 08:00:00', '2025-07-14 16:00:00', 8.00, 'PRESENT'),
(7, 1, '2025-07-14', '2025-07-14 08:00:00', '2025-07-14 16:00:00', 8.00, 'PRESENT'),
(8, 2, '2025-07-14', '2025-07-14 12:00:00', '2025-07-14 20:00:00', 8.00, 'PRESENT')
GO

-- Insert Appointment Handled Records
INSERT INTO [dbo].[appointment_handled] ([handled_at], [appointment_appointment_id], [receptionist_user_id]) VALUES
('2025-07-14 09:30:00', 4, 7),
('2025-07-14 10:00:00', 1, 7),
('2025-07-14 14:00:00', 2, 7)
GO
-- =============================================
-- NOTE: COMPLETE VERSION AVAILABLE
-- =============================================
--
-- This file has been converted to a complete database script.
-- Please use the file: spa_management_complete.sql
--
-- The complete script includes:
-- - Database creation
-- - All table definitions with proper relationships
-- - Foreign key constraints
-- - Sample data for all major entities
-- - Performance indexes
-- - Ready-to-use database setup
--
-- =============================================

PRINT '=================================================='
PRINT 'PLEASE USE: spa_management_complete.sql'
PRINT 'This file contains the complete database setup'
PRINT '=================================================='



    GO
CREATE TABLE [dbo].[customer_memberships](
    [customer_membership_id] [int] IDENTITY(1,1) NOT NULL,
    [created_at] [datetime2](6) NULL,
    [end_date] [datetime2](6) NULL,
    [purchase_date] [datetime2](6) NULL,
    [start_date] [datetime2](6) NULL,
    [status] [varchar](255) NULL,
    [updated_at] [datetime2](6) NULL,
    [used_bookings_this_month] [int] NULL,
    [customer_id] [int] NOT NULL,
    [membership_id] [int] NOT NULL,
    PRIMARY KEY CLUSTERED
(
[customer_membership_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[customer_preferences]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[customer_preferences](
    [preference_id] [int] IDENTITY(1,1) NOT NULL,
    [customer_id] [int] NOT NULL,
    [preferred_services] [nvarchar](4000) NULL,
    [preferred_technicians] [nvarchar](4000) NULL,
    [preferred_time_slots] [nvarchar](4000) NULL,
    [allergies] [nvarchar](4000) NULL,
    [medical_conditions] [nvarchar](4000) NULL,
    [special_requirements] [nvarchar](4000) NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[preference_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[customer_visits]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[customer_visits](
    [visit_id] [int] IDENTITY(1,1) NOT NULL,
    [customer_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [appointment_id] [int] NULL,
    [check_in] [datetime] NULL,
    [check_out] [datetime] NULL,
    [status] [nvarchar](20) NULL,
    [notes] [nvarchar](4000) NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[visit_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[employee_attendance]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[employee_attendance](
    [attendance_id] [int] IDENTITY(1,1) NOT NULL,
    [user_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [check_in] [datetime] NULL,
    [check_out] [datetime] NULL,
    [status] [nvarchar](20) NULL,
    [notes] [nvarchar](4000) NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[attendance_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[employee_reviews]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[employee_reviews](
    [review_id] [int] IDENTITY(1,1) NOT NULL,
    [employee_id] [int] NOT NULL,
    [reviewer_id] [int] NOT NULL,
    [review_date] [date] NOT NULL,
    [review_period] [nvarchar](20) NOT NULL,
    [performance_rating] [decimal](3, 2) NULL,
    [attendance_rating] [decimal](3, 2) NULL,
    [customer_satisfaction_rating] [decimal](3, 2) NULL,
    [comments] [nvarchar](4000) NULL,
    [recommendations] [nvarchar](4000) NULL,
    [status] [nvarchar](20) NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[review_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[equipment]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[equipment](
    [equipment_id] [int] IDENTITY(1,1) NOT NULL,
    [branch_id] [int] NOT NULL,
    [name] [nvarchar](100) NOT NULL,
    [serial_number] [nvarchar](50) NULL,
    [model] [nvarchar](100) NULL,
    [purchase_date] [date] NULL,
    [warranty_expiry] [date] NULL,
    [last_maintenance_date] [date] NULL,
    [next_maintenance_date] [date] NULL,
    [status] [nvarchar](20) NULL,
    [notes] [nvarchar](4000) NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[equipment_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[equipment_maintenance]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[equipment_maintenance](
    [maintenance_id] [int] IDENTITY(1,1) NOT NULL,
    [equipment_id] [int] NOT NULL,
    [maintenance_type] [nvarchar](20) NOT NULL,
    [maintenance_date] [date] NOT NULL,
    [next_maintenance_date] [date] NULL,
    [cost] [decimal](10, 2) NULL,
    [technician] [nvarchar](100) NULL,
    [description] [nvarchar](4000) NULL,
    [status] [nvarchar](20) NULL,
    [created_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[maintenance_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[favorite_services]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[favorite_services](
    [favorite_id] [int] IDENTITY(1,1) NOT NULL,
    [created_at] [datetime2](6) NULL,
    [customer_id] [int] NOT NULL,
    [service_id] [int] NOT NULL,
    PRIMARY KEY CLUSTERED
(
[favorite_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[heat_map_data]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[heat_map_data](
    [data_id] [int] IDENTITY(1,1) NOT NULL,
    [branch_id] [int] NOT NULL,
    [date] [date] NOT NULL,
    [hour] [int] NOT NULL,
    [customer_count] [int] NULL,
    [employee_count] [int] NULL,
    [service_count] [int] NULL,
    [created_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[data_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[inventory]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[inventory](
    [item_id] [int] IDENTITY(1,1) NOT NULL,
    [branch_id] [int] NOT NULL,
    [item_name] [nvarchar](100) NOT NULL,
    [description] [nvarchar](4000) NULL,
    [category] [nvarchar](50) NULL,
    [quantity] [int] NOT NULL,
    [unit] [nvarchar](20) NOT NULL,
    [reorder_level] [int] NOT NULL,
    [supplier_id] [int] NULL,
    [cost_price] [decimal](10, 2) NULL,
    [retail_price] [decimal](10, 2) NULL,
    [expiry_date] [date] NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[item_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[inventory_transactions]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[inventory_transactions](
    [transaction_id] [int] IDENTITY(1,1) NOT NULL,
    [item_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [transaction_type] [nvarchar](20) NOT NULL,
    [quantity] [int] NOT NULL,
    [unit_price] [decimal](10, 2) NULL,
    [total_amount] [decimal](10, 2) NULL,
    [reference_type] [nvarchar](20) NOT NULL,
    [reference_id] [int] NULL,
    [notes] [nvarchar](4000) NULL,
    [transaction_date] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[transaction_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[invoice_details]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[invoice_details](
    [detail_id] [int] IDENTITY(1,1) NOT NULL,
    [invoice_id] [int] NOT NULL,
    [service_id] [int] NOT NULL,
    [quantity] [int] NOT NULL,
    [unit_price] [decimal](10, 2) NOT NULL,
    [discount_percentage] [decimal](5, 2) NULL,
    [total_price] [decimal](10, 2) NOT NULL,
    PRIMARY KEY CLUSTERED
(
[detail_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[invoices]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[invoices](
    [invoice_id] [int] IDENTITY(1,1) NOT NULL,
    [appointment_id] [int] NULL,
    [customer_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [total_amount] [numeric](38, 2) NULL,
    [discount_amount] [numeric](38, 2) NULL,
    [tax_amount] [numeric](38, 2) NULL,
    [final_amount] [numeric](38, 2) NULL,
    [payment_status] [varchar](255) NULL,
    [payment_method] [varchar](255) NULL,
    [payment_date] [datetime] NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    [payment_reference] [varchar](255) NULL,
    [payment_channel] [varchar](255) NULL,
    [payment_notes] [nvarchar](4000) NULL,
    [invoice_number] [varchar](255) NULL,
    PRIMARY KEY CLUSTERED
(
[invoice_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[kpi_records]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[kpi_records](
    [kpi_id] [int] IDENTITY(1,1) NOT NULL,
    [user_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [period_start] [date] NOT NULL,
    [period_end] [date] NOT NULL,
    [total_appointments] [int] NULL,
    [completed_appointments] [int] NULL,
    [cancelled_appointments] [int] NULL,
    [total_revenue] [decimal](10, 2) NULL,
    [customer_satisfaction] [decimal](5, 2) NULL,
    [average_rating] [decimal](3, 2) NULL,
    [created_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[kpi_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[membership_orders]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[membership_orders](
    [order_id] [int] IDENTITY(1,1) NOT NULL,
    [created_at] [datetime2](6) NULL,
    [discount_amount] [numeric](38, 2) NULL,
    [final_price] [numeric](38, 2) NULL,
    [order_code] [bigint] NOT NULL,
    [original_price] [numeric](38, 2) NULL,
    [paid_at] [datetime2](6) NULL,
    [payment_method] [varchar](255) NULL,
    [payment_transaction_id] [varchar](255) NULL,
    [status] [varchar](255) NULL,
    [updated_at] [datetime2](6) NULL,
    [customer_id] [int] NOT NULL,
    [membership_id] [int] NOT NULL,
    PRIMARY KEY CLUSTERED
(
[order_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[memberships]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[memberships](
    [membership_id] [int] IDENTITY(1,1) NOT NULL,
    [benefits] [varchar](4000) NULL,
    [created_at] [datetime2](6) NULL,
    [description] [varchar](4000) NULL,
    [discount_percent] [int] NULL,
    [duration_months] [int] NULL,
    [free_consultation] [bit] NULL,
    [max_bookings_per_month] [int] NULL,
    [name] [varchar](255) NULL,
    [price] [numeric](38, 2) NULL,
    [priority_booking] [bit] NULL,
    [status] [varchar](255) NULL,
    [updated_at] [datetime2](6) NULL,
    PRIMARY KEY CLUSTERED
(
[membership_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[notifications]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[notifications](
    [notification_id] [int] IDENTITY(1,1) NOT NULL,
    [sender_id] [int] NULL,
    [recipient_id] [int] NOT NULL,
    [title] [nvarchar](200) NOT NULL,
    [content] [nvarchar](4000) NOT NULL,
    [type] [nvarchar](50) NOT NULL,
    [is_read] [bit] NULL,
    [read_at] [datetime] NULL,
    [created_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[notification_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[package_booking_details]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[package_booking_details](
    [detail_id] [int] IDENTITY(1,1) NOT NULL,
    [booking_id] [int] NOT NULL,
    [service_id] [int] NOT NULL,
    [technician_id] [int] NULL,
    [appointment_date] [date] NOT NULL,
    [start_time] [time](7) NOT NULL,
    [end_time] [time](7) NOT NULL,
    [status] [nvarchar](20) NULL,
    [notes] [nvarchar](4000) NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[detail_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[package_bookings]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[package_bookings](
    [booking_id] [int] IDENTITY(1,1) NOT NULL,
    [package_id] [int] NOT NULL,
    [customer_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [booking_date] [date] NOT NULL,
    [start_time] [time](7) NOT NULL,
    [end_time] [time](7) NOT NULL,
    [status] [nvarchar](20) NULL,
    [remaining_uses] [int] NOT NULL,
    [expiry_date] [date] NOT NULL,
    [notes] [nvarchar](4000) NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[booking_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[package_promotions]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[package_promotions](
    [promotion_id] [int] IDENTITY(1,1) NOT NULL,
    [package_id] [int] NOT NULL,
    [name] [nvarchar](100) NOT NULL,
    [description] [nvarchar](4000) NULL,
    [discount_percentage] [decimal](5, 2) NOT NULL,
    [start_date] [date] NOT NULL,
    [end_date] [date] NOT NULL,
    [is_active] [bit] NULL,
    [created_by] [int] NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[promotion_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[package_ratings]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[package_ratings](
    [rating_id] [int] IDENTITY(1,1) NOT NULL,
    [package_id] [int] NOT NULL,
    [customer_id] [int] NOT NULL,
    [booking_id] [int] NOT NULL,
    [rating] [int] NULL,
    [comment] [nvarchar](4000) NULL,
    [created_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[rating_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[package_services]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[package_services](
    [package_id] [int] NOT NULL,
    [service_id] [int] NOT NULL,
    [sequence] [int] NOT NULL,
    [duration] [int] NOT NULL,
    [is_optional] [bit] NULL,
    [notes] [nvarchar](4000) NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    CONSTRAINT [PK_PackageServices] PRIMARY KEY CLUSTERED
(
    [package_id] ASC,
[service_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[package_statistics]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[package_statistics](
    [stat_id] [int] IDENTITY(1,1) NOT NULL,
    [package_id] [int] NOT NULL,
    [total_bookings] [int] NULL,
    [total_revenue] [decimal](10, 2) NULL,
    [average_rating] [decimal](3, 2) NULL,
    [total_customers] [int] NULL,
    [period_start] [date] NOT NULL,
    [period_end] [date] NOT NULL,
    [created_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[stat_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[payment_transactions]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[payment_transactions](
    [transaction_id] [int] IDENTITY(1,1) NOT NULL,
    [invoice_id] [int] NOT NULL,
    [amount] [numeric](38, 2) NULL,
    [payment_method] [varchar](255) NULL,
    [payment_channel] [varchar](255) NULL,
    [transaction_reference] [varchar](255) NULL,
    [status] [varchar](255) NULL,
    [payment_date] [datetime] NULL,
    [notes] [nvarchar](4000) NULL,
    PRIMARY KEY CLUSTERED
(
[transaction_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[points_transactions]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[points_transactions](
    [transaction_id] [int] IDENTITY(1,1) NOT NULL,
    [points_amount] [int] NOT NULL,
    [transaction_type] [nvarchar](20) NOT NULL,
    [reference_type] [nvarchar](20) NOT NULL,
    [reference_id] [int] NULL,
    [notes] [nvarchar](4000) NULL,
    [created_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[transaction_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[roles]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[roles](
    [role_id] [int] IDENTITY(1,1) NOT NULL,
    [description] [varchar](255) NULL,
    [role_name] [varchar](50) NOT NULL,
    PRIMARY KEY CLUSTERED
(
[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[rooms]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[rooms](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [capacity] [int] NULL,
    [description] [varchar](1000) NULL,
    [name] [varchar](100) NOT NULL,
    [status] [varchar](20) NULL,
    [branch_id] [int] NOT NULL,
    PRIMARY KEY CLUSTERED
(
[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[salary_records]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[salary_records](
    [salary_id] [int] IDENTITY(1,1) NOT NULL,
    [user_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [month] [int] NOT NULL,
    [year] [int] NOT NULL,
    [base_salary] [decimal](10, 2) NOT NULL,
    [bonus] [decimal](10, 2) NULL,
    [commission] [decimal](10, 2) NULL,
    [overtime_pay] [decimal](10, 2) NULL,
    [deductions] [decimal](10, 2) NULL,
    [net_salary] [decimal](10, 2) NOT NULL,
    [payment_date] [date] NULL,
    [status] [nvarchar](20) NULL,
    [notes] [nvarchar](4000) NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[salary_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[salary_settings]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[salary_settings](
    [id] [bigint] IDENTITY(1,1) NOT NULL,
    [attendance_bonus] [float] NULL,
    [commission_per_customer] [float] NULL,
    [commission_per_service] [float] NULL,
    [penalty] [float] NULL,
    [rating_bonus] [float] NULL,
    [revenue_bonus] [float] NULL,
    [role] [varchar](255) NOT NULL,
    PRIMARY KEY CLUSTERED
(
[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[service_categories]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[service_categories](
    [category_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [varchar](255) NULL,
    [description] [nvarchar](4000) NULL,
    [parent_category_id] [int] NULL,
    [created_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[category_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[service_packages]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[service_packages](
    [package_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](100) NOT NULL,
    [description] [nvarchar](4000) NULL,
    [duration] [int] NOT NULL,
    [price] [decimal](10, 2) NOT NULL,
    [discount_percentage] [decimal](5, 2) NULL,
    [is_active] [bit] NULL,
    [image_url] [nvarchar](255) NULL,
    [validity_period] [int] NULL,
    [max_uses] [int] NULL,
    [created_by] [int] NULL,
    [updated_by] [int] NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[package_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[service_rating]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[service_rating](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [comment] [varchar](255) NULL,
    [created_at] [datetime2](6) NULL,
    [rating] [int] NOT NULL,
    [customer_id] [int] NULL,
    [service_id] [int] NULL,
    PRIMARY KEY CLUSTERED
(
[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[service_ratings]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[service_ratings](
    [rating_id] [int] IDENTITY(1,1) NOT NULL,
    [appointment_id] [int] NOT NULL,
    [customer_id] [int] NOT NULL,
    [service_id] [int] NOT NULL,
    [technician_id] [int] NOT NULL,
    [service_rating] [int] NULL,
    [technician_rating] [int] NULL,
    [facility_rating] [int] NULL,
    [overall_rating] [int] NULL,
    [comment] [nvarchar](4000) NULL,
    [created_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[rating_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[service_reviews]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[service_reviews](
    [review_id] [int] IDENTITY(1,1) NOT NULL,
    [comment] [varchar](4000) NULL,
    [created_at] [datetime2](6) NULL,
    [rating] [int] NULL,
    [status] [varchar](255) NULL,
    [updated_at] [datetime2](6) NULL,
    [appointment_id] [int] NULL,
    [customer_id] [int] NOT NULL,
    [service_id] [int] NOT NULL,
    PRIMARY KEY CLUSTERED
(
[review_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[service_schedule]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[service_schedule](
    [schedule_id] [int] IDENTITY(1,1) NOT NULL,
    [service_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [technician_id] [int] NOT NULL,
    [start_time] [datetime2](6) NULL,
    [end_time] [datetime2](6) NULL,
    [day_of_week] [int] NOT NULL,
    [is_active] [bit] NULL,
    [created_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[schedule_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[services]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[services](
    [service_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [varchar](255) NULL,
    [description] [nvarchar](4000) NULL,
    [duration] [int] NOT NULL,
    [price] [numeric](38, 2) NULL,
    [category_id] [int] NULL,
    [image_url] [nvarchar](255) NULL,
    [status] [varchar](255) NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[service_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[social_logins]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[social_logins](
    [social_id] [int] IDENTITY(1,1) NOT NULL,
    [user_id] [int] NOT NULL,
    [provider] [nvarchar](50) NOT NULL,
    [provider_user_id] [nvarchar](100) NOT NULL,
    [email] [nvarchar](100) NULL,
    [created_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[social_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[system_config]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[system_config](
    [config_id] [int] IDENTITY(1,1) NOT NULL,
    [config_key] [nvarchar](50) NOT NULL,
    [config_value] [nvarchar](4000) NULL,
    [description] [nvarchar](4000) NULL,
    [is_active] [bit] NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[config_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[treatment_records]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[treatment_records](
    [record_id] [int] IDENTITY(1,1) NOT NULL,
    [appointment_id] [int] NOT NULL,
    [technician_id] [int] NOT NULL,
    [pre_treatment_notes] [nvarchar](4000) NULL,
    [post_treatment_notes] [nvarchar](4000) NULL,
    [before_image_url] [nvarchar](255) NULL,
    [after_image_url] [nvarchar](255) NULL,
    [treatment_date] [datetime] NULL,
    [customer_feedback] [nvarchar](4000) NULL,
    [follow_up_notes] [nvarchar](4000) NULL,
    [treatment_progress] [int] NULL,
    [next_appointment_recommendation] [date] NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    PRIMARY KEY CLUSTERED
(
[record_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[user_kpi]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[user_kpi](
    [kpi_id] [int] IDENTITY(1,1) NOT NULL,
    [actual_appointments] [int] NULL,
    [created_at] [datetime2](6) NOT NULL,
    [month] [int] NOT NULL,
    [status] [varchar](20) NULL,
    [target_appointments] [int] NOT NULL,
    [updated_at] [datetime2](6) NOT NULL,
    [year] [int] NOT NULL,
    [manager_id] [int] NOT NULL,
    [technician_id] [int] NOT NULL,
    PRIMARY KEY CLUSTERED
(
[kpi_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[user_roles]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[user_roles](
    [user_id] [int] NOT NULL,
    [role_id] [int] NOT NULL,
     PRIMARY KEY CLUSTERED
    (
    [user_id] ASC,
[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[user_sessions]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[user_sessions](
    [session_id] [int] IDENTITY(1,1) NOT NULL,
    [user_id] [int] NOT NULL,
    [token] [nvarchar](500) NOT NULL,
    [device_info] [nvarchar](4000) NULL,
    [ip_address] [nvarchar](50) NULL,
    [login_time] [datetime] NULL,
    [last_activity] [datetime] NULL,
    [expiry_time] [datetime] NOT NULL,
    [is_active] [bit] NULL,
    PRIMARY KEY CLUSTERED
(
[session_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[users]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[users](
    [user_id] [int] IDENTITY(1,1) NOT NULL,
    [username] [nvarchar](50) NOT NULL,
    [password] [nvarchar](255) NOT NULL,
    [email] [nvarchar](100) NOT NULL,
    [full_name] [nvarchar](100) NOT NULL,
    [phone] [nvarchar](20) NULL,
    [date_of_birth] [date] NULL,
    [gender] [nvarchar](10) NULL,
    [address] [nvarchar](4000) NULL,
    [status] [nvarchar](20) NULL,
    [enabled] [bit] NULL,
    [verification_token] [nvarchar](255) NULL,
    [verification_token_expiry] [datetime] NULL,
    [reset_password_token] [nvarchar](255) NULL,
    [reset_password_token_expiry] [datetime] NULL,
    [last_login] [datetime] NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    [last_check_in] [datetime] NULL,
    [last_check_out] [datetime] NULL,
    [total_working_hours] [decimal](10, 2) NULL,
    [performance_score] [decimal](5, 2) NULL,
    [vip_level] [nvarchar](20) NULL,
    [total_spent] [decimal](10, 2) NULL,
    [last_visit_date] [datetime] NULL,
    [preferred_branch_id] [int] NULL,
    [last_password_change] [datetime] NULL,
    [email_verified] [bit] NULL,
    [phone_verified] [bit] NULL,
    [two_factor_enabled] [bit] NULL,
    [two_factor_secret] [nvarchar](100) NULL,
    [login_attempts] [int] NULL,
    [last_login_attempt] [datetime] NULL,
    [profile_picture] [varchar](255) NULL,
    [otp_code] [varchar](10) NULL,
    [otp_expiry] [datetime2](6) NULL,
    [branch_id] [int] NULL,
    [base_salary] [numeric](10, 2) NULL,
    PRIMARY KEY CLUSTERED
(
[user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
/****** Object:  Table [dbo].[work_schedules]    Script Date: 7/12/2025 2:16:40 PM ******/
    SET ANSI_NULLS ON
    GO
    SET QUOTED_IDENTIFIER ON
    GO
CREATE TABLE [dbo].[work_schedules](
    [schedule_id] [int] IDENTITY(1,1) NOT NULL,
    [user_id] [int] NOT NULL,
    [branch_id] [int] NOT NULL,
    [work_date] [date] NOT NULL,
    [start_time] [time](7) NOT NULL,
    [end_time] [time](7) NOT NULL,
    [break_start] [time](7) NULL,
    [break_end] [time](7) NULL,
    [status] [varchar](255) NULL,
    [notes] [varchar](1000) NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
    [created_by] [int] NULL,
    [is_recurring] [bit] NULL,
    [recurring_end_date] [date] NULL,
    [recurring_pattern] [varchar](50) NULL,
    [shift_type] [varchar](255) NOT NULL,
    [updated_by] [int] NULL,
    PRIMARY KEY CLUSTERED
(
[schedule_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
    GO
    INSERT [dbo].[appointment_handled] ([id], [handled_at], [appointment_appointment_id], [receptionist_user_id]) VALUES (1, CAST(N'2025-06-26T22:18:11.9678250' AS DateTime2), 29, 23)
    GO
    SET IDENTITY_INSERT [dbo].[appointments] ON

    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (3, 11, 1, 3, 19, CAST(N'2025-09-14T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T06:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T06:00:00.0000000' AS DateTime2), N'test', NULL, CAST(N'2025-06-05T23:18:07.693' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (4, 11, 1, 12, 21, CAST(N'2025-07-07T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T07:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T07:00:00.0000000' AS DateTime2), N'tét', NULL, CAST(N'2025-06-05T23:23:44.213' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (5, 11, 1, 3, 19, CAST(N'2025-07-07T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T06:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T06:00:00.0000000' AS DateTime2), N'sa', NULL, CAST(N'2025-06-05T23:28:26.183' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (6, 11, 1, 8, 21, CAST(N'2025-07-07T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T07:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T07:00:00.0000000' AS DateTime2), N'sa', NULL, CAST(N'2025-06-05T23:31:01.290' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (7, 11, 1, 3, 19, CAST(N'2026-01-10T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T08:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T08:00:00.0000000' AS DateTime2), N'tets', NULL, CAST(N'2025-06-05T23:34:57.107' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (8, 11, 1, 3, 19, CAST(N'2026-01-10T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T07:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T07:00:00.0000000' AS DateTime2), N'test', NULL, CAST(N'2025-06-05T23:37:20.330' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (9, 11, 1, 3, 19, CAST(N'2027-01-01T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T06:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T06:00:00.0000000' AS DateTime2), N'sa', NULL, CAST(N'2025-06-05T23:39:28.063' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (10, 11, 1, 3, 19, CAST(N'2026-01-08T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T07:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T07:00:00.0000000' AS DateTime2), N'ste', NULL, CAST(N'2025-06-05T23:41:41.867' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (11, 11, 1, 3, 19, CAST(N'2025-10-10T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T07:07:00.0000000' AS DateTime2), CAST(N'1900-01-01T07:07:00.0000000' AS DateTime2), N'sa', NULL, CAST(N'2025-06-05T23:46:13.853' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (12, 11, 1, 3, 19, CAST(N'2025-12-12T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T02:22:00.0000000' AS DateTime2), CAST(N'1900-01-01T03:07:00.0000000' AS DateTime2), N'as', NULL, CAST(N'2025-06-15T22:50:49.497' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (13, 11, 1, 3, 19, CAST(N'2025-12-12T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T14:22:00.0000000' AS DateTime2), CAST(N'1900-01-01T15:07:00.0000000' AS DateTime2), N'12', NULL, CAST(N'2025-06-15T22:54:00.193' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (14, 11, 1, 3, 19, NULL, CAST(N'1900-01-01T00:12:00.0000000' AS DateTime2), CAST(N'1900-01-01T00:57:00.0000000' AS DateTime2), N'a', NULL, CAST(N'2025-06-15T23:40:08.293' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (15, 11, 1, 3, 19, CAST(N'2025-12-12T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:11:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:56:00.0000000' AS DateTime2), N'111', NULL, CAST(N'2025-06-15T23:42:44.010' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (16, 11, 1, 4, 19, CAST(N'2025-11-11T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:11:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:41:00.0000000' AS DateTime2), N'as', NULL, CAST(N'2025-06-16T20:13:27.160' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (17, 11, 1, 3, 19, CAST(N'2025-06-16T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T22:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T22:45:00.0000000' AS DateTime2), N'aaaaa', NULL, CAST(N'2025-06-16T20:38:04.693' AS DateTime), CAST(N'2025-06-16T20:47:58.607' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, N'CHECKED_OUT', NULL, CAST(N'2025-06-16T20:47:54.9171310' AS DateTime2), CAST(N'2025-06-16T20:47:58.6019420' AS DateTime2), NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (18, 11, 1, 12, 19, CAST(N'2025-12-12T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T14:14:00.0000000' AS DateTime2), CAST(N'1900-01-01T15:14:00.0000000' AS DateTime2), N'aaaa', NULL, CAST(N'2025-06-18T23:47:07.550' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (19, 11, 1, 3, 20, CAST(N'2025-10-10T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T10:10:00.0000000' AS DateTime2), CAST(N'1900-01-01T10:55:00.0000000' AS DateTime2), N'as', NULL, CAST(N'2025-06-19T00:12:16.147' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (20, 11, 1, 3, 20, CAST(N'2025-09-09T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:11:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:56:00.0000000' AS DateTime2), N'a', NULL, CAST(N'2025-06-19T00:12:58.827' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (21, 11, 1, 3, 19, CAST(N'2025-08-08T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:11:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:56:00.0000000' AS DateTime2), N'sa', NULL, CAST(N'2025-06-19T00:18:29.133' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (22, 11, 2, 12, 22, CAST(N'2025-12-12T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T00:12:00.0000000' AS DateTime2), CAST(N'1900-01-01T01:12:00.0000000' AS DateTime2), N'sa', NULL, CAST(N'2025-06-19T00:21:47.520' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (23, 11, 1, 4, 21, CAST(N'2025-08-08T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:11:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:41:00.0000000' AS DateTime2), N'sa', NULL, CAST(N'2025-06-19T00:32:06.020' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (24, 11, 1, 3, 20, CAST(N'2025-08-18T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T00:12:00.0000000' AS DateTime2), CAST(N'1900-01-01T00:57:00.0000000' AS DateTime2), N'aaa', NULL, CAST(N'2025-06-19T23:14:40.020' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (25, 11, 1, 6, 22, CAST(N'2025-07-17T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T00:12:00.0000000' AS DateTime2), CAST(N'1900-01-01T00:42:00.0000000' AS DateTime2), N'asss', NULL, CAST(N'2025-06-25T01:43:25.047' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (26, 11, 1, 12, 21, CAST(N'2025-08-26T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T23:11:00.0000000' AS DateTime2), CAST(N'1900-01-01T00:11:00.0000000' AS DateTime2), N'tét', NULL, CAST(N'2025-06-26T17:52:22.043' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (27, 11, 1, 3, 20, CAST(N'2025-07-20T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T10:12:00.0000000' AS DateTime2), CAST(N'1900-01-01T10:57:00.0000000' AS DateTime2), N'sa', NULL, CAST(N'2025-06-26T18:00:13.107' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (28, 11, 1, 3, 20, CAST(N'2025-07-12T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:11:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:56:00.0000000' AS DateTime2), N'Tái khám sau điều trị', NULL, CAST(N'2025-06-26T21:22:31.867' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (29, 11, 1, 3, 19, CAST(N'2025-06-26T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T22:50:00.0000000' AS DateTime2), CAST(N'1900-01-01T23:35:00.0000000' AS DateTime2), NULL, NULL, CAST(N'2025-06-26T22:14:07.213' AS DateTime), CAST(N'2025-06-26T22:18:11.907' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, N'CHECK_IN', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (30, 11, 1, 1, 19, CAST(N'2025-06-26T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T23:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T00:00:00.0000000' AS DateTime2), NULL, NULL, CAST(N'2025-06-26T22:25:27.913' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (31, 11, 1, 3, 21, CAST(N'2025-06-30T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T23:45:00.0000000' AS DateTime2), CAST(N'1900-01-01T00:30:00.0000000' AS DateTime2), N'tesst', NULL, CAST(N'2025-06-30T23:06:08.360' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (32, 11, 1, 3, 20, CAST(N'2025-06-30T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T23:55:00.0000000' AS DateTime2), CAST(N'1900-01-01T00:40:00.0000000' AS DateTime2), N'test', NULL, CAST(N'2025-06-30T23:30:41.720' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (33, 11, 1, 3, 19, CAST(N'2025-07-13T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T12:12:00.0000000' AS DateTime2), CAST(N'1900-01-01T12:57:00.0000000' AS DateTime2), NULL, NULL, CAST(N'2025-06-30T23:35:30.623' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (34, 11, 1, 3, 19, CAST(N'2025-07-13T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T12:12:00.0000000' AS DateTime2), CAST(N'1900-01-01T12:57:00.0000000' AS DateTime2), NULL, NULL, CAST(N'2025-06-30T23:36:46.377' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (35, 11, 1, 3, 21, CAST(N'2025-12-12T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T00:12:00.0000000' AS DateTime2), CAST(N'1900-01-01T00:57:00.0000000' AS DateTime2), NULL, NULL, CAST(N'2025-06-30T23:38:55.680' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (36, 11, 1, 3, 19, CAST(N'2025-12-01T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T12:12:00.0000000' AS DateTime2), CAST(N'1900-01-01T12:57:00.0000000' AS DateTime2), NULL, NULL, CAST(N'2025-06-30T23:51:23.103' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (37, 11, 1, 3, 19, CAST(N'2025-12-12T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:01:00.0000000' AS DateTime2), CAST(N'1900-01-01T11:46:00.0000000' AS DateTime2), NULL, NULL, CAST(N'2025-07-04T01:20:04.473' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (38, 11, 1, 3, 19, CAST(N'2025-07-05T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T23:11:00.0000000' AS DateTime2), CAST(N'1900-01-01T23:56:00.0000000' AS DateTime2), NULL, NULL, CAST(N'2025-07-04T01:23:14.060' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (39, 11, 1, 3, 19, CAST(N'2025-07-05T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T23:11:00.0000000' AS DateTime2), CAST(N'1900-01-01T23:56:00.0000000' AS DateTime2), NULL, NULL, CAST(N'2025-07-04T01:26:35.437' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (40, 11, 1, 3, 19, CAST(N'2025-07-05T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T23:11:00.0000000' AS DateTime2), CAST(N'1900-01-01T23:56:00.0000000' AS DateTime2), NULL, NULL, CAST(N'2025-07-04T01:28:56.553' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    INSERT [dbo].[appointments] ([appointment_id], [customer_id], [branch_id], [service_id], [technician_id], [appointment_date], [start_time], [end_time], [notes], [cancellation_reason], [created_at], [updated_at], [reminder_sent], [reminder_sent_at], [check_in_time], [check_out_time], [preferred_technician_id], [special_requests], [status], [reminder_method], [checkin_time], [checkout_time], [room_id]) VALUES (41, 11, 1, 3, 19, CAST(N'2025-07-11T00:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T23:11:00.0000000' AS DateTime2), CAST(N'1900-01-01T23:56:00.0000000' AS DateTime2), NULL, NULL, CAST(N'2025-07-04T01:32:36.647' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'scheduled', NULL, NULL, NULL, NULL)
    SET IDENTITY_INSERT [dbo].[appointments] OFF
    GO
    SET IDENTITY_INSERT [dbo].[attendances] ON

    INSERT [dbo].[attendances] ([attendance_id], [break_end], [break_start], [check_in_time], [check_out_time], [created_at], [early_leave_minutes], [ip_address], [late_minutes], [location], [notes], [overtime_hours], [status], [total_hours], [updated_at], [work_date], [branch_id], [user_id]) VALUES (1, CAST(N'2025-06-12T20:54:27.1991690' AS DateTime2), CAST(N'2025-06-12T20:54:25.1228900' AS DateTime2), CAST(N'2025-06-12T12:54:02.8915620' AS DateTime2), CAST(N'2025-06-12T20:54:34.2250650' AS DateTime2), CAST(N'2025-06-12T20:54:02.9348960' AS DateTime2), NULL, N'0:0:0:0:0:0:0:1', NULL, N'Office', N'vao | Checkout: test', NULL, N'present', CAST(0.00 AS Numeric(5, 2)), CAST(N'2025-06-12T20:54:34.2586430' AS DateTime2), CAST(N'2025-06-12' AS Date), 1, 13)
    INSERT [dbo].[attendances] ([attendance_id], [break_end], [break_start], [check_in_time], [check_out_time], [created_at], [early_leave_minutes], [ip_address], [late_minutes], [location], [notes], [overtime_hours], [status], [total_hours], [updated_at], [work_date], [branch_id], [user_id]) VALUES (2, CAST(N'2025-06-12T20:57:23.1410680' AS DateTime2), CAST(N'2025-06-12T20:57:20.4825650' AS DateTime2), CAST(N'2025-06-12T12:57:17.4522170' AS DateTime2), CAST(N'2025-06-12T20:57:28.5501950' AS DateTime2), CAST(N'2025-06-12T20:57:17.4702260' AS DateTime2), NULL, N'0:0:0:0:0:0:0:1', NULL, N'Office', N'test | Checkout: 5', NULL, N'present', CAST(0.00 AS Numeric(5, 2)), CAST(N'2025-06-12T20:57:28.5857140' AS DateTime2), CAST(N'2025-06-12' AS Date), 1, 14)
    SET IDENTITY_INSERT [dbo].[attendances] OFF
    GO
    SET IDENTITY_INSERT [dbo].[blog] ON

    INSERT [dbo].[blog] ([id], [author], [content], [published_date], [title]) VALUES (1, N'Thinh', N'?? Bí quy?t gi? làn da luôn r?ng r? m?i ngày!
B?n có bi?t? M?t làn da d?p không ch? d?n t? m? ph?m d?t ti?n, mà b?t d?u t? nh?ng thói quen nh? m?i ngày.
Du?i dây là 3 “bí kíp” giúp b?n luôn r?ng ng?i, t? tin:

? 1. Làm s?ch sâu nhung nh? d?u
Làm s?ch da m?i sáng và t?i giúp lo?i b? b?i b?n và d?u th?a – bu?c n?n t?ng d? da h?p th? du?ng ch?t t?t hon!

?? 2. Du?ng ?m d?y d? – b?t k? b?n da khô hay da d?u
Ð? ?m cân b?ng giúp da m?n màng, ch?ng lão hóa và h?n ch? ti?t d?u.

?? 3. Ð?p t? bên trong: U?ng d? nu?c, an nhi?u rau xanh và ng? d? gi?c
Không gì thay th? du?c l?i s?ng lành m?nh – dó chính là "m? ph?m t? nhiên" quý giá nh?t.', CAST(N'2025-06-27' AS Date), N'test')
    SET IDENTITY_INSERT [dbo].[blog] OFF
    GO
    SET IDENTITY_INSERT [dbo].[branches] ON

    INSERT [dbo].[branches] ([branch_id], [name], [address], [phone], [email], [manager_id], [opening_hours], [capacity], [status], [created_at], [updated_at], [is_active], [operating_hours], [holiday_schedule]) VALUES (1, N'Tr?n Th?nh', N'326 c?m 4 thôn 3 xã Th?ch Hòa huy?n Th?ch Th?t', N'0342617981', N'thinhtran9797yb@gmail.com', 14, N'7:00', 123, N'active', CAST(N'2025-06-05T02:38:07.333' AS DateTime), CAST(N'2025-06-05T02:43:24.297' AS DateTime), 1, N'8h', N'thu 7')
    INSERT [dbo].[branches] ([branch_id], [name], [address], [phone], [email], [manager_id], [opening_hours], [capacity], [status], [created_at], [updated_at], [is_active], [operating_hours], [holiday_schedule]) VALUES (2, N'Da Nang', N'Da Nang', N'0342617981', N'thinhtran@gmail.com', 16, N'7:00', 123, N'active', CAST(N'2025-06-12T23:20:52.297' AS DateTime), CAST(N'2025-06-12T23:20:52.297' AS DateTime), 1, N'8h', N'thu 7')
    SET IDENTITY_INSERT [dbo].[branches] OFF
    GO
    SET IDENTITY_INSERT [dbo].[favorite_services] ON

    INSERT [dbo].[favorite_services] ([favorite_id], [created_at], [customer_id], [service_id]) VALUES (1, CAST(N'2025-06-25T01:07:20.4444360' AS DateTime2), 11, 3)
    SET IDENTITY_INSERT [dbo].[favorite_services] OFF
    GO
    SET IDENTITY_INSERT [dbo].[invoices] ON

    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (1, 3, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-05T23:18:07.743' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1749140287741')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (2, 4, 11, 1, CAST(280000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(28000.00 AS Numeric(38, 2)), CAST(308000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-05T23:23:44.257' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1749140624253')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (3, 5, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-05T23:28:26.240' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1749140906238')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (4, 6, 11, 1, CAST(450000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(45000.00 AS Numeric(38, 2)), CAST(495000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-05T23:31:01.330' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1749141061328')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (5, 7, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-05T23:34:57.173' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1749141297171')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (6, 8, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-05T23:37:20.400' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1749141440399')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (7, 9, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-05T23:39:28.120' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1749141568118')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (8, 10, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-05T23:41:41.920' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1749141701919')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (9, 11, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'paid', N'VNPAY', CAST(N'2025-06-05T23:47:19.657' AS DateTime), CAST(N'2025-06-05T23:46:13.917' AS DateTime), CAST(N'2025-06-05T23:47:19.657' AS DateTime), NULL, NULL, NULL, N'INV-1749141973913')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (10, 15, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-15T23:42:44.070' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1750005764066')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (11, 16, 11, 1, CAST(250000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(25000.00 AS Numeric(38, 2)), CAST(275000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-16T20:13:27.243' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1750079607239')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (12, 17, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-16T20:38:04.757' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1750081084752')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (13, 18, 11, 1, CAST(280000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(28000.00 AS Numeric(38, 2)), CAST(308000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-18T23:47:07.600' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1750265227600')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (14, 19, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-19T00:12:16.197' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1750266736193')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (15, 20, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-19T00:12:58.863' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1750266778861')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (16, 21, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-19T00:18:29.217' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1750267109212')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (17, 22, 11, 2, CAST(280000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(28000.00 AS Numeric(38, 2)), CAST(308000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-19T00:21:47.577' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1750267307576')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (18, 23, 11, 1, CAST(250000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(25000.00 AS Numeric(38, 2)), CAST(275000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-19T00:32:06.070' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1750267926067')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (19, 24, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'unpaid', NULL, NULL, CAST(N'2025-06-19T23:14:40.083' AS DateTime), NULL, NULL, NULL, NULL, N'INV-1750349680081')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (20, 3, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'PAID', N'CASH', CAST(N'2025-06-19T23:57:03.693' AS DateTime), CAST(N'2025-06-19T23:57:03.700' AS DateTime), NULL, NULL, NULL, N'', N'INV-1750352223692')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (21, 3, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'PAID', N'CASH', CAST(N'2025-06-23T21:10:58.903' AS DateTime), CAST(N'2025-06-23T21:10:58.920' AS DateTime), NULL, NULL, NULL, N'', N'INV-1750687858902')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (22, 3, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'PAID', N'CASH', CAST(N'2025-06-23T21:11:08.520' AS DateTime), CAST(N'2025-06-23T21:11:08.523' AS DateTime), NULL, NULL, NULL, N'', N'INV-1750687868521')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (23, 30, 11, 1, CAST(450000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(45000.00 AS Numeric(38, 2)), CAST(495000.00 AS Numeric(38, 2)), N'PAID', N'CASH', CAST(N'2025-06-26T22:25:27.953' AS DateTime), CAST(N'2025-06-26T22:25:27.957' AS DateTime), NULL, NULL, NULL, N'Invoice created automatically after appointment.', N'INV-1750951527954')
    INSERT [dbo].[invoices] ([invoice_id], [appointment_id], [customer_id], [branch_id], [total_amount], [discount_amount], [tax_amount], [final_amount], [payment_status], [payment_method], [payment_date], [created_at], [updated_at], [payment_reference], [payment_channel], [payment_notes], [invoice_number]) VALUES (24, 41, 11, 1, CAST(300000.00 AS Numeric(38, 2)), CAST(0.00 AS Numeric(38, 2)), CAST(30000.00 AS Numeric(38, 2)), CAST(330000.00 AS Numeric(38, 2)), N'PAID', N'CASH', CAST(N'2025-07-04T01:32:36.773' AS DateTime), CAST(N'2025-07-04T01:32:36.777' AS DateTime), NULL, NULL, NULL, N'Invoice created automatically after appointment.', N'INV-1751567556772')
    SET IDENTITY_INSERT [dbo].[invoices] OFF
    GO
    SET IDENTITY_INSERT [dbo].[membership_orders] ON

    INSERT [dbo].[membership_orders] ([order_id], [created_at], [discount_amount], [final_price], [order_code], [original_price], [paid_at], [payment_method], [payment_transaction_id], [status], [updated_at], [customer_id], [membership_id]) VALUES (1, CAST(N'2025-06-24T20:38:22.5607950' AS DateTime2), CAST(15.00 AS Numeric(38, 2)), CAST(135.00 AS Numeric(38, 2)), 1750772302601, CAST(150.00 AS Numeric(38, 2)), NULL, N'PAYOS', NULL, N'PENDING', NULL, 11, 4)
    INSERT [dbo].[membership_orders] ([order_id], [created_at], [discount_amount], [final_price], [order_code], [original_price], [paid_at], [payment_method], [payment_transaction_id], [status], [updated_at], [customer_id], [membership_id]) VALUES (2, CAST(N'2025-06-24T20:39:41.5265640' AS DateTime2), CAST(5.00 AS Numeric(38, 2)), CAST(95.00 AS Numeric(38, 2)), 1750772381589, CAST(100.00 AS Numeric(38, 2)), NULL, N'PAYOS', NULL, N'PENDING', NULL, 11, 1)
    INSERT [dbo].[membership_orders] ([order_id], [created_at], [discount_amount], [final_price], [order_code], [original_price], [paid_at], [payment_method], [payment_transaction_id], [status], [updated_at], [customer_id], [membership_id]) VALUES (3, CAST(N'2025-06-24T20:50:15.0333590' AS DateTime2), CAST(15.00 AS Numeric(38, 2)), CAST(135.00 AS Numeric(38, 2)), 1750773015438, CAST(150.00 AS Numeric(38, 2)), NULL, N'PAYOS', NULL, N'PENDING', NULL, 11, 4)
    INSERT [dbo].[membership_orders] ([order_id], [created_at], [discount_amount], [final_price], [order_code], [original_price], [paid_at], [payment_method], [payment_transaction_id], [status], [updated_at], [customer_id], [membership_id]) VALUES (4, CAST(N'2025-06-24T20:53:36.8108190' AS DateTime2), CAST(15.00 AS Numeric(38, 2)), CAST(135.00 AS Numeric(38, 2)), 1750773217006, CAST(150.00 AS Numeric(38, 2)), NULL, N'PAYOS', NULL, N'PENDING', NULL, 11, 4)
    INSERT [dbo].[membership_orders] ([order_id], [created_at], [discount_amount], [final_price], [order_code], [original_price], [paid_at], [payment_method], [payment_transaction_id], [status], [updated_at], [customer_id], [membership_id]) VALUES (5, CAST(N'2025-06-24T22:23:17.4891630' AS DateTime2), CAST(15.00 AS Numeric(38, 2)), CAST(135.00 AS Numeric(38, 2)), 1750778598167, CAST(150.00 AS Numeric(38, 2)), NULL, N'PAYOS', NULL, N'PENDING', NULL, 11, 4)
    INSERT [dbo].[membership_orders] ([order_id], [created_at], [discount_amount], [final_price], [order_code], [original_price], [paid_at], [payment_method], [payment_transaction_id], [status], [updated_at], [customer_id], [membership_id]) VALUES (6, CAST(N'2025-06-24T22:25:30.9211490' AS DateTime2), CAST(5.00 AS Numeric(38, 2)), CAST(95.00 AS Numeric(38, 2)), 1750778728535, CAST(100.00 AS Numeric(38, 2)), NULL, N'PAYOS', NULL, N'PENDING', NULL, 11, 1)
    INSERT [dbo].[membership_orders] ([order_id], [created_at], [discount_amount], [final_price], [order_code], [original_price], [paid_at], [payment_method], [payment_transaction_id], [status], [updated_at], [customer_id], [membership_id]) VALUES (7, CAST(N'2025-06-24T22:35:35.6272310' AS DateTime2), CAST(15.00 AS Numeric(38, 2)), CAST(135.00 AS Numeric(38, 2)), 1750779334425, CAST(150.00 AS Numeric(38, 2)), NULL, N'PAYOS', NULL, N'PENDING', NULL, 11, 4)
    INSERT [dbo].[membership_orders] ([order_id], [created_at], [discount_amount], [final_price], [order_code], [original_price], [paid_at], [payment_method], [payment_transaction_id], [status], [updated_at], [customer_id], [membership_id]) VALUES (8, CAST(N'2025-06-24T22:36:31.9716360' AS DateTime2), CAST(5.00 AS Numeric(38, 2)), CAST(95.00 AS Numeric(38, 2)), 1750779392009, CAST(100.00 AS Numeric(38, 2)), NULL, N'PAYOS', NULL, N'PENDING', NULL, 11, 1)
    INSERT [dbo].[membership_orders] ([order_id], [created_at], [discount_amount], [final_price], [order_code], [original_price], [paid_at], [payment_method], [payment_transaction_id], [status], [updated_at], [customer_id], [membership_id]) VALUES (9, CAST(N'2025-06-25T01:22:41.4604930' AS DateTime2), CAST(15.00 AS Numeric(38, 2)), CAST(135.00 AS Numeric(38, 2)), 1750789361959, CAST(150.00 AS Numeric(38, 2)), NULL, N'PAYOS', NULL, N'PENDING', NULL, 11, 4)
    INSERT [dbo].[membership_orders] ([order_id], [created_at], [discount_amount], [final_price], [order_code], [original_price], [paid_at], [payment_method], [payment_transaction_id], [status], [updated_at], [customer_id], [membership_id]) VALUES (10, CAST(N'2025-06-25T01:24:55.2573640' AS DateTime2), CAST(5.00 AS Numeric(38, 2)), CAST(95.00 AS Numeric(38, 2)), 1750789496211, CAST(100.00 AS Numeric(38, 2)), NULL, N'PAYOS', NULL, N'PENDING', NULL, 11, 1)
    INSERT [dbo].[membership_orders] ([order_id], [created_at], [discount_amount], [final_price], [order_code], [original_price], [paid_at], [payment_method], [payment_transaction_id], [status], [updated_at], [customer_id], [membership_id]) VALUES (11, CAST(N'2025-06-25T01:26:34.4114250' AS DateTime2), CAST(5.00 AS Numeric(38, 2)), CAST(95.00 AS Numeric(38, 2)), 1750789595146, CAST(100.00 AS Numeric(38, 2)), NULL, N'PAYOS', NULL, N'PENDING', NULL, 11, 1)
    INSERT [dbo].[membership_orders] ([order_id], [created_at], [discount_amount], [final_price], [order_code], [original_price], [paid_at], [payment_method], [payment_transaction_id], [status], [updated_at], [customer_id], [membership_id]) VALUES (12, CAST(N'2025-06-25T01:28:19.4155940' AS DateTime2), CAST(5.00 AS Numeric(38, 2)), CAST(95.00 AS Numeric(38, 2)), 1750789699603, CAST(100.00 AS Numeric(38, 2)), NULL, N'PAYOS', NULL, N'PENDING', NULL, 11, 1)
    SET IDENTITY_INSERT [dbo].[membership_orders] OFF
    GO
    SET IDENTITY_INSERT [dbo].[memberships] ON

    INSERT [dbo].[memberships] ([membership_id], [benefits], [created_at], [description], [discount_percent], [duration_months], [free_consultation], [max_bookings_per_month], [name], [price], [priority_booking], [status], [updated_at]) VALUES (1, N'Gi?m giá 5% d?ch v?', CAST(N'2025-06-23T23:22:03.1833330' AS DateTime2), N'Gói co b?n phù h?p v?i ngu?i dùng m?i.', 5, 6, 0, 3, N'Standard', CAST(100.00 AS Numeric(38, 2)), 0, N'active', CAST(N'2025-06-23T23:22:03.1833330' AS DateTime2))
    INSERT [dbo].[memberships] ([membership_id], [benefits], [created_at], [description], [discount_percent], [duration_months], [free_consultation], [max_bookings_per_month], [name], [price], [priority_booking], [status], [updated_at]) VALUES (2, N'Gi?m giá 15%, tu v?n mi?n phí', CAST(N'2025-06-23T23:22:03.1833330' AS DateTime2), N'Gói nâng cao v?i quy?n l?i t?t hon.', 15, 12, 1, 6, N'Premium', CAST(250.00 AS Numeric(38, 2)), 1, N'active', CAST(N'2025-06-23T23:22:03.1833330' AS DateTime2))
    INSERT [dbo].[memberships] ([membership_id], [benefits], [created_at], [description], [discount_percent], [duration_months], [free_consultation], [max_bookings_per_month], [name], [price], [priority_booking], [status], [updated_at]) VALUES (3, N'Gi?m giá 20%, uu tiên d?t l?ch', CAST(N'2025-06-23T23:22:03.1833330' AS DateTime2), N'Gói d?c bi?t cho khách hàng thân thi?t.', 20, 12, 1, 8, N'Gold', CAST(400.00 AS Numeric(38, 2)), 1, N'active', CAST(N'2025-06-23T23:22:03.1833330' AS DateTime2))
    INSERT [dbo].[memberships] ([membership_id], [benefits], [created_at], [description], [discount_percent], [duration_months], [free_consultation], [max_bookings_per_month], [name], [price], [priority_booking], [status], [updated_at]) VALUES (4, N'Gi?m giá 10%', CAST(N'2025-06-23T23:22:03.1833330' AS DateTime2), N'Gói ti?t ki?m v?i m?t s? quy?n l?i co b?n.', 10, 6, 0, 4, N'Silver', CAST(150.00 AS Numeric(38, 2)), 0, N'active', CAST(N'2025-06-23T23:22:03.1833330' AS DateTime2))
    INSERT [dbo].[memberships] ([membership_id], [benefits], [created_at], [description], [discount_percent], [duration_months], [free_consultation], [max_bookings_per_month], [name], [price], [priority_booking], [status], [updated_at]) VALUES (5, N'Gi?m giá 30%, d?t l?ch không gi?i h?n, tu v?n mi?n phí', CAST(N'2025-06-23T23:22:03.1833330' AS DateTime2), N'Gói cao c?p nh?t v?i d?y d? d?c quy?n.', 30, 24, 1, 999, N'VIP', CAST(800.00 AS Numeric(38, 2)), 1, N'active', CAST(N'2025-06-23T23:22:03.1833330' AS DateTime2))
    SET IDENTITY_INSERT [dbo].[memberships] OFF
    GO
    SET IDENTITY_INSERT [dbo].[payment_transactions] ON

    INSERT [dbo].[payment_transactions] ([transaction_id], [invoice_id], [amount], [payment_method], [payment_channel], [transaction_reference], [status], [payment_date], [notes]) VALUES (1, 9, CAST(330000.00 AS Numeric(38, 2)), N'VNPAY', N'ONLINE', N'1749141975090', N'success', CAST(N'2025-06-05T23:47:19.640' AS DateTime), NULL)
    INSERT [dbo].[payment_transactions] ([transaction_id], [invoice_id], [amount], [payment_method], [payment_channel], [transaction_reference], [status], [payment_date], [notes]) VALUES (2, 17, CAST(308000.00 AS Numeric(38, 2)), N'PAYOS', N'ONLINE', N'1750267308741', N'cancelled', CAST(N'2025-06-19T00:21:49.553' AS DateTime), NULL)
    INSERT [dbo].[payment_transactions] ([transaction_id], [invoice_id], [amount], [payment_method], [payment_channel], [transaction_reference], [status], [payment_date], [notes]) VALUES (3, 18, CAST(275000.00 AS Numeric(38, 2)), N'PAYOS', N'ONLINE', N'1750267927507', N'cancelled', CAST(N'2025-06-19T00:32:08.973' AS DateTime), NULL)
    INSERT [dbo].[payment_transactions] ([transaction_id], [invoice_id], [amount], [payment_method], [payment_channel], [transaction_reference], [status], [payment_date], [notes]) VALUES (4, 1, CAST(330000.00 AS Numeric(38, 2)), N'PAYOS', N'ONLINE', N'1750338924253', N'cancelled', CAST(N'2025-06-19T20:15:24.683' AS DateTime), NULL)
    INSERT [dbo].[payment_transactions] ([transaction_id], [invoice_id], [amount], [payment_method], [payment_channel], [transaction_reference], [status], [payment_date], [notes]) VALUES (5, 2, CAST(308000.00 AS Numeric(38, 2)), N'PAYOS', N'ONLINE', N'1750338935650', N'cancelled', CAST(N'2025-06-19T20:15:35.927' AS DateTime), NULL)
    INSERT [dbo].[payment_transactions] ([transaction_id], [invoice_id], [amount], [payment_method], [payment_channel], [transaction_reference], [status], [payment_date], [notes]) VALUES (6, 1, CAST(330000.00 AS Numeric(38, 2)), N'PAYOS', N'ONLINE', N'1750779197994', N'cancelled', CAST(N'2025-06-24T22:34:59.770' AS DateTime), NULL)
    INSERT [dbo].[payment_transactions] ([transaction_id], [invoice_id], [amount], [payment_method], [payment_channel], [transaction_reference], [status], [payment_date], [notes]) VALUES (7, 1, CAST(330000.00 AS Numeric(38, 2)), N'PAYOS', N'ONLINE', N'1750779486342', N'cancelled', CAST(N'2025-06-24T22:38:09.347' AS DateTime), NULL)
    INSERT [dbo].[payment_transactions] ([transaction_id], [invoice_id], [amount], [payment_method], [payment_channel], [transaction_reference], [status], [payment_date], [notes]) VALUES (8, 1, CAST(330000.00 AS Numeric(38, 2)), N'PAYOS', N'ONLINE', N'1750779522863', N'pending', CAST(N'2025-06-24T22:48:34.983' AS DateTime), NULL)
    SET IDENTITY_INSERT [dbo].[payment_transactions] OFF
    GO
    SET IDENTITY_INSERT [dbo].[roles] ON

    INSERT [dbo].[roles] ([role_id], [description], [role_name]) VALUES (1, NULL, N'CUSTOMER')
    INSERT [dbo].[roles] ([role_id], [description], [role_name]) VALUES (2, NULL, N'ADMIN')
    INSERT [dbo].[roles] ([role_id], [description], [role_name]) VALUES (3, NULL, N'MANAGER')
    INSERT [dbo].[roles] ([role_id], [description], [role_name]) VALUES (4, NULL, N'TECHNICIAN')
    INSERT [dbo].[roles] ([role_id], [description], [role_name]) VALUES (5, NULL, N'RECEPTIONIST')
    SET IDENTITY_INSERT [dbo].[roles] OFF
    GO
    SET IDENTITY_INSERT [dbo].[rooms] ON

    INSERT [dbo].[rooms] ([id], [capacity], [description], [name], [status], [branch_id]) VALUES (1, 12, NULL, N'Tr?n Th?nh', N'available', 1)
    SET IDENTITY_INSERT [dbo].[rooms] OFF
    GO
    SET IDENTITY_INSERT [dbo].[salary_records] ON

    INSERT [dbo].[salary_records] ([salary_id], [user_id], [branch_id], [month], [year], [base_salary], [bonus], [commission], [overtime_pay], [deductions], [net_salary], [payment_date], [status], [notes], [created_at], [updated_at]) VALUES (2, 11, 1, 6, 2025, CAST(5000000.00 AS Decimal(10, 2)), NULL, NULL, CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), NULL, N'pending', N'Tính lương tự động dựa trên chấm công', CAST(N'2025-06-12T21:56:23.490' AS DateTime), CAST(N'2025-06-12T21:56:23.490' AS DateTime))
    INSERT [dbo].[salary_records] ([salary_id], [user_id], [branch_id], [month], [year], [base_salary], [bonus], [commission], [overtime_pay], [deductions], [net_salary], [payment_date], [status], [notes], [created_at], [updated_at]) VALUES (23, 14, 1, 6, 2025, CAST(50000000.00 AS Decimal(10, 2)), NULL, CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(-2272727.27 AS Decimal(10, 2)), CAST(4545454.54 AS Decimal(10, 2)), NULL, N'approved', N'Tính lương tự động dựa trên chấm công và cấu hình hoa hồng', CAST(N'2025-06-16T22:51:44.703' AS DateTime), CAST(N'2025-06-16T22:51:44.703' AS DateTime))
    INSERT [dbo].[salary_records] ([salary_id], [user_id], [branch_id], [month], [year], [base_salary], [bonus], [commission], [overtime_pay], [deductions], [net_salary], [payment_date], [status], [notes], [created_at], [updated_at]) VALUES (24, 15, 1, 6, 2025, CAST(5000000.00 AS Decimal(10, 2)), NULL, CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), NULL, N'approved', N'Tính lương tự động dựa trên chấm công và cấu hình hoa hồng', CAST(N'2025-06-16T22:51:44.710' AS DateTime), CAST(N'2025-06-16T22:51:44.710' AS DateTime))
    INSERT [dbo].[salary_records] ([salary_id], [user_id], [branch_id], [month], [year], [base_salary], [bonus], [commission], [overtime_pay], [deductions], [net_salary], [payment_date], [status], [notes], [created_at], [updated_at]) VALUES (25, 16, 1, 6, 2025, CAST(5000000.00 AS Decimal(10, 2)), NULL, CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), NULL, N'approved', N'Tính lương tự động dựa trên chấm công và cấu hình hoa hồng', CAST(N'2025-06-16T22:51:44.720' AS DateTime), CAST(N'2025-06-16T22:51:44.720' AS DateTime))
    INSERT [dbo].[salary_records] ([salary_id], [user_id], [branch_id], [month], [year], [base_salary], [bonus], [commission], [overtime_pay], [deductions], [net_salary], [payment_date], [status], [notes], [created_at], [updated_at]) VALUES (26, 17, 1, 6, 2025, CAST(5000000.00 AS Decimal(10, 2)), NULL, CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), NULL, N'approved', N'Tính lương tự động dựa trên chấm công và cấu hình hoa hồng', CAST(N'2025-06-16T22:51:44.723' AS DateTime), CAST(N'2025-06-16T22:51:44.723' AS DateTime))
    INSERT [dbo].[salary_records] ([salary_id], [user_id], [branch_id], [month], [year], [base_salary], [bonus], [commission], [overtime_pay], [deductions], [net_salary], [payment_date], [status], [notes], [created_at], [updated_at]) VALUES (27, 18, 1, 6, 2025, CAST(5000000.00 AS Decimal(10, 2)), NULL, CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), NULL, N'approved', N'Tính lương tự động dựa trên chấm công và cấu hình hoa hồng', CAST(N'2025-06-16T22:51:44.727' AS DateTime), CAST(N'2025-06-16T22:51:44.727' AS DateTime))
    INSERT [dbo].[salary_records] ([salary_id], [user_id], [branch_id], [month], [year], [base_salary], [bonus], [commission], [overtime_pay], [deductions], [net_salary], [payment_date], [status], [notes], [created_at], [updated_at]) VALUES (28, 19, 1, 6, 2025, CAST(5000000.00 AS Decimal(10, 2)), NULL, CAST(30000.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(30000.00 AS Decimal(10, 2)), NULL, N'approved', N'Tính lương tự động dựa trên chấm công và cấu hình hoa hồng', CAST(N'2025-06-16T22:51:44.730' AS DateTime), CAST(N'2025-06-16T22:51:44.730' AS DateTime))
    INSERT [dbo].[salary_records] ([salary_id], [user_id], [branch_id], [month], [year], [base_salary], [bonus], [commission], [overtime_pay], [deductions], [net_salary], [payment_date], [status], [notes], [created_at], [updated_at]) VALUES (29, 20, 1, 6, 2025, CAST(5000000.00 AS Decimal(10, 2)), NULL, CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), NULL, N'approved', N'Tính lương tự động dựa trên chấm công và cấu hình hoa hồng', CAST(N'2025-06-16T22:51:44.737' AS DateTime), CAST(N'2025-06-16T22:51:44.737' AS DateTime))
    INSERT [dbo].[salary_records] ([salary_id], [user_id], [branch_id], [month], [year], [base_salary], [bonus], [commission], [overtime_pay], [deductions], [net_salary], [payment_date], [status], [notes], [created_at], [updated_at]) VALUES (30, 21, 1, 6, 2025, CAST(5000000.00 AS Decimal(10, 2)), NULL, CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), NULL, N'approved', N'Tính lương tự động dựa trên chấm công và cấu hình hoa hồng', CAST(N'2025-06-16T22:51:44.737' AS DateTime), CAST(N'2025-06-16T22:51:44.737' AS DateTime))
    INSERT [dbo].[salary_records] ([salary_id], [user_id], [branch_id], [month], [year], [base_salary], [bonus], [commission], [overtime_pay], [deductions], [net_salary], [payment_date], [status], [notes], [created_at], [updated_at]) VALUES (31, 22, 1, 6, 2025, CAST(5000000.00 AS Decimal(10, 2)), NULL, CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), NULL, N'approved', N'Tính lương tự động dựa trên chấm công và cấu hình hoa hồng', CAST(N'2025-06-16T22:51:44.743' AS DateTime), CAST(N'2025-06-16T22:51:44.743' AS DateTime))
    INSERT [dbo].[salary_records] ([salary_id], [user_id], [branch_id], [month], [year], [base_salary], [bonus], [commission], [overtime_pay], [deductions], [net_salary], [payment_date], [status], [notes], [created_at], [updated_at]) VALUES (32, 23, 1, 6, 2025, CAST(5000000.00 AS Decimal(10, 2)), NULL, CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), NULL, N'approved', N'Tính lương tự động dựa trên chấm công và cấu hình hoa hồng', CAST(N'2025-06-16T22:51:44.743' AS DateTime), CAST(N'2025-06-16T22:51:44.743' AS DateTime))
    INSERT [dbo].[salary_records] ([salary_id], [user_id], [branch_id], [month], [year], [base_salary], [bonus], [commission], [overtime_pay], [deductions], [net_salary], [payment_date], [status], [notes], [created_at], [updated_at]) VALUES (33, 24, 1, 6, 2025, CAST(15000000.00 AS Decimal(10, 2)), NULL, CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), CAST(0.00 AS Decimal(10, 2)), NULL, N'approved', N'Tính lương tự động dựa trên chấm công và cấu hình hoa hồng', CAST(N'2025-06-16T22:51:44.747' AS DateTime), CAST(N'2025-06-16T22:51:44.747' AS DateTime))
    SET IDENTITY_INSERT [dbo].[salary_records] OFF
    GO
    SET IDENTITY_INSERT [dbo].[salary_settings] ON

    INSERT [dbo].[salary_settings] ([id], [attendance_bonus], [commission_per_customer], [commission_per_service], [penalty], [rating_bonus], [revenue_bonus], [role]) VALUES (1, 10, 10, 25, 10, 10, 10, N'RECEPTIONIST')
    INSERT [dbo].[salary_settings] ([id], [attendance_bonus], [commission_per_customer], [commission_per_service], [penalty], [rating_bonus], [revenue_bonus], [role]) VALUES (2, 10, 10, 25, 10, 10, 10, N'TECHNICIAN')
    SET IDENTITY_INSERT [dbo].[salary_settings] OFF
    GO
    SET IDENTITY_INSERT [dbo].[service_categories] ON

    INSERT [dbo].[service_categories] ([category_id], [name], [description], [parent_category_id], [created_at]) VALUES (1, N'Thu giãn toàn thân', N'Dịch vụ massage giúp giảm stress, thư giãn toàn thân', NULL, CAST(N'2025-06-05T01:09:19.980' AS DateTime))
    INSERT [dbo].[service_categories] ([category_id], [name], [description], [parent_category_id], [created_at]) VALUES (2, N'Cham sóc da m?t', N'Làm sạch và chăm sóc da mặt chuyên sâu', NULL, CAST(N'2025-06-05T01:09:19.980' AS DateTime))
    INSERT [dbo].[service_categories] ([category_id], [name], [description], [parent_category_id], [created_at]) VALUES (3, N'Tri?t lông', N'Dịch vụ triệt lông bằng công nghệ hiện đại', NULL, CAST(N'2025-06-05T01:09:19.980' AS DateTime))
    INSERT [dbo].[service_categories] ([category_id], [name], [description], [parent_category_id], [created_at]) VALUES (4, N'Cham sóc móng', N'Làm móng tay và chân chuyên nghiệp', NULL, CAST(N'2025-06-05T01:09:19.980' AS DateTime))
    INSERT [dbo].[service_categories] ([category_id], [name], [description], [parent_category_id], [created_at]) VALUES (5, N'Massage dá nóng', N'Thuộc nhóm thư giãn toàn thân', 1, CAST(N'2025-06-05T01:09:19.980' AS DateTime))
    INSERT [dbo].[service_categories] ([category_id], [name], [description], [parent_category_id], [created_at]) VALUES (6, N'Massage Thái', N'Thuộc nhóm thư giãn toàn thân', 1, CAST(N'2025-06-05T01:09:19.980' AS DateTime))
    INSERT [dbo].[service_categories] ([category_id], [name], [description], [parent_category_id], [created_at]) VALUES (7, N'Làm s?ch sâu', N'Thuộc nhóm chăm sóc da mặt', 2, CAST(N'2025-06-05T01:09:19.980' AS DateTime))
    SET IDENTITY_INSERT [dbo].[service_categories] OFF
    GO
    SET IDENTITY_INSERT [dbo].[service_rating] ON

    INSERT [dbo].[service_rating] ([id], [comment], [created_at], [rating], [customer_id], [service_id]) VALUES (1, N'du?c', CAST(N'2025-06-25T01:02:59.0522810' AS DateTime2), 5, 11, 12)
    INSERT [dbo].[service_rating] ([id], [comment], [created_at], [rating], [customer_id], [service_id]) VALUES (2, N'test', CAST(N'2025-06-25T01:04:57.1209260' AS DateTime2), 5, 11, 3)
    SET IDENTITY_INSERT [dbo].[service_rating] OFF
    GO
    SET IDENTITY_INSERT [dbo].[service_schedule] ON

    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (102, 1, 1, 19, CAST(N'1900-01-01T08:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T16:00:00.0000000' AS DateTime2), 1, 1, CAST(N'2025-06-13T00:05:54.647' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (103, 1, 1, 20, CAST(N'1900-01-01T08:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T16:00:00.0000000' AS DateTime2), 1, 1, CAST(N'2025-06-13T00:05:54.713' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (104, 2, 2, 21, CAST(N'1900-01-01T09:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T17:00:00.0000000' AS DateTime2), 2, 1, CAST(N'2025-06-13T00:05:54.720' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (105, 2, 2, 21, CAST(N'1900-01-01T08:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T16:00:00.0000000' AS DateTime2), 4, 1, CAST(N'2025-06-13T00:05:54.733' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (106, 2, 2, 21, CAST(N'1900-01-01T09:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T17:00:00.0000000' AS DateTime2), 2, 1, CAST(N'2025-06-13T00:06:11.023' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (107, 2, 2, 21, CAST(N'1900-01-01T08:00:00.0000000' AS DateTime2), CAST(N'1900-01-01T16:00:00.0000000' AS DateTime2), 4, 1, CAST(N'2025-06-13T00:06:11.083' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (108, 3, 1, 19, CAST(N'2025-12-12T11:11:00.0000000' AS DateTime2), CAST(N'2025-12-12T11:56:00.0000000' AS DateTime2), 5, 1, CAST(N'2025-06-15T23:42:44.053' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (109, 4, 1, 19, CAST(N'2025-11-11T11:11:00.0000000' AS DateTime2), CAST(N'2025-11-11T11:41:00.0000000' AS DateTime2), 2, 1, CAST(N'2025-06-16T20:13:27.227' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (110, 3, 1, 19, CAST(N'2025-06-16T22:00:00.0000000' AS DateTime2), CAST(N'2025-06-16T22:45:00.0000000' AS DateTime2), 1, 1, CAST(N'2025-06-16T20:38:04.743' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (111, 12, 1, 19, CAST(N'2025-12-12T14:14:00.0000000' AS DateTime2), CAST(N'2025-12-12T15:14:00.0000000' AS DateTime2), 5, 1, CAST(N'2025-06-18T23:47:07.590' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (112, 3, 1, 20, CAST(N'2025-10-10T10:10:00.0000000' AS DateTime2), CAST(N'2025-10-10T10:55:00.0000000' AS DateTime2), 5, 1, CAST(N'2025-06-19T00:12:16.187' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (113, 3, 1, 20, CAST(N'2025-09-09T11:11:00.0000000' AS DateTime2), CAST(N'2025-09-09T11:56:00.0000000' AS DateTime2), 2, 1, CAST(N'2025-06-19T00:12:58.853' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (114, 3, 1, 19, CAST(N'2025-08-08T11:11:00.0000000' AS DateTime2), CAST(N'2025-08-08T11:56:00.0000000' AS DateTime2), 5, 1, CAST(N'2025-06-19T00:18:29.197' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (115, 12, 2, 22, CAST(N'2025-12-12T00:12:00.0000000' AS DateTime2), CAST(N'2025-12-12T01:12:00.0000000' AS DateTime2), 5, 1, CAST(N'2025-06-19T00:21:47.563' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (116, 4, 1, 21, CAST(N'2025-08-08T11:11:00.0000000' AS DateTime2), CAST(N'2025-08-08T11:41:00.0000000' AS DateTime2), 5, 1, CAST(N'2025-06-19T00:32:06.057' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (117, 3, 1, 20, CAST(N'2025-08-18T00:12:00.0000000' AS DateTime2), CAST(N'2025-08-18T00:57:00.0000000' AS DateTime2), 1, 1, CAST(N'2025-06-19T23:14:40.073' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (118, 6, 1, 22, CAST(N'2025-07-17T00:12:00.0000000' AS DateTime2), CAST(N'2025-07-17T00:42:00.0000000' AS DateTime2), 4, 1, CAST(N'2025-06-25T01:43:25.100' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (119, 12, 1, 21, CAST(N'2025-08-26T23:11:00.0000000' AS DateTime2), CAST(N'2025-08-27T00:11:00.0000000' AS DateTime2), 2, 1, CAST(N'2025-06-26T17:52:22.150' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (120, 3, 1, 20, CAST(N'2025-07-20T10:12:00.0000000' AS DateTime2), CAST(N'2025-07-20T10:57:00.0000000' AS DateTime2), 0, 1, CAST(N'2025-06-26T18:00:13.207' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (121, 3, 1, 20, CAST(N'2025-07-12T11:11:00.0000000' AS DateTime2), CAST(N'2025-07-12T11:56:00.0000000' AS DateTime2), 6, 1, CAST(N'2025-06-26T21:22:32.033' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (122, 3, 1, 20, CAST(N'2025-07-12T11:11:00.0000000' AS DateTime2), CAST(N'2025-07-12T11:56:00.0000000' AS DateTime2), 6, 1, CAST(N'2025-06-26T21:22:32.077' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (123, 3, 1, 21, CAST(N'2025-06-30T23:45:00.0000000' AS DateTime2), CAST(N'2025-07-01T00:30:00.0000000' AS DateTime2), 1, 1, CAST(N'2025-06-30T23:06:08.477' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (124, 3, 1, 20, CAST(N'2025-06-30T23:55:00.0000000' AS DateTime2), CAST(N'2025-07-01T00:40:00.0000000' AS DateTime2), 1, 1, CAST(N'2025-06-30T23:30:41.793' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (125, 3, 1, 19, CAST(N'2025-07-13T12:12:00.0000000' AS DateTime2), CAST(N'2025-07-13T12:57:00.0000000' AS DateTime2), 0, 1, CAST(N'2025-06-30T23:35:30.693' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (126, 3, 1, 21, CAST(N'2025-12-12T00:12:00.0000000' AS DateTime2), CAST(N'2025-12-12T00:57:00.0000000' AS DateTime2), 5, 1, CAST(N'2025-06-30T23:38:55.717' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (127, 3, 1, 19, CAST(N'2025-12-01T12:12:00.0000000' AS DateTime2), CAST(N'2025-12-01T12:57:00.0000000' AS DateTime2), 1, 1, CAST(N'2025-06-30T23:51:23.183' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (128, 3, 1, 19, CAST(N'2025-12-12T11:01:00.0000000' AS DateTime2), CAST(N'2025-12-12T11:46:00.0000000' AS DateTime2), 5, 1, CAST(N'2025-07-04T01:20:04.560' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (129, 3, 1, 19, CAST(N'2025-07-05T23:11:00.0000000' AS DateTime2), CAST(N'2025-07-05T23:56:00.0000000' AS DateTime2), 6, 1, CAST(N'2025-07-04T01:23:14.147' AS DateTime))
    INSERT [dbo].[service_schedule] ([schedule_id], [service_id], [branch_id], [technician_id], [start_time], [end_time], [day_of_week], [is_active], [created_at]) VALUES (130, 3, 1, 19, CAST(N'2025-07-11T23:11:00.0000000' AS DateTime2), CAST(N'2025-07-11T23:56:00.0000000' AS DateTime2), 5, 1, CAST(N'2025-07-04T01:32:36.713' AS DateTime))
    SET IDENTITY_INSERT [dbo].[service_schedule] OFF
    GO
    SET IDENTITY_INSERT [dbo].[services] ON

    INSERT [dbo].[services] ([service_id], [name], [description], [duration], [price], [category_id], [image_url], [status], [created_at], [updated_at]) VALUES (1, N'Massage dá nóng toàn thân', N'Thư giãn cơ thể với đá nóng và tinh dầu thiên nhiên', 60, CAST(450000.00 AS Numeric(38, 2)), 5, N'https://images.unsplash.com/photo-1600431521340-491eca880b09', N'active', CAST(N'2025-06-05T01:37:15.183' AS DateTime), CAST(N'2025-06-05T01:37:15.183' AS DateTime))
    INSERT [dbo].[services] ([service_id], [name], [description], [duration], [price], [category_id], [image_url], [status], [created_at], [updated_at]) VALUES (2, N'Massage Thái truy?n th?ng', N'Kỹ thuật bấm huyệt Thái Lan giúp giảm đau mỏi', 90, CAST(600000.00 AS Numeric(38, 2)), 6, N'https://images.unsplash.com/photo-1622030229241-06a2a7ddf67e', N'active', CAST(N'2025-06-05T01:37:15.183' AS DateTime), CAST(N'2025-06-05T01:37:15.183' AS DateTime))
    INSERT [dbo].[services] ([service_id], [name], [description], [duration], [price], [category_id], [image_url], [status], [created_at], [updated_at]) VALUES (3, N'Làm s?ch sâu da m?t', N'Làm sạch lỗ chân lông, hút dầu thừa và dưỡng da', 45, CAST(300000.00 AS Numeric(38, 2)), 7, N'https://res.cloudinary.com/dnm1hfesq/image/upload/v1749063604/zh2qd4rg8kabmenuj18s.jpg', N'active', CAST(N'2025-06-05T02:00:02.660' AS DateTime), CAST(N'2025-06-05T02:00:04.923' AS DateTime))
    INSERT [dbo].[services] ([service_id], [name], [description], [duration], [price], [category_id], [image_url], [status], [created_at], [updated_at]) VALUES (4, N'Tri?t lông nách', N'Sử dụng công nghệ ánh sáng IPL', 30, CAST(250000.00 AS Numeric(38, 2)), 3, N'https://images.unsplash.com/photo-1603428583044-2b6fdc51e4bc', N'active', CAST(N'2025-06-05T01:37:15.183' AS DateTime), CAST(N'2025-06-05T01:37:15.183' AS DateTime))
    INSERT [dbo].[services] ([service_id], [name], [description], [duration], [price], [category_id], [image_url], [status], [created_at], [updated_at]) VALUES (5, N'Tri?t lông chân toàn ph?n', N'Triệt vùng chân bằng ánh sáng sinh học', 60, CAST(450000.00 AS Numeric(38, 2)), 3, N'https://images.unsplash.com/photo-1582719478403-5011d02f8e8c', N'inactive', CAST(N'2025-06-05T01:37:15.183' AS DateTime), CAST(N'2025-06-05T01:37:15.183' AS DateTime))
    INSERT [dbo].[services] ([service_id], [name], [description], [duration], [price], [category_id], [image_url], [status], [created_at], [updated_at]) VALUES (6, N'Làm móng tay co b?n', N'Làm sạch da và sơn móng thường', 30, CAST(150000.00 AS Numeric(38, 2)), 4, N'https://images.unsplash.com/photo-1617059311344-4f5f243d178e', N'active', CAST(N'2025-06-05T01:37:15.183' AS DateTime), CAST(N'2025-06-05T01:37:15.183' AS DateTime))
    INSERT [dbo].[services] ([service_id], [name], [description], [duration], [price], [category_id], [image_url], [status], [created_at], [updated_at]) VALUES (7, N'Son gel ngh? thu?t', N'Thiết kế móng gel đẹp, sáng tạo, bền màu', 60, CAST(280000.00 AS Numeric(38, 2)), 4, N'https://images.unsplash.com/photo-1617691664513-f5fa7aa9f771', N'inactive', CAST(N'2025-06-05T01:47:40.817' AS DateTime), CAST(N'2025-06-05T01:47:40.843' AS DateTime))
    INSERT [dbo].[services] ([service_id], [name], [description], [duration], [price], [category_id], [image_url], [status], [created_at], [updated_at]) VALUES (8, N'Massage dá nóng toàn thân', N'Thư giãn cơ thể với đá nóng và tinh dầu thiên nhiên', 60, CAST(450000.00 AS Numeric(38, 2)), 5, N'https://res.cloudinary.com/dnm1hfesq/image/upload/v1749062305/zxt2zldcp5i0tkc34gms.png', N'active', CAST(N'2025-06-05T01:38:22.393' AS DateTime), CAST(N'2025-06-05T01:38:22.393' AS DateTime))
    INSERT [dbo].[services] ([service_id], [name], [description], [duration], [price], [category_id], [image_url], [status], [created_at], [updated_at]) VALUES (9, N'Son gel ngh? thu?t', N'Thiết kế móng gel đẹp, sáng tạo, bền màu', 60, CAST(280000.00 AS Numeric(38, 2)), 4, NULL, N'active', CAST(N'2025-06-05T01:43:13.933' AS DateTime), CAST(N'2025-06-05T01:43:13.933' AS DateTime))
    INSERT [dbo].[services] ([service_id], [name], [description], [duration], [price], [category_id], [image_url], [status], [created_at], [updated_at]) VALUES (10, N'Son gel ngh? thu?t', N'Thiết kế móng gel đẹp, sáng tạo, bền màu', 60, CAST(280000.00 AS Numeric(38, 2)), 4, NULL, N'inactive', CAST(N'2025-06-05T01:43:19.197' AS DateTime), CAST(N'2025-06-05T01:43:19.197' AS DateTime))
    INSERT [dbo].[services] ([service_id], [name], [description], [duration], [price], [category_id], [image_url], [status], [created_at], [updated_at]) VALUES (11, N'Son gel ngh? thu?t', N'Thiết kế móng gel đẹp, sáng tạo, bền màu', 60, CAST(280000.00 AS Numeric(38, 2)), 4, NULL, N'inactive', CAST(N'2025-06-05T01:43:28.913' AS DateTime), CAST(N'2025-06-05T01:43:28.913' AS DateTime))
    INSERT [dbo].[services] ([service_id], [name], [description], [duration], [price], [category_id], [image_url], [status], [created_at], [updated_at]) VALUES (12, N'Son gel ngh? thu?t', N'Thiết kế móng gel đẹp, sáng tạo, bền màu', 60, CAST(280000.00 AS Numeric(38, 2)), 4, NULL, N'active', CAST(N'2025-06-05T01:46:04.207' AS DateTime), CAST(N'2025-06-05T01:46:04.207' AS DateTime))
    SET IDENTITY_INSERT [dbo].[services] OFF
    GO
    SET IDENTITY_INSERT [dbo].[treatment_records] ON

    INSERT [dbo].[treatment_records] ([record_id], [appointment_id], [technician_id], [pre_treatment_notes], [post_treatment_notes], [before_image_url], [after_image_url], [treatment_date], [customer_feedback], [follow_up_notes], [treatment_progress], [next_appointment_recommendation], [created_at], [updated_at]) VALUES (1, 15, 19, N'test', N'test', N'https://res.cloudinary.com/dnm1hfesq/image/upload/v1750079821/egynamwt7gaxeovrpnga.png', N'https://res.cloudinary.com/dnm1hfesq/image/upload/v1750079823/hsapfml4jceb8uepj5tn.jpg', CAST(N'2025-11-11T11:30:00.000' AS DateTime), N'good', N'chưa biết', 70, NULL, CAST(N'2025-06-16T20:17:02.657' AS DateTime), NULL)
    INSERT [dbo].[treatment_records] ([record_id], [appointment_id], [technician_id], [pre_treatment_notes], [post_treatment_notes], [before_image_url], [after_image_url], [treatment_date], [customer_feedback], [follow_up_notes], [treatment_progress], [next_appointment_recommendation], [created_at], [updated_at]) VALUES (2, 22, 22, N'test', N'test', N'https://res.cloudinary.com/dnm1hfesq/image/upload/v1750349246/ptr5yijlets37ozed1cd.png', N'https://res.cloudinary.com/dnm1hfesq/image/upload/v1750349249/mhdtqhy8q6zjsotqz0la.png', CAST(N'2025-12-12T00:12:00.000' AS DateTime), N'good', N'chưa biết', 80, CAST(N'2025-12-17' AS Date), CAST(N'2025-06-19T23:07:29.840' AS DateTime), NULL)
    INSERT [dbo].[treatment_records] ([record_id], [appointment_id], [technician_id], [pre_treatment_notes], [post_treatment_notes], [before_image_url], [after_image_url], [treatment_date], [customer_feedback], [follow_up_notes], [treatment_progress], [next_appointment_recommendation], [created_at], [updated_at]) VALUES (3, 19, 20, N'tesst', N'tesst', N'https://res.cloudinary.com/dnm1hfesq/image/upload/v1750947749/qy5hjigkbcrgowvdthsc.png', N'https://res.cloudinary.com/dnm1hfesq/image/upload/v1750947751/rot3ieejqj166kzs0xhc.png', CAST(N'2025-12-12T11:11:00.000' AS DateTime), N'test', N'test', 70, CAST(N'2025-07-12' AS Date), CAST(N'2025-06-26T21:22:31.663' AS DateTime), NULL)
    SET IDENTITY_INSERT [dbo].[treatment_records] OFF
    GO
    SET IDENTITY_INSERT [dbo].[user_kpi] ON

    INSERT [dbo].[user_kpi] ([kpi_id], [actual_appointments], [created_at], [month], [status], [target_appointments], [updated_at], [year], [manager_id], [technician_id]) VALUES (1, 5, CAST(N'2025-07-04T00:33:16.5344640' AS DateTime2), 7, N'active', 25, CAST(N'2025-07-04T01:32:36.7445490' AS DateTime2), 2025, 14, 19)
    SET IDENTITY_INSERT [dbo].[user_kpi] OFF
    GO
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (11, 1)
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (12, 1)
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (13, 2)
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (14, 3)
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (15, 3)
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (16, 3)
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (17, 3)
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (18, 3)
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (19, 4)
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (20, 4)
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (21, 4)
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (22, 4)
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (23, 5)
    INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (24, 3)
    GO
    SET IDENTITY_INSERT [dbo].[users] ON

    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (11, N'thinhtran9797yb', N'OAUTH2_USER', N'thinhtran9797yb@gmail.com', N'Thịnh Trần', NULL, NULL, NULL, NULL, N'active', 1, NULL, NULL, NULL, NULL, CAST(N'2025-06-30T23:30:16.937' AS DateTime), CAST(N'2025-05-30T01:22:44.080' AS DateTime), CAST(N'2025-06-30T23:30:17.013' AS DateTime), NULL, NULL, NULL, NULL, N'regular', NULL, NULL, NULL, NULL, 1, 0, 0, NULL, 0, NULL, N'https://res.cloudinary.com/dnm1hfesq/image/upload/v1749150169/unmdwn4cvq8abmlgaanj.jpg', NULL, NULL, 1, CAST(10000000.00 AS Numeric(10, 2)))
    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (12, N'thinhtdhe173229', N'OAUTH2_USER', N'thinhtdhe173229@fpt.edu.vn', N'Tran Duc Thinh (K17 HL)', NULL, NULL, NULL, NULL, N'active', 1, NULL, NULL, NULL, NULL, CAST(N'2025-06-02T12:57:48.080' AS DateTime), CAST(N'2025-05-30T01:23:17.273' AS DateTime), CAST(N'2025-06-05T21:57:17.993' AS DateTime), NULL, NULL, NULL, NULL, N'regular', NULL, NULL, NULL, NULL, 1, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL)
    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (13, N'nghia', N'$2a$10$SjCSwIfmJICybJFfbGdSjemk7dSQRU9m/FTTBK.K94ml0dQLI0sea', N'tuannghia200603@gmail.com', N'Nghixa', N'0342617981', CAST(N'2003-06-20' AS Date), N'MALE', N'Trọ Mai Linh thôn 8 xã Thạch Hòa huyện Thạch Thất', N'active', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'2025-06-02T13:07:16.043' AS DateTime), CAST(N'2025-06-12T22:31:50.950' AS DateTime), CAST(N'2025-06-12T20:54:02.890' AS DateTime), CAST(N'2025-06-12T20:54:34.227' AS DateTime), NULL, NULL, N'regular', NULL, NULL, NULL, CAST(N'2025-06-02T21:12:17.973' AS DateTime), 1, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, CAST(10000000.00 AS Numeric(10, 2)))
    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (14, N'manager1', N'$2a$10$iJQ7ebVk01v2CEnJpM/GNuGt9R47R3AHjDAJOwchvjgL9TzCQRbTS', N'manager1@spa.com', N'Manager 1', N'0123456781', CAST(N'1990-01-01' AS Date), N'MALE', N'Địa chỉ số 1', N'active', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'2025-06-05T02:05:31.917' AS DateTime), CAST(N'2025-06-12T22:49:22.940' AS DateTime), CAST(N'2025-06-12T20:57:17.453' AS DateTime), CAST(N'2025-06-12T20:57:28.550' AS DateTime), NULL, NULL, N'regular', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, CAST(50000000.00 AS Numeric(10, 2)))
    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (15, N'manager2', N'$2a$10$Rtah9Y.tBu1Ym/H6Ax6Kge6KcWdz6P4dIktQG6q71UKXNZdsvPGbK', N'manager2@spa.com', N'Manager 2', N'0123456782', CAST(N'1990-01-02' AS Date), N'MALE', N'Địa chỉ số 2', N'active', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'2025-06-05T02:05:32.073' AS DateTime), CAST(N'2025-06-05T02:05:32.073' AS DateTime), NULL, NULL, NULL, NULL, N'regular', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL)
    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (16, N'manager3', N'$2a$10$zddciW0ElKNggPBqFx4Av.e3gSD6w336jJUfs1RHOV1I4t/Scbi7O', N'manager3@spa.com', N'Manager 3', N'0123456783', CAST(N'1990-01-03' AS Date), N'MALE', N'Địa chỉ số 3', N'active', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'2025-06-05T02:05:32.190' AS DateTime), CAST(N'2025-06-05T02:05:32.190' AS DateTime), NULL, NULL, NULL, NULL, N'regular', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL)
    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (17, N'manager4', N'$2a$10$QL/g6WSWCz4BQVPKFg4l/umaQGlI9Jdw1SJ.dnOe2a.CWEbheHOg.', N'manager4@spa.com', N'Manager 4', N'0123456784', CAST(N'1990-01-04' AS Date), N'MALE', N'Địa chỉ số 4', N'active', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'2025-06-05T02:05:32.310' AS DateTime), CAST(N'2025-06-05T02:05:32.310' AS DateTime), NULL, NULL, NULL, NULL, N'regular', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL)
    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (18, N'manager5', N'$2a$10$M7Ok1Zuuw827jBV9AEHz6OEZ1Sl1qx6pH4mvSstQLOb69MTeB1L6K', N'manager5@spa.com', N'Manager 5', N'0123456785', CAST(N'1990-01-05' AS Date), N'MALE', N'Địa chỉ số 5', N'active', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'2025-06-05T02:05:32.420' AS DateTime), CAST(N'2025-06-05T02:05:32.420' AS DateTime), NULL, NULL, NULL, NULL, N'regular', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL)
    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (19, N'tech1', N'$2a$10$m6idcpcwtHBPyypPrgBj0.kFHyl4Vypz8/pj/xSzp51DR9JqtYcRC', N'tech1@spa.com', N'Technician 1', N'0902000001', CAST(N'1992-02-01' AS Date), N'FEMALE', N'Kỹ thuật viên số 1', N'active', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'2025-06-05T23:00:12.210' AS DateTime), CAST(N'2025-06-05T23:00:12.210' AS DateTime), NULL, NULL, NULL, NULL, N'regular', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL)
    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (20, N'tech2', N'$2a$10$v7tyKluSTma.nO3nEsFh/.yVGHnEq4jBE38ryX.RxFBo/xwHKuozO', N'tech2@spa.com', N'Technician 2', N'0902000002', CAST(N'1992-02-02' AS Date), N'FEMALE', N'Kỹ thuật viên số 2', N'active', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'2025-06-05T23:00:12.370' AS DateTime), CAST(N'2025-06-05T23:00:12.370' AS DateTime), NULL, NULL, NULL, NULL, N'regular', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL)
    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (21, N'tech3', N'$2a$10$uKTneKZdzOhzuQjpZ0ZtUuvAhVcRlX5A8.H16z/.fr35m/IT5co6i', N'tech3@spa.com', N'Technician 3', N'0902000003', CAST(N'1992-02-03' AS Date), N'FEMALE', N'Kỹ thuật viên số 3', N'active', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'2025-06-05T23:00:12.493' AS DateTime), CAST(N'2025-06-05T23:00:12.493' AS DateTime), NULL, NULL, NULL, NULL, N'regular', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL)
    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (22, N'tech4', N'$2a$10$GeaovNmt1oUiNxdumO3mneaFJlYvqDuFR4KBbh/av8p5RtWIM13Ni', N'tech4@spa.com', N'Technician 4', N'0902000004', CAST(N'1992-02-04' AS Date), N'FEMALE', N'Kỹ thuật viên số 4', N'active', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'2025-06-05T23:00:12.620' AS DateTime), CAST(N'2025-06-05T23:00:12.620' AS DateTime), NULL, NULL, NULL, NULL, N'regular', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL)
    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (23, N'tech5', N'$2a$10$2UHf59YPzQpFrJppgG5WcOonyyH6SvxxrtJZZNK2shuOoslO51R5O', N'tech5@spa.com', N'Technician 5', N'0902000005', CAST(N'1992-02-05' AS Date), N'FEMALE', N'Kỹ thuật viên số 5', N'active', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'2025-06-05T23:00:12.743' AS DateTime), CAST(N'2025-06-16T20:36:06.747' AS DateTime), NULL, NULL, NULL, NULL, N'regular', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL)
    INSERT [dbo].[users] ([user_id], [username], [password], [email], [full_name], [phone], [date_of_birth], [gender], [address], [status], [enabled], [verification_token], [verification_token_expiry], [reset_password_token], [reset_password_token_expiry], [last_login], [created_at], [updated_at], [last_check_in], [last_check_out], [total_working_hours], [performance_score], [vip_level], [total_spent], [last_visit_date], [preferred_branch_id], [last_password_change], [email_verified], [phone_verified], [two_factor_enabled], [two_factor_secret], [login_attempts], [last_login_attempt], [profile_picture], [otp_code], [otp_expiry], [branch_id], [base_salary]) VALUES (24, N'manager', N'$2a$10$vg.gqZwOBPAiXMWUm6QInuPVcSlhsSAC6vAI.JItihsSG3rnf/oLy', N'manager@gmai.com', N'Manager', N'0912345678', CAST(N'2003-01-10' AS Date), N'MALE', N'326 cụm 4 thôn 3 xã Thạch Hòa huyện Thạch Thất', N'active', 1, NULL, NULL, NULL, NULL, NULL, CAST(N'2025-06-15T20:58:59.767' AS DateTime), CAST(N'2025-06-15T20:58:59.767' AS DateTime), NULL, NULL, NULL, NULL, N'regular', NULL, NULL, NULL, NULL, 1, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, CAST(15000000.00 AS Numeric(10, 2)))
    SET IDENTITY_INSERT [dbo].[users] OFF
    GO
    SET IDENTITY_INSERT [dbo].[work_schedules] ON

    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (1, 19, 1, CAST(N'2025-07-10' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:29.817' AS DateTime), CAST(N'2025-07-08T00:25:29.817' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (2, 19, 1, CAST(N'2025-07-11' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:29.957' AS DateTime), CAST(N'2025-07-08T00:25:29.957' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (3, 19, 1, CAST(N'2025-07-12' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:29.967' AS DateTime), CAST(N'2025-07-08T00:25:29.967' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (4, 19, 1, CAST(N'2025-07-13' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:29.987' AS DateTime), CAST(N'2025-07-08T00:25:29.987' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (5, 19, 1, CAST(N'2025-07-14' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:29.993' AS DateTime), CAST(N'2025-07-08T00:25:29.993' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (6, 19, 1, CAST(N'2025-07-15' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.003' AS DateTime), CAST(N'2025-07-08T00:25:30.003' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (7, 19, 1, CAST(N'2025-07-16' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.010' AS DateTime), CAST(N'2025-07-08T00:25:30.010' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (8, 19, 1, CAST(N'2025-07-17' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.023' AS DateTime), CAST(N'2025-07-08T00:25:30.023' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (9, 19, 1, CAST(N'2025-07-18' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.037' AS DateTime), CAST(N'2025-07-08T00:25:30.037' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (10, 19, 1, CAST(N'2025-07-19' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.043' AS DateTime), CAST(N'2025-07-08T00:25:30.043' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (11, 19, 1, CAST(N'2025-07-20' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.053' AS DateTime), CAST(N'2025-07-08T00:25:30.053' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (12, 19, 1, CAST(N'2025-07-21' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.060' AS DateTime), CAST(N'2025-07-08T00:25:30.060' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (13, 19, 1, CAST(N'2025-07-22' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.070' AS DateTime), CAST(N'2025-07-08T00:25:30.070' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (14, 19, 1, CAST(N'2025-07-23' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.080' AS DateTime), CAST(N'2025-07-08T00:25:30.080' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (15, 19, 1, CAST(N'2025-07-24' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.087' AS DateTime), CAST(N'2025-07-08T00:25:30.087' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (16, 19, 1, CAST(N'2025-07-25' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.093' AS DateTime), CAST(N'2025-07-08T00:25:30.093' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (17, 19, 1, CAST(N'2025-07-26' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.107' AS DateTime), CAST(N'2025-07-08T00:25:30.107' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (18, 19, 1, CAST(N'2025-07-27' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.113' AS DateTime), CAST(N'2025-07-08T00:25:30.113' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (19, 19, 1, CAST(N'2025-07-28' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.120' AS DateTime), CAST(N'2025-07-08T00:25:30.120' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (20, 19, 1, CAST(N'2025-07-29' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.127' AS DateTime), CAST(N'2025-07-08T00:25:30.127' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (21, 19, 1, CAST(N'2025-07-30' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.133' AS DateTime), CAST(N'2025-07-08T00:25:30.133' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (22, 19, 1, CAST(N'2025-07-31' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.140' AS DateTime), CAST(N'2025-07-08T00:25:30.140' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (23, 19, 1, CAST(N'2025-08-01' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.147' AS DateTime), CAST(N'2025-07-08T00:25:30.147' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (24, 19, 1, CAST(N'2025-08-02' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.153' AS DateTime), CAST(N'2025-07-08T00:25:30.153' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (25, 19, 1, CAST(N'2025-08-03' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.160' AS DateTime), CAST(N'2025-07-08T00:25:30.160' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (26, 19, 1, CAST(N'2025-08-04' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.163' AS DateTime), CAST(N'2025-07-08T00:25:30.163' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (27, 19, 1, CAST(N'2025-08-05' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.170' AS DateTime), CAST(N'2025-07-08T00:25:30.170' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (28, 19, 1, CAST(N'2025-08-06' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.180' AS DateTime), CAST(N'2025-07-08T00:25:30.180' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (29, 19, 1, CAST(N'2025-08-07' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.190' AS DateTime), CAST(N'2025-07-08T00:25:30.190' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (30, 19, 1, CAST(N'2025-08-08' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.197' AS DateTime), CAST(N'2025-07-08T00:25:30.197' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (31, 19, 1, CAST(N'2025-08-09' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.207' AS DateTime), CAST(N'2025-07-08T00:25:30.207' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (32, 19, 1, CAST(N'2025-08-10' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.217' AS DateTime), CAST(N'2025-07-08T00:25:30.217' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (33, 19, 1, CAST(N'2025-08-11' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.223' AS DateTime), CAST(N'2025-07-08T00:25:30.223' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (34, 19, 1, CAST(N'2025-08-12' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.233' AS DateTime), CAST(N'2025-07-08T00:25:30.233' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (35, 19, 1, CAST(N'2025-08-13' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.247' AS DateTime), CAST(N'2025-07-08T00:25:30.247' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (36, 19, 1, CAST(N'2025-08-14' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.257' AS DateTime), CAST(N'2025-07-08T00:25:30.257' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (37, 19, 1, CAST(N'2025-08-15' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.263' AS DateTime), CAST(N'2025-07-08T00:25:30.263' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (38, 19, 1, CAST(N'2025-08-16' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.273' AS DateTime), CAST(N'2025-07-08T00:25:30.273' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (39, 19, 1, CAST(N'2025-08-17' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.287' AS DateTime), CAST(N'2025-07-08T00:25:30.287' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (40, 19, 1, CAST(N'2025-08-18' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.300' AS DateTime), CAST(N'2025-07-08T00:25:30.300' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (41, 19, 1, CAST(N'2025-08-19' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.310' AS DateTime), CAST(N'2025-07-08T00:25:30.310' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (42, 19, 1, CAST(N'2025-08-20' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.320' AS DateTime), CAST(N'2025-07-08T00:25:30.320' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (43, 19, 1, CAST(N'2025-08-21' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.330' AS DateTime), CAST(N'2025-07-08T00:25:30.330' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (44, 19, 1, CAST(N'2025-08-22' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.340' AS DateTime), CAST(N'2025-07-08T00:25:30.340' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (45, 19, 1, CAST(N'2025-08-23' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.350' AS DateTime), CAST(N'2025-07-08T00:25:30.350' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (46, 19, 1, CAST(N'2025-08-24' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.363' AS DateTime), CAST(N'2025-07-08T00:25:30.363' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (47, 19, 1, CAST(N'2025-08-25' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.373' AS DateTime), CAST(N'2025-07-08T00:25:30.373' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (48, 19, 1, CAST(N'2025-08-26' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.383' AS DateTime), CAST(N'2025-07-08T00:25:30.383' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (49, 19, 1, CAST(N'2025-08-27' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.390' AS DateTime), CAST(N'2025-07-08T00:25:30.390' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (50, 19, 1, CAST(N'2025-08-28' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.397' AS DateTime), CAST(N'2025-07-08T00:25:30.397' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (51, 19, 1, CAST(N'2025-08-29' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.407' AS DateTime), CAST(N'2025-07-08T00:25:30.407' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (52, 19, 1, CAST(N'2025-08-30' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-08T00:25:30.420' AS DateTime), CAST(N'2025-07-08T00:25:30.420' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (53, 20, 1, CAST(N'2025-07-11' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.570' AS DateTime), CAST(N'2025-07-10T23:06:58.570' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (54, 20, 1, CAST(N'2025-07-12' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.627' AS DateTime), CAST(N'2025-07-10T23:06:58.627' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (55, 20, 1, CAST(N'2025-07-13' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.637' AS DateTime), CAST(N'2025-07-10T23:06:58.637' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (56, 20, 1, CAST(N'2025-07-14' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.647' AS DateTime), CAST(N'2025-07-10T23:06:58.647' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (57, 20, 1, CAST(N'2025-07-15' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.657' AS DateTime), CAST(N'2025-07-10T23:06:58.657' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (58, 20, 1, CAST(N'2025-07-16' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.667' AS DateTime), CAST(N'2025-07-10T23:06:58.667' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (59, 20, 1, CAST(N'2025-07-17' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.680' AS DateTime), CAST(N'2025-07-10T23:06:58.680' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (60, 20, 1, CAST(N'2025-07-18' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.690' AS DateTime), CAST(N'2025-07-10T23:06:58.690' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (61, 20, 1, CAST(N'2025-07-19' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.700' AS DateTime), CAST(N'2025-07-10T23:06:58.700' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (62, 20, 1, CAST(N'2025-07-20' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.710' AS DateTime), CAST(N'2025-07-10T23:06:58.710' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (63, 20, 1, CAST(N'2025-07-21' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.720' AS DateTime), CAST(N'2025-07-10T23:06:58.720' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (64, 20, 1, CAST(N'2025-07-22' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.730' AS DateTime), CAST(N'2025-07-10T23:06:58.730' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (65, 20, 1, CAST(N'2025-07-23' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.743' AS DateTime), CAST(N'2025-07-10T23:06:58.743' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (66, 20, 1, CAST(N'2025-07-24' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.753' AS DateTime), CAST(N'2025-07-10T23:06:58.753' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (67, 20, 1, CAST(N'2025-07-25' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.763' AS DateTime), CAST(N'2025-07-10T23:06:58.763' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (68, 20, 1, CAST(N'2025-07-26' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.777' AS DateTime), CAST(N'2025-07-10T23:06:58.777' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (69, 20, 1, CAST(N'2025-07-27' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.787' AS DateTime), CAST(N'2025-07-10T23:06:58.787' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (70, 20, 1, CAST(N'2025-07-28' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.800' AS DateTime), CAST(N'2025-07-10T23:06:58.800' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (71, 20, 1, CAST(N'2025-07-29' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.810' AS DateTime), CAST(N'2025-07-10T23:06:58.810' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (72, 20, 1, CAST(N'2025-07-30' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.820' AS DateTime), CAST(N'2025-07-10T23:06:58.820' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (73, 20, 1, CAST(N'2025-07-31' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.843' AS DateTime), CAST(N'2025-07-10T23:06:58.843' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (74, 20, 1, CAST(N'2025-08-01' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.853' AS DateTime), CAST(N'2025-07-10T23:06:58.853' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (75, 20, 1, CAST(N'2025-08-02' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.867' AS DateTime), CAST(N'2025-07-10T23:06:58.867' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (76, 20, 1, CAST(N'2025-08-03' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.880' AS DateTime), CAST(N'2025-07-10T23:06:58.880' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (77, 20, 1, CAST(N'2025-08-04' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.887' AS DateTime), CAST(N'2025-07-10T23:06:58.887' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (78, 20, 1, CAST(N'2025-08-05' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.897' AS DateTime), CAST(N'2025-07-10T23:06:58.897' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (79, 20, 1, CAST(N'2025-08-06' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.907' AS DateTime), CAST(N'2025-07-10T23:06:58.907' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (80, 20, 1, CAST(N'2025-08-07' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.917' AS DateTime), CAST(N'2025-07-10T23:06:58.917' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (81, 20, 1, CAST(N'2025-08-08' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.927' AS DateTime), CAST(N'2025-07-10T23:06:58.927' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (82, 20, 1, CAST(N'2025-08-09' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.937' AS DateTime), CAST(N'2025-07-10T23:06:58.937' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (83, 20, 1, CAST(N'2025-08-10' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.947' AS DateTime), CAST(N'2025-07-10T23:06:58.947' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (84, 20, 1, CAST(N'2025-08-11' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.960' AS DateTime), CAST(N'2025-07-10T23:06:58.960' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (85, 20, 1, CAST(N'2025-08-12' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.973' AS DateTime), CAST(N'2025-07-10T23:06:58.973' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (86, 20, 1, CAST(N'2025-08-13' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.983' AS DateTime), CAST(N'2025-07-10T23:06:58.983' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (87, 20, 1, CAST(N'2025-08-14' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:58.990' AS DateTime), CAST(N'2025-07-10T23:06:58.990' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (88, 20, 1, CAST(N'2025-08-15' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.000' AS DateTime), CAST(N'2025-07-10T23:06:59.000' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (89, 20, 1, CAST(N'2025-08-16' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.010' AS DateTime), CAST(N'2025-07-10T23:06:59.010' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (90, 20, 1, CAST(N'2025-08-17' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.017' AS DateTime), CAST(N'2025-07-10T23:06:59.017' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (91, 20, 1, CAST(N'2025-08-18' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.027' AS DateTime), CAST(N'2025-07-10T23:06:59.027' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (92, 20, 1, CAST(N'2025-08-19' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.037' AS DateTime), CAST(N'2025-07-10T23:06:59.037' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (93, 20, 1, CAST(N'2025-08-20' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.047' AS DateTime), CAST(N'2025-07-10T23:06:59.047' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (94, 20, 1, CAST(N'2025-08-21' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.057' AS DateTime), CAST(N'2025-07-10T23:06:59.057' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (95, 20, 1, CAST(N'2025-08-22' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.067' AS DateTime), CAST(N'2025-07-10T23:06:59.067' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (96, 20, 1, CAST(N'2025-08-23' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.077' AS DateTime), CAST(N'2025-07-10T23:06:59.077' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (97, 20, 1, CAST(N'2025-08-24' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.087' AS DateTime), CAST(N'2025-07-10T23:06:59.087' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (98, 20, 1, CAST(N'2025-08-25' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.093' AS DateTime), CAST(N'2025-07-10T23:06:59.093' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (99, 20, 1, CAST(N'2025-08-26' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.107' AS DateTime), CAST(N'2025-07-10T23:06:59.107' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    GO
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (100, 20, 1, CAST(N'2025-08-27' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.113' AS DateTime), CAST(N'2025-07-10T23:06:59.113' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (101, 20, 1, CAST(N'2025-08-28' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.127' AS DateTime), CAST(N'2025-07-10T23:06:59.127' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (102, 20, 1, CAST(N'2025-08-29' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.137' AS DateTime), CAST(N'2025-07-10T23:06:59.137' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (103, 20, 1, CAST(N'2025-08-30' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'test', CAST(N'2025-07-10T23:06:59.143' AS DateTime), CAST(N'2025-07-10T23:06:59.143' AS DateTime), NULL, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (104, 20, 1, CAST(N'2025-07-10' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.157' AS DateTime), CAST(N'2025-07-10T23:11:43.157' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (105, 20, 1, CAST(N'2025-08-31' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.410' AS DateTime), CAST(N'2025-07-10T23:11:43.410' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (106, 20, 1, CAST(N'2025-09-01' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.420' AS DateTime), CAST(N'2025-07-10T23:11:43.420' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (107, 20, 1, CAST(N'2025-09-02' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.430' AS DateTime), CAST(N'2025-07-10T23:11:43.430' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (108, 20, 1, CAST(N'2025-09-03' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.437' AS DateTime), CAST(N'2025-07-10T23:11:43.437' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (109, 20, 1, CAST(N'2025-09-04' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.447' AS DateTime), CAST(N'2025-07-10T23:11:43.447' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (110, 20, 1, CAST(N'2025-09-05' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.457' AS DateTime), CAST(N'2025-07-10T23:11:43.457' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (111, 20, 1, CAST(N'2025-09-06' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.463' AS DateTime), CAST(N'2025-07-10T23:11:43.463' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (112, 20, 1, CAST(N'2025-09-07' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.473' AS DateTime), CAST(N'2025-07-10T23:11:43.473' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (113, 20, 1, CAST(N'2025-09-08' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.483' AS DateTime), CAST(N'2025-07-10T23:11:43.483' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (114, 20, 1, CAST(N'2025-09-09' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.490' AS DateTime), CAST(N'2025-07-10T23:11:43.490' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (115, 20, 1, CAST(N'2025-09-10' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.500' AS DateTime), CAST(N'2025-07-10T23:11:43.500' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (116, 20, 1, CAST(N'2025-09-11' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.510' AS DateTime), CAST(N'2025-07-10T23:11:43.510' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (117, 20, 1, CAST(N'2025-09-12' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.520' AS DateTime), CAST(N'2025-07-10T23:11:43.520' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (118, 20, 1, CAST(N'2025-09-13' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.527' AS DateTime), CAST(N'2025-07-10T23:11:43.527' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (119, 20, 1, CAST(N'2025-09-14' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.540' AS DateTime), CAST(N'2025-07-10T23:11:43.540' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (120, 20, 1, CAST(N'2025-09-15' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.547' AS DateTime), CAST(N'2025-07-10T23:11:43.547' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (121, 20, 1, CAST(N'2025-09-16' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.557' AS DateTime), CAST(N'2025-07-10T23:11:43.557' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (122, 20, 1, CAST(N'2025-09-17' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.563' AS DateTime), CAST(N'2025-07-10T23:11:43.563' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (123, 20, 1, CAST(N'2025-09-18' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.573' AS DateTime), CAST(N'2025-07-10T23:11:43.573' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (124, 20, 1, CAST(N'2025-09-19' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.583' AS DateTime), CAST(N'2025-07-10T23:11:43.583' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (125, 20, 1, CAST(N'2025-09-20' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.587' AS DateTime), CAST(N'2025-07-10T23:11:43.587' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (126, 20, 1, CAST(N'2025-09-21' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.597' AS DateTime), CAST(N'2025-07-10T23:11:43.597' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (127, 20, 1, CAST(N'2025-09-22' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.603' AS DateTime), CAST(N'2025-07-10T23:11:43.603' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (128, 20, 1, CAST(N'2025-09-23' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.610' AS DateTime), CAST(N'2025-07-10T23:11:43.610' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (129, 20, 1, CAST(N'2025-09-24' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.617' AS DateTime), CAST(N'2025-07-10T23:11:43.617' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (130, 20, 1, CAST(N'2025-09-25' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.627' AS DateTime), CAST(N'2025-07-10T23:11:43.627' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (131, 20, 1, CAST(N'2025-09-26' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.637' AS DateTime), CAST(N'2025-07-10T23:11:43.637' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (132, 20, 1, CAST(N'2025-09-27' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.643' AS DateTime), CAST(N'2025-07-10T23:11:43.647' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (133, 20, 1, CAST(N'2025-09-28' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.653' AS DateTime), CAST(N'2025-07-10T23:11:43.653' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (134, 20, 1, CAST(N'2025-09-29' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.663' AS DateTime), CAST(N'2025-07-10T23:11:43.663' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (135, 20, 1, CAST(N'2025-09-30' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.670' AS DateTime), CAST(N'2025-07-10T23:11:43.670' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (136, 20, 1, CAST(N'2025-10-01' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.697' AS DateTime), CAST(N'2025-07-10T23:11:43.697' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (137, 20, 1, CAST(N'2025-10-02' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.703' AS DateTime), CAST(N'2025-07-10T23:11:43.703' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (138, 20, 1, CAST(N'2025-10-03' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.713' AS DateTime), CAST(N'2025-07-10T23:11:43.713' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (139, 20, 1, CAST(N'2025-10-04' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.720' AS DateTime), CAST(N'2025-07-10T23:11:43.720' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (140, 20, 1, CAST(N'2025-10-05' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.727' AS DateTime), CAST(N'2025-07-10T23:11:43.727' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (141, 20, 1, CAST(N'2025-10-06' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.737' AS DateTime), CAST(N'2025-07-10T23:11:43.737' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (142, 20, 1, CAST(N'2025-10-07' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.743' AS DateTime), CAST(N'2025-07-10T23:11:43.743' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (143, 20, 1, CAST(N'2025-10-08' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.747' AS DateTime), CAST(N'2025-07-10T23:11:43.747' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (144, 20, 1, CAST(N'2025-10-09' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.763' AS DateTime), CAST(N'2025-07-10T23:11:43.763' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (145, 20, 1, CAST(N'2025-10-10' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.770' AS DateTime), CAST(N'2025-07-10T23:11:43.770' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (146, 20, 1, CAST(N'2025-10-11' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.780' AS DateTime), CAST(N'2025-07-10T23:11:43.780' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (147, 20, 1, CAST(N'2025-10-12' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.787' AS DateTime), CAST(N'2025-07-10T23:11:43.787' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (148, 20, 1, CAST(N'2025-10-13' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.833' AS DateTime), CAST(N'2025-07-10T23:11:43.833' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (149, 20, 1, CAST(N'2025-10-14' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.850' AS DateTime), CAST(N'2025-07-10T23:11:43.850' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (150, 20, 1, CAST(N'2025-10-15' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.857' AS DateTime), CAST(N'2025-07-10T23:11:43.857' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (151, 20, 1, CAST(N'2025-10-16' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.863' AS DateTime), CAST(N'2025-07-10T23:11:43.863' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (152, 20, 1, CAST(N'2025-10-17' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.870' AS DateTime), CAST(N'2025-07-10T23:11:43.870' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (153, 20, 1, CAST(N'2025-10-18' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.877' AS DateTime), CAST(N'2025-07-10T23:11:43.877' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (154, 20, 1, CAST(N'2025-10-19' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.883' AS DateTime), CAST(N'2025-07-10T23:11:43.883' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (155, 20, 1, CAST(N'2025-10-20' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.893' AS DateTime), CAST(N'2025-07-10T23:11:43.893' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (156, 20, 1, CAST(N'2025-10-21' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.900' AS DateTime), CAST(N'2025-07-10T23:11:43.900' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (157, 20, 1, CAST(N'2025-10-22' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.903' AS DateTime), CAST(N'2025-07-10T23:11:43.903' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (158, 20, 1, CAST(N'2025-10-23' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.913' AS DateTime), CAST(N'2025-07-10T23:11:43.913' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (159, 20, 1, CAST(N'2025-10-24' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.920' AS DateTime), CAST(N'2025-07-10T23:11:43.920' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (160, 20, 1, CAST(N'2025-10-25' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.927' AS DateTime), CAST(N'2025-07-10T23:11:43.927' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (161, 20, 1, CAST(N'2025-10-26' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.937' AS DateTime), CAST(N'2025-07-10T23:11:43.937' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (162, 20, 1, CAST(N'2025-10-27' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.943' AS DateTime), CAST(N'2025-07-10T23:11:43.943' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (163, 20, 1, CAST(N'2025-10-28' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.953' AS DateTime), CAST(N'2025-07-10T23:11:43.953' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (164, 20, 1, CAST(N'2025-10-29' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.963' AS DateTime), CAST(N'2025-07-10T23:11:43.963' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (165, 20, 1, CAST(N'2025-10-30' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.973' AS DateTime), CAST(N'2025-07-10T23:11:43.973' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (166, 20, 1, CAST(N'2025-10-31' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.983' AS DateTime), CAST(N'2025-07-10T23:11:43.983' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (167, 20, 1, CAST(N'2025-11-01' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:43.990' AS DateTime), CAST(N'2025-07-10T23:11:43.990' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (168, 20, 1, CAST(N'2025-11-02' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.000' AS DateTime), CAST(N'2025-07-10T23:11:44.000' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (169, 20, 1, CAST(N'2025-11-03' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.010' AS DateTime), CAST(N'2025-07-10T23:11:44.010' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (170, 20, 1, CAST(N'2025-11-04' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.020' AS DateTime), CAST(N'2025-07-10T23:11:44.020' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (171, 20, 1, CAST(N'2025-11-05' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.030' AS DateTime), CAST(N'2025-07-10T23:11:44.030' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (172, 20, 1, CAST(N'2025-11-06' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.040' AS DateTime), CAST(N'2025-07-10T23:11:44.040' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (173, 20, 1, CAST(N'2025-11-07' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.047' AS DateTime), CAST(N'2025-07-10T23:11:44.047' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (174, 20, 1, CAST(N'2025-11-08' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.057' AS DateTime), CAST(N'2025-07-10T23:11:44.057' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (175, 20, 1, CAST(N'2025-11-09' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.067' AS DateTime), CAST(N'2025-07-10T23:11:44.067' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (176, 20, 1, CAST(N'2025-11-10' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.077' AS DateTime), CAST(N'2025-07-10T23:11:44.077' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (177, 20, 1, CAST(N'2025-11-11' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.087' AS DateTime), CAST(N'2025-07-10T23:11:44.087' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (178, 20, 1, CAST(N'2025-11-12' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.097' AS DateTime), CAST(N'2025-07-10T23:11:44.097' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (179, 20, 1, CAST(N'2025-11-13' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.103' AS DateTime), CAST(N'2025-07-10T23:11:44.103' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (180, 20, 1, CAST(N'2025-11-14' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.113' AS DateTime), CAST(N'2025-07-10T23:11:44.113' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (181, 20, 1, CAST(N'2025-11-15' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.127' AS DateTime), CAST(N'2025-07-10T23:11:44.127' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (182, 20, 1, CAST(N'2025-11-16' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.137' AS DateTime), CAST(N'2025-07-10T23:11:44.137' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (183, 20, 1, CAST(N'2025-11-17' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.143' AS DateTime), CAST(N'2025-07-10T23:11:44.143' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (184, 20, 1, CAST(N'2025-11-18' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.157' AS DateTime), CAST(N'2025-07-10T23:11:44.157' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (185, 20, 1, CAST(N'2025-11-19' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.163' AS DateTime), CAST(N'2025-07-10T23:11:44.163' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (186, 20, 1, CAST(N'2025-11-20' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.173' AS DateTime), CAST(N'2025-07-10T23:11:44.173' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (187, 20, 1, CAST(N'2025-11-21' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.180' AS DateTime), CAST(N'2025-07-10T23:11:44.180' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (188, 20, 1, CAST(N'2025-11-22' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.190' AS DateTime), CAST(N'2025-07-10T23:11:44.190' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (189, 20, 1, CAST(N'2025-11-23' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.200' AS DateTime), CAST(N'2025-07-10T23:11:44.200' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (190, 20, 1, CAST(N'2025-11-24' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.213' AS DateTime), CAST(N'2025-07-10T23:11:44.213' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (191, 20, 1, CAST(N'2025-11-25' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.223' AS DateTime), CAST(N'2025-07-10T23:11:44.223' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (192, 20, 1, CAST(N'2025-11-26' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.233' AS DateTime), CAST(N'2025-07-10T23:11:44.233' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (193, 20, 1, CAST(N'2025-11-27' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.240' AS DateTime), CAST(N'2025-07-10T23:11:44.240' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (194, 20, 1, CAST(N'2025-11-28' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.253' AS DateTime), CAST(N'2025-07-10T23:11:44.253' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (195, 20, 1, CAST(N'2025-11-29' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.267' AS DateTime), CAST(N'2025-07-10T23:11:44.267' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (196, 20, 1, CAST(N'2025-11-30' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.273' AS DateTime), CAST(N'2025-07-10T23:11:44.273' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (197, 20, 1, CAST(N'2025-12-01' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.283' AS DateTime), CAST(N'2025-07-10T23:11:44.283' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (198, 20, 1, CAST(N'2025-12-02' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.297' AS DateTime), CAST(N'2025-07-10T23:11:44.297' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (199, 20, 1, CAST(N'2025-12-03' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.303' AS DateTime), CAST(N'2025-07-10T23:11:44.303' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    GO
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (200, 20, 1, CAST(N'2025-12-04' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.313' AS DateTime), CAST(N'2025-07-10T23:11:44.313' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (201, 20, 1, CAST(N'2025-12-05' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.323' AS DateTime), CAST(N'2025-07-10T23:11:44.323' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (202, 20, 1, CAST(N'2025-12-06' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.333' AS DateTime), CAST(N'2025-07-10T23:11:44.333' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (203, 20, 1, CAST(N'2025-12-07' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.343' AS DateTime), CAST(N'2025-07-10T23:11:44.343' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (204, 20, 1, CAST(N'2025-12-08' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.353' AS DateTime), CAST(N'2025-07-10T23:11:44.353' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (205, 20, 1, CAST(N'2025-12-09' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.363' AS DateTime), CAST(N'2025-07-10T23:11:44.363' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (206, 20, 1, CAST(N'2025-12-10' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.370' AS DateTime), CAST(N'2025-07-10T23:11:44.370' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (207, 20, 1, CAST(N'2025-12-11' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.377' AS DateTime), CAST(N'2025-07-10T23:11:44.377' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (208, 20, 1, CAST(N'2025-12-12' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:00:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'tét', CAST(N'2025-07-10T23:11:44.383' AS DateTime), CAST(N'2025-07-10T23:11:44.383' AS DateTime), NULL, 1, CAST(N'2025-12-12' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (209, 23, 2, CAST(N'2025-07-10' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.340' AS DateTime), CAST(N'2025-07-10T23:27:26.340' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (210, 23, 2, CAST(N'2025-07-11' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.393' AS DateTime), CAST(N'2025-07-10T23:27:26.393' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (211, 23, 2, CAST(N'2025-07-12' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.410' AS DateTime), CAST(N'2025-07-10T23:27:26.410' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (212, 23, 2, CAST(N'2025-07-13' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.423' AS DateTime), CAST(N'2025-07-10T23:27:26.423' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (213, 23, 2, CAST(N'2025-07-14' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.433' AS DateTime), CAST(N'2025-07-10T23:27:26.433' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (214, 23, 2, CAST(N'2025-07-15' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.443' AS DateTime), CAST(N'2025-07-10T23:27:26.443' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (215, 23, 2, CAST(N'2025-07-16' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.463' AS DateTime), CAST(N'2025-07-10T23:27:26.463' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (216, 23, 2, CAST(N'2025-07-17' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.473' AS DateTime), CAST(N'2025-07-10T23:27:26.473' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (217, 23, 2, CAST(N'2025-07-18' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.483' AS DateTime), CAST(N'2025-07-10T23:27:26.483' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (218, 23, 2, CAST(N'2025-07-19' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.493' AS DateTime), CAST(N'2025-07-10T23:27:26.493' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (219, 23, 2, CAST(N'2025-07-20' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.503' AS DateTime), CAST(N'2025-07-10T23:27:26.503' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (220, 23, 2, CAST(N'2025-07-21' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.517' AS DateTime), CAST(N'2025-07-10T23:27:26.517' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (221, 23, 2, CAST(N'2025-07-22' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.523' AS DateTime), CAST(N'2025-07-10T23:27:26.523' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (222, 23, 2, CAST(N'2025-07-23' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.533' AS DateTime), CAST(N'2025-07-10T23:27:26.533' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (223, 23, 2, CAST(N'2025-07-24' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.543' AS DateTime), CAST(N'2025-07-10T23:27:26.543' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (224, 23, 2, CAST(N'2025-07-25' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.553' AS DateTime), CAST(N'2025-07-10T23:27:26.553' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (225, 23, 2, CAST(N'2025-07-26' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.563' AS DateTime), CAST(N'2025-07-10T23:27:26.563' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (226, 23, 2, CAST(N'2025-07-27' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.570' AS DateTime), CAST(N'2025-07-10T23:27:26.570' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (227, 23, 2, CAST(N'2025-07-28' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.577' AS DateTime), CAST(N'2025-07-10T23:27:26.577' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (228, 23, 2, CAST(N'2025-07-29' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.587' AS DateTime), CAST(N'2025-07-10T23:27:26.587' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (229, 23, 2, CAST(N'2025-07-30' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.600' AS DateTime), CAST(N'2025-07-10T23:27:26.600' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (230, 23, 2, CAST(N'2025-07-31' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.613' AS DateTime), CAST(N'2025-07-10T23:27:26.613' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (231, 23, 2, CAST(N'2025-08-01' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.627' AS DateTime), CAST(N'2025-07-10T23:27:26.627' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (232, 23, 2, CAST(N'2025-08-02' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.637' AS DateTime), CAST(N'2025-07-10T23:27:26.637' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (233, 23, 2, CAST(N'2025-08-03' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.650' AS DateTime), CAST(N'2025-07-10T23:27:26.650' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (234, 23, 2, CAST(N'2025-08-04' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.660' AS DateTime), CAST(N'2025-07-10T23:27:26.660' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (235, 23, 2, CAST(N'2025-08-05' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.673' AS DateTime), CAST(N'2025-07-10T23:27:26.673' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (236, 23, 2, CAST(N'2025-08-06' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.683' AS DateTime), CAST(N'2025-07-10T23:27:26.683' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (237, 23, 2, CAST(N'2025-08-07' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.693' AS DateTime), CAST(N'2025-07-10T23:27:26.693' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (238, 23, 2, CAST(N'2025-08-08' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.707' AS DateTime), CAST(N'2025-07-10T23:27:26.707' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (239, 23, 2, CAST(N'2025-08-09' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.717' AS DateTime), CAST(N'2025-07-10T23:27:26.717' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (240, 23, 2, CAST(N'2025-08-10' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.730' AS DateTime), CAST(N'2025-07-10T23:27:26.730' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (241, 23, 2, CAST(N'2025-08-11' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.740' AS DateTime), CAST(N'2025-07-10T23:27:26.740' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (242, 23, 2, CAST(N'2025-08-12' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.753' AS DateTime), CAST(N'2025-07-10T23:27:26.753' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (243, 23, 2, CAST(N'2025-08-13' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.763' AS DateTime), CAST(N'2025-07-10T23:27:26.763' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (244, 23, 2, CAST(N'2025-08-14' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.810' AS DateTime), CAST(N'2025-07-10T23:27:26.810' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (245, 23, 2, CAST(N'2025-08-15' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.827' AS DateTime), CAST(N'2025-07-10T23:27:26.827' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (246, 23, 2, CAST(N'2025-08-16' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.837' AS DateTime), CAST(N'2025-07-10T23:27:26.837' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (247, 23, 2, CAST(N'2025-08-17' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.843' AS DateTime), CAST(N'2025-07-10T23:27:26.843' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (248, 23, 2, CAST(N'2025-08-18' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.853' AS DateTime), CAST(N'2025-07-10T23:27:26.853' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (249, 23, 2, CAST(N'2025-08-19' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.863' AS DateTime), CAST(N'2025-07-10T23:27:26.863' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (250, 23, 2, CAST(N'2025-08-20' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.873' AS DateTime), CAST(N'2025-07-10T23:27:26.873' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (251, 23, 2, CAST(N'2025-08-21' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.880' AS DateTime), CAST(N'2025-07-10T23:27:26.880' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (252, 23, 2, CAST(N'2025-08-22' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.887' AS DateTime), CAST(N'2025-07-10T23:27:26.887' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (253, 23, 2, CAST(N'2025-08-23' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.917' AS DateTime), CAST(N'2025-07-10T23:27:26.917' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (254, 23, 2, CAST(N'2025-08-24' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.923' AS DateTime), CAST(N'2025-07-10T23:27:26.923' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (255, 23, 2, CAST(N'2025-08-25' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.933' AS DateTime), CAST(N'2025-07-10T23:27:26.933' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (256, 23, 2, CAST(N'2025-08-26' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.937' AS DateTime), CAST(N'2025-07-10T23:27:26.937' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (257, 23, 2, CAST(N'2025-08-27' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.947' AS DateTime), CAST(N'2025-07-10T23:27:26.947' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (258, 23, 2, CAST(N'2025-08-28' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.953' AS DateTime), CAST(N'2025-07-10T23:27:26.953' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (259, 23, 2, CAST(N'2025-08-29' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.960' AS DateTime), CAST(N'2025-07-10T23:27:26.960' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    INSERT [dbo].[work_schedules] ([schedule_id], [user_id], [branch_id], [work_date], [start_time], [end_time], [break_start], [break_end], [status], [notes], [created_at], [updated_at], [created_by], [is_recurring], [recurring_end_date], [recurring_pattern], [shift_type], [updated_by]) VALUES (260, 23, 2, CAST(N'2025-08-30' AS Date), CAST(N'08:00:00' AS Time), CAST(N'17:00:00' AS Time), CAST(N'12:05:00' AS Time), CAST(N'13:00:00' AS Time), N'SCHEDULED', N'aaa', CAST(N'2025-07-10T23:27:26.967' AS DateTime), CAST(N'2025-07-10T23:27:26.967' AS DateTime), 14, 1, CAST(N'2025-08-30' AS Date), N'DAILY', N'FULL_DAY', NULL)
    SET IDENTITY_INSERT [dbo].[work_schedules] OFF
    GO
/****** Object:  Index [UKdldf8hkqk3p0tjptsexrs04hn]    Script Date: 7/12/2025 2:16:41 PM ******/
ALTER TABLE [dbo].[membership_orders] ADD  CONSTRAINT [UKdldf8hkqk3p0tjptsexrs04hn] UNIQUE NONCLUSTERED
    (
    [order_code] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    GO
/****** Object:  Index [UQ_PackageRatings_Booking]    Script Date: 7/12/2025 2:16:41 PM ******/
ALTER TABLE [dbo].[package_ratings] ADD  CONSTRAINT [UQ_PackageRatings_Booking] UNIQUE NONCLUSTERED
    (
    [booking_id] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    GO
    SET ANSI_PADDING ON
    GO
/****** Object:  Index [UK716hgxp60ym1lifrdgp67xt5k]    Script Date: 7/12/2025 2:16:41 PM ******/
ALTER TABLE [dbo].[roles] ADD  CONSTRAINT [UK716hgxp60ym1lifrdgp67xt5k] UNIQUE NONCLUSTERED
    (
    [role_name] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    GO
    SET ANSI_PADDING ON
    GO
/****** Object:  Index [UQ_SocialLogins_ProviderUser]    Script Date: 7/12/2025 2:16:41 PM ******/
ALTER TABLE [dbo].[social_logins] ADD  CONSTRAINT [UQ_SocialLogins_ProviderUser] UNIQUE NONCLUSTERED
    (
    [provider] ASC,
    [provider_user_id] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    GO
    SET ANSI_PADDING ON
    GO
/****** Object:  Index [UQ__system_c__BDF6033D26135B33]    Script Date: 7/12/2025 2:16:41 PM ******/
ALTER TABLE [dbo].[system_config] ADD UNIQUE NONCLUSTERED
    (
    [config_key] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    GO
    SET ANSI_PADDING ON
    GO
/****** Object:  Index [UQ__system_c__BDF6033DFFF90BD8]    Script Date: 7/12/2025 2:16:41 PM ******/
ALTER TABLE [dbo].[system_config] ADD UNIQUE NONCLUSTERED
    (
    [config_key] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    GO
    SET ANSI_PADDING ON
    GO
/****** Object:  Index [UQ__users__AB6E61642423A516]    Script Date: 7/12/2025 2:16:41 PM ******/
ALTER TABLE [dbo].[users] ADD UNIQUE NONCLUSTERED
    (
    [email] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    GO
    SET ANSI_PADDING ON
    GO
/****** Object:  Index [UQ__users__AB6E6164FAF4750B]    Script Date: 7/12/2025 2:16:41 PM ******/
ALTER TABLE [dbo].[users] ADD UNIQUE NONCLUSTERED
    (
    [email] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    GO
    SET ANSI_PADDING ON
    GO
/****** Object:  Index [UQ__users__F3DBC57268884723]    Script Date: 7/12/2025 2:16:41 PM ******/
ALTER TABLE [dbo].[users] ADD UNIQUE NONCLUSTERED
    (
    [username] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    GO
    SET ANSI_PADDING ON
    GO
/****** Object:  Index [UQ__users__F3DBC572EB5D82A5]    Script Date: 7/12/2025 2:16:41 PM ******/
ALTER TABLE [dbo].[users] ADD UNIQUE NONCLUSTERED
    (
    [username] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    GO
ALTER TABLE [dbo].[appointments] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[appointments] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[appointments] ADD  DEFAULT ((0)) FOR [reminder_sent]
    GO
ALTER TABLE [dbo].[appointments] ADD  DEFAULT ('pending') FOR [status]
    GO
ALTER TABLE [dbo].[audit_logs] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[branches] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[branches] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[branches] ADD  DEFAULT ((1)) FOR [is_active]
    GO
ALTER TABLE [dbo].[customer_density] ADD  DEFAULT ((0)) FOR [customer_count]
    GO
ALTER TABLE [dbo].[customer_density] ADD  DEFAULT ((0)) FOR [appointment_count]
    GO
ALTER TABLE [dbo].[customer_density] ADD  DEFAULT ((0)) FOR [total_revenue]
    GO
ALTER TABLE [dbo].[customer_density] ADD  DEFAULT (getdate()) FOR [last_updated]
    GO
ALTER TABLE [dbo].[customer_density] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[customer_feedback] ADD  DEFAULT ((0)) FOR [is_anonymous]
    GO
ALTER TABLE [dbo].[customer_feedback] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[customer_preferences] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[customer_preferences] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[customer_visits] ADD  DEFAULT ('checked-in') FOR [status]
    GO
ALTER TABLE [dbo].[customer_visits] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[customer_visits] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[employee_attendance] ADD  DEFAULT ('present') FOR [status]
    GO
ALTER TABLE [dbo].[employee_attendance] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[employee_attendance] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[employee_reviews] ADD  DEFAULT ('pending') FOR [status]
    GO
ALTER TABLE [dbo].[employee_reviews] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[employee_reviews] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[equipment] ADD  DEFAULT ('active') FOR [status]
    GO
ALTER TABLE [dbo].[equipment] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[equipment] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[equipment_maintenance] ADD  DEFAULT ('scheduled') FOR [status]
    GO
ALTER TABLE [dbo].[equipment_maintenance] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[heat_map_data] ADD  DEFAULT ((0)) FOR [customer_count]
    GO
ALTER TABLE [dbo].[heat_map_data] ADD  DEFAULT ((0)) FOR [employee_count]
    GO
ALTER TABLE [dbo].[heat_map_data] ADD  DEFAULT ((0)) FOR [service_count]
    GO
ALTER TABLE [dbo].[heat_map_data] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[inventory] ADD  DEFAULT ((0)) FOR [quantity]
    GO
ALTER TABLE [dbo].[inventory] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[inventory] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[inventory_transactions] ADD  DEFAULT (getdate()) FOR [transaction_date]
    GO
ALTER TABLE [dbo].[invoice_details] ADD  DEFAULT ((1)) FOR [quantity]
    GO
ALTER TABLE [dbo].[invoice_details] ADD  DEFAULT ((0)) FOR [discount_percentage]
    GO
ALTER TABLE [dbo].[invoices] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[invoices] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[kpi_records] ADD  DEFAULT ((0)) FOR [total_appointments]
    GO
ALTER TABLE [dbo].[kpi_records] ADD  DEFAULT ((0)) FOR [completed_appointments]
    GO
ALTER TABLE [dbo].[kpi_records] ADD  DEFAULT ((0)) FOR [cancelled_appointments]
    GO
ALTER TABLE [dbo].[kpi_records] ADD  DEFAULT ((0)) FOR [total_revenue]
    GO
ALTER TABLE [dbo].[kpi_records] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[notifications] ADD  DEFAULT ((0)) FOR [is_read]
    GO
ALTER TABLE [dbo].[notifications] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[package_booking_details] ADD  DEFAULT ('pending') FOR [status]
    GO
ALTER TABLE [dbo].[package_booking_details] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[package_booking_details] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[package_bookings] ADD  DEFAULT ('pending') FOR [status]
    GO
ALTER TABLE [dbo].[package_bookings] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[package_bookings] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[package_promotions] ADD  DEFAULT ((1)) FOR [is_active]
    GO
ALTER TABLE [dbo].[package_promotions] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[package_promotions] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[package_ratings] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[package_services] ADD  DEFAULT ((0)) FOR [is_optional]
    GO
ALTER TABLE [dbo].[package_services] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[package_services] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[package_statistics] ADD  DEFAULT ((0)) FOR [total_bookings]
    GO
ALTER TABLE [dbo].[package_statistics] ADD  DEFAULT ((0)) FOR [total_revenue]
    GO
ALTER TABLE [dbo].[package_statistics] ADD  DEFAULT ((0)) FOR [total_customers]
    GO
ALTER TABLE [dbo].[package_statistics] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[payment_transactions] ADD  DEFAULT (getdate()) FOR [payment_date]
    GO
ALTER TABLE [dbo].[points_transactions] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[salary_records] ADD  DEFAULT ((0)) FOR [bonus]
    GO
ALTER TABLE [dbo].[salary_records] ADD  DEFAULT ((0)) FOR [commission]
    GO
ALTER TABLE [dbo].[salary_records] ADD  DEFAULT ((0)) FOR [overtime_pay]
    GO
ALTER TABLE [dbo].[salary_records] ADD  DEFAULT ((0)) FOR [deductions]
    GO
ALTER TABLE [dbo].[salary_records] ADD  DEFAULT ('pending') FOR [status]
    GO
ALTER TABLE [dbo].[salary_records] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[salary_records] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[service_categories] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[service_packages] ADD  DEFAULT ((0)) FOR [discount_percentage]
    GO
ALTER TABLE [dbo].[service_packages] ADD  DEFAULT ((1)) FOR [is_active]
    GO
ALTER TABLE [dbo].[service_packages] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[service_packages] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[service_ratings] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[service_schedule] ADD  DEFAULT ((1)) FOR [is_active]
    GO
ALTER TABLE [dbo].[service_schedule] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[services] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[services] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[social_logins] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[system_config] ADD  DEFAULT ((1)) FOR [is_active]
    GO
ALTER TABLE [dbo].[system_config] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[system_config] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[treatment_records] ADD  DEFAULT (getdate()) FOR [treatment_date]
    GO
ALTER TABLE [dbo].[treatment_records] ADD  DEFAULT ((0)) FOR [treatment_progress]
    GO
ALTER TABLE [dbo].[treatment_records] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[treatment_records] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[user_sessions] ADD  DEFAULT (getdate()) FOR [login_time]
    GO
ALTER TABLE [dbo].[user_sessions] ADD  DEFAULT (getdate()) FOR [last_activity]
    GO
ALTER TABLE [dbo].[user_sessions] ADD  DEFAULT ((1)) FOR [is_active]
    GO
ALTER TABLE [dbo].[users] ADD  DEFAULT ('active') FOR [status]
    GO
ALTER TABLE [dbo].[users] ADD  DEFAULT ((0)) FOR [enabled]
    GO
ALTER TABLE [dbo].[users] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[users] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[users] ADD  DEFAULT ((0)) FOR [total_working_hours]
    GO
ALTER TABLE [dbo].[users] ADD  DEFAULT ((0)) FOR [performance_score]
    GO
ALTER TABLE [dbo].[users] ADD  DEFAULT ('regular') FOR [vip_level]
    GO
ALTER TABLE [dbo].[users] ADD  DEFAULT ((0)) FOR [total_spent]
    GO
ALTER TABLE [dbo].[users] ADD  DEFAULT ((0)) FOR [email_verified]
    GO
ALTER TABLE [dbo].[users] ADD  DEFAULT ((0)) FOR [phone_verified]
    GO
ALTER TABLE [dbo].[users] ADD  DEFAULT ((0)) FOR [two_factor_enabled]
    GO
ALTER TABLE [dbo].[users] ADD  DEFAULT ((0)) FOR [login_attempts]
    GO
ALTER TABLE [dbo].[work_schedules] ADD  DEFAULT (getdate()) FOR [created_at]
    GO
ALTER TABLE [dbo].[work_schedules] ADD  DEFAULT (getdate()) FOR [updated_at]
    GO
ALTER TABLE [dbo].[appointment_handled]  WITH CHECK ADD  CONSTRAINT [FK32ss1ynnwu5rfkugmv272yth2] FOREIGN KEY([receptionist_user_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[appointment_handled] CHECK CONSTRAINT [FK32ss1ynnwu5rfkugmv272yth2]
    GO
ALTER TABLE [dbo].[appointment_handled]  WITH CHECK ADD  CONSTRAINT [FKm9tfoqvih7nehecwagvf0cevp] FOREIGN KEY([appointment_appointment_id])
    REFERENCES [dbo].[appointments] ([appointment_id])
    GO
ALTER TABLE [dbo].[appointment_handled] CHECK CONSTRAINT [FKm9tfoqvih7nehecwagvf0cevp]
    GO
ALTER TABLE [dbo].[appointments]  WITH CHECK ADD  CONSTRAINT [FK_Appointments_Branches] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[appointments] CHECK CONSTRAINT [FK_Appointments_Branches]
    GO
ALTER TABLE [dbo].[appointments]  WITH CHECK ADD  CONSTRAINT [FK_Appointments_PreferredTechnician] FOREIGN KEY([preferred_technician_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[appointments] CHECK CONSTRAINT [FK_Appointments_PreferredTechnician]
    GO
ALTER TABLE [dbo].[appointments]  WITH CHECK ADD  CONSTRAINT [FK_Appointments_Services] FOREIGN KEY([service_id])
    REFERENCES [dbo].[services] ([service_id])
    GO
ALTER TABLE [dbo].[appointments] CHECK CONSTRAINT [FK_Appointments_Services]
    GO
ALTER TABLE [dbo].[appointments]  WITH CHECK ADD  CONSTRAINT [FK_Appointments_Users_Customer] FOREIGN KEY([customer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[appointments] CHECK CONSTRAINT [FK_Appointments_Users_Customer]
    GO
ALTER TABLE [dbo].[appointments]  WITH CHECK ADD  CONSTRAINT [FK_Appointments_Users_Technician] FOREIGN KEY([technician_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[appointments] CHECK CONSTRAINT [FK_Appointments_Users_Technician]
    GO
ALTER TABLE [dbo].[appointments]  WITH CHECK ADD  CONSTRAINT [FKbsma6x4pnujct0e6xkycu9864] FOREIGN KEY([room_id])
    REFERENCES [dbo].[rooms] ([id])
    GO
ALTER TABLE [dbo].[appointments] CHECK CONSTRAINT [FKbsma6x4pnujct0e6xkycu9864]
    GO
ALTER TABLE [dbo].[attendances]  WITH CHECK ADD  CONSTRAINT [FK23a71nd5bqeq12r9ptmeq2ppe] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[attendances] CHECK CONSTRAINT [FK23a71nd5bqeq12r9ptmeq2ppe]
    GO
ALTER TABLE [dbo].[attendances]  WITH CHECK ADD  CONSTRAINT [FK8o39cn3ghqwhccyrrqdesttr8] FOREIGN KEY([user_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[attendances] CHECK CONSTRAINT [FK8o39cn3ghqwhccyrrqdesttr8]
    GO
ALTER TABLE [dbo].[audit_logs]  WITH CHECK ADD  CONSTRAINT [FK_AuditLogs_Users] FOREIGN KEY([user_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[audit_logs] CHECK CONSTRAINT [FK_AuditLogs_Users]
    GO
ALTER TABLE [dbo].[branches]  WITH CHECK ADD  CONSTRAINT [FK_Branches_Users] FOREIGN KEY([manager_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[branches] CHECK CONSTRAINT [FK_Branches_Users]
    GO
ALTER TABLE [dbo].[customer_feedback]  WITH CHECK ADD  CONSTRAINT [FK_CustomerFeedback_Appointments] FOREIGN KEY([appointment_id])
    REFERENCES [dbo].[appointments] ([appointment_id])
    GO
ALTER TABLE [dbo].[customer_feedback] CHECK CONSTRAINT [FK_CustomerFeedback_Appointments]
    GO
ALTER TABLE [dbo].[customer_feedback]  WITH CHECK ADD  CONSTRAINT [FK_CustomerFeedback_Users] FOREIGN KEY([customer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[customer_feedback] CHECK CONSTRAINT [FK_CustomerFeedback_Users]
    GO
ALTER TABLE [dbo].[customer_memberships]  WITH CHECK ADD  CONSTRAINT [FK72k8k47tksky0o1ox05qgijcs] FOREIGN KEY([customer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[customer_memberships] CHECK CONSTRAINT [FK72k8k47tksky0o1ox05qgijcs]
    GO
ALTER TABLE [dbo].[customer_memberships]  WITH CHECK ADD  CONSTRAINT [FKjej9pn2kdao5llfe73y21dhbe] FOREIGN KEY([membership_id])
    REFERENCES [dbo].[memberships] ([membership_id])
    GO
ALTER TABLE [dbo].[customer_memberships] CHECK CONSTRAINT [FKjej9pn2kdao5llfe73y21dhbe]
    GO
ALTER TABLE [dbo].[customer_preferences]  WITH CHECK ADD  CONSTRAINT [FK_CustomerPreferences_Users] FOREIGN KEY([customer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[customer_preferences] CHECK CONSTRAINT [FK_CustomerPreferences_Users]
    GO
ALTER TABLE [dbo].[customer_visits]  WITH CHECK ADD  CONSTRAINT [FK_CustomerVisits_Appointments] FOREIGN KEY([appointment_id])
    REFERENCES [dbo].[appointments] ([appointment_id])
    GO
ALTER TABLE [dbo].[customer_visits] CHECK CONSTRAINT [FK_CustomerVisits_Appointments]
    GO
ALTER TABLE [dbo].[customer_visits]  WITH CHECK ADD  CONSTRAINT [FK_CustomerVisits_Branches] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[customer_visits] CHECK CONSTRAINT [FK_CustomerVisits_Branches]
    GO
ALTER TABLE [dbo].[customer_visits]  WITH CHECK ADD  CONSTRAINT [FK_CustomerVisits_Users] FOREIGN KEY([customer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[customer_visits] CHECK CONSTRAINT [FK_CustomerVisits_Users]
    GO
ALTER TABLE [dbo].[employee_attendance]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeAttendance_Branches] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[employee_attendance] CHECK CONSTRAINT [FK_EmployeeAttendance_Branches]
    GO
ALTER TABLE [dbo].[employee_attendance]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeAttendance_Users] FOREIGN KEY([user_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[employee_attendance] CHECK CONSTRAINT [FK_EmployeeAttendance_Users]
    GO
ALTER TABLE [dbo].[employee_reviews]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeReviews_Employee] FOREIGN KEY([employee_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[employee_reviews] CHECK CONSTRAINT [FK_EmployeeReviews_Employee]
    GO
ALTER TABLE [dbo].[employee_reviews]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeReviews_Reviewer] FOREIGN KEY([reviewer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[employee_reviews] CHECK CONSTRAINT [FK_EmployeeReviews_Reviewer]
    GO
ALTER TABLE [dbo].[equipment]  WITH CHECK ADD  CONSTRAINT [FK_Equipment_Branches] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[equipment] CHECK CONSTRAINT [FK_Equipment_Branches]
    GO
ALTER TABLE [dbo].[equipment_maintenance]  WITH CHECK ADD  CONSTRAINT [FK_EquipmentMaintenance_Equipment] FOREIGN KEY([equipment_id])
    REFERENCES [dbo].[equipment] ([equipment_id])
    GO
ALTER TABLE [dbo].[equipment_maintenance] CHECK CONSTRAINT [FK_EquipmentMaintenance_Equipment]
    GO
ALTER TABLE [dbo].[favorite_services]  WITH CHECK ADD  CONSTRAINT [FK1ogq9heqf12l0ulqo9gkiuceu] FOREIGN KEY([service_id])
    REFERENCES [dbo].[services] ([service_id])
    GO
ALTER TABLE [dbo].[favorite_services] CHECK CONSTRAINT [FK1ogq9heqf12l0ulqo9gkiuceu]
    GO
ALTER TABLE [dbo].[favorite_services]  WITH CHECK ADD  CONSTRAINT [FKpdsewbppejdoi5na6kpcv9jvt] FOREIGN KEY([customer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[favorite_services] CHECK CONSTRAINT [FKpdsewbppejdoi5na6kpcv9jvt]
    GO
ALTER TABLE [dbo].[heat_map_data]  WITH CHECK ADD  CONSTRAINT [FK_HeatMapData_Branches] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[heat_map_data] CHECK CONSTRAINT [FK_HeatMapData_Branches]
    GO
ALTER TABLE [dbo].[inventory]  WITH CHECK ADD  CONSTRAINT [FK_Inventory_Branches] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[inventory] CHECK CONSTRAINT [FK_Inventory_Branches]
    GO
ALTER TABLE [dbo].[inventory_transactions]  WITH CHECK ADD  CONSTRAINT [FK_InventoryTransactions_Branches] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[inventory_transactions] CHECK CONSTRAINT [FK_InventoryTransactions_Branches]
    GO
ALTER TABLE [dbo].[inventory_transactions]  WITH CHECK ADD  CONSTRAINT [FK_InventoryTransactions_Inventory] FOREIGN KEY([item_id])
    REFERENCES [dbo].[inventory] ([item_id])
    GO
ALTER TABLE [dbo].[inventory_transactions] CHECK CONSTRAINT [FK_InventoryTransactions_Inventory]
    GO
ALTER TABLE [dbo].[invoice_details]  WITH CHECK ADD  CONSTRAINT [FK_InvoiceDetails_Invoices] FOREIGN KEY([invoice_id])
    REFERENCES [dbo].[invoices] ([invoice_id])
    GO
ALTER TABLE [dbo].[invoice_details] CHECK CONSTRAINT [FK_InvoiceDetails_Invoices]
    GO
ALTER TABLE [dbo].[invoice_details]  WITH CHECK ADD  CONSTRAINT [FK_InvoiceDetails_Services] FOREIGN KEY([service_id])
    REFERENCES [dbo].[services] ([service_id])
    GO
ALTER TABLE [dbo].[invoice_details] CHECK CONSTRAINT [FK_InvoiceDetails_Services]
    GO
ALTER TABLE [dbo].[invoices]  WITH CHECK ADD  CONSTRAINT [FK_Invoices_Appointments] FOREIGN KEY([appointment_id])
    REFERENCES [dbo].[appointments] ([appointment_id])
    GO
ALTER TABLE [dbo].[invoices] CHECK CONSTRAINT [FK_Invoices_Appointments]
    GO
ALTER TABLE [dbo].[invoices]  WITH CHECK ADD  CONSTRAINT [FK_Invoices_Branches] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[invoices] CHECK CONSTRAINT [FK_Invoices_Branches]
    GO
ALTER TABLE [dbo].[invoices]  WITH CHECK ADD  CONSTRAINT [FK_Invoices_Users] FOREIGN KEY([customer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[invoices] CHECK CONSTRAINT [FK_Invoices_Users]
    GO
ALTER TABLE [dbo].[kpi_records]  WITH CHECK ADD  CONSTRAINT [FK_KPIRecords_Branches] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[kpi_records] CHECK CONSTRAINT [FK_KPIRecords_Branches]
    GO
ALTER TABLE [dbo].[kpi_records]  WITH CHECK ADD  CONSTRAINT [FK_KPIRecords_Users] FOREIGN KEY([user_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[kpi_records] CHECK CONSTRAINT [FK_KPIRecords_Users]
    GO
ALTER TABLE [dbo].[membership_orders]  WITH CHECK ADD  CONSTRAINT [FKo20a7nf1gqdgum58r0ktb7wv3] FOREIGN KEY([membership_id])
    REFERENCES [dbo].[memberships] ([membership_id])
    GO
ALTER TABLE [dbo].[membership_orders] CHECK CONSTRAINT [FKo20a7nf1gqdgum58r0ktb7wv3]
    GO
ALTER TABLE [dbo].[membership_orders]  WITH CHECK ADD  CONSTRAINT [FKq6e3sfvhpfn4oydnfyastgnoa] FOREIGN KEY([customer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[membership_orders] CHECK CONSTRAINT [FKq6e3sfvhpfn4oydnfyastgnoa]
    GO
ALTER TABLE [dbo].[notifications]  WITH CHECK ADD  CONSTRAINT [FK_Notifications_Recipient] FOREIGN KEY([recipient_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[notifications] CHECK CONSTRAINT [FK_Notifications_Recipient]
    GO
ALTER TABLE [dbo].[notifications]  WITH CHECK ADD  CONSTRAINT [FK_Notifications_Sender] FOREIGN KEY([sender_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[notifications] CHECK CONSTRAINT [FK_Notifications_Sender]
    GO
ALTER TABLE [dbo].[package_booking_details]  WITH CHECK ADD  CONSTRAINT [FK_PackageBookingDetails_Bookings] FOREIGN KEY([booking_id])
    REFERENCES [dbo].[package_bookings] ([booking_id])
    ON DELETE CASCADE
GO
ALTER TABLE [dbo].[package_booking_details] CHECK CONSTRAINT [FK_PackageBookingDetails_Bookings]
    GO
ALTER TABLE [dbo].[package_booking_details]  WITH CHECK ADD  CONSTRAINT [FK_PackageBookingDetails_Services] FOREIGN KEY([service_id])
    REFERENCES [dbo].[services] ([service_id])
    GO
ALTER TABLE [dbo].[package_booking_details] CHECK CONSTRAINT [FK_PackageBookingDetails_Services]
    GO
ALTER TABLE [dbo].[package_booking_details]  WITH CHECK ADD  CONSTRAINT [FK_PackageBookingDetails_Technicians] FOREIGN KEY([technician_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[package_booking_details] CHECK CONSTRAINT [FK_PackageBookingDetails_Technicians]
    GO
ALTER TABLE [dbo].[package_bookings]  WITH CHECK ADD  CONSTRAINT [FK_PackageBookings_Branches] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[package_bookings] CHECK CONSTRAINT [FK_PackageBookings_Branches]
    GO
ALTER TABLE [dbo].[package_bookings]  WITH CHECK ADD  CONSTRAINT [FK_PackageBookings_Packages] FOREIGN KEY([package_id])
    REFERENCES [dbo].[service_packages] ([package_id])
    GO
ALTER TABLE [dbo].[package_bookings] CHECK CONSTRAINT [FK_PackageBookings_Packages]
    GO
ALTER TABLE [dbo].[package_bookings]  WITH CHECK ADD  CONSTRAINT [FK_PackageBookings_Users] FOREIGN KEY([customer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[package_bookings] CHECK CONSTRAINT [FK_PackageBookings_Users]
    GO
ALTER TABLE [dbo].[package_promotions]  WITH CHECK ADD  CONSTRAINT [FK_PackagePromotions_Packages] FOREIGN KEY([package_id])
    REFERENCES [dbo].[service_packages] ([package_id])
    GO
ALTER TABLE [dbo].[package_promotions] CHECK CONSTRAINT [FK_PackagePromotions_Packages]
    GO
ALTER TABLE [dbo].[package_promotions]  WITH CHECK ADD  CONSTRAINT [FK_PackagePromotions_Users] FOREIGN KEY([created_by])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[package_promotions] CHECK CONSTRAINT [FK_PackagePromotions_Users]
    GO
ALTER TABLE [dbo].[package_ratings]  WITH CHECK ADD  CONSTRAINT [FK_PackageRatings_Bookings] FOREIGN KEY([booking_id])
    REFERENCES [dbo].[package_bookings] ([booking_id])
    GO
ALTER TABLE [dbo].[package_ratings] CHECK CONSTRAINT [FK_PackageRatings_Bookings]
    GO
ALTER TABLE [dbo].[package_ratings]  WITH CHECK ADD  CONSTRAINT [FK_PackageRatings_Packages] FOREIGN KEY([package_id])
    REFERENCES [dbo].[service_packages] ([package_id])
    GO
ALTER TABLE [dbo].[package_ratings] CHECK CONSTRAINT [FK_PackageRatings_Packages]
    GO
ALTER TABLE [dbo].[package_ratings]  WITH CHECK ADD  CONSTRAINT [FK_PackageRatings_Users] FOREIGN KEY([customer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[package_ratings] CHECK CONSTRAINT [FK_PackageRatings_Users]
    GO
ALTER TABLE [dbo].[package_services]  WITH CHECK ADD  CONSTRAINT [FK_PackageServices_Packages] FOREIGN KEY([package_id])
    REFERENCES [dbo].[service_packages] ([package_id])
    ON DELETE CASCADE
GO
ALTER TABLE [dbo].[package_services] CHECK CONSTRAINT [FK_PackageServices_Packages]
    GO
ALTER TABLE [dbo].[package_services]  WITH CHECK ADD  CONSTRAINT [FK_PackageServices_Services] FOREIGN KEY([service_id])
    REFERENCES [dbo].[services] ([service_id])
    ON DELETE CASCADE
GO
ALTER TABLE [dbo].[package_services] CHECK CONSTRAINT [FK_PackageServices_Services]
    GO
ALTER TABLE [dbo].[package_statistics]  WITH CHECK ADD  CONSTRAINT [FK_PackageStatistics_Packages] FOREIGN KEY([package_id])
    REFERENCES [dbo].[service_packages] ([package_id])
    GO
ALTER TABLE [dbo].[package_statistics] CHECK CONSTRAINT [FK_PackageStatistics_Packages]
    GO
ALTER TABLE [dbo].[payment_transactions]  WITH CHECK ADD  CONSTRAINT [FK_PaymentTransactions_Invoices] FOREIGN KEY([invoice_id])
    REFERENCES [dbo].[invoices] ([invoice_id])
    GO
ALTER TABLE [dbo].[payment_transactions] CHECK CONSTRAINT [FK_PaymentTransactions_Invoices]
    GO
ALTER TABLE [dbo].[rooms]  WITH CHECK ADD  CONSTRAINT [FKi1eu1fwwr964lh073mt43w3g2] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[rooms] CHECK CONSTRAINT [FKi1eu1fwwr964lh073mt43w3g2]
    GO
ALTER TABLE [dbo].[salary_records]  WITH CHECK ADD  CONSTRAINT [FK_SalaryRecords_Branches] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[salary_records] CHECK CONSTRAINT [FK_SalaryRecords_Branches]
    GO
ALTER TABLE [dbo].[salary_records]  WITH CHECK ADD  CONSTRAINT [FK_SalaryRecords_Users] FOREIGN KEY([user_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[salary_records] CHECK CONSTRAINT [FK_SalaryRecords_Users]
    GO
ALTER TABLE [dbo].[service_categories]  WITH CHECK ADD  CONSTRAINT [FK_ServiceCategories_ServiceCategories] FOREIGN KEY([parent_category_id])
    REFERENCES [dbo].[service_categories] ([category_id])
    GO
ALTER TABLE [dbo].[service_categories] CHECK CONSTRAINT [FK_ServiceCategories_ServiceCategories]
    GO
ALTER TABLE [dbo].[service_packages]  WITH CHECK ADD  CONSTRAINT [FK_ServicePackages_CreatedBy] FOREIGN KEY([created_by])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[service_packages] CHECK CONSTRAINT [FK_ServicePackages_CreatedBy]
    GO
ALTER TABLE [dbo].[service_packages]  WITH CHECK ADD  CONSTRAINT [FK_ServicePackages_UpdatedBy] FOREIGN KEY([updated_by])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[service_packages] CHECK CONSTRAINT [FK_ServicePackages_UpdatedBy]
    GO
ALTER TABLE [dbo].[service_rating]  WITH CHECK ADD  CONSTRAINT [FKee7nj4xrgtq4s8nr9lx205kty] FOREIGN KEY([customer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[service_rating] CHECK CONSTRAINT [FKee7nj4xrgtq4s8nr9lx205kty]
    GO
ALTER TABLE [dbo].[service_rating]  WITH CHECK ADD  CONSTRAINT [FKqro4lmoyb78so6i05lo19ydal] FOREIGN KEY([service_id])
    REFERENCES [dbo].[services] ([service_id])
    GO
ALTER TABLE [dbo].[service_rating] CHECK CONSTRAINT [FKqro4lmoyb78so6i05lo19ydal]
    GO
ALTER TABLE [dbo].[service_ratings]  WITH CHECK ADD  CONSTRAINT [FK_ServiceRatings_Appointments] FOREIGN KEY([appointment_id])
    REFERENCES [dbo].[appointments] ([appointment_id])
    GO
ALTER TABLE [dbo].[service_ratings] CHECK CONSTRAINT [FK_ServiceRatings_Appointments]
    GO
ALTER TABLE [dbo].[service_ratings]  WITH CHECK ADD  CONSTRAINT [FK_ServiceRatings_Customer] FOREIGN KEY([customer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[service_ratings] CHECK CONSTRAINT [FK_ServiceRatings_Customer]
    GO
ALTER TABLE [dbo].[service_ratings]  WITH CHECK ADD  CONSTRAINT [FK_ServiceRatings_Services] FOREIGN KEY([service_id])
    REFERENCES [dbo].[services] ([service_id])
    GO
ALTER TABLE [dbo].[service_ratings] CHECK CONSTRAINT [FK_ServiceRatings_Services]
    GO
ALTER TABLE [dbo].[service_ratings]  WITH CHECK ADD  CONSTRAINT [FK_ServiceRatings_Technician] FOREIGN KEY([technician_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[service_ratings] CHECK CONSTRAINT [FK_ServiceRatings_Technician]
    GO
ALTER TABLE [dbo].[service_reviews]  WITH CHECK ADD  CONSTRAINT [FKlbn1hffpt0fyd8oajnpcjme1m] FOREIGN KEY([appointment_id])
    REFERENCES [dbo].[appointments] ([appointment_id])
    GO
ALTER TABLE [dbo].[service_reviews] CHECK CONSTRAINT [FKlbn1hffpt0fyd8oajnpcjme1m]
    GO
ALTER TABLE [dbo].[service_reviews]  WITH CHECK ADD  CONSTRAINT [FKog1fsabqfx7sbvf9t0ygnwolc] FOREIGN KEY([customer_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[service_reviews] CHECK CONSTRAINT [FKog1fsabqfx7sbvf9t0ygnwolc]
    GO
ALTER TABLE [dbo].[service_reviews]  WITH CHECK ADD  CONSTRAINT [FKswvvdd1fiadm0niifdauvqi3d] FOREIGN KEY([service_id])
    REFERENCES [dbo].[services] ([service_id])
    GO
ALTER TABLE [dbo].[service_reviews] CHECK CONSTRAINT [FKswvvdd1fiadm0niifdauvqi3d]
    GO
ALTER TABLE [dbo].[service_schedule]  WITH CHECK ADD  CONSTRAINT [FK_ServiceSchedule_Branches] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[service_schedule] CHECK CONSTRAINT [FK_ServiceSchedule_Branches]
    GO
ALTER TABLE [dbo].[service_schedule]  WITH CHECK ADD  CONSTRAINT [FK_ServiceSchedule_Services] FOREIGN KEY([service_id])
    REFERENCES [dbo].[services] ([service_id])
    GO
ALTER TABLE [dbo].[service_schedule] CHECK CONSTRAINT [FK_ServiceSchedule_Services]
    GO
ALTER TABLE [dbo].[service_schedule]  WITH CHECK ADD  CONSTRAINT [FK_ServiceSchedule_Technician] FOREIGN KEY([technician_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[service_schedule] CHECK CONSTRAINT [FK_ServiceSchedule_Technician]
    GO
ALTER TABLE [dbo].[services]  WITH CHECK ADD  CONSTRAINT [FK_Services_Categories] FOREIGN KEY([category_id])
    REFERENCES [dbo].[service_categories] ([category_id])
    GO
ALTER TABLE [dbo].[services] CHECK CONSTRAINT [FK_Services_Categories]
    GO
ALTER TABLE [dbo].[social_logins]  WITH CHECK ADD  CONSTRAINT [FK_SocialLogins_Users] FOREIGN KEY([user_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[social_logins] CHECK CONSTRAINT [FK_SocialLogins_Users]
    GO
ALTER TABLE [dbo].[treatment_records]  WITH CHECK ADD  CONSTRAINT [FK_TreatmentRecords_Appointments] FOREIGN KEY([appointment_id])
    REFERENCES [dbo].[appointments] ([appointment_id])
    GO
ALTER TABLE [dbo].[treatment_records] CHECK CONSTRAINT [FK_TreatmentRecords_Appointments]
    GO
ALTER TABLE [dbo].[treatment_records]  WITH CHECK ADD  CONSTRAINT [FK_TreatmentRecords_Users] FOREIGN KEY([technician_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[treatment_records] CHECK CONSTRAINT [FK_TreatmentRecords_Users]
    GO
ALTER TABLE [dbo].[user_kpi]  WITH CHECK ADD  CONSTRAINT [FK672tye2i9hpebtk1hdfjlcyc5] FOREIGN KEY([technician_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[user_kpi] CHECK CONSTRAINT [FK672tye2i9hpebtk1hdfjlcyc5]
    GO
ALTER TABLE [dbo].[user_kpi]  WITH CHECK ADD  CONSTRAINT [FKr3d38yd5cb7v8l5wwwtn8uh4u] FOREIGN KEY([manager_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[user_kpi] CHECK CONSTRAINT [FKr3d38yd5cb7v8l5wwwtn8uh4u]
    GO
ALTER TABLE [dbo].[user_roles]  WITH CHECK ADD  CONSTRAINT [FKh8ciramu9cc9q3qcqiv4ue8a6] FOREIGN KEY([role_id])
    REFERENCES [dbo].[roles] ([role_id])
    GO
ALTER TABLE [dbo].[user_roles] CHECK CONSTRAINT [FKh8ciramu9cc9q3qcqiv4ue8a6]
    GO
ALTER TABLE [dbo].[user_roles]  WITH CHECK ADD  CONSTRAINT [FKhfh9dx7w3ubf1co1vdev94g3f] FOREIGN KEY([user_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[user_roles] CHECK CONSTRAINT [FKhfh9dx7w3ubf1co1vdev94g3f]
    GO
ALTER TABLE [dbo].[user_sessions]  WITH CHECK ADD  CONSTRAINT [FK_UserSessions_Users] FOREIGN KEY([user_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[user_sessions] CHECK CONSTRAINT [FK_UserSessions_Users]
    GO
ALTER TABLE [dbo].[users]  WITH CHECK ADD  CONSTRAINT [FK_Users_PreferredBranch] FOREIGN KEY([preferred_branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[users] CHECK CONSTRAINT [FK_Users_PreferredBranch]
    GO
ALTER TABLE [dbo].[users]  WITH CHECK ADD  CONSTRAINT [FK9o70sp9ku40077y38fk4wieyk] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[users] CHECK CONSTRAINT [FK9o70sp9ku40077y38fk4wieyk]
    GO
ALTER TABLE [dbo].[work_schedules]  WITH CHECK ADD  CONSTRAINT [FK_WorkSchedules_Branches] FOREIGN KEY([branch_id])
    REFERENCES [dbo].[branches] ([branch_id])
    GO
ALTER TABLE [dbo].[work_schedules] CHECK CONSTRAINT [FK_WorkSchedules_Branches]
    GO
ALTER TABLE [dbo].[work_schedules]  WITH CHECK ADD  CONSTRAINT [FK_WorkSchedules_Users] FOREIGN KEY([user_id])
    REFERENCES [dbo].[users] ([user_id])
    GO
ALTER TABLE [dbo].[work_schedules] CHECK CONSTRAINT [FK_WorkSchedules_Users]
    GO
ALTER TABLE [dbo].[branches]  WITH CHECK ADD CHECK  (([status]='maintenance' OR [status]='suspended' OR [status]='inactive' OR [status]='active'))
    GO
ALTER TABLE [dbo].[branches]  WITH CHECK ADD CHECK  (([status]='maintenance' OR [status]='suspended' OR [status]='inactive' OR [status]='active'))
    GO
ALTER TABLE [dbo].[customer_feedback]  WITH CHECK ADD  CONSTRAINT [CHK_CustomerFeedback_Ratings] CHECK  (([service_rating]>=(1) AND [service_rating]<=(5) AND [technician_rating]>=(1) AND [technician_rating]<=(5) AND [facility_rating]>=(1) AND [facility_rating]<=(5) AND [overall_rating]>=(1) AND [overall_rating]<=(5)))
    GO
ALTER TABLE [dbo].[customer_feedback] CHECK CONSTRAINT [CHK_CustomerFeedback_Ratings]
    GO
ALTER TABLE [dbo].[customer_visits]  WITH CHECK ADD  CONSTRAINT [CHK_CustomerVisits_Status] CHECK  (([status]='cancelled' OR [status]='completed' OR [status]='in-progress' OR [status]='checked-in'))
    GO
ALTER TABLE [dbo].[customer_visits] CHECK CONSTRAINT [CHK_CustomerVisits_Status]
    GO
ALTER TABLE [dbo].[employee_attendance]  WITH CHECK ADD  CONSTRAINT [CHK_EmployeeAttendance_Status] CHECK  (([status]='half-day' OR [status]='absent' OR [status]='late' OR [status]='present'))
    GO
ALTER TABLE [dbo].[employee_attendance] CHECK CONSTRAINT [CHK_EmployeeAttendance_Status]
    GO
ALTER TABLE [dbo].[employee_reviews]  WITH CHECK ADD  CONSTRAINT [CHK_EmployeeReviews_Period] CHECK  (([review_period]='annual' OR [review_period]='quarterly' OR [review_period]='monthly'))
    GO
ALTER TABLE [dbo].[employee_reviews] CHECK CONSTRAINT [CHK_EmployeeReviews_Period]
    GO
ALTER TABLE [dbo].[employee_reviews]  WITH CHECK ADD  CONSTRAINT [CHK_EmployeeReviews_Status] CHECK  (([status]='rejected' OR [status]='approved' OR [status]='pending'))
    GO
ALTER TABLE [dbo].[employee_reviews] CHECK CONSTRAINT [CHK_EmployeeReviews_Status]
    GO
ALTER TABLE [dbo].[equipment]  WITH CHECK ADD CHECK  (([status]='disposed' OR [status]='inactive' OR [status]='maintenance' OR [status]='active'))
    GO
ALTER TABLE [dbo].[equipment]  WITH CHECK ADD CHECK  (([status]='disposed' OR [status]='inactive' OR [status]='maintenance' OR [status]='active'))
    GO
ALTER TABLE [dbo].[equipment_maintenance]  WITH CHECK ADD CHECK  (([maintenance_type]='inspection' OR [maintenance_type]='repair' OR [maintenance_type]='routine'))
    GO
ALTER TABLE [dbo].[equipment_maintenance]  WITH CHECK ADD CHECK  (([maintenance_type]='inspection' OR [maintenance_type]='repair' OR [maintenance_type]='routine'))
    GO
ALTER TABLE [dbo].[equipment_maintenance]  WITH CHECK ADD CHECK  (([status]='cancelled' OR [status]='completed' OR [status]='scheduled'))
    GO
ALTER TABLE [dbo].[equipment_maintenance]  WITH CHECK ADD CHECK  (([status]='cancelled' OR [status]='completed' OR [status]='scheduled'))
    GO
ALTER TABLE [dbo].[heat_map_data]  WITH CHECK ADD  CONSTRAINT [CHK_HeatMapData_Hour] CHECK  (([hour]>=(0) AND [hour]<=(23)))
    GO
ALTER TABLE [dbo].[heat_map_data] CHECK CONSTRAINT [CHK_HeatMapData_Hour]
    GO
ALTER TABLE [dbo].[inventory_transactions]  WITH CHECK ADD CHECK  (([reference_type]='return' OR [reference_type]='adjustment' OR [reference_type]='usage' OR [reference_type]='purchase'))
    GO
ALTER TABLE [dbo].[inventory_transactions]  WITH CHECK ADD CHECK  (([reference_type]='return' OR [reference_type]='adjustment' OR [reference_type]='usage' OR [reference_type]='purchase'))
    GO
ALTER TABLE [dbo].[inventory_transactions]  WITH CHECK ADD CHECK  (([transaction_type]='return' OR [transaction_type]='adjust' OR [transaction_type]='out' OR [transaction_type]='in'))
    GO
ALTER TABLE [dbo].[inventory_transactions]  WITH CHECK ADD CHECK  (([transaction_type]='return' OR [transaction_type]='adjust' OR [transaction_type]='out' OR [transaction_type]='in'))
    GO
ALTER TABLE [dbo].[membership_orders]  WITH CHECK ADD CHECK  (([status]='EXPIRED' OR [status]='CANCELLED' OR [status]='PAID' OR [status]='PENDING'))
    GO
ALTER TABLE [dbo].[membership_orders]  WITH CHECK ADD CHECK  (([status]='EXPIRED' OR [status]='CANCELLED' OR [status]='PAID' OR [status]='PENDING'))
    GO
ALTER TABLE [dbo].[package_booking_details]  WITH CHECK ADD  CONSTRAINT [CHK_PackageBookingDetails_Date] CHECK  (([appointment_date]>=CONVERT([date],getdate())))
    GO
ALTER TABLE [dbo].[package_booking_details] CHECK CONSTRAINT [CHK_PackageBookingDetails_Date]
    GO
ALTER TABLE [dbo].[package_booking_details]  WITH CHECK ADD  CONSTRAINT [CHK_PackageBookingDetails_Time] CHECK  (([end_time]>[start_time]))
    GO
ALTER TABLE [dbo].[package_booking_details] CHECK CONSTRAINT [CHK_PackageBookingDetails_Time]
    GO
ALTER TABLE [dbo].[package_booking_details]  WITH CHECK ADD CHECK  (([status]='no_show' OR [status]='cancelled' OR [status]='completed' OR [status]='pending'))
    GO
ALTER TABLE [dbo].[package_booking_details]  WITH CHECK ADD CHECK  (([status]='no_show' OR [status]='cancelled' OR [status]='completed' OR [status]='pending'))
    GO
ALTER TABLE [dbo].[package_bookings]  WITH CHECK ADD  CONSTRAINT [CHK_PackageBookings_ExpiryDate] CHECK  (([expiry_date]>=[booking_date]))
    GO
ALTER TABLE [dbo].[package_bookings] CHECK CONSTRAINT [CHK_PackageBookings_ExpiryDate]
    GO
ALTER TABLE [dbo].[package_bookings]  WITH CHECK ADD  CONSTRAINT [CHK_PackageBookings_RemainingUses] CHECK  (([remaining_uses]>=(0)))
    GO
ALTER TABLE [dbo].[package_bookings] CHECK CONSTRAINT [CHK_PackageBookings_RemainingUses]
    GO
ALTER TABLE [dbo].[package_bookings]  WITH CHECK ADD  CONSTRAINT [CHK_PackageBookings_Time] CHECK  (([end_time]>[start_time]))
    GO
ALTER TABLE [dbo].[package_bookings] CHECK CONSTRAINT [CHK_PackageBookings_Time]
    GO
ALTER TABLE [dbo].[package_bookings]  WITH CHECK ADD CHECK  (([status]='no_show' OR [status]='cancelled' OR [status]='completed' OR [status]='confirmed' OR [status]='pending'))
    GO
ALTER TABLE [dbo].[package_bookings]  WITH CHECK ADD CHECK  (([status]='no_show' OR [status]='cancelled' OR [status]='completed' OR [status]='confirmed' OR [status]='pending'))
    GO
ALTER TABLE [dbo].[package_promotions]  WITH CHECK ADD  CONSTRAINT [CHK_PackagePromotions_ActiveDate] CHECK  (([start_date]<=[end_date]))
    GO
ALTER TABLE [dbo].[package_promotions] CHECK CONSTRAINT [CHK_PackagePromotions_ActiveDate]
    GO
ALTER TABLE [dbo].[package_promotions]  WITH CHECK ADD  CONSTRAINT [CHK_PackagePromotions_Dates] CHECK  (([end_date]>=[start_date]))
    GO
ALTER TABLE [dbo].[package_promotions] CHECK CONSTRAINT [CHK_PackagePromotions_Dates]
    GO
ALTER TABLE [dbo].[package_promotions]  WITH CHECK ADD  CONSTRAINT [CHK_PackagePromotions_Discount] CHECK  (([discount_percentage]>(0) AND [discount_percentage]<=(100)))
    GO
ALTER TABLE [dbo].[package_promotions] CHECK CONSTRAINT [CHK_PackagePromotions_Discount]
    GO
ALTER TABLE [dbo].[package_ratings]  WITH CHECK ADD CHECK  (([rating]>=(1) AND [rating]<=(5)))
    GO
ALTER TABLE [dbo].[package_ratings]  WITH CHECK ADD CHECK  (([rating]>=(1) AND [rating]<=(5)))
    GO
ALTER TABLE [dbo].[package_services]  WITH CHECK ADD  CONSTRAINT [CHK_PackageServices_Duration] CHECK  (([duration]>(0)))
    GO
ALTER TABLE [dbo].[package_services] CHECK CONSTRAINT [CHK_PackageServices_Duration]
    GO
ALTER TABLE [dbo].[package_services]  WITH CHECK ADD  CONSTRAINT [CHK_PackageServices_Sequence] CHECK  (([sequence]>(0)))
    GO
ALTER TABLE [dbo].[package_services] CHECK CONSTRAINT [CHK_PackageServices_Sequence]
    GO
ALTER TABLE [dbo].[package_statistics]  WITH CHECK ADD  CONSTRAINT [CHK_PackageStatistics_Bookings] CHECK  (([total_bookings]>=(0)))
    GO
ALTER TABLE [dbo].[package_statistics] CHECK CONSTRAINT [CHK_PackageStatistics_Bookings]
    GO
ALTER TABLE [dbo].[package_statistics]  WITH CHECK ADD  CONSTRAINT [CHK_PackageStatistics_Customers] CHECK  (([total_customers]>=(0)))
    GO
ALTER TABLE [dbo].[package_statistics] CHECK CONSTRAINT [CHK_PackageStatistics_Customers]
    GO
ALTER TABLE [dbo].[package_statistics]  WITH CHECK ADD  CONSTRAINT [CHK_PackageStatistics_Period] CHECK  (([period_end]>=[period_start]))
    GO
ALTER TABLE [dbo].[package_statistics] CHECK CONSTRAINT [CHK_PackageStatistics_Period]
    GO
ALTER TABLE [dbo].[package_statistics]  WITH CHECK ADD  CONSTRAINT [CHK_PackageStatistics_Rating] CHECK  (([average_rating]>=(0) AND [average_rating]<=(5)))
    GO
ALTER TABLE [dbo].[package_statistics] CHECK CONSTRAINT [CHK_PackageStatistics_Rating]
    GO
ALTER TABLE [dbo].[package_statistics]  WITH CHECK ADD  CONSTRAINT [CHK_PackageStatistics_Revenue] CHECK  (([total_revenue]>=(0)))
    GO
ALTER TABLE [dbo].[package_statistics] CHECK CONSTRAINT [CHK_PackageStatistics_Revenue]
    GO
ALTER TABLE [dbo].[points_transactions]  WITH CHECK ADD CHECK  (([reference_type]='manual' OR [reference_type]='promotion' OR [reference_type]='purchase' OR [reference_type]='appointment'))
    GO
ALTER TABLE [dbo].[points_transactions]  WITH CHECK ADD CHECK  (([reference_type]='manual' OR [reference_type]='promotion' OR [reference_type]='purchase' OR [reference_type]='appointment'))
    GO
ALTER TABLE [dbo].[points_transactions]  WITH CHECK ADD CHECK  (([transaction_type]='adjust' OR [transaction_type]='expire' OR [transaction_type]='redeem' OR [transaction_type]='earn'))
    GO
ALTER TABLE [dbo].[points_transactions]  WITH CHECK ADD CHECK  (([transaction_type]='adjust' OR [transaction_type]='expire' OR [transaction_type]='redeem' OR [transaction_type]='earn'))
    GO
ALTER TABLE [dbo].[salary_records]  WITH CHECK ADD CHECK  (([status]='paid' OR [status]='approved' OR [status]='pending'))
    GO
ALTER TABLE [dbo].[salary_records]  WITH CHECK ADD CHECK  (([status]='paid' OR [status]='approved' OR [status]='pending'))
    GO
ALTER TABLE [dbo].[salary_settings]  WITH CHECK ADD CHECK  (([role]='TECHNICIAN' OR [role]='RECEPTIONIST'))
    GO
ALTER TABLE [dbo].[salary_settings]  WITH CHECK ADD CHECK  (([role]='TECHNICIAN' OR [role]='RECEPTIONIST'))
    GO
ALTER TABLE [dbo].[service_packages]  WITH CHECK ADD  CONSTRAINT [CHK_ServicePackages_Discount] CHECK  (([discount_percentage]>=(0) AND [discount_percentage]<=(100)))
    GO
ALTER TABLE [dbo].[service_packages] CHECK CONSTRAINT [CHK_ServicePackages_Discount]
    GO
ALTER TABLE [dbo].[service_packages]  WITH CHECK ADD  CONSTRAINT [CHK_ServicePackages_MaxUses] CHECK  (([max_uses]>(0)))
    GO
ALTER TABLE [dbo].[service_packages] CHECK CONSTRAINT [CHK_ServicePackages_MaxUses]
    GO
ALTER TABLE [dbo].[service_packages]  WITH CHECK ADD  CONSTRAINT [CHK_ServicePackages_Price] CHECK  (([price]>=(0)))
    GO
ALTER TABLE [dbo].[service_packages] CHECK CONSTRAINT [CHK_ServicePackages_Price]
    GO
ALTER TABLE [dbo].[service_packages]  WITH CHECK ADD  CONSTRAINT [CHK_ServicePackages_ValidityPeriod] CHECK  (([validity_period]>(0)))
    GO
ALTER TABLE [dbo].[service_packages] CHECK CONSTRAINT [CHK_ServicePackages_ValidityPeriod]
    GO
ALTER TABLE [dbo].[service_ratings]  WITH CHECK ADD CHECK  (([facility_rating]>=(1) AND [facility_rating]<=(5)))
    GO
ALTER TABLE [dbo].[service_ratings]  WITH CHECK ADD CHECK  (([facility_rating]>=(1) AND [facility_rating]<=(5)))
    GO
ALTER TABLE [dbo].[service_ratings]  WITH CHECK ADD CHECK  (([overall_rating]>=(1) AND [overall_rating]<=(5)))
    GO
ALTER TABLE [dbo].[service_ratings]  WITH CHECK ADD CHECK  (([overall_rating]>=(1) AND [overall_rating]<=(5)))
    GO
ALTER TABLE [dbo].[service_ratings]  WITH CHECK ADD CHECK  (([service_rating]>=(1) AND [service_rating]<=(5)))
    GO
ALTER TABLE [dbo].[service_ratings]  WITH CHECK ADD CHECK  (([service_rating]>=(1) AND [service_rating]<=(5)))
    GO
ALTER TABLE [dbo].[service_ratings]  WITH CHECK ADD CHECK  (([technician_rating]>=(1) AND [technician_rating]<=(5)))
    GO
ALTER TABLE [dbo].[service_ratings]  WITH CHECK ADD CHECK  (([technician_rating]>=(1) AND [technician_rating]<=(5)))
    GO
ALTER TABLE [dbo].[treatment_records]  WITH CHECK ADD  CONSTRAINT [CHK_TreatmentRecords_Progress] CHECK  (([treatment_progress]>=(0) AND [treatment_progress]<=(100)))
    GO
ALTER TABLE [dbo].[treatment_records] CHECK CONSTRAINT [CHK_TreatmentRecords_Progress]
    GO
ALTER TABLE [dbo].[users]  WITH CHECK ADD  CONSTRAINT [CHK_Users_VipLevel] CHECK  (([vip_level]='diamond' OR [vip_level]='platinum' OR [vip_level]='gold' OR [vip_level]='silver' OR [vip_level]='regular'))
    GO
ALTER TABLE [dbo].[users] CHECK CONSTRAINT [CHK_Users_VipLevel]
    GO
ALTER TABLE [dbo].[users]  WITH CHECK ADD CHECK  (([gender]='other' OR [gender]='female' OR [gender]='male'))
    GO
ALTER TABLE [dbo].[users]  WITH CHECK ADD CHECK  (([gender]='other' OR [gender]='female' OR [gender]='male'))
    GO
ALTER TABLE [dbo].[users]  WITH CHECK ADD CHECK  (([status]='suspended' OR [status]='inactive' OR [status]='active'))
    GO
ALTER TABLE [dbo].[users]  WITH CHECK ADD CHECK  (([status]='suspended' OR [status]='inactive' OR [status]='active'))
    GO
ALTER TABLE [dbo].[work_schedules]  WITH CHECK ADD CHECK  (([shift_type]='FULL_DAY' OR [shift_type]='NIGHT' OR [shift_type]='EVENING' OR [shift_type]='AFTERNOON' OR [shift_type]='MORNING'))
    GO
    USE [master]
    GO
ALTER DATABASE [spa_management] SET  READ_WRITE
GO
