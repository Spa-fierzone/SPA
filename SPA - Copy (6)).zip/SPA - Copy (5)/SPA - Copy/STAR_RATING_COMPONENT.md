# Interactive Star Rating Component

## Overview

The Interactive Star Rating Component is a comprehensive, accessible, and visually appealing 5-star rating system designed to replace poor or confusing rating input methods in the SPA application. It provides an intuitive user experience with hover effects, keyboard navigation, and seamless form integration.

## Features

### ⭐ **Core Features**
- **5-Star Rating System**: Standard 1-5 star scale with clear visual feedback
- **Interactive Design**: Clickable and hoverable stars with smooth animations
- **Visual Feedback**: Stars highlight on hover and remain filled when selected
- **Clear Rating Scale**: 1=Very Poor, 2=Poor, 3=Average, 4=Good, 5=Excellent
- **Reset Functionality**: Optional clear/reset button to remove rating

### 🎨 **Visual Design**
- **Consistent Styling**: Matches SPA application theme (gradient buttons, glass cards)
- **Multiple Sizes**: Small, medium, and large size options
- **Hover Effects**: Smooth transitions and scale effects
- **Focus Indicators**: Clear visual focus for keyboard navigation
- **Responsive Design**: Works on all screen sizes and devices

### ♿ **Accessibility Features**
- **Keyboard Navigation**: Full keyboard support with arrow keys, Home/End, Enter/Space
- **Screen Reader Support**: Comprehensive ARIA labels and live regions
- **Focus Management**: Proper focus indicators and tab order
- **High Contrast**: Adapts to system accessibility preferences
- **Semantic HTML**: Proper role attributes and form integration

### 🔧 **Integration Features**
- **Form Integration**: Seamless integration with HTML forms
- **Validation Support**: Built-in validation with error states
- **Auto-initialization**: Automatic setup via data attributes
- **JavaScript API**: Programmatic control and event handling
- **Framework Agnostic**: Works with any web framework

## Implementation

### 1. **Files Added**

```
src/main/resources/static/js/star-rating.js     - Core JavaScript component
src/main/resources/static/css/star-rating.css  - Component styles
src/main/resources/templates/demo/star-rating-demo.html - Demo page
src/main/java/com/spazone/controller/DemoController.java - Demo controller
src/test/java/com/spazone/component/StarRatingComponentTest.java - Tests
```

### 2. **Updated Files**

```
src/main/resources/templates/spa-service/detail.html - Enhanced rating form
```

### 3. **Basic Usage**

#### HTML (Auto-initialization)
```html
<!-- Include CSS and JS -->
<link th:href="@{/css/star-rating.css}" rel="stylesheet">
<script th:src="@{/js/star-rating.js}"></script>

<!-- Basic star rating -->
<div data-star-rating data-name="rating" data-size="medium"></div>

<!-- With initial rating -->
<div data-star-rating data-initial-rating="4" data-readonly data-size="small"></div>

<!-- Large with labels -->
<div data-star-rating data-name="service_rating" data-size="large" data-show-labels="true"></div>
```

#### JavaScript (Programmatic)
```javascript
// Create instance
const rating = new StarRating('#myRating', {
    size: 'large',
    showLabels: true,
    allowClear: true,
    onRate: function(rating, label) {
        console.log(`Rated ${rating} stars - ${label}`);
    }
});

// Set rating programmatically
rating.setRating(4);

// Get current rating
const currentRating = rating.getRating();

// Clear rating
rating.clearRating();
```

### 4. **Configuration Options**

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `maxStars` | Number | 5 | Maximum number of stars |
| `initialRating` | Number | 0 | Initial rating value |
| `readonly` | Boolean | false | Make rating read-only |
| `size` | String | 'medium' | Size: 'small', 'medium', 'large' |
| `showLabels` | Boolean | true | Show rating labels |
| `allowClear` | Boolean | true | Show clear button |
| `onRate` | Function | null | Callback when rating changes |
| `onHover` | Function | null | Callback on hover |
| `onLeave` | Function | null | Callback on mouse leave |

### 5. **Data Attributes**

| Attribute | Description | Example |
|-----------|-------------|---------|
| `data-star-rating` | Initialize component | `data-star-rating` |
| `data-name` | Form field name | `data-name="rating"` |
| `data-initial-rating` | Initial rating | `data-initial-rating="3"` |
| `data-readonly` | Read-only mode | `data-readonly` |
| `data-size` | Component size | `data-size="large"` |
| `data-show-labels` | Show labels | `data-show-labels="true"` |
| `data-allow-clear` | Allow clearing | `data-allow-clear="false"` |

## Rating Scale

| Stars | Label | Description |
|-------|-------|-------------|
| ⭐ | Very Poor | Extremely unsatisfactory |
| ⭐⭐ | Poor | Below expectations |
| ⭐⭐⭐ | Average | Meets basic expectations |
| ⭐⭐⭐⭐ | Good | Above expectations |
| ⭐⭐⭐⭐⭐ | Excellent | Exceptional quality |

## Keyboard Navigation

| Key | Action |
|-----|--------|
| `Arrow Right/Up` | Increase rating by 1 |
| `Arrow Left/Down` | Decrease rating by 1 |
| `Home` | Set to 1 star |
| `End` | Set to 5 stars |
| `Enter/Space` | Confirm hovered rating |
| `Delete/Backspace` | Clear rating |
| `1-5` | Set specific rating |

## Form Integration

### Basic Form
```html
<form id="ratingForm">
    <div class="mb-3">
        <label class="form-label">Service Rating *</label>
        <div id="serviceRating" data-star-rating data-name="rating" data-size="large"></div>
        <div class="invalid-feedback" style="display: none;">Please select a rating</div>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
```

### Validation
```javascript
document.getElementById('ratingForm').addEventListener('submit', function(e) {
    const ratingInput = document.querySelector('#serviceRating input[type="hidden"]');
    
    if (!ratingInput || ratingInput.value === '0') {
        e.preventDefault();
        document.getElementById('serviceRating').classList.add('is-invalid');
        document.querySelector('.invalid-feedback').style.display = 'block';
        return false;
    }
});
```

## Styling

### CSS Classes
- `.star-rating` - Main container
- `.star-rating.small/medium/large` - Size variants
- `.star-rating.readonly` - Read-only state
- `.star-rating.focused` - Focus state
- `.star` - Individual star
- `.star.filled` - Filled star
- `.star.hovered` - Hovered star
- `.rating-label` - Rating label text
- `.clear-rating` - Clear button

### Custom Styling
```css
.star-rating {
    /* Custom container styles */
}

.star.filled i {
    color: #your-color;
    /* Custom filled star color */
}

.star-rating.large .star i {
    font-size: 28px;
    /* Custom large size */
}
```

## Browser Support

- **Modern Browsers**: Chrome 60+, Firefox 55+, Safari 12+, Edge 79+
- **Mobile**: iOS Safari 12+, Chrome Mobile 60+
- **Accessibility**: NVDA, JAWS, VoiceOver compatible
- **Keyboard**: Full keyboard navigation support

## Performance

- **Lightweight**: ~8KB minified JavaScript + 4KB CSS
- **No Dependencies**: Pure JavaScript, no external libraries
- **Efficient**: Event delegation and optimized DOM manipulation
- **Memory Safe**: Proper cleanup and garbage collection

## Demo

Visit `/demo/star-rating` to see all features in action:
- Basic star rating
- Different sizes
- Readonly ratings
- Form integration with validation
- Accessibility features
- Customization options
- JavaScript API examples

## Migration Guide

### From Dropdown Select
```html
<!-- Old -->
<select name="rating">
    <option value="1">1 star</option>
    <option value="2">2 stars</option>
    <!-- ... -->
</select>

<!-- New -->
<div data-star-rating data-name="rating" data-size="medium"></div>
```

### From Number Input
```html
<!-- Old -->
<input type="number" name="rating" min="1" max="5">

<!-- New -->
<div data-star-rating data-name="rating" data-size="medium"></div>
```

## Best Practices

1. **Always include labels** for better UX
2. **Use appropriate sizes** for context
3. **Implement validation** for required ratings
4. **Test keyboard navigation** thoroughly
5. **Provide clear instructions** for users
6. **Use readonly mode** for displaying existing ratings
7. **Handle form submission** properly with hidden inputs

## Troubleshooting

### Common Issues

**Stars not appearing**: Ensure CSS file is loaded and Font Awesome is available
**JavaScript errors**: Check that star-rating.js is loaded after DOM content
**Form submission issues**: Verify hidden input is created with correct name
**Accessibility problems**: Test with screen readers and keyboard navigation

### Debug Mode
```javascript
// Enable debug logging
StarRating.debug = true;
```

## Future Enhancements

- Half-star ratings (0.5 increments)
- Custom star icons
- Animation customization
- Touch gesture support
- RTL language support
- Theme variants
