-- =============================================
-- APPOINTMENT SERVICES MIGRATION SCRIPT
-- Phase 1: Create new appointment_services junction table
-- =============================================

USE [spa_management]
GO

-- =============================================
-- 1. CREATE APPOINTMENT_SERVICES TABLE
-- =============================================

-- Check if table already exists
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='appointment_services' AND xtype='U')
BEGIN
    CREATE TABLE [dbo].[appointment_services](
        [id] [int] IDENTITY(1,1) NOT NULL,
        [appointment_id] [int] NOT NULL,
        [service_id] [int] NOT NULL,
        [quantity] [int] NOT NULL DEFAULT 1,
        [custom_price] [numeric](10, 2) NULL,
        [notes] [nvarchar](1000) NULL,
        [created_at] [datetime2](6) NOT NULL DEFAULT GETDATE(),
        
        CONSTRAINT [PK_appointment_services] PRIMARY KEY CLUSTERED ([id] ASC),
        CONSTRAINT [FK_appointment_services_appointment] FOREIGN KEY ([appointment_id]) 
            REFERENCES [dbo].[appointments]([appointment_id]) ON DELETE CASCADE,
        CONSTRAINT [FK_appointment_services_service] FOREIGN KEY ([service_id]) 
            REFERENCES [dbo].[services]([service_id]) ON DELETE CASCADE,
        CONSTRAINT [UQ_appointment_service] UNIQUE ([appointment_id], [service_id])
    ) ON [PRIMARY]
    
    PRINT 'Created appointment_services table successfully.'
END
ELSE
BEGIN
    PRINT 'Table appointment_services already exists.'
END
GO

-- =============================================
-- 2. CREATE INDEXES FOR PERFORMANCE
-- =============================================

-- Index on appointment_id for faster lookups
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_appointment_services_appointment_id')
BEGIN
    CREATE INDEX [IX_appointment_services_appointment_id] 
    ON [dbo].[appointment_services] ([appointment_id])
    PRINT 'Created index IX_appointment_services_appointment_id.'
END
GO

-- Index on service_id for faster lookups
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_appointment_services_service_id')
BEGIN
    CREATE INDEX [IX_appointment_services_service_id] 
    ON [dbo].[appointment_services] ([service_id])
    PRINT 'Created index IX_appointment_services_service_id.'
END
GO

-- Composite index for unique constraint and faster queries
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_appointment_services_composite')
BEGIN
    CREATE INDEX [IX_appointment_services_composite] 
    ON [dbo].[appointment_services] ([appointment_id], [service_id])
    PRINT 'Created index IX_appointment_services_composite.'
END
GO

-- =============================================
-- 3. DATA MIGRATION FROM EXISTING APPOINTMENTS
-- =============================================

-- Migrate existing appointment-service relationships
-- Only migrate if there are existing appointments with service_id
IF EXISTS (SELECT 1 FROM [dbo].[appointments] WHERE [service_id] IS NOT NULL)
BEGIN
    PRINT 'Starting data migration from appointments.service_id to appointment_services table...'
    
    -- Insert existing appointment-service relationships
    INSERT INTO [dbo].[appointment_services] ([appointment_id], [service_id], [quantity], [created_at])
    SELECT 
        [appointment_id],
        [service_id],
        1 as [quantity],
        ISNULL([created_at], GETDATE()) as [created_at]
    FROM [dbo].[appointments] 
    WHERE [service_id] IS NOT NULL
    AND NOT EXISTS (
        SELECT 1 FROM [dbo].[appointment_services] 
        WHERE [appointment_id] = [appointments].[appointment_id] 
        AND [service_id] = [appointments].[service_id]
    )
    
    DECLARE @MigratedCount INT = @@ROWCOUNT
    PRINT 'Migrated ' + CAST(@MigratedCount AS VARCHAR(10)) + ' appointment-service relationships.'
END
ELSE
BEGIN
    PRINT 'No existing appointments with service_id found. Skipping data migration.'
END
GO

-- =============================================
-- 4. VERIFICATION QUERIES
-- =============================================

-- Verify the migration
PRINT '=== MIGRATION VERIFICATION ==='

-- Count total appointments
DECLARE @TotalAppointments INT
SELECT @TotalAppointments = COUNT(*) FROM [dbo].[appointments]
PRINT 'Total appointments: ' + CAST(@TotalAppointments AS VARCHAR(10))

-- Count appointments with service_id
DECLARE @AppointmentsWithService INT
SELECT @AppointmentsWithService = COUNT(*) FROM [dbo].[appointments] WHERE [service_id] IS NOT NULL
PRINT 'Appointments with service_id: ' + CAST(@AppointmentsWithService AS VARCHAR(10))

-- Count appointment_services records
DECLARE @AppointmentServicesCount INT
SELECT @AppointmentServicesCount = COUNT(*) FROM [dbo].[appointment_services]
PRINT 'Appointment services records: ' + CAST(@AppointmentServicesCount AS VARCHAR(10))

-- Check for any orphaned records
DECLARE @OrphanedCount INT
SELECT @OrphanedCount = COUNT(*) 
FROM [dbo].[appointment_services] as1
WHERE NOT EXISTS (
    SELECT 1 FROM [dbo].[appointments] a 
    WHERE a.[appointment_id] = as1.[appointment_id]
)
OR NOT EXISTS (
    SELECT 1 FROM [dbo].[services] s 
    WHERE s.[service_id] = as1.[service_id]
)
PRINT 'Orphaned appointment_services records: ' + CAST(@OrphanedCount AS VARCHAR(10))

-- Sample data verification
PRINT '=== SAMPLE DATA ==='
SELECT TOP 5 
    as1.[id],
    as1.[appointment_id],
    a.[customer_id],
    as1.[service_id],
    s.[name] as service_name,
    as1.[quantity],
    as1.[created_at]
FROM [dbo].[appointment_services] as1
INNER JOIN [dbo].[appointments] a ON as1.[appointment_id] = a.[appointment_id]
INNER JOIN [dbo].[services] s ON as1.[service_id] = s.[service_id]
ORDER BY as1.[created_at] DESC

PRINT '=== MIGRATION COMPLETED SUCCESSFULLY ==='
GO
