-- Additional Users Seed Data
-- This script adds 1 Admin and 3 Receptionists to the system
-- Password for all users: admin123 (for admin), reception123 (for receptionists)
-- Encoded password: $2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia

-- First, ensure all required roles exist
INSERT INTO roles (role_name, description) 
SELECT 'ADMIN', 'System Administrator Role'
WHERE NOT EXISTS (SELECT 1 FROM roles WHERE role_name = 'ADMIN');

INSERT INTO roles (role_name, description) 
SELECT 'RECEPTIONIST', 'Front Desk Receptionist Role'
WHERE NOT EXISTS (SELECT 1 FROM roles WHERE role_name = 'RECEPTIONIST');

INSERT INTO roles (role_name, description) 
SELECT 'MANAGER', 'Branch Manager Role'
WHERE NOT EXISTS (SELECT 1 FROM roles WHERE role_name = 'MANAGER');

INSERT INTO roles (role_name, description) 
SELECT 'TECHNICIAN', 'Service Technician Role'
WHERE NOT EXISTS (SELECT 1 FROM roles WHERE role_name = 'TECHNICIAN');

INSERT INTO roles (role_name, description) 
SELECT 'CUSTOMER', 'Customer Role'
WHERE NOT EXISTS (SELECT 1 FROM roles WHERE role_name = 'CUSTOMER');

-- Insert Admin user
INSERT INTO users (username, password, email, full_name, phone, gender, date_of_birth, address, status, enabled, booking_enabled, late_cancellation_count, created_at, updated_at)
SELECT 'admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'admin@spazone.com', 'System Administrator', '0901000001', 'MALE', '1985-01-01', 'Địa chỉ Admin', 'active', 1, 1, 0, GETDATE(), GETDATE()
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'admin');

-- Insert 3 Receptionist users
INSERT INTO users (username, password, email, full_name, phone, gender, date_of_birth, address, status, enabled, booking_enabled, late_cancellation_count, created_at, updated_at)
SELECT 'receptionist1', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'receptionist1@spazone.com', 'Receptionist 1', '0903000001', 'FEMALE', '1995-03-01', 'Địa chỉ lễ tân số 1', 'active', 1, 1, 0, GETDATE(), GETDATE()
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'receptionist1');

INSERT INTO users (username, password, email, full_name, phone, gender, date_of_birth, address, status, enabled, booking_enabled, late_cancellation_count, created_at, updated_at)
SELECT 'receptionist2', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'receptionist2@spazone.com', 'Receptionist 2', '0903000002', 'MALE', '1995-03-02', 'Địa chỉ lễ tân số 2', 'active', 1, 1, 0, GETDATE(), GETDATE()
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'receptionist2');

INSERT INTO users (username, password, email, full_name, phone, gender, date_of_birth, address, status, enabled, booking_enabled, late_cancellation_count, created_at, updated_at)
SELECT 'receptionist3', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM5lIaU0VEDsuYilQ4Ia', 'receptionist3@spazone.com', 'Receptionist 3', '0903000003', 'FEMALE', '1995-03-03', 'Địa chỉ lễ tân số 3', 'active', 1, 1, 0, GETDATE(), GETDATE()
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'receptionist3');

-- Assign roles to users
-- Admin role assignment
INSERT INTO user_roles (user_id, role_id)
SELECT u.user_id, r.role_id
FROM users u, roles r
WHERE u.username = 'admin' AND r.role_name = 'ADMIN'
AND NOT EXISTS (SELECT 1 FROM user_roles ur WHERE ur.user_id = u.user_id AND ur.role_id = r.role_id);

-- Receptionist role assignments
INSERT INTO user_roles (user_id, role_id)
SELECT u.user_id, r.role_id
FROM users u, roles r
WHERE u.username = 'receptionist1' AND r.role_name = 'RECEPTIONIST'
AND NOT EXISTS (SELECT 1 FROM user_roles ur WHERE ur.user_id = u.user_id AND ur.role_id = r.role_id);

INSERT INTO user_roles (user_id, role_id)
SELECT u.user_id, r.role_id
FROM users u, roles r
WHERE u.username = 'receptionist2' AND r.role_name = 'RECEPTIONIST'
AND NOT EXISTS (SELECT 1 FROM user_roles ur WHERE ur.user_id = u.user_id AND ur.role_id = r.role_id);

INSERT INTO user_roles (user_id, role_id)
SELECT u.user_id, r.role_id
FROM users u, roles r
WHERE u.username = 'receptionist3' AND r.role_name = 'RECEPTIONIST'
AND NOT EXISTS (SELECT 1 FROM user_roles ur WHERE ur.user_id = u.user_id AND ur.role_id = r.role_id);

-- Print completion message
PRINT 'Additional users seed data completed successfully!';
PRINT 'Created: 1 Admin, 3 Receptionists';
PRINT 'Admin login: admin / admin123';
PRINT 'Receptionist logins: receptionist1, receptionist2, receptionist3 / reception123';
