-- Fix null booking_enabled values in users table
-- This script updates all users with null booking_enabled to true (default value)

UPDATE users 
SET booking_enabled = true 
WHERE booking_enabled IS NULL;

-- Also ensure late_cancellation_count is not null
UPDATE users 
SET late_cancellation_count = 0 
WHERE late_cancellation_count IS NULL;

-- Add comments for documentation
-- This migration fixes the null pointer exception that occurs when 
-- getBookingEnabled() returns null and code tries to unbox it to boolean
