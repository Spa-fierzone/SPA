-- Migration to remove legacy service_id column from appointments table
-- This migration assumes all data has been migrated to appointment_services table

-- Step 1: Verify that appointment_services table exists and has data
-- (This is just a comment for manual verification before running)

-- Step 2: Remove the foreign key constraint first (if it exists)
-- Note: Constraint name may vary depending on your database setup
-- ALTER TABLE appointments DROP FOREIGN KEY fk_appointments_service_id;

-- Step 3: Drop the service_id column
ALTER TABLE appointments DROP COLUMN IF EXISTS service_id;

-- Step 4: Add comment to track this migration
-- ALTER TABLE appointments COMMENT = 'Legacy service_id column removed - using appointment_services table for service relationships';
