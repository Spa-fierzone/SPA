/**
 * Interactive Star Rating Component
 * Provides a 5-star rating system with hover effects, click selection, and accessibility features
 */
class StarRating {
    constructor(container, options = {}) {
        this.container = typeof container === 'string' ? document.querySelector(container) : container;
        this.options = {
            maxStars: options.maxStars || 5,
            initialRating: options.initialRating || 0,
            readonly: options.readonly || false,
            size: options.size || 'medium', // small, medium, large
            showLabels: options.showLabels !== false,
            allowClear: options.allowClear !== false,
            onRate: options.onRate || null,
            onHover: options.onHover || null,
            onLeave: options.onLeave || null
        };
        
        this.currentRating = this.options.initialRating;
        this.hoverRating = 0;
        
        this.labels = {
            1: 'Very Poor',
            2: 'Poor', 
            3: 'Average',
            4: 'Good',
            5: 'Excellent'
        };
        
        this.init();
    }
    
    init() {
        this.createStarContainer();
        this.createStars();
        this.createLabel();
        this.createClearButton();
        this.createHiddenInput();
        this.updateDisplay();
        this.bindEvents();
    }
    
    createStarContainer() {
        this.container.className = `star-rating ${this.options.size} ${this.options.readonly ? 'readonly' : ''}`;
        this.container.setAttribute('role', 'radiogroup');
        this.container.setAttribute('aria-label', 'Rating');
        this.container.tabIndex = 0;
    }
    
    createStars() {
        this.starsContainer = document.createElement('div');
        this.starsContainer.className = 'stars-container';
        
        this.stars = [];
        for (let i = 1; i <= this.options.maxStars; i++) {
            const star = document.createElement('span');
            star.className = 'star';
            star.setAttribute('data-rating', i);
            star.setAttribute('role', 'radio');
            star.setAttribute('aria-checked', 'false');
            star.setAttribute('aria-label', `${i} star${i > 1 ? 's' : ''} - ${this.labels[i] || ''}`);
            star.tabIndex = -1;
            
            const icon = document.createElement('i');
            icon.className = 'fas fa-star';
            star.appendChild(icon);
            
            this.stars.push(star);
            this.starsContainer.appendChild(star);
        }
        
        this.container.appendChild(this.starsContainer);
    }
    
    createLabel() {
        if (this.options.showLabels) {
            this.label = document.createElement('span');
            this.label.className = 'rating-label';
            this.label.setAttribute('aria-live', 'polite');
            this.container.appendChild(this.label);
        }
    }
    
    createClearButton() {
        if (this.options.allowClear && !this.options.readonly) {
            this.clearButton = document.createElement('button');
            this.clearButton.type = 'button';
            this.clearButton.className = 'clear-rating';
            this.clearButton.innerHTML = '<i class="fas fa-times"></i>';
            this.clearButton.setAttribute('aria-label', 'Clear rating');
            this.clearButton.title = 'Clear rating';
            this.container.appendChild(this.clearButton);
        }
    }
    
    createHiddenInput() {
        // Create hidden input for form submission
        this.hiddenInput = document.createElement('input');
        this.hiddenInput.type = 'hidden';
        this.hiddenInput.name = this.container.getAttribute('data-name') || 'rating';
        this.hiddenInput.value = this.currentRating;
        this.container.appendChild(this.hiddenInput);
    }
    
    bindEvents() {
        if (this.options.readonly) return;
        
        // Mouse events
        this.stars.forEach((star, index) => {
            star.addEventListener('mouseenter', () => this.handleHover(index + 1));
            star.addEventListener('click', () => this.handleClick(index + 1));
        });
        
        this.starsContainer.addEventListener('mouseleave', () => this.handleMouseLeave());
        
        // Clear button
        if (this.clearButton) {
            this.clearButton.addEventListener('click', () => this.clearRating());
        }
        
        // Keyboard events
        this.container.addEventListener('keydown', (e) => this.handleKeydown(e));
        this.container.addEventListener('focus', () => this.handleFocus());
        this.container.addEventListener('blur', () => this.handleBlur());
    }
    
    handleHover(rating) {
        this.hoverRating = rating;
        this.updateDisplay();
        
        if (this.options.onHover) {
            this.options.onHover(rating, this.labels[rating]);
        }
    }
    
    handleClick(rating) {
        this.setRating(rating);
        
        if (this.options.onRate) {
            this.options.onRate(rating, this.labels[rating]);
        }
    }
    
    handleMouseLeave() {
        this.hoverRating = 0;
        this.updateDisplay();
        
        if (this.options.onLeave) {
            this.options.onLeave();
        }
    }
    
    handleKeydown(e) {
        const currentIndex = this.currentRating - 1;
        let newRating = this.currentRating;
        
        switch (e.key) {
            case 'ArrowRight':
            case 'ArrowUp':
                newRating = Math.min(this.currentRating + 1, this.options.maxStars);
                break;
            case 'ArrowLeft':
            case 'ArrowDown':
                newRating = Math.max(this.currentRating - 1, 0);
                break;
            case 'Home':
                newRating = 1;
                break;
            case 'End':
                newRating = this.options.maxStars;
                break;
            case 'Enter':
            case ' ':
                if (this.hoverRating > 0) {
                    newRating = this.hoverRating;
                }
                break;
            case 'Delete':
            case 'Backspace':
                if (this.options.allowClear) {
                    newRating = 0;
                }
                break;
            default:
                // Number keys 1-5
                const num = parseInt(e.key);
                if (num >= 1 && num <= this.options.maxStars) {
                    newRating = num;
                }
                break;
        }
        
        if (newRating !== this.currentRating) {
            e.preventDefault();
            this.setRating(newRating);
        }
    }
    
    handleFocus() {
        this.container.classList.add('focused');
    }
    
    handleBlur() {
        this.container.classList.remove('focused');
        this.hoverRating = 0;
        this.updateDisplay();
    }
    
    setRating(rating) {
        this.currentRating = rating;
        this.hiddenInput.value = rating;
        this.updateDisplay();
        
        // Update ARIA attributes
        this.stars.forEach((star, index) => {
            star.setAttribute('aria-checked', index < rating ? 'true' : 'false');
        });
        
        // Trigger change event for form validation
        const changeEvent = new CustomEvent('change', {
            detail: { rating: rating, label: this.labels[rating] }
        });
        this.container.dispatchEvent(changeEvent);
    }
    
    clearRating() {
        this.setRating(0);
        
        if (this.options.onRate) {
            this.options.onRate(0, 'No rating');
        }
    }
    
    updateDisplay() {
        const displayRating = this.hoverRating || this.currentRating;
        
        this.stars.forEach((star, index) => {
            const isFilled = index < displayRating;
            const isHovered = this.hoverRating > 0 && index < this.hoverRating;
            
            star.classList.toggle('filled', isFilled);
            star.classList.toggle('hovered', isHovered);
        });
        
        // Update label
        if (this.label) {
            if (displayRating > 0) {
                this.label.textContent = `${displayRating} star${displayRating > 1 ? 's' : ''} - ${this.labels[displayRating] || ''}`;
            } else {
                this.label.textContent = 'No rating';
            }
        }
        
        // Update clear button visibility
        if (this.clearButton) {
            this.clearButton.style.display = this.currentRating > 0 ? 'inline-block' : 'none';
        }
    }
    
    // Public methods
    getRating() {
        return this.currentRating;
    }
    
    setReadonly(readonly) {
        this.options.readonly = readonly;
        this.container.classList.toggle('readonly', readonly);
        
        if (readonly) {
            this.container.removeAttribute('tabindex');
        } else {
            this.container.tabIndex = 0;
        }
    }
    
    destroy() {
        this.container.innerHTML = '';
        this.container.className = '';
        this.container.removeAttribute('role');
        this.container.removeAttribute('aria-label');
        this.container.removeAttribute('tabindex');
    }
}

// Auto-initialize star ratings
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('[data-star-rating]').forEach(element => {
        try {
            // Skip if already initialized
            if (element.classList.contains('star-rating-initialized')) {
                return;
            }

            const options = {
                initialRating: parseInt(element.getAttribute('data-initial-rating')) || 0,
                readonly: element.hasAttribute('data-readonly') || element.getAttribute('data-readonly') === 'true',
                size: element.getAttribute('data-size') || 'medium',
                showLabels: element.getAttribute('data-show-labels') !== 'false',
                allowClear: element.getAttribute('data-allow-clear') !== 'false'
            };

            const instance = new StarRating(element, options);
            element.classList.add('star-rating-initialized');

            // Store instance reference for later access
            element.starRatingInstance = instance;
        } catch (error) {
            console.error('Error initializing star rating:', error);
        }
    });
});

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = StarRating;
}
