package com.spazone.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class CustomerProfileDto {
    // Basic user information
    private Integer userId;
    private String username;
    private String email;
    private String fullName;
    private String phone;
    private LocalDate dateOfBirth;
    private String gender;
    private String address;
    private String profilePicture;
    private LocalDateTime createdAt;
    private LocalDateTime lastLogin;
    private LocalDateTime lastVisitDate;
    
    // Customer-specific information
    private String vipLevel;
    private BigDecimal totalSpent;
    private Integer preferredBranchId;
    private String preferredBranchName;
    private Boolean emailVerified;
    private Boolean phoneVerified;
    private Boolean twoFactorEnabled;
    
    // Statistics
    private Integer totalAppointments;
    private Integer completedAppointments;
    private Integer cancelledAppointments;
    private Integer upcomingAppointments;
    private List<String> favoriteServices;
    private BigDecimal averageRating;
    private Integer totalReviews;
    
    // Membership information
    private String membershipType;
    private LocalDateTime membershipExpiry;
    private Integer membershipDiscountPercent;
    private String membershipBenefits;
    
    // Constructors
    public CustomerProfileDto() {}
    
    // Getters and Setters
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }
    
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getProfilePicture() { return profilePicture; }
    public void setProfilePicture(String profilePicture) { this.profilePicture = profilePicture; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getLastLogin() { return lastLogin; }
    public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }
    
    public LocalDateTime getLastVisitDate() { return lastVisitDate; }
    public void setLastVisitDate(LocalDateTime lastVisitDate) { this.lastVisitDate = lastVisitDate; }
    
    public String getVipLevel() { return vipLevel; }
    public void setVipLevel(String vipLevel) { this.vipLevel = vipLevel; }
    
    public BigDecimal getTotalSpent() { return totalSpent; }
    public void setTotalSpent(BigDecimal totalSpent) { this.totalSpent = totalSpent; }
    
    public Integer getPreferredBranchId() { return preferredBranchId; }
    public void setPreferredBranchId(Integer preferredBranchId) { this.preferredBranchId = preferredBranchId; }
    
    public String getPreferredBranchName() { return preferredBranchName; }
    public void setPreferredBranchName(String preferredBranchName) { this.preferredBranchName = preferredBranchName; }
    
    public Boolean getEmailVerified() { return emailVerified; }
    public void setEmailVerified(Boolean emailVerified) { this.emailVerified = emailVerified; }
    
    public Boolean getPhoneVerified() { return phoneVerified; }
    public void setPhoneVerified(Boolean phoneVerified) { this.phoneVerified = phoneVerified; }
    
    public Boolean getTwoFactorEnabled() { return twoFactorEnabled; }
    public void setTwoFactorEnabled(Boolean twoFactorEnabled) { this.twoFactorEnabled = twoFactorEnabled; }
    
    public Integer getTotalAppointments() { return totalAppointments; }
    public void setTotalAppointments(Integer totalAppointments) { this.totalAppointments = totalAppointments; }
    
    public Integer getCompletedAppointments() { return completedAppointments; }
    public void setCompletedAppointments(Integer completedAppointments) { this.completedAppointments = completedAppointments; }
    
    public Integer getCancelledAppointments() { return cancelledAppointments; }
    public void setCancelledAppointments(Integer cancelledAppointments) { this.cancelledAppointments = cancelledAppointments; }
    
    public Integer getUpcomingAppointments() { return upcomingAppointments; }
    public void setUpcomingAppointments(Integer upcomingAppointments) { this.upcomingAppointments = upcomingAppointments; }
    
    public List<String> getFavoriteServices() { return favoriteServices; }
    public void setFavoriteServices(List<String> favoriteServices) { this.favoriteServices = favoriteServices; }
    
    public BigDecimal getAverageRating() { return averageRating; }
    public void setAverageRating(BigDecimal averageRating) { this.averageRating = averageRating; }
    
    public Integer getTotalReviews() { return totalReviews; }
    public void setTotalReviews(Integer totalReviews) { this.totalReviews = totalReviews; }
    
    public String getMembershipType() { return membershipType; }
    public void setMembershipType(String membershipType) { this.membershipType = membershipType; }
    
    public LocalDateTime getMembershipExpiry() { return membershipExpiry; }
    public void setMembershipExpiry(LocalDateTime membershipExpiry) { this.membershipExpiry = membershipExpiry; }
    
    public Integer getMembershipDiscountPercent() { return membershipDiscountPercent; }
    public void setMembershipDiscountPercent(Integer membershipDiscountPercent) { this.membershipDiscountPercent = membershipDiscountPercent; }
    
    public String getMembershipBenefits() { return membershipBenefits; }
    public void setMembershipBenefits(String membershipBenefits) { this.membershipBenefits = membershipBenefits; }
}
