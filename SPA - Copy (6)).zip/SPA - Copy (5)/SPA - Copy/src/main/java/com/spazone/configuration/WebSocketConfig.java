package com.spazone.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

/**
 * WebSocket configuration for real-time chat functionality
 * Integrates with existing Spring Security authentication
 * Supports STOMP messaging protocol with SockJS fallback
 */
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    /**
     * Configure message broker for handling subscriptions and broadcasting
     * Uses simple in-memory broker for Phase 1 (can be upgraded to RabbitMQ later)
     */
    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        // Enable simple broker for destinations starting with /topic and /user
        config.enableSimpleBroker("/topic", "/user");
        
        // Set application destination prefix for messages from client
        config.setApplicationDestinationPrefixes("/app");
        
        // Set user destination prefix for personal messages
        config.setUserDestinationPrefix("/user");
    }

    /**
     * Register STOMP endpoints for WebSocket connections
     * Includes SockJS fallback for browsers that don't support WebSocket
     */
    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws/chat")
                .setAllowedOriginPatterns("*") // Configure for production with specific origins
                .withSockJS()
                .setHeartbeatTime(25000); // 25 seconds heartbeat
    }

    /**
     * Configure client inbound channel with authentication interceptor
     * Integrates with existing Spring Security authentication
     */
    @Override
    public void configureClientInboundChannel(ChannelRegistration registration) {
        registration.interceptors(new ChannelInterceptor() {
            @Override
            public Message<?> preSend(Message<?> message, MessageChannel channel) {
                StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);
                
                if (accessor != null) {
                    if (StompCommand.CONNECT.equals(accessor.getCommand())) {
                        // Authenticate WebSocket connection using existing Spring Security context
                        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

                        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getName())) {
                            accessor.setUser(auth);
                            System.out.println("WebSocket connection authenticated for user: " + auth.getName());
                        } else {
                            // For development/testing, allow connection but log the issue
                            System.err.println("WebSocket connection without proper authentication - allowing for development");
                            // In production, you would throw an exception here:
                            // throw new AccessDeniedException("Authentication required for WebSocket connection");
                        }
                    }

                    if (StompCommand.DISCONNECT.equals(accessor.getCommand())) {
                        System.out.println("WebSocket disconnection for user: " +
                                         (accessor.getUser() != null ? accessor.getUser().getName() : "unknown"));
                    }
                    
                    // Log WebSocket commands for debugging (remove in production)
                    if (accessor.getCommand() != null) {
                        System.out.println("WebSocket command: " + accessor.getCommand() + 
                                         " from user: " + (accessor.getUser() != null ? accessor.getUser().getName() : "anonymous"));
                    }
                }
                
                return message;
            }
        });
    }

    /**
     * Configure client outbound channel for message processing
     * Can be used for message transformation or logging
     */
    @Override
    public void configureClientOutboundChannel(ChannelRegistration registration) {
        // Add any outbound message processing if needed
        // For now, use default configuration
    }
}
