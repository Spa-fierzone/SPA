package com.spazone.controller;

import com.spazone.entity.*;
import com.spazone.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;

@Controller
@RequestMapping("/technician/treatments")
public class TreatmentController {

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private UserService userService;

    @Autowired
    private CloudinaryService cloudinaryService;

    @Autowired
    private TreatmentRecordService treatmentService;

    @Autowired
    private ServiceScheduleService serviceScheduleService;

    @Autowired
    private NotificationService notificationService;

    @GetMapping("/view/{id}")
    public String viewTreatment(@PathVariable Integer id, Model model) {
        TreatmentRecord record = treatmentService.findById(id);
        model.addAttribute("treatment", record);
        return "technician/treatment-view";
    }

    @GetMapping("/new/{appointmentId}")
    public String newTreatmentForm(@PathVariable Integer appointmentId, Model model, Principal principal) {
        Appointment appointment = appointmentService.findById(appointmentId);
        User technician = userService.findByUsername(principal.getName());

        TreatmentRecord treatment = new TreatmentRecord();
        treatment.setAppointment(appointment);
        treatment.setTechnician(technician);
        treatment.setTreatmentDate(LocalDateTime.now());

        model.addAttribute("treatment", treatment);
        return "technician/treatment-form";
    }

    @GetMapping("/edit/{id}")
    public String editTreatmentForm(@PathVariable Integer id, Model model) {
        TreatmentRecord treatment = treatmentService.findById(id);
        model.addAttribute("treatment", treatment);
        return "technician/treatment-form";
    }

    @PostMapping("/save")
    public String saveTreatment(@ModelAttribute TreatmentRecord treatment,
                                @RequestParam("beforeImageFile") MultipartFile beforeImage,
                                @RequestParam("afterImageFile") MultipartFile afterImage,
                                @RequestParam(value = "nextAppointmentDateTime", required = false) String nextAppointmentDateTimeStr,
                                @RequestParam(value = "createNextAppointment", required = false) String createNextAppointment,
                                RedirectAttributes redirectAttributes) {

        TreatmentRecord recordToSave;

        // Check if this is an update (recordId exists) or new record
        if (treatment.getRecordId() != null) {
            // Update existing record - fetch from database to preserve all data
            recordToSave = treatmentService.findById(treatment.getRecordId());

            // Update fields from form
            recordToSave.setPreTreatmentNotes(treatment.getPreTreatmentNotes());
            recordToSave.setPostTreatmentNotes(treatment.getPostTreatmentNotes());
            recordToSave.setTreatmentDate(treatment.getTreatmentDate());
            recordToSave.setCustomerFeedback(treatment.getCustomerFeedback());
            recordToSave.setFollowUpNotes(treatment.getFollowUpNotes());
            recordToSave.setTreatmentProgress(treatment.getTreatmentProgress());
            recordToSave.setNextAppointmentRecommendation(treatment.getNextAppointmentRecommendation());
        } else {
            // New record - use the form data directly
            recordToSave = treatment;
        }

        // Handle image uploads
        if (!beforeImage.isEmpty()) {
            String beforeUrl = cloudinaryService.uploadImage(beforeImage);
            recordToSave.setBeforeImageUrl(beforeUrl);
        }
        if (!afterImage.isEmpty()) {
            String afterUrl = cloudinaryService.uploadImage(afterImage);
            recordToSave.setAfterImageUrl(afterUrl);
        }

        // Save the record (JPA @PrePersist/@PreUpdate will handle timestamps)
        treatmentService.save(recordToSave);

        // Send notification to customer about treatment record update
        try {
            User customer = recordToSave.getAppointment().getCustomer();
            User technician = recordToSave.getTechnician();
            // Get service names for treatment details
            List<Service> services = recordToSave.getAppointment().getServices();
            String serviceNames = services.isEmpty() ? "Không có dịch vụ" :
                services.stream().map(com.spazone.entity.Service::getName).collect(java.util.stream.Collectors.joining(", "));

            String treatmentDetails = String.format("Dịch vụ: %s, Ngày điều trị: %s",
                    serviceNames,
                    recordToSave.getTreatmentDate().toLocalDate());
            notificationService.sendTreatmentRecordUpdateNotification(customer, technician, treatmentDetails);
        } catch (Exception e) {
            // Log error but don't fail the treatment save
            System.err.println("Failed to send treatment notification: " + e.getMessage());
        }

        // --- Create new Appointment and ServiceSchedule after treatment record ---
        String appointmentMessage = "";
        if ("on".equals(createNextAppointment)) {
            Appointment prevAppointment = recordToSave.getAppointment();
            if (prevAppointment != null) {
                try {
                    LocalDateTime nextAppointmentDateTime = null;
                    if (nextAppointmentDateTimeStr != null && !nextAppointmentDateTimeStr.isEmpty()) {
                        nextAppointmentDateTime = LocalDateTime.parse(nextAppointmentDateTimeStr);
                    } else {
                        nextAppointmentDateTime = LocalDateTime.now().plusDays(7);
                    }

                    Appointment newAppointment = new Appointment();
                    newAppointment.setCustomer(prevAppointment.getCustomer());
                    newAppointment.setTechnician(prevAppointment.getTechnician());
                    newAppointment.setBranch(prevAppointment.getBranch());
                    newAppointment.setStartTime(nextAppointmentDateTime);
                    newAppointment.setAppointmentDate(nextAppointmentDateTime);
                    newAppointment.setNotes("Tái khám sau điều trị");

                    // Copy all services from previous appointment
                    for (com.spazone.entity.Service service : prevAppointment.getServices()) {
                        newAppointment.addService(service);
                    }

                    appointmentService.create(newAppointment);

                    // Create service schedules for all services
                    for (com.spazone.entity.Service service : newAppointment.getServices()) {
                        ServiceSchedule newSchedule = new ServiceSchedule();
                        newSchedule.setService(service);
                        newSchedule.setBranch(newAppointment.getBranch());
                        newSchedule.setTechnician(newAppointment.getTechnician());
                        newSchedule.setStartTime(newAppointment.getStartTime());
                        newSchedule.setEndTime(newAppointment.getStartTime().plusMinutes(service.getDuration()));
                        newSchedule.setDayOfWeek(newAppointment.getStartTime().getDayOfWeek().getValue());
                        newSchedule.setActive(true);
                        serviceScheduleService.save(newSchedule);
                    }

                    appointmentMessage = " Lịch hẹn tiếp theo đã được tạo thành công.";
                } catch (IllegalStateException e) {
                    // Handle appointment conflict - show error but don't fail treatment save
                    appointmentMessage = " Không thể tạo lịch hẹn tiếp theo: " + e.getMessage();
                } catch (Exception e) {
                    // Handle other errors
                    appointmentMessage = " Lỗi khi tạo lịch hẹn tiếp theo: " + e.getMessage();
                }
            }
        }
        // --- End create new Appointment and ServiceSchedule ---

        // Add success message with appointment status

        return "redirect:/technician/schedule";
    }

    /**
     * Treatment History with Search functionality
     */
    @GetMapping("/history")
    public String treatmentHistory(@RequestParam(value = "search", required = false) String search,
                                 @RequestParam(value = "customerName", required = false) String customerName,
                                 @RequestParam(value = "startDate", required = false) String startDate,
                                 @RequestParam(value = "endDate", required = false) String endDate,
                                 @RequestParam(value = "page", defaultValue = "0") int page,
                                 @RequestParam(value = "size", defaultValue = "10") int size,
                                 Authentication authentication,
                                 Model model) {

        // Get current technician
        String username = authentication.getName();
        User currentTechnician = userService.findByUsername(username);

        // Create pageable
        Pageable pageable = PageRequest.of(page, size);

        // Get treatment history with search filters
        Page<TreatmentRecord> treatmentHistory = treatmentService.searchTreatmentHistory(
                currentTechnician.getUserId(), search, customerName, startDate, endDate, pageable);

        model.addAttribute("treatmentHistory", treatmentHistory);
        model.addAttribute("search", search);
        model.addAttribute("customerName", customerName);
        model.addAttribute("startDate", startDate);
        model.addAttribute("endDate", endDate);
        model.addAttribute("currentTechnician", currentTechnician);

        return "technician/treatment-history";
    }

    /**
     * Export treatment reports
     */
    @GetMapping("/export")
    public String exportTreatmentReports(@RequestParam(value = "format", defaultValue = "pdf") String format,
                                       @RequestParam(value = "startDate", required = false) String startDate,
                                       @RequestParam(value = "endDate", required = false) String endDate,
                                       Authentication authentication,
                                       Model model) {

        // Get current technician
        String username = authentication.getName();
        User currentTechnician = userService.findByUsername(username);

        // Get treatment records for export
        List<TreatmentRecord> treatments = treatmentService.getTreatmentRecordsForExport(
                currentTechnician.getUserId(), startDate, endDate);

        model.addAttribute("treatments", treatments);
        model.addAttribute("technician", currentTechnician);
        model.addAttribute("startDate", startDate);
        model.addAttribute("endDate", endDate);
        model.addAttribute("format", format);

        // Return appropriate view based on format
        if ("excel".equals(format)) {
            return "technician/treatment-export-excel";
        } else {
            return "technician/treatment-export-pdf";
        }
    }

}
