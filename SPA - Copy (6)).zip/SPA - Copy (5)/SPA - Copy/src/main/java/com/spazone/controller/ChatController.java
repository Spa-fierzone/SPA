package com.spazone.controller;

import com.spazone.dto.ChatMessageResponseDTO;
import com.spazone.dto.ChatRoomDTO;
import com.spazone.entity.ChatMessage;
import com.spazone.entity.ChatParticipant;
import com.spazone.entity.ChatRoom;
import com.spazone.entity.User;
import com.spazone.service.ChatService;
import com.spazone.service.UserService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Controller for chat functionality
 * Provides both REST API endpoints and web page rendering
 * Integrates with existing Spring Security authentication
 */
@Controller
@RequestMapping("/chat")
public class ChatController {

    private static final Logger logger = LoggerFactory.getLogger(ChatController.class);

    @Autowired
    private ChatService chatService;

    @Autowired
    private UserService userService;

    // ===== WEB PAGES =====

    /**
     * Main chat page
     */
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER', 'TECHNICIAN', 'RECEPTIONIST')")
    public String chatPage(Model model, Authentication authentication) {
        try {
            User currentUser = getCurrentUser(authentication);
            if (currentUser == null) {
                return "redirect:/login";
            }

            // Get accessible chat rooms
            List<ChatRoom> chatRooms = chatService.getAccessibleChatRooms(currentUser);
            List<ChatRoomDTO> roomDTOs = chatRooms.stream()
                    .map(room -> convertToRoomDTO(room, currentUser))
                    .collect(Collectors.toList());

            model.addAttribute("chatRooms", roomDTOs);
            model.addAttribute("currentUser", currentUser);
            model.addAttribute("userRole", getUserPrimaryRole(currentUser));

            return "chat/chat";

        } catch (Exception e) {
            logger.error("Error loading chat page: {}", e.getMessage(), e);
            model.addAttribute("error", "Không thể tải trang chat: " + e.getMessage());
            return "error/500";
        }
    }

    // ===== REST API ENDPOINTS =====

    /**
     * Get accessible chat rooms for current user
     */
    @GetMapping("/api/rooms")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER', 'TECHNICIAN', 'RECEPTIONIST')")
    @ResponseBody
    public ResponseEntity<List<ChatRoomDTO>> getChatRooms(Authentication authentication) {
        try {
            User currentUser = getCurrentUser(authentication);
            if (currentUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
            }

            List<ChatRoom> chatRooms = chatService.getAccessibleChatRooms(currentUser);
            List<ChatRoomDTO> roomDTOs = chatRooms.stream()
                    .map(room -> convertToRoomDTO(room, currentUser))
                    .collect(Collectors.toList());

            return ResponseEntity.ok(roomDTOs);

        } catch (Exception e) {
            logger.error("Error getting chat rooms: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Create new chat room
     */
    @PostMapping("/api/rooms")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> createChatRoom(
            @Valid @RequestBody ChatRoomDTO roomDTO,
            BindingResult bindingResult,
            Authentication authentication) {

        Map<String, Object> response = new HashMap<>();

        try {
            if (bindingResult.hasErrors()) {
                response.put("success", false);
                response.put("message", "Dữ liệu không hợp lệ");
                response.put("errors", bindingResult.getAllErrors());
                return ResponseEntity.badRequest().body(response);
            }

            User currentUser = getCurrentUser(authentication);
            if (currentUser == null) {
                response.put("success", false);
                response.put("message", "Người dùng không được xác thực");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }

            ChatRoom newRoom = chatService.createChatRoom(
                    roomDTO.getRoomName(),
                    roomDTO.getRoomType(),
                    currentUser,
                    roomDTO.getBranchId(),
                    roomDTO.getRoomDescription()
            );

            ChatRoomDTO responseDTO = convertToRoomDTO(newRoom, currentUser);

            response.put("success", true);
            response.put("message", "Tạo phòng chat thành công");
            response.put("room", responseDTO);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error creating chat room: {}", e.getMessage(), e);
            response.put("success", false);
            response.put("message", "Không thể tạo phòng chat: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * Get chat room details
     */
    @GetMapping("/api/rooms/{roomId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER', 'TECHNICIAN', 'RECEPTIONIST')")
    @ResponseBody
    public ResponseEntity<ChatRoomDTO> getChatRoom(@PathVariable Integer roomId, Authentication authentication) {
        try {
            User currentUser = getCurrentUser(authentication);
            if (currentUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
            }

            Optional<ChatRoom> roomOpt = chatService.getChatRoom(roomId, currentUser);
            if (roomOpt.isEmpty()) {
                return ResponseEntity.notFound().build();
            }

            ChatRoomDTO roomDTO = convertToRoomDTO(roomOpt.get(), currentUser);
            return ResponseEntity.ok(roomDTO);

        } catch (Exception e) {
            logger.error("Error getting chat room {}: {}", roomId, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get messages in a chat room
     */
    @GetMapping("/api/rooms/{roomId}/messages")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER', 'TECHNICIAN', 'RECEPTIONIST')")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getChatMessages(
            @PathVariable Integer roomId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size,
            Authentication authentication) {

        try {
            User currentUser = getCurrentUser(authentication);
            if (currentUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
            }

            Pageable pageable = PageRequest.of(page, size);
            Page<ChatMessage> messagesPage = chatService.getChatMessages(roomId, currentUser, pageable);

            List<ChatMessageResponseDTO> messageDTOs = messagesPage.getContent().stream()
                    .map(this::convertToMessageDTO)
                    .collect(Collectors.toList());

            Map<String, Object> response = new HashMap<>();
            response.put("messages", messageDTOs);
            response.put("totalElements", messagesPage.getTotalElements());
            response.put("totalPages", messagesPage.getTotalPages());
            response.put("currentPage", messagesPage.getNumber());
            response.put("hasNext", messagesPage.hasNext());
            response.put("hasPrevious", messagesPage.hasPrevious());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error getting messages for room {}: {}", roomId, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Mark messages as read
     */
    @PostMapping("/api/rooms/{roomId}/mark-read")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER', 'TECHNICIAN', 'RECEPTIONIST')")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> markMessagesAsRead(
            @PathVariable Integer roomId,
            Authentication authentication) {

        Map<String, Object> response = new HashMap<>();

        try {
            User currentUser = getCurrentUser(authentication);
            if (currentUser == null) {
                response.put("success", false);
                response.put("message", "Người dùng không được xác thực");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }

            chatService.markMessagesAsRead(roomId, currentUser);

            response.put("success", true);
            response.put("message", "Đã đánh dấu tin nhắn là đã đọc");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error marking messages as read for room {}: {}", roomId, e.getMessage(), e);
            response.put("success", false);
            response.put("message", "Không thể đánh dấu tin nhắn: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * Get available users for chat creation
     */
    @GetMapping("/api/users")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER', 'TECHNICIAN', 'RECEPTIONIST')")
    @ResponseBody
    public ResponseEntity<List<Map<String, Object>>> getAvailableUsers(Authentication authentication) {
        try {
            User currentUser = getCurrentUser(authentication);
            if (currentUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
            }

            List<User> availableUsers = getAvailableUsersForChat(currentUser);
            List<Map<String, Object>> userList = availableUsers.stream()
                    .filter(user -> !user.getUserId().equals(currentUser.getUserId())) // Exclude current user
                    .map(user -> {
                        Map<String, Object> userInfo = new HashMap<>();
                        userInfo.put("userId", user.getUserId());
                        userInfo.put("fullName", user.getFullName());
                        userInfo.put("username", user.getUsername());
                        userInfo.put("branchName", user.getBranch() != null ? user.getBranch().getName() : "");
                        userInfo.put("role", getUserPrimaryRole(user));
                        return userInfo;
                    })
                    .collect(Collectors.toList());

            return ResponseEntity.ok(userList);

        } catch (Exception e) {
            logger.error("Error getting available users: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get or create direct message room
     */
    @PostMapping("/api/rooms/direct")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER', 'TECHNICIAN', 'RECEPTIONIST')")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getOrCreateDirectRoom(
            @RequestParam Integer otherUserId,
            Authentication authentication) {

        Map<String, Object> response = new HashMap<>();

        try {
            User currentUser = getCurrentUser(authentication);
            if (currentUser == null) {
                response.put("success", false);
                response.put("message", "Người dùng không được xác thực");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }

            User otherUserOpt = userService.findById(otherUserId);
            if (otherUserOpt == null) {
                response.put("success", false);
                response.put("message", "Người dùng không tồn tại");
                return ResponseEntity.badRequest().body(response);
            }

            ChatRoom directRoom = chatService.getOrCreateDirectMessageRoom(currentUser, otherUserOpt);
            ChatRoomDTO roomDTO = convertToRoomDTO(directRoom, currentUser);

            response.put("success", true);
            response.put("room", roomDTO);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error creating direct message room: {}", e.getMessage(), e);
            response.put("success", false);
            response.put("message", "Không thể tạo phòng chat: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * Add participant to chat room
     */
    @PostMapping("/api/rooms/{roomId}/participants")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER', 'TECHNICIAN', 'RECEPTIONIST')")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> addParticipant(
            @PathVariable Integer roomId,
            @RequestBody Map<String, Object> request,
            Authentication authentication) {

        Map<String, Object> response = new HashMap<>();

        try {
            User currentUser = getCurrentUser(authentication);
            if (currentUser == null) {
                response.put("success", false);
                response.put("message", "Người dùng không được xác thực");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }

            Integer userId = (Integer) request.get("userId");
            String role = (String) request.getOrDefault("role", "MEMBER");

            if (userId == null) {
                response.put("success", false);
                response.put("message", "ID người dùng không hợp lệ");
                return ResponseEntity.badRequest().body(response);
            }

            chatService.addParticipant(roomId, userId, role, currentUser);

            response.put("success", true);
            response.put("message", "Đã thêm thành viên thành công");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error adding participant to room {}: {}", roomId, e.getMessage(), e);
            response.put("success", false);
            response.put("message", "Không thể thêm thành viên: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ===== HELPER METHODS =====

    private User getCurrentUser(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return null;
        }
        return userService.findByUsername(authentication.getName());
    }

    private String getUserPrimaryRole(User user) {
        return user.getRoles().stream()
                .map(role -> role.getRoleName())
                .filter(roleName -> !roleName.equals("CUSTOMER"))
                .findFirst()
                .orElse("USER");
    }

    private ChatRoomDTO convertToRoomDTO(ChatRoom room, User currentUser) {
        ChatRoomDTO dto = new ChatRoomDTO();
        dto.setRoomId(room.getRoomId());
        dto.setRoomName(room.getRoomName());
        dto.setRoomType(room.getRoomType());
        dto.setRoomDescription(room.getRoomDescription());
        dto.setMaxParticipants(room.getMaxParticipants());
        dto.setCreatedAt(room.getCreatedAt());
        dto.setUpdatedAt(room.getUpdatedAt());
        dto.setIsActive(room.getIsActive());

        if (room.getBranch() != null) {
            dto.setBranchId(room.getBranch().getBranchId());
            dto.setBranchName(room.getBranch().getName());
        }

        if (room.getCreatedBy() != null) {
            dto.setCreatedBy(room.getCreatedBy().getUserId());
            dto.setCreatorName(room.getCreatedBy().getFullName());
        }

        // Get participant count
        dto.setParticipantCount(room.getParticipantCount());

        // Get unread message count for current user
        Long unreadCount = chatService.getUnreadMessageCount(room.getRoomId(), currentUser);
        dto.setUnreadMessageCount(unreadCount);

        return dto;
    }

    private ChatMessageResponseDTO convertToMessageDTO(ChatMessage message) {
        ChatMessageResponseDTO dto = new ChatMessageResponseDTO();
        dto.setMessageId(message.getMessageId());
        dto.setRoomId(message.getChatRoom().getRoomId());
        dto.setContent(message.getDisplayContent());
        dto.setMessageType(message.getMessageType());
        dto.setSentAt(message.getSentAt());
        dto.setEditedAt(message.getEditedAt());
        dto.setEdited(message.isEdited());

        if (message.getSender() != null) {
            dto.setSenderId(message.getSender().getUserId());
            dto.setSenderName(message.getSender().getFullName());
            dto.setSenderAvatar(message.getSender().getProfilePicture());
        }

        if (message.getReplyToMessage() != null) {
            dto.setReplyToMessageId(message.getReplyToMessage().getMessageId());
            dto.setReplyToContent(message.getReplyToMessage().getDisplayContent());
            dto.setReplyToSenderName(message.getReplyToMessage().getSender().getFullName());
        }

        if (message.hasFile()) {
            dto.setFileUrl(message.getFileUrl());
            dto.setFileName(message.getFileName());
            dto.setFileSize(message.getFileSize());
            dto.setFileSizeFormatted(message.getFileSizeFormatted());
        }

        return dto;
    }

    private List<User> getAvailableUsersForChat(User currentUser) {
        String currentUserRole = getUserPrimaryRole(currentUser);

        // ADMIN can chat with everyone
        if ("ADMIN".equals(currentUserRole)) {
            return userService.findAllActiveStaffUsers();
        }

        // MANAGER can chat with users in their branch and other managers/admins
        if ("MANAGER".equals(currentUserRole)) {
            List<User> users = new ArrayList<>();

            // Add users from same branch
            if (currentUser.getBranch() != null) {
                users.addAll(userService.findActiveUsersByBranch(currentUser.getBranch().getBranchId()));
            }

            // Add all managers and admins from other branches
            users.addAll(userService.findActiveUsersByRole("MANAGER"));
            users.addAll(userService.findActiveUsersByRole("ADMIN"));

            // Remove duplicates
            return users.stream().distinct().collect(Collectors.toList());
        }

        // TECHNICIAN and RECEPTIONIST can chat with users in their branch and managers/admins
        List<User> users = new ArrayList<>();

        // Add users from same branch
        if (currentUser.getBranch() != null) {
            users.addAll(userService.findActiveUsersByBranch(currentUser.getBranch().getBranchId()));
        }

        // Add all managers and admins
        users.addAll(userService.findActiveUsersByRole("MANAGER"));
        users.addAll(userService.findActiveUsersByRole("ADMIN"));

        // Remove duplicates
        return users.stream().distinct().collect(Collectors.toList());
    }
}
