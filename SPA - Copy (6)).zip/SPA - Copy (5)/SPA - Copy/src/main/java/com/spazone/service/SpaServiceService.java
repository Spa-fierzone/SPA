package com.spazone.service;

import com.spazone.entity.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface SpaServiceService {
    Page<Service> searchByName(String keyword, int page, int size);
    Service getById(Integer id);
    Service save(Service service);
    void deleteById(Integer id);
    void toggleStatus(Integer serviceId);

    List<Service> getTop6();
    List<Service> findAllActive();

    Service getServiceById(Integer serviceId);

    // Branch-specific methods for manager service management
    Page<Service> findByBranchId(Integer branchId, Pageable pageable);
    Page<Service> searchByNameAndBranchId(String keyword, Integer branchId, Pageable pageable);
    List<Service> findActiveByBranchId(Integer branchId);
    boolean validateManagerAccess(Integer serviceId, Integer managerBranchId);
}
