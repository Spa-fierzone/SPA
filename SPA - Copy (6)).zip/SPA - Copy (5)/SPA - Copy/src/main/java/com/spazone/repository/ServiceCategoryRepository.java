package com.spazone.repository;

import com.spazone.entity.ServiceCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ServiceCategoryRepository extends JpaRepository<ServiceCategory, Integer> {

    // Find all active categories (assuming categories don't have status field, they're active by default)
    List<ServiceCategory> findAll();

    // Check if category exists and is valid for service assignment
    @Query("SELECT COUNT(c) > 0 FROM ServiceCategory c WHERE c.categoryId = :categoryId")
    boolean existsById(@Param("categoryId") Integer categoryId);

    // Find categories that are suitable for specific service types (can be extended based on business rules)
    @Query("SELECT c FROM ServiceCategory c ORDER BY c.name")
    List<ServiceCategory> findAllOrderByName();
}



