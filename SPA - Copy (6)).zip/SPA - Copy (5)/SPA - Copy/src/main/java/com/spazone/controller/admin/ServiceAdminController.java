package com.spazone.controller.admin;

import com.spazone.entity.Service;
import com.spazone.exception.DuplicateResourceException;
import com.spazone.exception.ResourceNotFoundException;
import com.spazone.exception.ServiceValidationException;
import com.spazone.repository.BranchRepository;
import com.spazone.repository.ServiceCategoryRepository;
import com.spazone.service.CloudinaryService;
import com.spazone.service.SpaServiceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin/services")
public class ServiceAdminController {

    private static final Logger logger = LoggerFactory.getLogger(ServiceAdminController.class);

    @Autowired
    private SpaServiceService serviceService;

    @Autowired
    private ServiceCategoryRepository categoryRepo;

    @Autowired
    private BranchRepository branchRepo;

    @Autowired
    private CloudinaryService cloudinaryService;

    @GetMapping
    public String listServices(
            @RequestParam(value = "keyword", required = false) String keyword,
            @RequestParam(value = "page", defaultValue = "0") int page,
            Model model) {

        int size = 5;
        Page<Service> servicePage = serviceService.searchByName(keyword, page, size);

        model.addAttribute("services", servicePage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", servicePage.getTotalPages());
        model.addAttribute("keyword", keyword);

        return "admin/services/list";
    }

    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("service", new Service());
        model.addAttribute("categories", categoryRepo.findAllOrderByName());
        model.addAttribute("branches", branchRepo.findByIsActiveTrue());
        return "admin/services/form";
    }

    @PostMapping("/save")
    public String save(@ModelAttribute("service") Service service,
                       @RequestParam("imageFile") MultipartFile imageFile,
                       Model model,
                       RedirectAttributes redirectAttributes) {
        try {
            logger.info("Attempting to save service: {}", service.getName());

            // Handle image upload
            if (!imageFile.isEmpty()) {
                String imageUrl = cloudinaryService.uploadImage(imageFile);
                service.setImageUrl(imageUrl);
            } else if (service.getServiceId() != null) {
                Service existing = serviceService.getById(service.getServiceId());
                service.setImageUrl(existing.getImageUrl());
            }

            Service savedService = serviceService.save(service);

            // Success message
            String successMessage = service.getServiceId() == null ?
                "Tạo dịch vụ '" + savedService.getName() + "' thành công!" :
                "Cập nhật dịch vụ '" + savedService.getName() + "' thành công!";

            redirectAttributes.addFlashAttribute("successMessage", successMessage);
            logger.info("Successfully saved service with ID: {}", savedService.getServiceId());

            return "redirect:/admin/services";

        } catch (ServiceValidationException e) {
            logger.warn("Service validation failed: {}", e.getMessage());
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("service", service);
            model.addAttribute("categories", categoryRepo.findAllOrderByName());
            model.addAttribute("branches", branchRepo.findByIsActiveTrue());
            return "admin/services/form";

        } catch (DuplicateResourceException e) {
            logger.warn("Duplicate resource error: {}", e.getMessage());
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("service", service);
            model.addAttribute("categories", categoryRepo.findAllOrderByName());
            model.addAttribute("branches", branchRepo.findByIsActiveTrue());
            return "admin/services/form";

        } catch (ResourceNotFoundException e) {
            logger.error("Resource not found: {}", e.getMessage());
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/admin/services";

        } catch (Exception e) {
            logger.error("Unexpected error while saving service: {}", e.getMessage(), e);
            model.addAttribute("errorMessage", "Đã xảy ra lỗi hệ thống. Vui lòng thử lại sau.");
            model.addAttribute("service", service);
            model.addAttribute("categories", categoryRepo.findAllOrderByName());
            model.addAttribute("branches", branchRepo.findByIsActiveTrue());
            return "admin/services/form";
        }
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Integer id, Model model, RedirectAttributes redirectAttributes) {
        try {
            Service service = serviceService.getById(id);
            model.addAttribute("service", service);
            model.addAttribute("categories", categoryRepo.findAllOrderByName());
            model.addAttribute("branches", branchRepo.findByIsActiveTrue());
            return "admin/services/form";
        } catch (ResourceNotFoundException e) {
            logger.error("Service not found for editing: {}", e.getMessage());
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/admin/services";
        }
    }

    @PostMapping("/toggle-status/{id}")
    public String toggleStatus(@PathVariable Integer id) {
        serviceService.toggleStatus(id);
        return "redirect:/admin/services";
    }
}