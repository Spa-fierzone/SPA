package com.spazone.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

/**
 * Data Transfer Object for ChatRoom REST API operations
 * Used for creating, updating, and retrieving chat room information
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatRoomDTO {

    private Integer roomId;

    @NotBlank(message = "Tên phòng chat không được để trống")
    @Size(max = 100, message = "Tên phòng chat không được vượt quá 100 ký tự")
    private String roomName;

    @NotNull(message = "Loại phòng chat không được để trống")
    private String roomType; // DIRECT, GROUP, BRANCH, SYSTEM

    private Integer branchId;
    private String branchName;

    @Size(max = 500, message = "Mô tả phòng chat không được vượt quá 500 ký tự")
    private String roomDescription;

    private Integer maxParticipants;
    private Integer participantCount;
    private Long unreadMessageCount;

    // Creator information
    private Integer createdBy;
    private String creatorName;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updatedAt;

    private Boolean isActive;

    // Last message information
    private String lastMessage;
    private String lastMessageSender;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lastMessageTime;

    // User's role in this room
    private String userRole; // ADMIN, MODERATOR, MEMBER

    // Constructors
    public ChatRoomDTO() {
    }

    public ChatRoomDTO(String roomName, String roomType) {
        this.roomName = roomName;
        this.roomType = roomType;
    }

    // Getters and Setters
    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public String getRoomName() {
        return roomName;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public Integer getBranchId() {
        return branchId;
    }

    public void setBranchId(Integer branchId) {
        this.branchId = branchId;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getRoomDescription() {
        return roomDescription;
    }

    public void setRoomDescription(String roomDescription) {
        this.roomDescription = roomDescription;
    }

    public Integer getMaxParticipants() {
        return maxParticipants;
    }

    public void setMaxParticipants(Integer maxParticipants) {
        this.maxParticipants = maxParticipants;
    }

    public Integer getParticipantCount() {
        return participantCount;
    }

    public void setParticipantCount(Integer participantCount) {
        this.participantCount = participantCount;
    }

    public Long getUnreadMessageCount() {
        return unreadMessageCount;
    }

    public void setUnreadMessageCount(Long unreadMessageCount) {
        this.unreadMessageCount = unreadMessageCount;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatorName() {
        return creatorName;
    }

    public void setCreatorName(String creatorName) {
        this.creatorName = creatorName;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    public void setLastMessage(String lastMessage) {
        this.lastMessage = lastMessage;
    }

    public String getLastMessageSender() {
        return lastMessageSender;
    }

    public void setLastMessageSender(String lastMessageSender) {
        this.lastMessageSender = lastMessageSender;
    }

    public LocalDateTime getLastMessageTime() {
        return lastMessageTime;
    }

    public void setLastMessageTime(LocalDateTime lastMessageTime) {
        this.lastMessageTime = lastMessageTime;
    }

    public String getUserRole() {
        return userRole;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    // Helper methods
    public boolean isDirectMessage() {
        return "DIRECT".equals(roomType);
    }

    public boolean isBranchRoom() {
        return "BRANCH".equals(roomType);
    }

    public boolean isGroupRoom() {
        return "GROUP".equals(roomType);
    }

    public boolean isSystemRoom() {
        return "SYSTEM".equals(roomType);
    }

    public boolean hasUnreadMessages() {
        return unreadMessageCount != null && unreadMessageCount > 0;
    }

    @Override
    public String toString() {
        return "ChatRoomDTO{" +
                "roomId=" + roomId +
                ", roomName='" + roomName + '\'' +
                ", roomType='" + roomType + '\'' +
                ", participantCount=" + participantCount +
                ", unreadMessageCount=" + unreadMessageCount +
                '}';
    }
}
