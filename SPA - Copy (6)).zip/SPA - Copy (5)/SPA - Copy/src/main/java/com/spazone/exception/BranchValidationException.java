package com.spazone.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when branch validation fails
 */
@ResponseStatus(HttpStatus.BAD_REQUEST)
public class BranchValidationException extends RuntimeException {
    
    public BranchValidationException(String message) {
        super(message);
    }
    
    public BranchValidationException(String message, Throwable cause) {
        super(message, cause);
    }
}
