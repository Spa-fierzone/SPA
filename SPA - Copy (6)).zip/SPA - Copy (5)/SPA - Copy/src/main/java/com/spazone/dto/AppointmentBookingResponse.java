package com.spazone.dto;

public class AppointmentBookingResponse extends ApiResponse {
    private Integer appointmentId;
    private Integer invoiceId;

    public AppointmentBookingResponse() {
        super();
    }

    public AppointmentBookingResponse(boolean success, String message, Integer appointmentId, Integer invoiceId) {
        super(success, message);
        this.appointmentId = appointmentId;
        this.invoiceId = invoiceId;
    }

    public Integer getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
    }

    public Integer getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Integer invoiceId) {
        this.invoiceId = invoiceId;
    }
}
