package com.spazone.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Global exception handler for the application
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * Handle branch validation exceptions
     */
    @ExceptionHandler(BranchValidationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public String handleBranchValidationException(BranchValidationException e, 
                                                 Model model, 
                                                 HttpServletRequest request) {
        logger.warn("Branch validation error: {}", e.getMessage());
        
        model.addAttribute("errorMessage", e.getMessage());
        
        // If it's a form submission, return to the form
        String referer = request.getHeader("Referer");
        if (referer != null && referer.contains("/form")) {
            return "admin/branches/form";
        }
        
        return "admin/branches/list";
    }

    /**
     * Handle duplicate resource exceptions
     */
    @ExceptionHandler(DuplicateResourceException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public String handleDuplicateResourceException(DuplicateResourceException e,
                                                  Model model,
                                                  HttpServletRequest request) {
        logger.warn("Duplicate resource error: {}", e.getMessage());

        model.addAttribute("errorMessage", e.getMessage());

        // If it's a form submission, return to the form
        String referer = request.getHeader("Referer");
        if (referer != null && referer.contains("/form")) {
            return "admin/branches/form";
        }

        return "admin/branches/list";
    }

    /**
     * Handle manager image upload exceptions
     */
    @ExceptionHandler(ManagerImageUploadException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public String handleManagerImageUploadException(ManagerImageUploadException e,
                                                   Model model,
                                                   HttpServletRequest request) {
        logger.warn("Manager image upload error: {}", e.getMessage());

        model.addAttribute("errorMessage", e.getMessage());

        // If it's a manager service form submission, return to the form
        String referer = request.getHeader("Referer");
        if (referer != null && referer.contains("/manager/services")) {
            if (referer.contains("/edit/")) {
                // Extract service ID from referer for edit form
                String[] parts = referer.split("/edit/");
                if (parts.length > 1) {
                    String serviceId = parts[1].split("\\?")[0]; // Remove query params if any
                    return "redirect:/manager/services/edit/" + serviceId;
                }
            } else if (referer.contains("/create")) {
                return "redirect:/manager/services/create";
            }
        }

        return "redirect:/manager/services/manage";
    }

    /**
     * Handle resource not found exceptions
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String handleResourceNotFoundException(ResourceNotFoundException e, 
                                                 RedirectAttributes redirectAttributes) {
        logger.error("Resource not found: {}", e.getMessage());
        
        redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        return "redirect:/admin/branches";
    }

    /**
     * Handle general exceptions
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleGeneralException(Exception e, 
                                       Model model, 
                                       HttpServletRequest request) {
        logger.error("Unexpected error: {}", e.getMessage(), e);
        
        String errorMessage = "Đã xảy ra lỗi hệ thống. Vui lòng thử lại sau.";
        model.addAttribute("errorMessage", errorMessage);
        
        // If it's a form submission, return to the form
        String referer = request.getHeader("Referer");
        if (referer != null && referer.contains("/form")) {
            return "admin/branches/form";
        }
        
        return "admin/branches/list";
    }
}
