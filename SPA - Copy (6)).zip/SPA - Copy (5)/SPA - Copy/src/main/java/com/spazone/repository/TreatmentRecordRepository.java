package com.spazone.repository;

import com.spazone.entity.Appointment;
import com.spazone.entity.Service;
import com.spazone.entity.TreatmentRecord;
import com.spazone.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface TreatmentRecordRepository extends JpaRepository<TreatmentRecord, Integer> {

    @Query("SELECT t FROM TreatmentRecord t WHERE t.appointment.appointmentId = :appointmentId")
    List<TreatmentRecord> findByAppointmentAppointmentId(@Param("appointmentId") Integer appointmentId);

    @Query("SELECT t FROM TreatmentRecord t WHERE t.technician.userId = :technicianId")
    List<TreatmentRecord> findByTechnicianUserId(@Param("technicianId") Integer technicianId);

    List<TreatmentRecord> findByTechnician(User technician);

    TreatmentRecord findByAppointment_AppointmentId(Integer appointmentAppointmentId);

    // Enhanced technician dashboard methods
    List<TreatmentRecord> findByTechnicianUserIdOrderByTreatmentDateDesc(Integer technicianId, Pageable pageable);

    Page<TreatmentRecord> findByAppointmentCustomerUserIdOrderByTreatmentDateDesc(Integer customerId, Pageable pageable);

    // Enhanced treatment record system methods
    @Query("SELECT tr FROM TreatmentRecord tr " +
           "WHERE tr.technician.userId = :technicianId " +
           "AND (:search IS NULL OR :search = '' OR " +
           "     LOWER(tr.preTreatmentNotes) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "     LOWER(tr.postTreatmentNotes) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "     LOWER(tr.customerFeedback) LIKE LOWER(CONCAT('%', :search, '%'))) " +
           "AND (:customerName IS NULL OR :customerName = '' OR " +
           "     LOWER(tr.appointment.customer.fullName) LIKE LOWER(CONCAT('%', :customerName, '%'))) " +
           "AND (:startDate IS NULL OR tr.treatmentDate >= :startDate) " +
           "AND (:endDate IS NULL OR tr.treatmentDate <= :endDate) " +
           "ORDER BY tr.treatmentDate DESC")
    Page<TreatmentRecord> searchTreatmentHistory(@Param("technicianId") Integer technicianId,
                                               @Param("search") String search,
                                               @Param("customerName") String customerName,
                                               @Param("startDate") LocalDateTime startDate,
                                               @Param("endDate") LocalDateTime endDate,
                                               Pageable pageable);

    @Query("SELECT tr FROM TreatmentRecord tr " +
           "WHERE tr.technician.userId = :technicianId " +
           "AND (:startDate IS NULL OR tr.treatmentDate >= :startDate) " +
           "AND (:endDate IS NULL OR tr.treatmentDate <= :endDate) " +
           "ORDER BY tr.treatmentDate DESC")
    List<TreatmentRecord> findTreatmentRecordsForExport(@Param("technicianId") Integer technicianId,
                                                       @Param("startDate") LocalDateTime startDate,
                                                       @Param("endDate") LocalDateTime endDate);

    // Service-specific treatment record methods
    @Query("SELECT tr FROM TreatmentRecord tr WHERE tr.appointment = :appointment AND tr.service = :service")
    List<TreatmentRecord> findByAppointmentAndService(@Param("appointment") Appointment appointment,
                                                     @Param("service") Service service);

}
