package com.spazone.service.impl;

import com.spazone.dto.TimeSlot;
import com.spazone.entity.Appointment;
import com.spazone.entity.AppointmentServiceEntity;
import com.spazone.entity.Branch;
import com.spazone.entity.Invoice;
import com.spazone.entity.Room;
import com.spazone.entity.ServiceSchedule;
import com.spazone.entity.TreatmentRecord;
import com.spazone.entity.User;
import com.spazone.repository.*;
import com.spazone.repository.AppointmentServiceRepository;
import com.spazone.service.AppointmentService;
import com.spazone.service.InvoiceService;
import com.spazone.service.RoomService;
import com.spazone.service.UserKPIService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.math.BigDecimal;

import java.time.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class AppointmentServiceImpl implements AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private AppointmentServiceRepository appointmentServiceRepository;

    @Autowired
    private ServiceScheduleRepository serviceScheduleRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ServiceRepository serviceRepository;

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private TreatmentRecordRepository treatmentRecordRepository;

    @Autowired
    private UserKPIService userKPIService;

    @Autowired
    private RoomService roomService;

    @Autowired
    private InvoiceService invoiceService;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    @Transactional
    public void create(Appointment appointment) {
        LocalDateTime startTime = appointment.getStartTime();

        // Validate services - support both legacy single service and new multiple services
        int totalDuration = validateAndCalculateDuration(appointment);

        LocalDateTime endTime = startTime.plusMinutes(totalDuration);
        appointment.setEndTime(endTime);

        List<Appointment> conflicts = appointmentRepository.findConflictingAppointments(
                appointment.getTechnician().getUserId(),
                startTime,
                endTime
        );

        if (!conflicts.isEmpty()) {
            List<TimeSlot> suggestions = suggestFreeSlots(
                    appointment.getTechnician().getUserId(),
                    appointment.getAppointmentDate(),
                    totalDuration
            );

            String message = "Kỹ thuật viên đã có lịch trong khoảng này.";
            if (!suggestions.isEmpty()) {
                message += " Gợi ý thời gian trống:\n" + suggestions.stream()
                        .map(TimeSlot::toString)
                        .collect(Collectors.joining("\n"));
            }

            throw new IllegalStateException(message);
        }

        // Validate room capacity if room is assigned
        if (appointment.getRoom() != null) {
            if (!roomService.hasAvailableCapacity(appointment.getRoom().getId())) {
                throw new IllegalStateException("Phòng " + appointment.getRoom().getName() + " đã hết chỗ.");
            }
        }

        if (appointment.getStatus() == null) {
            appointment.setStatus("scheduled");
        }

        appointmentRepository.save(appointment);

        // Decrease room capacity after successful save
        if (appointment.getRoom() != null) {
            boolean capacityDecreased = roomService.decreaseCapacity(appointment.getRoom().getId());
            if (!capacityDecreased) {
                throw new IllegalStateException("Không thể giảm capacity của phòng.");
            }
        }

        // Create ServiceSchedule for each service
        createServiceSchedules(appointment, startTime, endTime);

        // Update User KPI
        userKPIService.updateKPIOnAppointmentCreated(appointment.getTechnician().getUserId(), totalDuration);
    }

    /**
     * Validates services and calculates total duration for an appointment
     * Supports both legacy single service and new multiple services
     */
    private int validateAndCalculateDuration(Appointment appointment) {
        // Check if appointment has services
        if (appointment.getAppointmentServices() != null && !appointment.getAppointmentServices().isEmpty()) {
            // Validate each service
            for (com.spazone.entity.AppointmentServiceEntity appointmentService : appointment.getAppointmentServices()) {
                if (appointmentService.getService() == null) {
                    throw new IllegalArgumentException("Một trong các dịch vụ không hợp lệ.");
                }
                if (appointmentService.getService().getDuration() <= 0) {
                    throw new IllegalArgumentException("Thời lượng dịch vụ '" + appointmentService.getService().getName() + "' không hợp lệ.");
                }
                if (appointmentService.getQuantity() == null || appointmentService.getQuantity() <= 0) {
                    throw new IllegalArgumentException("Số lượng dịch vụ '" + appointmentService.getService().getName() + "' không hợp lệ.");
                }
            }
            return appointment.getTotalDuration();
        }
        else {
            throw new IllegalArgumentException("Cuộc hẹn phải có ít nhất một dịch vụ.");
        }
    }

    /**
     * Creates ServiceSchedule entries for all services in an appointment
     */
    private void createServiceSchedules(Appointment appointment, LocalDateTime startTime, LocalDateTime endTime) {
        int dayOfWeek = appointment.getAppointmentDate().getDayOfWeek().getValue() % 7;

        // Handle services
        if (appointment.getAppointmentServices() != null && !appointment.getAppointmentServices().isEmpty()) {
            for (com.spazone.entity.AppointmentServiceEntity appointmentService : appointment.getAppointmentServices()) {
                createServiceScheduleIfNotExists(
                    appointment.getTechnician(),
                    appointment.getBranch(),
                    appointmentService.getService(),
                    startTime,
                    endTime,
                    dayOfWeek
                );
            }
        }
    }

    /**
     * Creates a ServiceSchedule if it doesn't already exist
     */
    private void createServiceScheduleIfNotExists(User technician, Branch branch, com.spazone.entity.Service service,
                                                 LocalDateTime startTime, LocalDateTime endTime, int dayOfWeek) {
        boolean exists = serviceScheduleRepository
                .existsByTechnicianUserIdAndBranchBranchIdAndDayOfWeekAndStartTimeAndEndTimeAndServiceServiceId(
                        technician.getUserId(),
                        branch.getBranchId(),
                        dayOfWeek,
                        startTime,
                        endTime,
                        service.getServiceId()
                );

        if (!exists) {
            ServiceSchedule schedule = new ServiceSchedule();
            schedule.setTechnician(technician);
            schedule.setBranch(branch);
            schedule.setService(service);
            schedule.setStartTime(startTime);
            schedule.setEndTime(endTime);
            schedule.setDayOfWeek(dayOfWeek);
            schedule.setActive(true);
            serviceScheduleRepository.save(schedule);
        }
    }

    @Override
    public List<TimeSlot> suggestFreeSlots(Integer technicianId, LocalDateTime dateTime, int serviceDurationMinutes) {

        LocalDateTime workStart = dateTime.withHour(8).withMinute(0).withSecond(0).withNano(0);
        LocalDateTime workEnd = dateTime.withHour(18).withMinute(0).withSecond(0).withNano(0);

        // Truy vấn danh sách cuộc hẹn của kỹ thuật viên trong ngày
        List<Appointment> appointments = appointmentRepository
                .findAppointmentsByTechnicianAndDateRange(technicianId, workStart, workEnd);

        List<TimeSlot> freeSlots = new ArrayList<>();
        LocalDateTime current = workStart;

        for (Appointment a : appointments) {
            if (current.isBefore(a.getStartTime())) {
                Duration gap = Duration.between(current, a.getStartTime());
                if (gap.toMinutes() >= serviceDurationMinutes) {
                    freeSlots.add(new TimeSlot(current, a.getStartTime()));
                }
            }
            // Di chuyển thời điểm bắt đầu tiếp theo nếu cuộc hẹn hiện tại kết thúc muộn hơn
            current = a.getEndTime().isAfter(current) ? a.getEndTime() : current;
        }

        // Thêm khung giờ cuối nếu còn thời gian từ giờ hiện tại đến khi kết thúc làm việc
        if (current.isBefore(workEnd)) {
            Duration gap = Duration.between(current, workEnd);
            if (gap.toMinutes() >= serviceDurationMinutes) {
                freeSlots.add(new TimeSlot(current, workEnd));
            }
        }

        return freeSlots;
    }

    @Override
    public List<Appointment> getTodayAppointments() {
        LocalDate date = LocalDate.now();
        LocalDateTime startOfDay = date.atStartOfDay(); // 00:00
        LocalDateTime endOfDay = date.atTime(LocalTime.MAX); // 23:59:59.999999999

        return appointmentRepository.findByAppointmentDateRange(startOfDay, endOfDay);

    }

    @Override
    public Appointment findById(Integer id) {
        return appointmentRepository.findById(id).orElseThrow(() -> new RuntimeException("Not found"));
    }

    @Override
    public Appointment checkIn(Integer id) {
        return checkInWithTime(id, LocalDateTime.now());
    }

    @Override
    public Appointment checkInWithTime(Integer id, LocalDateTime checkinTime) {
        Appointment appointment = appointmentRepository.findById(id).orElse(null);
        if (appointment != null && Objects.equals(appointment.getStatus(), "scheduled")) {
            appointment.setStatus("CHECK_IN");
            appointment.setCheckinTime(checkinTime);
            appointmentRepository.save(appointment);
        }
        return appointment;
    }

    @Override
    @Transactional
    public void checkOut(Integer appointmentId) {
        Appointment appt = findById(appointmentId);

        // Restore room capacity when checking out
        if (appt.getRoom() != null) {
            roomService.increaseCapacity(appt.getRoom().getId());
        }

        appt.setCheckoutTime(LocalDateTime.now());
        appt.setStatus("CHECKED_OUT");
        appointmentRepository.save(appt);
    }

    @Override
    public Appointment findByIdWithTreatmentRecords(Integer id) {
        return appointmentRepository.findByIdWithTreatmentRecords(id);
    }

    @Override
    @Transactional
    public boolean createAppointment(Integer customerId, Integer serviceId, String appointmentDateTime, Integer technicianId, Integer branchId) {
        try {
            // Fetch customer, service, technician, and branch entities
            User customer = userRepository.findById(customerId).orElseThrow(() -> new IllegalArgumentException("Invalid customer ID"));
            com.spazone.entity.Service service = serviceRepository.findById(serviceId).orElseThrow(() -> new IllegalArgumentException("Invalid service ID"));
            User technician = userRepository.findById(technicianId).orElseThrow(() -> new IllegalArgumentException("Invalid technician ID"));
            Branch branch = branchRepository.findById(branchId).orElseThrow(() -> new IllegalArgumentException("Invalid branch ID"));
            // Parse appointmentDateTime
            LocalDateTime appointmentDate = LocalDateTime.parse(appointmentDateTime);
            LocalDateTime endTime = appointmentDate.plusMinutes(service.getDuration());

            // Auto-assign room
            Room assignedRoom = roomService.autoAssignRoom(branch, appointmentDate, endTime);
            if (assignedRoom == null) {
                throw new IllegalStateException("Không có phòng nào khả dụng cho thời gian này.");
            }

            // Create appointment entity
            Appointment appointment = new Appointment();
            appointment.setCustomer(customer);
            appointment.setTechnician(technician);
            appointment.setBranch(branch);
            appointment.setRoom(assignedRoom);
            appointment.setAppointmentDate(appointmentDate);
            appointment.setStartTime(appointmentDate);
            appointment.setStatus("scheduled");

            // Add service using new multi-service approach
            appointment.addService(service);

            // Use the main create method which handles multi-service logic
            create(appointment);

            // The create() method already handles:
            // - Room capacity decrease
            // - Service schedule creation
            // - KPI updates
            // So we don't need to duplicate that logic here

            return true;
        } catch (Exception e) {
            // Log error (optional)
            System.err.println("Error creating appointment: " + e.getMessage());
            return false;
        }
    }


    @Override
    public List<Appointment> getByCustomer(User customer) {
        return appointmentRepository.findByCustomer(customer);
    }

    @Override
    public Page<Appointment> getByCustomer(User customer, Pageable pageable) {
        return appointmentRepository.findByCustomer(customer, pageable);
    }

    @Override
    public Appointment findLatestAppointment(Integer customerId, Integer serviceId, Integer technicianId, Integer branchId) {
        return appointmentRepository.findTopByCustomerUserIdAndServiceServiceIdAndTechnicianUserIdAndBranchBranchIdOrderByCreatedAtDesc(
                customerId, serviceId, technicianId, branchId);
    }

    @Override
    @Transactional
    public void update(Appointment appointment) {
        // Get the original appointment to check if room changed
        Appointment originalAppointment = appointmentRepository.findById(appointment.getAppointmentId()).orElse(null);

        if (originalAppointment != null) {
            Room originalRoom = originalAppointment.getRoom();
            Room newRoom = appointment.getRoom();

            // If room changed, handle capacity
            if (originalRoom != null && newRoom != null && !originalRoom.getId().equals(newRoom.getId())) {
                // Restore capacity to original room
                roomService.increaseCapacity(originalRoom.getId());

                // Check if new room has capacity
                if (!roomService.hasAvailableCapacity(newRoom.getId())) {
                    throw new IllegalStateException("Phòng " + newRoom.getName() + " đã hết chỗ.");
                }

                // Decrease capacity of new room
                roomService.decreaseCapacity(newRoom.getId());
            } else if (originalRoom == null && newRoom != null) {
                // Room was assigned for the first time
                if (!roomService.hasAvailableCapacity(newRoom.getId())) {
                    throw new IllegalStateException("Phòng " + newRoom.getName() + " đã hết chỗ.");
                }
                roomService.decreaseCapacity(newRoom.getId());
            } else if (originalRoom != null && newRoom == null) {
                // Room was removed
                roomService.increaseCapacity(originalRoom.getId());
            }
        }

        appointmentRepository.save(appointment);
    }

    @Override
    @Transactional
    public boolean cancelAppointment(Integer appointmentId, String cancellationReason) {
        try {
            Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);
            if (appointment == null) {
                return false;
            }

            // Restore room capacity if appointment had a room
            if (appointment.getRoom() != null) {
                roomService.increaseCapacity(appointment.getRoom().getId());
            }

            // Update appointment status
            appointment.setStatus("cancelled");
            appointment.setCancellationReason(cancellationReason);
            appointmentRepository.save(appointment);

            return true;
        } catch (Exception e) {
            System.err.println("Error cancelling appointment: " + e.getMessage());
            return false;
        }
    }

    @Override
    @Transactional
    public boolean deleteAppointment(Integer appointmentId) {
        try {
            Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);
            if (appointment == null) {
                return false;
            }

            // Restore room capacity if appointment had a room
            if (appointment.getRoom() != null) {
                roomService.increaseCapacity(appointment.getRoom().getId());
            }

            // Delete appointment
            appointmentRepository.deleteById(appointmentId);

            return true;
        } catch (Exception e) {
            System.err.println("Error deleting appointment: " + e.getMessage());
            return false;
        }
    }

    @Override
    public List<Appointment> getWeeklyAppointments(LocalDate weekStart) {
        // Calculate week end (Sunday)
        LocalDate weekEnd = weekStart.plusDays(6);

        // Convert to LocalDateTime for database query
        LocalDateTime startDateTime = weekStart.atStartOfDay();
        LocalDateTime endDateTime = weekEnd.atTime(LocalTime.MAX);

        return appointmentRepository.findByAppointmentDateBetween(startDateTime, endDateTime);
    }

    @Override
    public List<Appointment> getAppointmentsByDateRange(LocalDateTime start, LocalDateTime end) {
        return appointmentRepository.findByAppointmentDateBetween(start, end);
    }

    @Override
    @Transactional
    public void createWithServices(Appointment appointment, List<Integer> serviceIds) {
        List<Integer> quantities = serviceIds.stream().map(id -> 1).toList();
        createWithServices(appointment, serviceIds, quantities);
    }

    @Override
    @Transactional
    public void createWithServices(Appointment appointment, List<Integer> serviceIds, List<Integer> quantities) {
        if (serviceIds == null || serviceIds.isEmpty()) {
            throw new IllegalArgumentException("Danh sách dịch vụ không được trống.");
        }

        if (quantities != null && quantities.size() != serviceIds.size()) {
            throw new IllegalArgumentException("Số lượng dịch vụ và số lượng phải có cùng kích thước.");
        }

        // Clear existing appointment services
        appointment.getAppointmentServices().clear();

        // Add services to appointment
        for (int i = 0; i < serviceIds.size(); i++) {
            Integer serviceId = serviceIds.get(i);
            Integer quantity = quantities != null ? quantities.get(i) : 1;

            com.spazone.entity.Service service = serviceRepository.findById(serviceId)
                    .orElseThrow(() -> new IllegalArgumentException("Dịch vụ với ID " + serviceId + " không tồn tại."));

            appointment.addService(service, quantity);
        }

        // Create the appointment using existing logic
        create(appointment);
    }

    @Override
    @Transactional
    public boolean createAppointmentWithServices(Integer customerId, List<Integer> serviceIds,
                                               String appointmentDateTime, Integer technicianId, Integer branchId) {
        try {
            // Fetch entities
            User customer = userRepository.findById(customerId)
                    .orElseThrow(() -> new IllegalArgumentException("Invalid customer ID"));
            User technician = userRepository.findById(technicianId)
                    .orElseThrow(() -> new IllegalArgumentException("Invalid technician ID"));
            Branch branch = branchRepository.findById(branchId)
                    .orElseThrow(() -> new IllegalArgumentException("Invalid branch ID"));

            // Parse appointment date time
            LocalDateTime appointmentDate = LocalDateTime.parse(appointmentDateTime);

            // Create appointment
            Appointment appointment = new Appointment();
            appointment.setCustomer(customer);
            appointment.setTechnician(technician);
            appointment.setBranch(branch);
            appointment.setAppointmentDate(appointmentDate);
            appointment.setStartTime(appointmentDate);
            appointment.setStatus("scheduled");

            // Add services
            for (Integer serviceId : serviceIds) {
                com.spazone.entity.Service service = serviceRepository.findById(serviceId)
                        .orElseThrow(() -> new IllegalArgumentException("Dịch vụ với ID " + serviceId + " không tồn tại."));
                appointment.addService(service);
            }

            // Calculate end time based on total duration
            int totalDuration = appointment.getTotalDuration();
            LocalDateTime endTime = appointmentDate.plusMinutes(totalDuration);

            // Auto-assign room
            Room assignedRoom = roomService.autoAssignRoom(branch, appointmentDate, endTime);
            if (assignedRoom == null) {
                throw new IllegalStateException("Không có phòng nào khả dụng cho thời gian này.");
            }
            appointment.setRoom(assignedRoom);

            // Create appointment using existing logic
            create(appointment);

            return true;
        } catch (Exception e) {
            System.err.println("Error creating appointment with services: " + e.getMessage());
            return false;
        }
    }

    @Override
    @Transactional
    public void updateAppointmentServices(Integer appointmentId, List<Integer> serviceIds, List<Integer> quantities) {
        // Find the appointment
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found with id: " + appointmentId));

        // Delete existing appointment services from database
        if (appointment.getAppointmentServices() != null && !appointment.getAppointmentServices().isEmpty()) {
            appointmentServiceRepository.deleteByAppointmentAppointmentId(appointmentId);
            appointment.getAppointmentServices().clear();
        }

        // Add new services
        if (serviceIds != null && !serviceIds.isEmpty()) {
            for (int i = 0; i < serviceIds.size(); i++) {
                Integer serviceId = serviceIds.get(i);
                Integer quantity = (quantities != null && i < quantities.size()) ? quantities.get(i) : 1;

                if (quantity == null || quantity <= 0) {
                    quantity = 1; // Default to 1 if invalid quantity
                }

                com.spazone.entity.Service service = serviceRepository.findById(serviceId)
                        .orElseThrow(() -> new RuntimeException("Service not found with id: " + serviceId));

                appointment.addService(service, quantity);
            }
        }

        // Save the appointment
        appointmentRepository.save(appointment);
    }

    // Enhanced check-in functionality
    @Override
    public boolean canCheckIn(Integer appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);
        if (appointment == null) {
            return false;
        }

        // Can check in if status is scheduled and within allowed time window
        if (!"scheduled".equals(appointment.getStatus())) {
            return false;
        }

        return isEarlyCheckInAllowed(appointment);
    }

    @Override
    public boolean isEarlyCheckInAllowed(Appointment appointment) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime appointmentTime = appointment.getStartTime();

        // Allow check-in up to 30 minutes early
        LocalDateTime earliestCheckIn = appointmentTime.minusMinutes(30);

        // Allow check-in from 30 minutes early until 15 minutes after appointment time
        LocalDateTime latestCheckIn = appointmentTime.plusMinutes(15);

        return now.isAfter(earliestCheckIn) && now.isBefore(latestCheckIn);
    }

    @Override
    public List<Appointment> getCheckedInAppointments() {
        return appointmentRepository.findByStatus("CHECK_IN");
    }

    @Override
    public List<Appointment> getCheckedInAppointmentsByBranch(Integer branchId) {
        return appointmentRepository.findByBranchBranchIdAndStatus(branchId, "CHECK_IN");
    }

    // Service addition functionality
    @Override
    @Transactional
    public void addServiceToAppointment(Integer appointmentId, Integer serviceId, Integer quantity) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        com.spazone.entity.Service service = serviceRepository.findById(serviceId)
                .orElseThrow(() -> new RuntimeException("Service not found"));

        // Comprehensive business logic validation
        validateServiceAddition(appointment, service, quantity);

        // Add service to appointment
        appointment.addService(service, quantity);

        // Recalculate totals and update duration
        recalculateAppointmentTotals(appointmentId);
        updateAppointmentDuration(appointmentId);

        appointmentRepository.save(appointment);
    }

    private void validateServiceAddition(Appointment appointment, com.spazone.entity.Service service, Integer quantity) {
        // 1. Check invoice payment status
        if (!canAddServicesToUnpaidAppointment(appointment.getAppointmentId())) {
            throw new IllegalStateException("Không thể thêm dịch vụ vào hóa đơn đã thanh toán.");
        }

        // 2. Check service availability for branch
        if (!service.getBranch().getBranchId().equals(appointment.getBranch().getBranchId())) {
            throw new IllegalStateException("Dịch vụ không khả dụng cho chi nhánh này.");
        }

        // 3. Check if service is active
        if (!"active".equals(service.getStatus())) {
            throw new IllegalStateException("Dịch vụ hiện không khả dụng.");
        }

        // 4. Validate quantity
        if (quantity < 1 || quantity > 10) {
            throw new IllegalArgumentException("Số lượng dịch vụ phải từ 1 đến 10.");
        }

        // 5. Check for duplicate services
        boolean serviceExists = appointment.getAppointmentServices().stream()
                .anyMatch(aps -> aps.getService().getServiceId().equals(service.getServiceId()));
        if (serviceExists) {
            throw new IllegalStateException("Dịch vụ đã tồn tại trong lịch hẹn.");
        }

        // 6. Validate technician availability for extended duration
        int additionalMinutes = service.getDuration() * quantity;
        if (!checkTechnicianAvailabilityForExtension(appointment.getAppointmentId(), additionalMinutes)) {
            throw new IllegalStateException("Kỹ thuật viên không rảnh để thực hiện thêm dịch vụ trong thời gian này.");
        }

        // 7. Validate room capacity if needed
        validateRoomCapacityForExtension(appointment, additionalMinutes);
    }

    private void validateRoomCapacityForExtension(Appointment appointment, int additionalMinutes) {
        if (appointment.getRoom() == null) {
            return; // No room assigned, skip validation
        }

        LocalDateTime currentEndTime = appointment.getEndTime();
        LocalDateTime newEndTime = currentEndTime.plusMinutes(additionalMinutes);

        // Check if room is available for the extended time
        // For now, we'll use technician-based conflict checking since room-based conflicts
        // would require a different repository method
        List<Appointment> conflictingAppointments = appointmentRepository.findConflictingAppointments(
                appointment.getTechnician().getUserId(),
                currentEndTime,
                newEndTime
        );

        if (!conflictingAppointments.isEmpty()) {
            throw new IllegalStateException("Kỹ thuật viên không rảnh cho thời gian gia hạn.");
        }
    }

    // Enhanced validation methods for comprehensive business logic
    public boolean validateAppointmentModification(Integer appointmentId) {
        try {
            Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);
            if (appointment == null) {
                return false;
            }

            // Check appointment status
            if (!"scheduled".equals(appointment.getStatus()) && !"CHECK_IN".equals(appointment.getStatus())) {
                return false;
            }

            // Check invoice status
            return canAddServicesToUnpaidAppointment(appointmentId);

        } catch (Exception e) {
            return false;
        }
    }

    public boolean validateServiceAvailability(Integer serviceId, Integer branchId) {
        try {
            com.spazone.entity.Service service = serviceRepository.findById(serviceId).orElse(null);
            if (service == null) {
                return false;
            }

            // Check if service is active
            if (!"active".equals(service.getStatus())) {
                return false;
            }

            // Check if service belongs to the branch
            return service.getBranch().getBranchId().equals(branchId);

        } catch (Exception e) {
            return false;
        }
    }

    public boolean validateTechnicianWorkload(Integer technicianId, LocalDateTime startTime, LocalDateTime endTime) {
        try {
            // Get technician's appointments for the day
            LocalDateTime dayStart = startTime.toLocalDate().atStartOfDay();
            LocalDateTime dayEnd = dayStart.plusDays(1);
            List<Appointment> dailyAppointments = appointmentRepository.findByTechnicianUserIdAndAppointmentDateBetween(
                    technicianId, dayStart, dayEnd);

            // Calculate total working hours for the day
            int totalMinutes = dailyAppointments.stream()
                    .filter(appt -> !"cancelled".equals(appt.getStatus()))
                    .mapToInt(appt -> appt.getTotalDuration())
                    .sum();

            // Add the new appointment duration
            int newDuration = (int) java.time.Duration.between(startTime, endTime).toMinutes();
            totalMinutes += newDuration;

            // Check if total exceeds 8 hours (480 minutes)
            return totalMinutes <= 480;

        } catch (Exception e) {
            return false;
        }
    }

    public String validateAppointmentCreation(Integer customerId, List<Integer> serviceIds,
                                            Integer technicianId, Integer branchId, LocalDateTime appointmentTime) {
        try {
            // Validate customer
            User customer = userRepository.findById(customerId).orElse(null);
            if (customer == null) {
                return "Không tìm thấy khách hàng.";
            }

            // Validate technician
            User technician = userRepository.findById(technicianId).orElse(null);
            if (technician == null) {
                return "Không tìm thấy kỹ thuật viên.";
            }

            // Validate services
            if (serviceIds == null || serviceIds.isEmpty()) {
                return "Vui lòng chọn ít nhất một dịch vụ.";
            }

            for (Integer serviceId : serviceIds) {
                if (!validateServiceAvailability(serviceId, branchId)) {
                    return "Một hoặc nhiều dịch vụ không khả dụng cho chi nhánh này.";
                }
            }

            // Calculate total duration
            int totalDuration = serviceIds.stream()
                    .mapToInt(serviceId -> {
                        com.spazone.entity.Service service = serviceRepository.findById(serviceId).orElse(null);
                        return service != null ? service.getDuration() : 0;
                    })
                    .sum();

            LocalDateTime endTime = appointmentTime.plusMinutes(totalDuration);

            // Validate technician availability
            List<Appointment> conflicts = appointmentRepository.findConflictingAppointments(technicianId, appointmentTime, endTime);
            if (!conflicts.isEmpty()) {
                return "Kỹ thuật viên không rảnh trong thời gian này.";
            }

            // Validate technician workload
            if (!validateTechnicianWorkload(technicianId, appointmentTime, endTime)) {
                return "Kỹ thuật viên đã đạt giới hạn giờ làm việc trong ngày.";
            }

            return null; // No validation errors

        } catch (Exception e) {
            return "Lỗi xác thực: " + e.getMessage();
        }
    }

    @Override
    @Transactional
    public void addServicesToAppointment(Integer appointmentId, List<Integer> serviceIds) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        for (Integer serviceId : serviceIds) {
            com.spazone.entity.Service service = serviceRepository.findById(serviceId)
                    .orElseThrow(() -> new RuntimeException("Service not found: " + serviceId));
            appointment.addService(service);
        }

        // Recalculate totals and update duration
        recalculateAppointmentTotals(appointmentId);
        updateAppointmentDuration(appointmentId);

        appointmentRepository.save(appointment);
    }

    @Override
    @Transactional
    public Appointment createAdditionalServiceAppointment(Integer originalAppointmentId, List<Integer> serviceIds) {
        Appointment originalAppointment = appointmentRepository.findById(originalAppointmentId)
                .orElseThrow(() -> new RuntimeException("Original appointment not found"));

        // Create new appointment for additional services
        Appointment newAppointment = new Appointment();
        newAppointment.setCustomer(originalAppointment.getCustomer());
        newAppointment.setBranch(originalAppointment.getBranch());
        newAppointment.setTechnician(originalAppointment.getTechnician());
        newAppointment.setAppointmentDate(LocalDateTime.now()); // Immediate service
        newAppointment.setStartTime(LocalDateTime.now());
        newAppointment.setStatus("scheduled");
        newAppointment.setNotes("Additional services for appointment #" + originalAppointmentId);

        // Add services
        for (Integer serviceId : serviceIds) {
            com.spazone.entity.Service service = serviceRepository.findById(serviceId)
                    .orElseThrow(() -> new RuntimeException("Service not found: " + serviceId));
            newAppointment.addService(service);
        }

        // Calculate duration and assign room
        int totalDuration = newAppointment.getTotalDuration();
        LocalDateTime endTime = newAppointment.getStartTime().plusMinutes(totalDuration);

        Room assignedRoom = roomService.autoAssignRoom(newAppointment.getBranch(),
                newAppointment.getStartTime(), endTime);
        if (assignedRoom == null) {
            throw new IllegalStateException("Không có phòng nào khả dụng cho dịch vụ bổ sung.");
        }
        newAppointment.setRoom(assignedRoom);

        // Create the appointment
        create(newAppointment);

        // Generate invoice for the new appointment
        invoiceService.generateInvoiceForAppointment(newAppointment);

        return newAppointment;
    }

    @Override
    public boolean canAddServicesToUnpaidAppointment(Integer appointmentId) {
        // Check if appointment exists and has unpaid invoice
        Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);
        if (appointment == null) {
            return false;
        }

        // Check if appointment is in a valid state for service addition
        if (!"scheduled".equals(appointment.getStatus()) && !"CHECK_IN".equals(appointment.getStatus())) {
            return false;
        }

        // Check invoice status - can only add services to unpaid invoices
        try {
            com.spazone.entity.Invoice invoice = invoiceService.findByAppointment(appointment);
            if (invoice == null) {
                // No invoice yet, can add services
                return true;
            }

            // Can add services only if invoice is unpaid
            return "unpaid".equals(invoice.getPaymentStatus());

        } catch (Exception e) {
            // If there's an error checking invoice status, be conservative and return false
            System.err.println("Error checking invoice status for appointment " + appointmentId + ": " + e.getMessage());
            return false;
        }
    }

    @Override
    @Transactional
    public void recalculateAppointmentTotals(Integer appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        // Force recalculation by calling the getter methods
        BigDecimal totalPrice = appointment.getTotalPrice();
        int totalDuration = appointment.getTotalDuration();

        System.out.println("Recalculated appointment " + appointmentId +
                         " - Total Price: " + totalPrice + ", Total Duration: " + totalDuration + " minutes");

        // Save to persist any changes
        appointmentRepository.save(appointment);
    }

    @Override
    @Transactional
    public void updateAppointmentDuration(Integer appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        // Calculate new end time based on total duration
        int totalDuration = appointment.getTotalDuration();
        LocalDateTime oldEndTime = appointment.getEndTime();
        LocalDateTime newEndTime = appointment.getStartTime().plusMinutes(totalDuration);
        appointment.setEndTime(newEndTime);

        System.out.println("Updated appointment " + appointmentId + " duration: " +
                         totalDuration + " minutes, End time: " + oldEndTime + " -> " + newEndTime);

        appointmentRepository.save(appointment);
    }

    @Override
    @Transactional(timeout = 30)
    public void removeServiceFromAppointment(Integer appointmentId, Integer serviceId) {
        try {
            System.out.println("Starting removeServiceFromAppointment for appointment " + appointmentId + ", service " + serviceId);

            // Check if the service exists first
            AppointmentServiceEntity serviceToRemove = appointmentServiceRepository
                    .findByAppointmentAppointmentIdAndServiceServiceId(appointmentId, serviceId);


            if (serviceToRemove == null) {
                throw new RuntimeException("Service not found in appointment");
            }

            // Use deleteBy method instead of finding entity first
            appointmentServiceRepository.delete(serviceToRemove);

            System.out.println("Successfully deleted service " + serviceId + " from appointment " + appointmentId);

        } catch (Exception e) {
            System.err.println("Error in removeServiceFromAppointment: " + e.getMessage());
            throw e;
        }
    }

    @Override
    @Transactional(timeout = 30)
    public void updateServiceQuantity(Integer appointmentId, Integer serviceId, Integer quantity) {
        try {
            System.out.println("Starting updateServiceQuantity for appointment " + appointmentId +
                             ", service " + serviceId + ", quantity " + quantity);

            // Check if the service exists first
            boolean exists = appointmentServiceRepository
                    .existsByAppointmentAppointmentIdAndServiceServiceId(appointmentId, serviceId);

            if (!exists) {
                throw new RuntimeException("Service not found in appointment");
            }

            // Find and update in a single transaction
            AppointmentServiceEntity appointmentService = appointmentServiceRepository
                    .findByAppointmentAppointmentIdAndServiceServiceId(appointmentId, serviceId);

            if (appointmentService != null) {
                appointmentService.setQuantity(quantity);
                appointmentServiceRepository.save(appointmentService);

                System.out.println("Successfully updated service " + serviceId + " quantity to " + quantity +
                                 " in appointment " + appointmentId);
            }

        } catch (Exception e) {
            System.err.println("Error in updateServiceQuantity: " + e.getMessage());
            throw e;
        }
    }

    @Override
    @Transactional(timeout = 60)
    public void removeServiceAndRecalculate(Integer appointmentId, Integer serviceId) {
        try {
            System.out.println("Starting removeServiceAndRecalculate for appointment " + appointmentId + ", service " + serviceId);

            // Step 1: Check if service exists
            boolean exists = appointmentServiceRepository
                    .existsByAppointmentAppointmentIdAndServiceServiceId(appointmentId, serviceId);

            if (!exists) {
                throw new RuntimeException("Service not found in appointment");
            }

            // Step 2: Delete service directly
            appointmentServiceRepository.deleteByAppointmentAppointmentIdAndServiceServiceId(appointmentId, serviceId);
            System.out.println("Service removed from database");

            // Step 3: Force Hibernate to flush and clear session to avoid deleted entity issues
            entityManager.flush();
            entityManager.clear();

            // Step 4: Recalculate manually without using entity getters (to avoid deleted entity merge)
            List<AppointmentServiceEntity> remainingServices = appointmentServiceRepository
                    .findByAppointmentIdWithService(appointmentId);

            // Calculate totals manually
            BigDecimal totalPrice = remainingServices.stream()
                    .map(aps -> {
                        BigDecimal price = aps.getCustomPrice() != null ? aps.getCustomPrice() : aps.getService().getPrice();
                        return price.multiply(BigDecimal.valueOf(aps.getQuantity()));
                    })
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            int totalDuration = remainingServices.stream()
                    .mapToInt(aps -> aps.getService().getDuration() * aps.getQuantity())
                    .sum();

            // Step 5: Update appointment directly
            Appointment appointment = appointmentRepository.findById(appointmentId)
                    .orElseThrow(() -> new RuntimeException("Appointment not found"));

            LocalDateTime newEndTime = appointment.getStartTime().plusMinutes(totalDuration);
            appointment.setEndTime(newEndTime);

            // Save appointment
            appointmentRepository.save(appointment);

            // Step 6: Update invoice with new totals
            updateInvoiceAfterServiceChange(appointment, totalPrice);

            System.out.println("Completed removeServiceAndRecalculate - Total Price: " + totalPrice +
                             ", Total Duration: " + totalDuration + " minutes");

        } catch (Exception e) {
            System.err.println("Error in removeServiceAndRecalculate: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    @Transactional(timeout = 60)
    public void updateServiceQuantityAndRecalculate(Integer appointmentId, Integer serviceId, Integer quantity) {
        try {
            System.out.println("Starting updateServiceQuantityAndRecalculate for appointment " + appointmentId +
                             ", service " + serviceId + ", quantity " + quantity);

            // Step 1: Check if service exists
            boolean exists = appointmentServiceRepository
                    .existsByAppointmentAppointmentIdAndServiceServiceId(appointmentId, serviceId);

            if (!exists) {
                throw new RuntimeException("Service not found in appointment");
            }

            // Step 2: Update quantity
            AppointmentServiceEntity appointmentService = appointmentServiceRepository
                    .findByAppointmentAppointmentIdAndServiceServiceId(appointmentId, serviceId);

            if (appointmentService != null) {
                appointmentService.setQuantity(quantity);
                appointmentServiceRepository.save(appointmentService);
                System.out.println("Service quantity updated in database");
            }

            // Step 3: Force Hibernate to flush changes and clear session
            entityManager.flush();
            entityManager.clear();

            // Step 4: Recalculate manually to avoid entity cache issues
            List<AppointmentServiceEntity> allServices = appointmentServiceRepository
                    .findByAppointmentIdWithService(appointmentId);

            // Calculate totals manually
            BigDecimal totalPrice = allServices.stream()
                    .map(aps -> {
                        BigDecimal price = aps.getCustomPrice() != null ? aps.getCustomPrice() : aps.getService().getPrice();
                        return price.multiply(BigDecimal.valueOf(aps.getQuantity()));
                    })
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            int totalDuration = allServices.stream()
                    .mapToInt(aps -> aps.getService().getDuration() * aps.getQuantity())
                    .sum();

            // Step 5: Update appointment
            Appointment appointment = appointmentRepository.findById(appointmentId)
                    .orElseThrow(() -> new RuntimeException("Appointment not found"));

            LocalDateTime newEndTime = appointment.getStartTime().plusMinutes(totalDuration);
            appointment.setEndTime(newEndTime);

            // Save appointment
            appointmentRepository.save(appointment);

            // Step 6: Update invoice with correct total price
            updateInvoiceAfterServiceChange(appointment, totalPrice);

            System.out.println("Completed updateServiceQuantityAndRecalculate - Total Price: " + totalPrice +
                             ", Total Duration: " + totalDuration + " minutes");

        } catch (Exception e) {
            System.err.println("Error in updateServiceQuantityAndRecalculate: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    // Helper method to update invoice after service changes
    private void updateInvoiceAfterServiceChange(Appointment appointment, BigDecimal correctTotalPrice) {
        try {
            // Find existing invoice for this appointment
            Invoice existingInvoice = invoiceService.findByAppointment(appointment);

            if (existingInvoice != null) {
                // Check if invoice is already paid
                if ("paid".equals(existingInvoice.getPaymentStatus())) {
                    System.out.println("Invoice already paid, cannot update: " + existingInvoice.getInvoiceId());
                    return;
                }

                // Use the correctly calculated total price
                BigDecimal newSubtotal = correctTotalPrice;

                // Calculate tax (assuming 10% VAT)
                BigDecimal taxRate = new BigDecimal("0.10");
                BigDecimal newTax = newSubtotal.multiply(taxRate);
                BigDecimal newFinalAmount = newSubtotal.add(newTax);

                // Update invoice amounts using correct method names
                existingInvoice.setTotalAmount(newSubtotal);
                existingInvoice.setTaxAmount(newTax);
                existingInvoice.setFinalAmount(newFinalAmount);
                existingInvoice.setUpdatedAt(LocalDateTime.now());

                // Save updated invoice
                invoiceService.save(existingInvoice);

                System.out.println("Updated invoice " + existingInvoice.getInvoiceId() +
                                 " with correct final amount: " + newFinalAmount +
                                 " (subtotal: " + newSubtotal + ", tax: " + newTax + ")");
            } else {
                // No existing invoice, generate new one
                invoiceService.generateInvoiceForAppointment(appointment);
                System.out.println("Generated new invoice for appointment: " + appointment.getAppointmentId());
            }

        } catch (Exception e) {
            System.err.println("Error updating invoice after service change: " + e.getMessage());
            e.printStackTrace();
            // Don't throw - invoice update failure shouldn't break service operations
        }
    }

    @Override
    public boolean checkTechnicianAvailabilityForExtension(Integer appointmentId, int additionalMinutes) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        LocalDateTime currentEndTime = appointment.getEndTime();
        LocalDateTime newEndTime = currentEndTime.plusMinutes(additionalMinutes);

        // Check for conflicts with the extended time
        List<Appointment> conflicts = appointmentRepository.findConflictingAppointments(
                appointment.getTechnician().getUserId(),
                currentEndTime,
                newEndTime
        );

        return conflicts.isEmpty();
    }

    // Notification functionality
    @Override
    public void notifyTechnicianOfCheckin(Appointment appointment) {
        // TODO: Implement notification system (email, SMS, push notification)
        System.out.println("Notification: Customer " + appointment.getCustomer().getFullName() +
                " has checked in for appointment #" + appointment.getAppointmentId());
    }

    @Override
    public void notifyTechnicianOfServiceAddition(Appointment appointment, List<com.spazone.entity.Service> addedServices) {
        // TODO: Implement notification system
        System.out.println("Notification: Services added to appointment #" + appointment.getAppointmentId() +
                " for customer " + appointment.getCustomer().getFullName());
    }

    @Override
    public Page<Appointment> getAppointmentsByTechnicianAndDateRange(Integer technicianId, LocalDateTime startDate,
                                                                   LocalDateTime endDate, String status, Pageable pageable) {
        if (status != null && !status.isEmpty()) {
            return appointmentRepository.findByTechnicianUserIdAndAppointmentDateBetweenAndStatus(
                    technicianId, startDate, endDate, status, pageable);
        } else {
            return appointmentRepository.findByTechnicianUserIdAndAppointmentDateBetween(
                    technicianId, startDate, endDate, pageable);
        }
    }

    @Override
    public List<Appointment> getAppointmentsByTechnicianAndDateRange(Integer technicianId, LocalDateTime startDate, LocalDateTime endDate) {
        return appointmentRepository.findAppointmentsByTechnicianAndDateRange(technicianId, startDate, endDate);
    }

    @Override
    public List<Appointment> getAppointmentsByCustomerAndTechnician(Integer customerId, Integer technicianId) {
        return appointmentRepository.findByCustomerUserIdAndTechnicianUserIdOrderByAppointmentDateDesc(customerId, technicianId);
    }

    @Override
    @Transactional
    public void updateAppointmentStatus(Integer appointmentId, String status) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));
        appointment.setStatus(status);
        appointmentRepository.save(appointment);
    }

    @Override
    @Transactional
    public void addServicesToAppointment(Integer appointmentId, List<Integer> serviceIds, List<Integer> quantities, String notes, boolean requiresApproval) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        for (int i = 0; i < serviceIds.size(); i++) {
            Integer serviceId = serviceIds.get(i);
            Integer quantity = quantities.get(i);

            com.spazone.entity.Service service = serviceRepository.findById(serviceId)
                    .orElseThrow(() -> new RuntimeException("Service not found"));

            // Create new appointment service entity
            AppointmentServiceEntity appointmentService = new AppointmentServiceEntity();
            appointmentService.setAppointment(appointment);
            appointmentService.setService(service);
            appointmentService.setQuantity(quantity);
            appointmentService.setNotes(notes);
            appointmentService.setStatus("in-progress");
            appointmentService.setCreatedAt(LocalDateTime.now());

            appointmentServiceRepository.save(appointmentService);
        }

        // Update appointment total duration and price
        updateAppointmentTotals(appointment);

        // If requires approval, notify customer
        if (requiresApproval) {
            // TODO: Implement customer notification for service approval
            System.out.println("Notification: Additional services require approval for appointment #" + appointmentId);
        }
    }

    @Override
    public List<com.spazone.entity.Service> getSuggestedServices(Integer appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));

        // Get current services in the appointment
        List<AppointmentServiceEntity> currentServices = appointmentServiceRepository.findByAppointmentAppointmentId(appointmentId);
        List<Integer> currentServiceIds = currentServices.stream()
                .map(as -> as.getService().getServiceId())
                .collect(Collectors.toList());

        // Get all active services from the same branch
        List<com.spazone.entity.Service> allServices = serviceRepository.findActiveByBranchId(
                appointment.getBranch().getBranchId());

        // Filter out services already in the appointment
        List<com.spazone.entity.Service> suggestedServices = allServices.stream()
                .filter(service -> !currentServiceIds.contains(service.getServiceId()))
                .limit(5) // Limit to top 5 suggestions
                .collect(Collectors.toList());

        return suggestedServices;
    }

    private void updateAppointmentTotals(Appointment appointment) {
        // Get the calculated totals from the appointment (these are calculated dynamically from services)
        int totalDuration = appointment.getTotalDuration();
        BigDecimal totalPrice = appointment.getTotalPrice();

        // Update end time based on new duration
        LocalDateTime newEndTime = appointment.getStartTime().plusMinutes(totalDuration);
        appointment.setEndTime(newEndTime);

        // Save the appointment with updated end time
        appointmentRepository.save(appointment);

        // Update the corresponding invoice with new totals
        updateInvoiceAfterServiceChange(appointment, totalPrice);

        System.out.println("Updated appointment " + appointment.getAppointmentId() +
                         " - Total Price: " + totalPrice + ", Total Duration: " + totalDuration + " minutes");
    }

    @Override
    public void updateAppointmentStatusBasedOnTreatmentRecords(Integer appointmentId) {
        try {
            Appointment appointment = findById(appointmentId);
            if (appointment == null) {
                System.out.println("Appointment not found: " + appointmentId);
                return;
            }

            boolean isCompleted = isAppointmentCompleted(appointmentId);

            // Update appointment status based on treatment record completion
            if (isCompleted && !"completed".equals(appointment.getStatus())) {
                appointment.setStatus("completed");
                appointmentRepository.save(appointment);
                System.out.println("Appointment " + appointmentId + " status updated to completed - all services have treatment records");
            } else if (!isCompleted && "completed".equals(appointment.getStatus())) {
                // If appointment was marked completed but not all services have records, revert to in-progress
                appointment.setStatus("in-progress");
                appointmentRepository.save(appointment);
                System.out.println("Appointment " + appointmentId + " status reverted to in-progress - missing treatment records");
            }

        } catch (Exception e) {
            System.err.println("Error updating appointment status for appointment " + appointmentId + ": " + e.getMessage());
        }
    }

    @Override
    public boolean isAppointmentCompleted(Integer appointmentId) {
        try {
            // Get all services in the appointment
            List<AppointmentServiceEntity> appointmentServices = appointmentServiceRepository.findByAppointmentAppointmentId(appointmentId);

            if (appointmentServices.isEmpty()) {
                return false; // No services, cannot be completed
            }

            Appointment appointment = findById(appointmentId);

            // Check if each service has at least one treatment record
            for (AppointmentServiceEntity appointmentService : appointmentServices) {
                List<TreatmentRecord> treatmentRecords = treatmentRecordRepository.findByAppointmentAndService(
                    appointment, appointmentService.getService());

                if (treatmentRecords.isEmpty()) {
                    return false; // This service has no treatment records
                }
            }

            return true; // All services have at least one treatment record

        } catch (Exception e) {
            System.err.println("Error checking appointment completion status for appointment " + appointmentId + ": " + e.getMessage());
            return false;
        }
    }

    @Override
    @Transactional
    public Appointment createFollowUpAppointment(Integer originalAppointmentId, List<Integer> serviceIds,
                                               List<Integer> quantities, String schedulingType,
                                               LocalDateTime customDateTime, Integer technicianId) {
        try {
            // Validate original appointment exists and is completed
            Appointment originalAppointment = findById(originalAppointmentId);
            if (originalAppointment == null) {
                throw new IllegalArgumentException("Original appointment not found");
            }

            if (!isAppointmentCompleted(originalAppointmentId)) {
                throw new IllegalStateException("Cannot create follow-up appointment: original appointment is not completed");
            }

            // Validate service IDs
            if (serviceIds == null || serviceIds.isEmpty()) {
                throw new IllegalArgumentException("Service list cannot be empty");
            }

            // Set default quantities if not provided
            if (quantities == null || quantities.isEmpty()) {
                quantities = serviceIds.stream().map(id -> 1).collect(Collectors.toList());
            }

            if (quantities.size() != serviceIds.size()) {
                throw new IllegalArgumentException("Service IDs and quantities must have the same size");
            }

            // Determine appointment time
            LocalDateTime appointmentTime;
            if ("immediate".equals(schedulingType)) {
                // Schedule for immediate service (current time + 15 minutes buffer)
                appointmentTime = LocalDateTime.now().plusMinutes(15);
            } else if ("future".equals(schedulingType)) {
                if (customDateTime == null) {
                    throw new IllegalArgumentException("Custom date/time is required for future scheduling");
                }
                appointmentTime = customDateTime;
            } else {
                throw new IllegalArgumentException("Invalid scheduling type: " + schedulingType);
            }

            // Calculate total duration for the new appointment
            int totalDuration = 0;
            for (int i = 0; i < serviceIds.size(); i++) {
                final Integer serviceId = serviceIds.get(i);
                final Integer quantity = quantities.get(i);
                com.spazone.entity.Service service = serviceRepository.findById(serviceId)
                        .orElseThrow(() -> new IllegalArgumentException("Service not found: " + serviceId));
                totalDuration += service.getDuration() * quantity;
            }

            LocalDateTime endTime = appointmentTime.plusMinutes(totalDuration);

            // Handle technician assignment
            User assignedTechnician;
            if (technicianId != null) {
                assignedTechnician = userRepository.findById(technicianId)
                        .orElseThrow(() -> new IllegalArgumentException("Technician not found: " + technicianId));
            } else {
                // Auto-assign technician (prefer the original technician if available)
                assignedTechnician = originalAppointment.getTechnician();

                // Check if original technician is available
                List<Appointment> conflicts = appointmentRepository.findConflictingAppointments(
                        assignedTechnician.getUserId(), appointmentTime, endTime);

                if (!conflicts.isEmpty()) {
                    // Find alternative technician from the same branch
                    List<User> availableTechnicians = userRepository.findByBranchIdAndRoleName(
                            originalAppointment.getBranch().getBranchId(), "TECHNICIAN");
                    List<User> freeTechnicians = availableTechnicians.stream()
                            .filter(t -> appointmentRepository.findConflictingAppointments(t.getUserId(), appointmentTime, endTime).isEmpty())
                            .collect(Collectors.toList());

                    if (freeTechnicians.isEmpty()) {
                        throw new IllegalStateException("No technicians available for the selected time slot");
                    }

                    assignedTechnician = freeTechnicians.get(0);
                }
            }

            // Auto-assign room
            Room assignedRoom = roomService.autoAssignRoom(originalAppointment.getBranch(), appointmentTime, endTime);
            if (assignedRoom == null) {
                throw new IllegalStateException("No rooms available for the selected time slot");
            }

            // Create the follow-up appointment
            Appointment followUpAppointment = new Appointment();
            followUpAppointment.setCustomer(originalAppointment.getCustomer());
            followUpAppointment.setBranch(originalAppointment.getBranch());
            followUpAppointment.setTechnician(assignedTechnician);
            followUpAppointment.setRoom(assignedRoom);
            followUpAppointment.setStartTime(appointmentTime);
            followUpAppointment.setEndTime(endTime);
            followUpAppointment.setAppointmentDate(appointmentTime);
            followUpAppointment.setStatus("scheduled");
            followUpAppointment.setOriginalAppointmentId(originalAppointmentId);
            followUpAppointment.setNotes("Follow-up appointment for additional services");

            // Create appointment with services
            createWithServices(followUpAppointment, serviceIds, quantities);

            // Generate invoice for the follow-up appointment
            invoiceService.generateInvoiceForAppointment(followUpAppointment);

            return followUpAppointment;

        } catch (Exception e) {
            System.err.println("Error creating follow-up appointment: " + e.getMessage());
            throw new RuntimeException("Failed to create follow-up appointment: " + e.getMessage(), e);
        }
    }
}
