package com.spazone.controller;

import com.spazone.service.CloudinaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

/**
 * Test controller for debugging file upload issues
 */
@Controller
@RequestMapping("/test")
public class UploadTestController {

    @Autowired
    private CloudinaryService cloudinaryService;

    @GetMapping("/upload")
    public String showUploadTestPage() {
        return "test/upload-test";
    }

    @PostMapping("/upload")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> testUpload(@RequestParam("file") MultipartFile file) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            // Log file details
            System.out.println("=== UPLOAD TEST ===");
            System.out.println("File name: " + file.getOriginalFilename());
            System.out.println("File size: " + file.getSize() + " bytes");
            System.out.println("Content type: " + file.getContentType());
            System.out.println("Is empty: " + file.isEmpty());
            
            if (file.isEmpty()) {
                response.put("success", false);
                response.put("error", "File is empty");
                return ResponseEntity.badRequest().body(response);
            }
            
            // Test Cloudinary upload
            String imageUrl = cloudinaryService.uploadImage(file);
            
            response.put("success", true);
            response.put("imageUrl", imageUrl);
            response.put("fileName", file.getOriginalFilename());
            response.put("fileSize", file.getSize());
            response.put("contentType", file.getContentType());
            
            System.out.println("Upload successful: " + imageUrl);
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            System.err.println("Upload failed: " + e.getMessage());
            e.printStackTrace();
            
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
}
