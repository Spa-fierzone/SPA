package com.spazone.repository;

import com.spazone.entity.AppealRequest;
import com.spazone.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AppealRequestRepository extends JpaRepository<AppealRequest, Integer> {

    List<AppealRequest> findByCustomer(User customer);

    List<AppealRequest> findByStatus(String status);

    List<AppealRequest> findByCustomerAndStatus(User customer, String status);

    @Query("SELECT a FROM AppealRequest a WHERE a.status = 'PENDING' ORDER BY a.submittedDate ASC")
    List<AppealRequest> findPendingAppeals();

    @Query("SELECT a FROM AppealRequest a WHERE a.reviewedBy = :reviewerId ORDER BY a.reviewedDate DESC")
    List<AppealRequest> findByReviewedBy(@Param("reviewerId") Integer reviewerId);

    @Query("SELECT COUNT(a) FROM AppealRequest a WHERE a.customer = :customer AND a.appealType = :appealType AND a.status = 'PENDING'")
    long countPendingAppealsByCustomerAndType(@Param("customer") User customer, @Param("appealType") String appealType);
}
