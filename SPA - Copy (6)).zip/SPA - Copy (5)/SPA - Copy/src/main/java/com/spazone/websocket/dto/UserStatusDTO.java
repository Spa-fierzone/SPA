package com.spazone.websocket.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;

/**
 * Data Transfer Object for user status updates in WebSocket communication
 * Used to track online/offline status and last seen information
 */
public class UserStatusDTO {

    private Integer userId;
    private String userName;
    private String status; // "online", "offline", "away", "busy"
    private String avatar;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lastSeen;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime timestamp;

    // Constructors
    public UserStatusDTO() {
        this.timestamp = LocalDateTime.now();
    }

    public UserStatusDTO(Integer userId, String userName, String status) {
        this.userId = userId;
        this.userName = userName;
        this.status = status;
        this.timestamp = LocalDateTime.now();
        this.lastSeen = LocalDateTime.now();
    }

    // Getters and Setters
    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public LocalDateTime getLastSeen() {
        return lastSeen;
    }

    public void setLastSeen(LocalDateTime lastSeen) {
        this.lastSeen = lastSeen;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    // Helper methods
    public boolean isOnline() {
        return "online".equals(status);
    }

    public boolean isOffline() {
        return "offline".equals(status);
    }

    public boolean isAway() {
        return "away".equals(status);
    }

    public boolean isBusy() {
        return "busy".equals(status);
    }

    @Override
    public String toString() {
        return "UserStatusDTO{" +
                "userId=" + userId +
                ", userName='" + userName + '\'' +
                ", status='" + status + '\'' +
                ", lastSeen=" + lastSeen +
                '}';
    }
}
