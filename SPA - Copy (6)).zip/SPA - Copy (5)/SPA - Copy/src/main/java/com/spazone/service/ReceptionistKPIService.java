package com.spazone.service;

import com.spazone.entity.ReceptionistKPI;
import com.spazone.entity.User;
import com.spazone.repository.AppointmentHandledRepository;
import com.spazone.repository.InvoiceRepository;
import com.spazone.repository.ReceptionistKPIRepository;
import com.spazone.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ReceptionistKPIService {

    @Autowired
    private ReceptionistKPIRepository receptionistKPIRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AppointmentHandledRepository appointmentHandledRepository;

    @Autowired
    private InvoiceRepository invoiceRepository;

    // Create or update KPI for receptionist
    public ReceptionistKPI createOrUpdateKPI(Integer receptionistId, Integer managerId, Integer month, Integer year,
                                           Integer targetAppointments, Integer targetInvoices, BigDecimal targetRevenue) {
        // Debug logging
        System.out.println("DEBUG: Creating KPI with month=" + month + ", year=" + year +
                          ", receptionistId=" + receptionistId + ", managerId=" + managerId);

        Optional<User> receptionist = userRepository.findById(receptionistId);
        Optional<User> manager = userRepository.findById(managerId);

        if (receptionist.isEmpty() || manager.isEmpty()) {
            throw new RuntimeException("Receptionist or Manager not found");
        }

        // Check if KPI already exists - use List to avoid NonUniqueResultException
        List<ReceptionistKPI> existingKPIs = receptionistKPIRepository.findKPIsByReceptionistAndMonthAndYear(receptionistId, month, year);

        ReceptionistKPI kpi;
        if (!existingKPIs.isEmpty()) {
            // Update existing KPI (get active first or first one)
            kpi = existingKPIs.stream()
                    .filter(k -> "active".equals(k.getStatus()))
                    .findFirst()
                    .orElse(existingKPIs.get(0));
            kpi.setTargetAppointments(targetAppointments);
            kpi.setTargetInvoices(targetInvoices);
            kpi.setTargetRevenue(targetRevenue);
            kpi.setManager(manager.get());
            kpi.setUpdatedAt(LocalDateTime.now());
        } else {
            // Create new KPI
            System.out.println("DEBUG: Creating new KPI entity with month=" + month + ", year=" + year);
            kpi = new ReceptionistKPI(receptionist.get(), manager.get(), month, year,
                                    targetAppointments, targetInvoices, targetRevenue);
        }

        ReceptionistKPI savedKPI = receptionistKPIRepository.save(kpi);
        System.out.println("DEBUG: Saved KPI with ID=" + savedKPI.getKpiId() +
                          ", month=" + savedKPI.getMonth() + ", year=" + savedKPI.getYear());
        return savedKPI;
    }

    // Get KPIs by manager
    public List<ReceptionistKPI> getKPIsByManager(Integer managerId) {
        Optional<User> manager = userRepository.findById(managerId);
        if (manager.isEmpty()) {
            throw new RuntimeException("Manager not found");
        }
        return receptionistKPIRepository.findByManagerOrderByYearDescMonthDesc(manager.get());
    }

    // Get KPIs by receptionist
    public List<ReceptionistKPI> getKPIsByReceptionist(Integer receptionistId) {
        Optional<User> receptionist = userRepository.findById(receptionistId);
        if (receptionist.isEmpty()) {
            throw new RuntimeException("Receptionist not found");
        }
        return receptionistKPIRepository.findByReceptionistOrderByYearDescMonthDesc(receptionist.get());
    }

    // Get KPIs by manager and month/year
    public List<ReceptionistKPI> getKPIsByManagerAndMonthAndYear(Integer managerId, Integer month, Integer year) {
        return receptionistKPIRepository.findByManagerAndMonthAndYear(managerId, month, year);
    }

    // Get KPIs by receptionist and month/year
    public List<ReceptionistKPI> getKPIsByReceptionistAndMonthAndYear(Integer receptionistId, Integer month, Integer year) {
        return receptionistKPIRepository.findKPIsByReceptionistAndMonthAndYear(receptionistId, month, year);
    }

    // Get KPI by ID
    public Optional<ReceptionistKPI> getKPIById(Integer kpiId) {
        return receptionistKPIRepository.findById(kpiId);
    }

    // Check if KPI exists
    public boolean isKPIExists(Integer receptionistId, Integer month, Integer year) {
        return receptionistKPIRepository.existsByReceptionistAndMonthAndYear(receptionistId, month, year);
    }

    // Get all receptionists
    public List<User> getAllReceptionists() {
        return userRepository.findUsersByRoleName("RECEPTIONIST");
    }

    // Update actual KPI metrics for a receptionist
    public void updateActualMetrics(Integer receptionistId, Integer month, Integer year) {
        List<ReceptionistKPI> kpis = receptionistKPIRepository.findKPIsByReceptionistAndMonthAndYear(receptionistId, month, year);

        if (!kpis.isEmpty()) {
            ReceptionistKPI kpi = kpis.get(0);

            // Calculate actual appointments handled
            int actualAppointments = appointmentHandledRepository.countByReceptionistAndMonth(receptionistId, month, year);
            kpi.setActualAppointments(actualAppointments);

            // Calculate actual invoices created and revenue
            YearMonth yearMonth = YearMonth.of(year, month);
            LocalDateTime startDate = yearMonth.atDay(1).atStartOfDay();
            LocalDateTime endDate = yearMonth.atEndOfMonth().atTime(23, 59, 59);

            // Get appointments handled by this receptionist in the month
            List<com.spazone.entity.AppointmentHandled> handledAppointments =
                appointmentHandledRepository.findByReceptionistAndMonth(receptionistId, month, year);

            // Calculate invoices and revenue from handled appointments
            int actualInvoices = 0;
            BigDecimal actualRevenue = BigDecimal.ZERO;

            for (com.spazone.entity.AppointmentHandled handled : handledAppointments) {
                // Check if appointment has an invoice
                com.spazone.entity.Invoice invoice = invoiceRepository.findByAppointment(handled.getAppointment());
                if (invoice != null) {
                    actualInvoices++;
                    if (invoice.getFinalAmount() != null) {
                        actualRevenue = actualRevenue.add(invoice.getFinalAmount());
                    }
                }
            }

            kpi.setActualInvoices(actualInvoices);
            kpi.setActualRevenue(actualRevenue);
            kpi.setActualCheckins(actualAppointments); // Assuming check-ins = appointments handled
            kpi.setActualCheckouts(actualAppointments); // Assuming check-outs = appointments handled

            kpi.setUpdatedAt(LocalDateTime.now());
            receptionistKPIRepository.save(kpi);
        }
    }

    // Get KPI history for a receptionist (last N months)
    public List<ReceptionistKPI> getKPIHistoryByReceptionist(Integer receptionistId, int months) {
        Optional<User> receptionist = userRepository.findById(receptionistId);
        if (receptionist.isEmpty()) {
            throw new RuntimeException("Receptionist not found");
        }
        
        LocalDateTime startDate = LocalDateTime.now().minusMonths(months);
        return receptionistKPIRepository.findByReceptionistAndCreatedAtAfterOrderByYearDescMonthDesc(
                receptionist.get(), startDate);
    }

    // Get top performing receptionists for a month
    public List<ReceptionistKPI> getTopPerformingReceptionists(Integer month, Integer year) {
        return receptionistKPIRepository.getTopPerformingReceptionists(month, year);
    }

    // Get underperforming receptionists for a month
    public List<ReceptionistKPI> getUnderperformingReceptionists(Integer month, Integer year) {
        return receptionistKPIRepository.getUnderperformingReceptionists(month, year);
    }

    // Get KPI summary for dashboard
    public Object[] getKPISummaryByMonth(Integer month, Integer year) {
        Object[] summary = receptionistKPIRepository.getKPISummaryByMonth(month, year);
        if (summary == null) {
            // Return default values when no data exists
            return new Object[]{0L, 0L, 0L, 0.0};
        }
        return summary;
    }

    // Get branch-wise KPI summary
    public List<Object[]> getBranchWiseKPISummary(Integer month, Integer year) {
        try {
            return receptionistKPIRepository.getBranchWiseKPISummary(month, year);
        } catch (Exception e) {
            // Return empty list if there's an error
            return new java.util.ArrayList<>();
        }
    }

    // Get revenue performance
    public Object[] getRevenuePerformanceByMonth(Integer month, Integer year) {
        return receptionistKPIRepository.getRevenuePerformanceByMonth(month, year);
    }

    // Get KPIs that need attention
    public List<ReceptionistKPI> getKPIsNeedingAttention(Integer month, Integer year) {
        return receptionistKPIRepository.getKPIsNeedingAttention(month, year);
    }

    // Get performance trends for a receptionist
    public List<Object[]> getPerformanceTrendsByReceptionist(Integer receptionistId) {
        return receptionistKPIRepository.getPerformanceTrendsByReceptionist(receptionistId);
    }

    // Get monthly comparison data
    public List<Object[]> getMonthlyComparison() {
        return receptionistKPIRepository.getMonthlyComparison();
    }

    // Delete KPI
    public void deleteKPI(Integer kpiId) {
        // Check if KPI exists before deletion
        Optional<ReceptionistKPI> kpiOpt = receptionistKPIRepository.findById(kpiId);
        if (kpiOpt.isEmpty()) {
            throw new RuntimeException("KPI with ID " + kpiId + " not found");
        }

        ReceptionistKPI kpi = kpiOpt.get();

        // Log deletion for audit purposes
        System.out.println("Deleting Receptionist KPI: ID=" + kpiId +
                          ", Receptionist=" + kpi.getReceptionist().getFullName() +
                          ", Month/Year=" + kpi.getMonth() + "/" + kpi.getYear());

        receptionistKPIRepository.deleteById(kpiId);

        System.out.println("Successfully deleted Receptionist KPI with ID: " + kpiId);
    }

    // Activate/Deactivate KPI
    public void updateKPIStatus(Integer kpiId, String status) {
        Optional<ReceptionistKPI> kpiOpt = receptionistKPIRepository.findById(kpiId);
        if (kpiOpt.isPresent()) {
            ReceptionistKPI kpi = kpiOpt.get();
            kpi.setStatus(status);
            kpi.setUpdatedAt(LocalDateTime.now());
            receptionistKPIRepository.save(kpi);
        }
    }

    // Get current month KPIs for a manager
    public List<ReceptionistKPI> getCurrentMonthKPIsByManager(Integer managerId, Integer month, Integer year) {
        return receptionistKPIRepository.findCurrentMonthKPIsByManager(managerId, month, year);
    }

    // Get active KPIs by manager
    public List<ReceptionistKPI> getActiveKPIsByManager(Integer managerId) {
        return receptionistKPIRepository.findActiveKPIsByManager(managerId);
    }

    // Bulk update actual metrics for all receptionists in a month
    public void updateAllActualMetricsForMonth(Integer month, Integer year) {
        List<ReceptionistKPI> allKPIs = receptionistKPIRepository.findByMonthAndYearOrderByReceptionistFullNameAsc(month, year);
        
        for (ReceptionistKPI kpi : allKPIs) {
            updateActualMetrics(kpi.getReceptionist().getUserId(), month, year);
        }
    }

    // Calculate overall performance score for a receptionist
    public Double calculateOverallPerformanceScore(Integer receptionistId, Integer month, Integer year) {
        List<ReceptionistKPI> kpis = getKPIsByReceptionistAndMonthAndYear(receptionistId, month, year);
        
        if (!kpis.isEmpty()) {
            return kpis.get(0).getOverallPerformanceScore();
        }
        
        return 0.0;
    }

    // Get KPI report data for export
    public List<Object[]> getKPIReportByMonth(Integer month, Integer year) {
        return receptionistKPIRepository.getKPIReportByMonthRaw(month, year);
    }
}
