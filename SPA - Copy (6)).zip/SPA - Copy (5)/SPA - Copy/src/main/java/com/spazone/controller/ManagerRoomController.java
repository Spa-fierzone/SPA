package com.spazone.controller;

import com.spazone.entity.Branch;
import com.spazone.entity.Room;
import com.spazone.entity.User;
import com.spazone.service.BranchService;
import com.spazone.service.RoomService;
import com.spazone.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/manager/rooms")
@PreAuthorize("hasRole('MANAGER')")
public class ManagerRoomController {

    @Autowired
    private RoomService roomService;

    @Autowired
    private BranchService branchService;

    @Autowired
    private UserService userService;

    /**
     * Get manager's branch
     */
    private Branch getManagerBranch(Authentication authentication) {
        User manager = userService.findByUsername(authentication.getName());
        return manager.getBranch();
    }

    /**
     * Validate if room belongs to manager's branch
     */
    private boolean isRoomInManagerBranch(Integer roomId, Branch managerBranch) {
        Room room = roomService.findById(roomId);
        return room != null && room.getBranch() != null && 
               room.getBranch().getBranchId().equals(managerBranch.getBranchId());
    }

    @GetMapping
    public String listRooms(Model model, Authentication authentication) {
        Branch managerBranch = getManagerBranch(authentication);
        if (managerBranch == null) {
            model.addAttribute("errorMessage", "Bạn chưa được assign vào branch nào.");
            return "manager/rooms";
        }

        List<Room> rooms = roomService.findByBranch(managerBranch);
        // Filter out any null rooms
        if (rooms != null) {
            rooms = rooms.stream().filter(room -> room != null).collect(Collectors.toList());
        } else {
            rooms = new java.util.ArrayList<>();
        }

        // Calculate room statistics
        long availableRooms = rooms.stream().filter(r -> "available".equals(r.getStatus())).count();
        long maintenanceRooms = rooms.stream().filter(r -> "maintenance".equals(r.getStatus())).count();
        long inUseRooms = rooms.stream().filter(r -> "in_use".equals(r.getStatus())).count();
        int totalRooms = rooms.size();

        model.addAttribute("rooms", rooms);
        model.addAttribute("branch", managerBranch);
        model.addAttribute("availableRooms", availableRooms);
        model.addAttribute("maintenanceRooms", maintenanceRooms);
        model.addAttribute("inUseRooms", inUseRooms);
        model.addAttribute("totalRooms", totalRooms);
        User manager = userService.findByUsername(authentication.getName());
        model.addAttribute("managerName", manager != null ? manager.getFullName() : "Unknown");
        return "manager/rooms";
    }

    @GetMapping("/create")
    public String showCreateForm(Model model, Authentication authentication) {
        Branch managerBranch = getManagerBranch(authentication);
        if (managerBranch == null) {
            model.addAttribute("errorMessage", "Bạn chưa được assign vào branch nào.");
            return "redirect:/manager/rooms";
        }

        Room room = new Room();
        room.setBranch(managerBranch);
        model.addAttribute("room", room);
        model.addAttribute("branch", managerBranch);
        return "manager/room-form";
    }

    @PostMapping("/create")
    public String createRoom(@ModelAttribute Room room, 
                           Authentication authentication,
                           RedirectAttributes redirectAttributes) {
        Branch managerBranch = getManagerBranch(authentication);
        if (managerBranch == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Bạn chưa được assign vào branch nào.");
            return "redirect:/manager/rooms";
        }

        // Ensure room belongs to manager's branch
        room.setBranch(managerBranch);
        
        // Set default status if not provided
        if (room.getStatus() == null || room.getStatus().isEmpty()) {
            room.setStatus("available");
        }

        // Validate capacity
        if (room.getCapacity() == null || room.getCapacity() <= 0) {
            redirectAttributes.addFlashAttribute("errorMessage", "Capacity phải lớn hơn 0.");
            return "redirect:/manager/rooms/create";
        }

        roomService.save(room);
        redirectAttributes.addFlashAttribute("successMessage", 
            "Tạo phòng '" + room.getName() + "' thành công!");
        return "redirect:/manager/rooms";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, 
                              Model model, 
                              Authentication authentication,
                              RedirectAttributes redirectAttributes) {
        Branch managerBranch = getManagerBranch(authentication);
        if (managerBranch == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Bạn chưa được assign vào branch nào.");
            return "redirect:/manager/rooms";
        }

        if (!isRoomInManagerBranch(id, managerBranch)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Bạn không có quyền chỉnh sửa phòng này.");
            return "redirect:/manager/rooms";
        }

        Room room = roomService.findById(id);
        model.addAttribute("room", room);
        model.addAttribute("branch", managerBranch);
        return "manager/room-form";
    }

    @PostMapping("/edit/{id}")
    public String updateRoom(@PathVariable Integer id, 
                           @ModelAttribute Room room,
                           Authentication authentication,
                           RedirectAttributes redirectAttributes) {
        Branch managerBranch = getManagerBranch(authentication);
        if (managerBranch == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Bạn chưa được assign vào branch nào.");
            return "redirect:/manager/rooms";
        }

        if (!isRoomInManagerBranch(id, managerBranch)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Bạn không có quyền chỉnh sửa phòng này.");
            return "redirect:/manager/rooms";
        }

        // Validate capacity
        if (room.getCapacity() == null || room.getCapacity() < 0) {
            redirectAttributes.addFlashAttribute("errorMessage", "Capacity không được âm.");
            return "redirect:/manager/rooms/edit/" + id;
        }

        room.setId(id);
        room.setBranch(managerBranch);
        roomService.save(room);
        redirectAttributes.addFlashAttribute("successMessage", 
            "Cập nhật phòng '" + room.getName() + "' thành công!");
        return "redirect:/manager/rooms";
    }

    @PostMapping("/delete/{id}")
    public String deleteRoom(@PathVariable Integer id, 
                           Authentication authentication,
                           RedirectAttributes redirectAttributes) {
        Branch managerBranch = getManagerBranch(authentication);
        if (managerBranch == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Bạn chưa được assign vào branch nào.");
            return "redirect:/manager/rooms";
        }

        if (!isRoomInManagerBranch(id, managerBranch)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Bạn không có quyền xóa phòng này.");
            return "redirect:/manager/rooms";
        }

        Room room = roomService.findById(id);
        String roomName = room != null ? room.getName() : "Unknown";
        
        roomService.deleteById(id);
        redirectAttributes.addFlashAttribute("successMessage", 
            "Xóa phòng '" + roomName + "' thành công!");
        return "redirect:/manager/rooms";
    }

    @GetMapping("/capacity-report")
    public String showCapacityReport(Model model, Authentication authentication) {
        Branch managerBranch = getManagerBranch(authentication);
        if (managerBranch == null) {
            model.addAttribute("errorMessage", "Bạn chưa được assign vào branch nào.");
            return "manager/rooms";
        }

        List<Room> rooms = roomService.findByBranch(managerBranch);
        // Filter out any null rooms
        if (rooms != null) {
            rooms = rooms.stream().filter(room -> room != null).collect(Collectors.toList());
        } else {
            rooms = new java.util.ArrayList<>();
        }

        // Calculate statistics with null safety
        int totalRooms = rooms.size();
        int totalCapacity = rooms.stream()
                .filter(r -> r != null && r.getCapacity() != null)
                .mapToInt(Room::getCapacity)
                .sum();
        long availableRooms = rooms.stream()
                .filter(r -> r != null && "available".equals(r.getStatus()))
                .count();
        long maintenanceRooms = rooms.stream()
                .filter(r -> r != null && "maintenance".equals(r.getStatus()))
                .count();

        model.addAttribute("rooms", rooms);
        model.addAttribute("branch", managerBranch);
        model.addAttribute("totalRooms", totalRooms);
        model.addAttribute("totalCapacity", totalCapacity);
        model.addAttribute("availableRooms", availableRooms);
        model.addAttribute("maintenanceRooms", maintenanceRooms);

        return "manager/room-capacity-report";
    }

    @PostMapping("/change-status/{id}")
    public String changeRoomStatus(@PathVariable Integer id,
                                 @RequestParam String status,
                                 Authentication authentication,
                                 RedirectAttributes redirectAttributes) {
        Branch managerBranch = getManagerBranch(authentication);
        if (managerBranch == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Bạn chưa được assign vào branch nào.");
            return "redirect:/manager/rooms";
        }

        if (!isRoomInManagerBranch(id, managerBranch)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Bạn không có quyền thay đổi status phòng này.");
            return "redirect:/manager/rooms";
        }

        Room room = roomService.findById(id);
        if (room != null) {
            room.setStatus(status);
            roomService.save(room);
            redirectAttributes.addFlashAttribute("successMessage", 
                "Thay đổi status phòng '" + room.getName() + "' thành '" + status + "' thành công!");
        }

        return "redirect:/manager/rooms";
    }
}
