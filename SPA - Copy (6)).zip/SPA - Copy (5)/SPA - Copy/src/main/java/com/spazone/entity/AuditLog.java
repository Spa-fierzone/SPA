package com.spazone.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "audit_logs")
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer logId;

    @Column(name = "entity_type", length = 50, nullable = false, columnDefinition = "NVARCHAR(50)")
    private String entityType; // APPOINTMENT, INVOICE, PAYMENT, etc.

    @Column(name = "entity_id", nullable = false)
    private Integer entityId;

    @Column(name = "action", length = 50, nullable = false, columnDefinition = "NVARCHAR(50)")
    private String action; // CREATE, UPDATE, DELETE, CANCEL, REFUND, etc.

    @Column(name = "performed_by", nullable = false)
    private Integer performedBy; // User ID

    @Column(name = "performed_by_role", length = 50, columnDefinition = "NVARCHAR(50)")
    private String performedByRole; // CUSTOMER, STAFF, MANAGER, ADMIN

    @Column(name = "old_values", length = 2000, columnDefinition = "NVARCHAR(2000)")
    private String oldValues; // JSON string of old values

    @Column(name = "new_values", length = 2000, columnDefinition = "NVARCHAR(2000)")
    private String newValues; // JSON string of new values

    @Column(name = "reason", length = 1000, columnDefinition = "NVARCHAR(1000)")
    private String reason;

    @Column(name = "ip_address", length = 45, columnDefinition = "NVARCHAR(45)")
    private String ipAddress;

    @Column(name = "user_agent", length = 500, columnDefinition = "NVARCHAR(500)")
    private String userAgent;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    // Constructors
    public AuditLog() {}

    public AuditLog(String entityType, Integer entityId, String action, Integer performedBy, String performedByRole) {
        this.entityType = entityType;
        this.entityId = entityId;
        this.action = action;
        this.performedBy = performedBy;
        this.performedByRole = performedByRole;
    }

    public AuditLog(String entityType, Integer entityId, String action, Integer performedBy, String performedByRole, String reason) {
        this(entityType, entityId, action, performedBy, performedByRole);
        this.reason = reason;
    }

    // Getters and Setters
    public Integer getLogId() {
        return logId;
    }

    public void setLogId(Integer logId) {
        this.logId = logId;
    }

    public String getEntityType() {
        return entityType;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public Integer getEntityId() {
        return entityId;
    }

    public void setEntityId(Integer entityId) {
        this.entityId = entityId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Integer getPerformedBy() {
        return performedBy;
    }

    public void setPerformedBy(Integer performedBy) {
        this.performedBy = performedBy;
    }

    public String getPerformedByRole() {
        return performedByRole;
    }

    public void setPerformedByRole(String performedByRole) {
        this.performedByRole = performedByRole;
    }

    public String getOldValues() {
        return oldValues;
    }

    public void setOldValues(String oldValues) {
        this.oldValues = oldValues;
    }

    public String getNewValues() {
        return newValues;
    }

    public void setNewValues(String newValues) {
        this.newValues = newValues;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
