package com.spazone.service;

import com.spazone.entity.AuditLog;

import java.time.LocalDateTime;
import java.util.List;

public interface AuditService {
    
    void logAction(String entityType, Integer entityId, String action, Integer performedBy, String performedByRole);
    
    void logAction(String entityType, Integer entityId, String action, Integer performedBy, String performedByRole, String reason);
    
    void logAction(String entityType, Integer entityId, String action, Integer performedBy, String performedByRole, 
                  String oldValues, String newValues, String reason);
    
    void logPaymentAction(Integer invoiceId, String action, Integer performedBy, String reason);
    
    void logAppointmentAction(Integer appointmentId, String action, Integer performedBy, String reason);
    
    void logCancellationAction(Integer appointmentId, Integer performedBy, String cancellationType, String reason);
    
    void logRefundAction(Integer invoiceId, Integer performedBy, String reason);
    
    List<AuditLog> getEntityAuditHistory(String entityType, Integer entityId);
    
    List<AuditLog> getUserActions(Integer userId, LocalDateTime startDate, LocalDateTime endDate);
    
    List<AuditLog> getActionsByType(String action);
    
    List<AuditLog> getAuditLogsByDateRange(LocalDateTime startDate, LocalDateTime endDate);
}
