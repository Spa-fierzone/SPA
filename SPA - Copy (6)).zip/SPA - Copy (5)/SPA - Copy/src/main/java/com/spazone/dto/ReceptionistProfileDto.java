package com.spazone.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class ReceptionistProfileDto {
    // Basic user information
    private Integer userId;
    private String username;
    private String email;
    private String fullName;
    private String phone;
    private LocalDate dateOfBirth;
    private String gender;
    private String address;
    private String profilePicture;
    private LocalDateTime createdAt;
    private LocalDateTime lastLogin;
    
    // Employee information
    private String status;
    private Integer branchId;
    private String branchName;
    private BigDecimal baseSalary;
    private LocalDateTime lastCheckIn;
    private LocalDateTime lastCheckOut;
    private BigDecimal totalWorkingHours;
    private BigDecimal performanceScore;
    
    // Receptionist-specific information
    private Integer totalCustomersHandled;
    private Integer appointmentsScheduled;
    private Integer appointmentsCancelled;
    private Integer appointmentsRescheduled;
    private Integer walkInCustomers;
    private Integer phoneCallsHandled;
    private Integer emailsResponded;
    
    // Performance metrics
    private BigDecimal customerSatisfactionRate;
    private BigDecimal responseTime; // Average response time in minutes
    private Integer complaintResolved;
    private Integer pendingComplaints;
    private BigDecimal appointmentAccuracyRate;
    private Integer noShowAppointments;
    
    // Daily operations
    private Integer todayAppointments;
    private Integer todayCheckIns;
    private Integer todayCheckOuts;
    private Integer pendingCheckIns;
    private Integer upcomingAppointments;
    private LocalDateTime nextAppointment;
    private String nextAppointmentCustomer;
    private String nextAppointmentService;
    
    // Customer service metrics
    private Integer newCustomerRegistrations;
    private Integer membershipSales;
    private BigDecimal totalSalesGenerated;
    private Integer referralsReceived;
    private Integer loyaltyPointsIssued;
    
    // Communication and coordination
    private Integer messagesReceived;
    private Integer messagesSent;
    private Integer meetingsAttended;
    private Integer trainingSessionsCompleted;
    
    // Schedule and availability
    private List<String> workingDays;
    private String preferredShift;
    private Integer overtimeHours;
    private Integer leavesTaken;
    private Integer remainingLeaves;
    
    // Constructors
    public ReceptionistProfileDto() {}
    
    // Getters and Setters
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getEmployeeId() {
        return userId != null ? String.format("NV%04d", userId) : "N/A";
    }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }
    
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getProfilePicture() { return profilePicture; }
    public void setProfilePicture(String profilePicture) { this.profilePicture = profilePicture; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getLastLogin() { return lastLogin; }
    public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Integer getBranchId() { return branchId; }
    public void setBranchId(Integer branchId) { this.branchId = branchId; }
    
    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }
    
    public BigDecimal getBaseSalary() { return baseSalary; }
    public void setBaseSalary(BigDecimal baseSalary) { this.baseSalary = baseSalary; }
    
    public LocalDateTime getLastCheckIn() { return lastCheckIn; }
    public void setLastCheckIn(LocalDateTime lastCheckIn) { this.lastCheckIn = lastCheckIn; }
    
    public LocalDateTime getLastCheckOut() { return lastCheckOut; }
    public void setLastCheckOut(LocalDateTime lastCheckOut) { this.lastCheckOut = lastCheckOut; }
    
    public BigDecimal getTotalWorkingHours() { return totalWorkingHours; }
    public void setTotalWorkingHours(BigDecimal totalWorkingHours) { this.totalWorkingHours = totalWorkingHours; }
    
    public BigDecimal getPerformanceScore() { return performanceScore; }
    public void setPerformanceScore(BigDecimal performanceScore) { this.performanceScore = performanceScore; }
    
    public Integer getTotalCustomersHandled() { return totalCustomersHandled; }
    public void setTotalCustomersHandled(Integer totalCustomersHandled) { this.totalCustomersHandled = totalCustomersHandled; }
    
    public Integer getAppointmentsScheduled() { return appointmentsScheduled; }
    public void setAppointmentsScheduled(Integer appointmentsScheduled) { this.appointmentsScheduled = appointmentsScheduled; }
    
    public Integer getAppointmentsCancelled() { return appointmentsCancelled; }
    public void setAppointmentsCancelled(Integer appointmentsCancelled) { this.appointmentsCancelled = appointmentsCancelled; }
    
    public Integer getAppointmentsRescheduled() { return appointmentsRescheduled; }
    public void setAppointmentsRescheduled(Integer appointmentsRescheduled) { this.appointmentsRescheduled = appointmentsRescheduled; }
    
    public Integer getWalkInCustomers() { return walkInCustomers; }
    public void setWalkInCustomers(Integer walkInCustomers) { this.walkInCustomers = walkInCustomers; }
    
    public Integer getPhoneCallsHandled() { return phoneCallsHandled; }
    public void setPhoneCallsHandled(Integer phoneCallsHandled) { this.phoneCallsHandled = phoneCallsHandled; }
    
    public Integer getEmailsResponded() { return emailsResponded; }
    public void setEmailsResponded(Integer emailsResponded) { this.emailsResponded = emailsResponded; }
    
    public BigDecimal getCustomerSatisfactionRate() { return customerSatisfactionRate; }
    public void setCustomerSatisfactionRate(BigDecimal customerSatisfactionRate) { this.customerSatisfactionRate = customerSatisfactionRate; }
    
    public BigDecimal getResponseTime() { return responseTime; }
    public void setResponseTime(BigDecimal responseTime) { this.responseTime = responseTime; }
    
    public Integer getComplaintResolved() { return complaintResolved; }
    public void setComplaintResolved(Integer complaintResolved) { this.complaintResolved = complaintResolved; }
    
    public Integer getPendingComplaints() { return pendingComplaints; }
    public void setPendingComplaints(Integer pendingComplaints) { this.pendingComplaints = pendingComplaints; }
    
    public BigDecimal getAppointmentAccuracyRate() { return appointmentAccuracyRate; }
    public void setAppointmentAccuracyRate(BigDecimal appointmentAccuracyRate) { this.appointmentAccuracyRate = appointmentAccuracyRate; }
    
    public Integer getNoShowAppointments() { return noShowAppointments; }
    public void setNoShowAppointments(Integer noShowAppointments) { this.noShowAppointments = noShowAppointments; }
    
    public Integer getTodayAppointments() { return todayAppointments; }
    public void setTodayAppointments(Integer todayAppointments) { this.todayAppointments = todayAppointments; }
    
    public Integer getTodayCheckIns() { return todayCheckIns; }
    public void setTodayCheckIns(Integer todayCheckIns) { this.todayCheckIns = todayCheckIns; }
    
    public Integer getTodayCheckOuts() { return todayCheckOuts; }
    public void setTodayCheckOuts(Integer todayCheckOuts) { this.todayCheckOuts = todayCheckOuts; }
    
    public Integer getPendingCheckIns() { return pendingCheckIns; }
    public void setPendingCheckIns(Integer pendingCheckIns) { this.pendingCheckIns = pendingCheckIns; }
    
    public Integer getUpcomingAppointments() { return upcomingAppointments; }
    public void setUpcomingAppointments(Integer upcomingAppointments) { this.upcomingAppointments = upcomingAppointments; }
    
    public LocalDateTime getNextAppointment() { return nextAppointment; }
    public void setNextAppointment(LocalDateTime nextAppointment) { this.nextAppointment = nextAppointment; }
    
    public String getNextAppointmentCustomer() { return nextAppointmentCustomer; }
    public void setNextAppointmentCustomer(String nextAppointmentCustomer) { this.nextAppointmentCustomer = nextAppointmentCustomer; }
    
    public String getNextAppointmentService() { return nextAppointmentService; }
    public void setNextAppointmentService(String nextAppointmentService) { this.nextAppointmentService = nextAppointmentService; }
    
    public Integer getNewCustomerRegistrations() { return newCustomerRegistrations; }
    public void setNewCustomerRegistrations(Integer newCustomerRegistrations) { this.newCustomerRegistrations = newCustomerRegistrations; }
    
    public Integer getMembershipSales() { return membershipSales; }
    public void setMembershipSales(Integer membershipSales) { this.membershipSales = membershipSales; }
    
    public BigDecimal getTotalSalesGenerated() { return totalSalesGenerated; }
    public void setTotalSalesGenerated(BigDecimal totalSalesGenerated) { this.totalSalesGenerated = totalSalesGenerated; }
    
    public Integer getReferralsReceived() { return referralsReceived; }
    public void setReferralsReceived(Integer referralsReceived) { this.referralsReceived = referralsReceived; }
    
    public Integer getLoyaltyPointsIssued() { return loyaltyPointsIssued; }
    public void setLoyaltyPointsIssued(Integer loyaltyPointsIssued) { this.loyaltyPointsIssued = loyaltyPointsIssued; }
    
    public Integer getMessagesReceived() { return messagesReceived; }
    public void setMessagesReceived(Integer messagesReceived) { this.messagesReceived = messagesReceived; }
    
    public Integer getMessagesSent() { return messagesSent; }
    public void setMessagesSent(Integer messagesSent) { this.messagesSent = messagesSent; }
    
    public Integer getMeetingsAttended() { return meetingsAttended; }
    public void setMeetingsAttended(Integer meetingsAttended) { this.meetingsAttended = meetingsAttended; }
    
    public Integer getTrainingSessionsCompleted() { return trainingSessionsCompleted; }
    public void setTrainingSessionsCompleted(Integer trainingSessionsCompleted) { this.trainingSessionsCompleted = trainingSessionsCompleted; }
    
    public List<String> getWorkingDays() { return workingDays; }
    public void setWorkingDays(List<String> workingDays) { this.workingDays = workingDays; }
    
    public String getPreferredShift() { return preferredShift; }
    public void setPreferredShift(String preferredShift) { this.preferredShift = preferredShift; }
    
    public Integer getOvertimeHours() { return overtimeHours; }
    public void setOvertimeHours(Integer overtimeHours) { this.overtimeHours = overtimeHours; }
    
    public Integer getLeavesTaken() { return leavesTaken; }
    public void setLeavesTaken(Integer leavesTaken) { this.leavesTaken = leavesTaken; }
    
    public Integer getRemainingLeaves() { return remainingLeaves; }
    public void setRemainingLeaves(Integer remainingLeaves) { this.remainingLeaves = remainingLeaves; }
}
