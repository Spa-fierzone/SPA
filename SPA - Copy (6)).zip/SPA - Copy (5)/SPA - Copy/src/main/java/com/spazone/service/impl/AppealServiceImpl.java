package com.spazone.service.impl;

import com.spazone.entity.AppealRequest;
import com.spazone.entity.CustomerViolation;
import com.spazone.entity.User;
import com.spazone.repository.AppealRequestRepository;
import com.spazone.repository.CustomerViolationRepository;
import com.spazone.repository.UserRepository;
import com.spazone.service.AppealService;
import com.spazone.service.AuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AppealServiceImpl implements AppealService {

    @Autowired
    private AppealRequestRepository appealRequestRepository;
    
    @Autowired
    private CustomerViolationRepository customerViolationRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private AuditService auditService;

    @Override
    @Transactional
    public AppealRequest submitAppeal(User customer, CustomerViolation violation, String appealType, String reason, String supportingDocuments) {
        try {
            // Check if customer already has a pending appeal of this type
            if (hasPendingAppeal(customer, appealType)) {
                throw new IllegalStateException("Bạn đã có một đơn khiếu nại đang chờ xử lý cho loại này.");
            }
            
            AppealRequest appeal = new AppealRequest(customer, violation, appealType, reason);
            appeal.setSupportingDocuments(supportingDocuments);
            appeal.setStatus("PENDING");
            
            AppealRequest savedAppeal = appealRequestRepository.save(appeal);
            
            // Log the appeal submission
            auditService.logAction("APPEAL", savedAppeal.getAppealId(), "SUBMIT", customer.getUserId(), "CUSTOMER", 
                "Appeal submitted: " + appealType + " - " + reason);
            
            return savedAppeal;
            
        } catch (Exception e) {
            throw new RuntimeException("Không thể gửi đơn khiếu nại: " + e.getMessage());
        }
    }

    @Override
    public AppealRequest submitBookingRestrictionAppeal(User customer, String reason, String supportingDocuments) {
        // Find the latest late cancellation violation for this customer
        List<CustomerViolation> violations = customerViolationRepository.findLateCancellationsByCustomer(customer);
        CustomerViolation latestViolation = violations.isEmpty() ? null : violations.get(0);
        
        return submitAppeal(customer, latestViolation, "BOOKING_RESTRICTION_REMOVAL", reason, supportingDocuments);
    }

    @Override
    public List<AppealRequest> getCustomerAppeals(User customer) {
        return appealRequestRepository.findByCustomer(customer);
    }

    @Override
    public List<AppealRequest> getPendingAppeals() {
        return appealRequestRepository.findPendingAppeals();
    }

    @Override
    public List<AppealRequest> getAppealsByStatus(String status) {
        return appealRequestRepository.findByStatus(status);
    }

    @Override
    @Transactional
    public AppealResult reviewAppeal(Integer appealId, Integer reviewerId, String decision, String reviewNotes, String resolution) {
        try {
            AppealRequest appeal = appealRequestRepository.findById(appealId).orElse(null);
            if (appeal == null) {
                return new AppealResult(false, "Không tìm thấy đơn khiếu nại.");
            }
            
            if (!"PENDING".equals(appeal.getStatus())) {
                return new AppealResult(false, "Đơn khiếu nại đã được xử lý trước đó.");
            }
            
            // Update appeal
            appeal.setStatus(decision); // APPROVED or REJECTED
            appeal.setReviewedBy(reviewerId);
            appeal.setReviewedDate(LocalDateTime.now());
            appeal.setReviewNotes(reviewNotes);
            appeal.setResolution(resolution);
            
            AppealRequest savedAppeal = appealRequestRepository.save(appeal);
            
            AppealResult result = new AppealResult(true, "Đơn khiếu nại đã được xử lý.", savedAppeal);
            
            // If approved and it's a booking restriction removal appeal
            if ("APPROVED".equals(decision) && "BOOKING_RESTRICTION_REMOVAL".equals(appeal.getAppealType())) {
                // Remove customer booking restriction
                User customer = appeal.getCustomer();
                customer.setBookingEnabled(true);
                userRepository.save(customer);
                result.setCustomerRestrictionRemoved(true);
                
                // Mark related violation as resolved
                if (appeal.getViolation() != null) {
                    CustomerViolation violation = appeal.getViolation();
                    violation.setResolved(true);
                    violation.setResolvedDate(LocalDateTime.now());
                    violation.setResolvedBy(reviewerId);
                    violation.setResolutionNotes("Appeal approved - booking restriction removed");
                    customerViolationRepository.save(violation);
                }
            }
            
            // Log the appeal review
            auditService.logAction("APPEAL", appealId, "REVIEW_" + decision, reviewerId, "STAFF", 
                "Appeal reviewed: " + decision + " - " + reviewNotes);
            
            return result;
            
        } catch (Exception e) {
            return new AppealResult(false, "Lỗi khi xử lý đơn khiếu nại: " + e.getMessage());
        }
    }

    @Override
    public boolean hasPendingAppeal(User customer, String appealType) {
        return appealRequestRepository.countPendingAppealsByCustomerAndType(customer, appealType) > 0;
    }

    @Override
    public AppealRequest getAppealById(Integer appealId) {
        return appealRequestRepository.findById(appealId).orElse(null);
    }

    @Override
    @Transactional
    public void updateAppealStatus(Integer appealId, String status) {
        AppealRequest appeal = appealRequestRepository.findById(appealId).orElse(null);
        if (appeal != null) {
            appeal.setStatus(status);
            appealRequestRepository.save(appeal);
        }
    }
}
