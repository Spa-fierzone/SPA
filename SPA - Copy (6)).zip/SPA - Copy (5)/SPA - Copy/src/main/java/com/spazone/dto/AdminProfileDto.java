package com.spazone.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class AdminProfileDto {
    // Basic user information
    private Integer userId;
    private String username;
    private String email;
    private String fullName;
    private String phone;
    private LocalDate dateOfBirth;
    private String gender;
    private String address;
    private String profilePicture;
    private LocalDateTime createdAt;
    private LocalDateTime lastLogin;
    
    // Admin-specific information
    private String status;
    private Boolean twoFactorEnabled;
    private Integer loginAttempts;
    private LocalDateTime lastPasswordChange;
    private List<String> permissions;
    private List<String> accessLevels;
    
    // System overview
    private Long totalUsers;
    private Long totalCustomers;
    private Long totalEmployees;
    private Long totalManagers;
    private Long totalTechnicians;
    private Long totalReceptionists;
    private Long totalBranches;
    private Long activeBranches;
    private Long totalServices;
    private Long activeServices;
    
    // Business metrics
    private BigDecimal totalRevenue;
    private BigDecimal monthlyRevenue;
    private BigDecimal yearlyRevenue;
    private BigDecimal averageOrderValue;
    private Integer totalAppointments;
    private Integer completedAppointments;
    private Integer cancelledAppointments;
    private BigDecimal appointmentCompletionRate;
    
    // Customer metrics
    private Integer newCustomersThisMonth;
    private Integer activeCustomers;
    private BigDecimal customerRetentionRate;
    private BigDecimal customerSatisfactionRate;
    private Integer totalMemberships;
    private Integer activeMemberships;
    
    // Employee metrics
    private BigDecimal averageEmployeePerformance;
    private Integer employeesOnLeave;
    private Integer pendingLeaveRequests;
    private BigDecimal totalPayroll;
    private BigDecimal averageSalary;
    
    // System health
    private Integer systemErrors;
    private Integer pendingIssues;
    private Integer resolvedIssues;
    private LocalDateTime lastSystemBackup;
    private Integer databaseSize;
    private Integer activeUserSessions;
    
    // Financial overview
    private BigDecimal operationalCosts;
    private BigDecimal marketingExpenses;
    private BigDecimal netProfit;
    private BigDecimal profitMargin;
    private List<String> topRevenueServices;
    private List<String> topPerformingBranches;
    
    // Quality and compliance
    private Integer totalServiceReviews;
    private BigDecimal averageServiceRating;
    private Integer complaintResolved;
    private Integer pendingComplaints;
    private Integer auditsPassed;
    private Integer complianceIssues;
    
    // Recent activities
    private List<String> recentUserRegistrations;
    private List<String> recentSystemChanges;
    private List<String> recentSecurityEvents;
    private Integer pendingApprovals;
    
    // Constructors
    public AdminProfileDto() {}
    
    // Getters and Setters
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }
    
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getProfilePicture() { return profilePicture; }
    public void setProfilePicture(String profilePicture) { this.profilePicture = profilePicture; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getLastLogin() { return lastLogin; }
    public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Boolean getTwoFactorEnabled() { return twoFactorEnabled; }
    public void setTwoFactorEnabled(Boolean twoFactorEnabled) { this.twoFactorEnabled = twoFactorEnabled; }
    
    public Integer getLoginAttempts() { return loginAttempts; }
    public void setLoginAttempts(Integer loginAttempts) { this.loginAttempts = loginAttempts; }
    
    public LocalDateTime getLastPasswordChange() { return lastPasswordChange; }
    public void setLastPasswordChange(LocalDateTime lastPasswordChange) { this.lastPasswordChange = lastPasswordChange; }
    
    public List<String> getPermissions() { return permissions; }
    public void setPermissions(List<String> permissions) { this.permissions = permissions; }
    
    public List<String> getAccessLevels() { return accessLevels; }
    public void setAccessLevels(List<String> accessLevels) { this.accessLevels = accessLevels; }
    
    public Long getTotalUsers() { return totalUsers; }
    public void setTotalUsers(Long totalUsers) { this.totalUsers = totalUsers; }

    public Long getTotalCustomers() { return totalCustomers; }
    public void setTotalCustomers(Long totalCustomers) { this.totalCustomers = totalCustomers; }

    public Long getTotalEmployees() { return totalEmployees; }
    public void setTotalEmployees(Long totalEmployees) { this.totalEmployees = totalEmployees; }

    public Long getTotalManagers() { return totalManagers; }
    public void setTotalManagers(Long totalManagers) { this.totalManagers = totalManagers; }

    public Long getTotalTechnicians() { return totalTechnicians; }
    public void setTotalTechnicians(Long totalTechnicians) { this.totalTechnicians = totalTechnicians; }

    public Long getTotalReceptionists() { return totalReceptionists; }
    public void setTotalReceptionists(Long totalReceptionists) { this.totalReceptionists = totalReceptionists; }

    public Long getTotalBranches() { return totalBranches; }
    public void setTotalBranches(Long totalBranches) { this.totalBranches = totalBranches; }

    public Long getActiveBranches() { return activeBranches; }
    public void setActiveBranches(Long activeBranches) { this.activeBranches = activeBranches; }

    public Long getTotalServices() { return totalServices; }
    public void setTotalServices(Long totalServices) { this.totalServices = totalServices; }

    public Long getActiveServices() { return activeServices; }
    public void setActiveServices(Long activeServices) { this.activeServices = activeServices; }
    
    public BigDecimal getTotalRevenue() { return totalRevenue; }
    public void setTotalRevenue(BigDecimal totalRevenue) { this.totalRevenue = totalRevenue; }
    
    public BigDecimal getMonthlyRevenue() { return monthlyRevenue; }
    public void setMonthlyRevenue(BigDecimal monthlyRevenue) { this.monthlyRevenue = monthlyRevenue; }
    
    public BigDecimal getYearlyRevenue() { return yearlyRevenue; }
    public void setYearlyRevenue(BigDecimal yearlyRevenue) { this.yearlyRevenue = yearlyRevenue; }
    
    public BigDecimal getAverageOrderValue() { return averageOrderValue; }
    public void setAverageOrderValue(BigDecimal averageOrderValue) { this.averageOrderValue = averageOrderValue; }
    
    public Integer getTotalAppointments() { return totalAppointments; }
    public void setTotalAppointments(Integer totalAppointments) { this.totalAppointments = totalAppointments; }
    
    public Integer getCompletedAppointments() { return completedAppointments; }
    public void setCompletedAppointments(Integer completedAppointments) { this.completedAppointments = completedAppointments; }
    
    public Integer getCancelledAppointments() { return cancelledAppointments; }
    public void setCancelledAppointments(Integer cancelledAppointments) { this.cancelledAppointments = cancelledAppointments; }
    
    public BigDecimal getAppointmentCompletionRate() { return appointmentCompletionRate; }
    public void setAppointmentCompletionRate(BigDecimal appointmentCompletionRate) { this.appointmentCompletionRate = appointmentCompletionRate; }
    
    public Integer getNewCustomersThisMonth() { return newCustomersThisMonth; }
    public void setNewCustomersThisMonth(Integer newCustomersThisMonth) { this.newCustomersThisMonth = newCustomersThisMonth; }
    
    public Integer getActiveCustomers() { return activeCustomers; }
    public void setActiveCustomers(Integer activeCustomers) { this.activeCustomers = activeCustomers; }
    
    public BigDecimal getCustomerRetentionRate() { return customerRetentionRate; }
    public void setCustomerRetentionRate(BigDecimal customerRetentionRate) { this.customerRetentionRate = customerRetentionRate; }
    
    public BigDecimal getCustomerSatisfactionRate() { return customerSatisfactionRate; }
    public void setCustomerSatisfactionRate(BigDecimal customerSatisfactionRate) { this.customerSatisfactionRate = customerSatisfactionRate; }
    
    public Integer getTotalMemberships() { return totalMemberships; }
    public void setTotalMemberships(Integer totalMemberships) { this.totalMemberships = totalMemberships; }
    
    public Integer getActiveMemberships() { return activeMemberships; }
    public void setActiveMemberships(Integer activeMemberships) { this.activeMemberships = activeMemberships; }
    
    public BigDecimal getAverageEmployeePerformance() { return averageEmployeePerformance; }
    public void setAverageEmployeePerformance(BigDecimal averageEmployeePerformance) { this.averageEmployeePerformance = averageEmployeePerformance; }
    
    public Integer getEmployeesOnLeave() { return employeesOnLeave; }
    public void setEmployeesOnLeave(Integer employeesOnLeave) { this.employeesOnLeave = employeesOnLeave; }
    
    public Integer getPendingLeaveRequests() { return pendingLeaveRequests; }
    public void setPendingLeaveRequests(Integer pendingLeaveRequests) { this.pendingLeaveRequests = pendingLeaveRequests; }
    
    public BigDecimal getTotalPayroll() { return totalPayroll; }
    public void setTotalPayroll(BigDecimal totalPayroll) { this.totalPayroll = totalPayroll; }
    
    public BigDecimal getAverageSalary() { return averageSalary; }
    public void setAverageSalary(BigDecimal averageSalary) { this.averageSalary = averageSalary; }
    
    public Integer getSystemErrors() { return systemErrors; }
    public void setSystemErrors(Integer systemErrors) { this.systemErrors = systemErrors; }
    
    public Integer getPendingIssues() { return pendingIssues; }
    public void setPendingIssues(Integer pendingIssues) { this.pendingIssues = pendingIssues; }
    
    public Integer getResolvedIssues() { return resolvedIssues; }
    public void setResolvedIssues(Integer resolvedIssues) { this.resolvedIssues = resolvedIssues; }
    
    public LocalDateTime getLastSystemBackup() { return lastSystemBackup; }
    public void setLastSystemBackup(LocalDateTime lastSystemBackup) { this.lastSystemBackup = lastSystemBackup; }
    
    public Integer getDatabaseSize() { return databaseSize; }
    public void setDatabaseSize(Integer databaseSize) { this.databaseSize = databaseSize; }
    
    public Integer getActiveUserSessions() { return activeUserSessions; }
    public void setActiveUserSessions(Integer activeUserSessions) { this.activeUserSessions = activeUserSessions; }
    
    public BigDecimal getOperationalCosts() { return operationalCosts; }
    public void setOperationalCosts(BigDecimal operationalCosts) { this.operationalCosts = operationalCosts; }
    
    public BigDecimal getMarketingExpenses() { return marketingExpenses; }
    public void setMarketingExpenses(BigDecimal marketingExpenses) { this.marketingExpenses = marketingExpenses; }
    
    public BigDecimal getNetProfit() { return netProfit; }
    public void setNetProfit(BigDecimal netProfit) { this.netProfit = netProfit; }
    
    public BigDecimal getProfitMargin() { return profitMargin; }
    public void setProfitMargin(BigDecimal profitMargin) { this.profitMargin = profitMargin; }
    
    public List<String> getTopRevenueServices() { return topRevenueServices; }
    public void setTopRevenueServices(List<String> topRevenueServices) { this.topRevenueServices = topRevenueServices; }
    
    public List<String> getTopPerformingBranches() { return topPerformingBranches; }
    public void setTopPerformingBranches(List<String> topPerformingBranches) { this.topPerformingBranches = topPerformingBranches; }
    
    public Integer getTotalServiceReviews() { return totalServiceReviews; }
    public void setTotalServiceReviews(Integer totalServiceReviews) { this.totalServiceReviews = totalServiceReviews; }
    
    public BigDecimal getAverageServiceRating() { return averageServiceRating; }
    public void setAverageServiceRating(BigDecimal averageServiceRating) { this.averageServiceRating = averageServiceRating; }
    
    public Integer getComplaintResolved() { return complaintResolved; }
    public void setComplaintResolved(Integer complaintResolved) { this.complaintResolved = complaintResolved; }
    
    public Integer getPendingComplaints() { return pendingComplaints; }
    public void setPendingComplaints(Integer pendingComplaints) { this.pendingComplaints = pendingComplaints; }
    
    public Integer getAuditsPassed() { return auditsPassed; }
    public void setAuditsPassed(Integer auditsPassed) { this.auditsPassed = auditsPassed; }
    
    public Integer getComplianceIssues() { return complianceIssues; }
    public void setComplianceIssues(Integer complianceIssues) { this.complianceIssues = complianceIssues; }
    
    public List<String> getRecentUserRegistrations() { return recentUserRegistrations; }
    public void setRecentUserRegistrations(List<String> recentUserRegistrations) { this.recentUserRegistrations = recentUserRegistrations; }
    
    public List<String> getRecentSystemChanges() { return recentSystemChanges; }
    public void setRecentSystemChanges(List<String> recentSystemChanges) { this.recentSystemChanges = recentSystemChanges; }
    
    public List<String> getRecentSecurityEvents() { return recentSecurityEvents; }
    public void setRecentSecurityEvents(List<String> recentSecurityEvents) { this.recentSecurityEvents = recentSecurityEvents; }
    
    public Integer getPendingApprovals() { return pendingApprovals; }
    public void setPendingApprovals(Integer pendingApprovals) { this.pendingApprovals = pendingApprovals; }
}
