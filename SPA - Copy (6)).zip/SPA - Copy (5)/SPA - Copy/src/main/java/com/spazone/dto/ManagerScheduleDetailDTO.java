package com.spazone.dto;

import com.spazone.entity.Appointment;
import com.spazone.entity.Service;
import com.spazone.entity.TreatmentRecord;
import com.spazone.entity.WorkSchedule;
import com.spazone.enums.ScheduleStatus;
import com.spazone.enums.ShiftType;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public class ManagerScheduleDetailDTO {
    
    // Work Schedule Information
    private Integer scheduleId;
    private Integer userId;
    private String userFullName;
    private String userRole;
    private Integer branchId;
    private String branchName;
    private LocalDate workDate;
    private LocalTime startTime;
    private LocalTime endTime;
    private ShiftType shiftType;
    private ScheduleStatus status;
    private String notes;
    
    // Treatment Order Information
    private List<AppointmentDetailDTO> appointments;
    private Integer totalAppointments;
    private Integer completedAppointments;
    private Integer pendingAppointments;
    
    // Service Statistics
    private List<ServiceUsageDTO> servicesUsed;
    private String mostPopularService;
    private Integer totalServicesProvided;
    
    // Constructors
    public ManagerScheduleDetailDTO() {}
    
    public ManagerScheduleDetailDTO(WorkSchedule schedule) {
        this.scheduleId = schedule.getScheduleId();
        this.userId = schedule.getUser().getUserId();
        this.userFullName = schedule.getUser().getFullName();
        this.userRole = schedule.getUser().getRoles().iterator().next().getRoleName();
        this.branchId = schedule.getBranch().getBranchId();
        this.branchName = schedule.getBranch().getName();
        this.workDate = schedule.getWorkDate();
        this.startTime = schedule.getStartTime();
        this.endTime = schedule.getEndTime();
        this.shiftType = schedule.getShiftType();
        this.status = schedule.getStatus();
        this.notes = schedule.getNotes();
    }
    
    // Inner class for appointment details
    public static class AppointmentDetailDTO {
        private Integer appointmentId;
        private String customerName;
        private String customerPhone;
        private String customerEmail;
        private String serviceName;
        private LocalDateTime appointmentDate;
        private LocalDateTime startTime;
        private LocalDateTime endTime;
        private String appointmentStatus;
        private String appointmentNotes;
        private TreatmentRecordDTO treatmentRecord;
        
        // Constructors
        public AppointmentDetailDTO() {}
        
        public AppointmentDetailDTO(Appointment appointment) {
            this.appointmentId = appointment.getAppointmentId();
            this.customerName = appointment.getCustomer().getFullName();
            this.customerPhone = appointment.getCustomer().getPhone();
            this.customerEmail = appointment.getCustomer().getEmail();
            // Handle multiple services
            List<Service> services = appointment.getServices();
            if (services.size() == 1) {
                this.serviceName = services.get(0).getName();
            } else if (services.size() > 1) {
                this.serviceName = services.size() + " dịch vụ";
            } else {
                this.serviceName = "Không có dịch vụ";
            }
            this.appointmentDate = appointment.getAppointmentDate();
            this.startTime = appointment.getStartTime();
            this.endTime = appointment.getEndTime();
            this.appointmentStatus = appointment.getStatus();
            this.appointmentNotes = appointment.getNotes();
        }
        
        // Getters and Setters
        public Integer getAppointmentId() { return appointmentId; }
        public void setAppointmentId(Integer appointmentId) { this.appointmentId = appointmentId; }
        
        public String getCustomerName() { return customerName; }
        public void setCustomerName(String customerName) { this.customerName = customerName; }
        
        public String getCustomerPhone() { return customerPhone; }
        public void setCustomerPhone(String customerPhone) { this.customerPhone = customerPhone; }
        
        public String getCustomerEmail() { return customerEmail; }
        public void setCustomerEmail(String customerEmail) { this.customerEmail = customerEmail; }
        
        public String getServiceName() { return serviceName; }
        public void setServiceName(String serviceName) { this.serviceName = serviceName; }
        
        public LocalDateTime getAppointmentDate() { return appointmentDate; }
        public void setAppointmentDate(LocalDateTime appointmentDate) { this.appointmentDate = appointmentDate; }
        
        public LocalDateTime getStartTime() { return startTime; }
        public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }
        
        public LocalDateTime getEndTime() { return endTime; }
        public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }
        
        public String getAppointmentStatus() { return appointmentStatus; }
        public void setAppointmentStatus(String appointmentStatus) { this.appointmentStatus = appointmentStatus; }
        
        public String getAppointmentNotes() { return appointmentNotes; }
        public void setAppointmentNotes(String appointmentNotes) { this.appointmentNotes = appointmentNotes; }
        
        public TreatmentRecordDTO getTreatmentRecord() { return treatmentRecord; }
        public void setTreatmentRecord(TreatmentRecordDTO treatmentRecord) { this.treatmentRecord = treatmentRecord; }
    }
    
    // Inner class for treatment record details
    public static class TreatmentRecordDTO {
        private Integer recordId;
        private String preTreatmentNotes;
        private String postTreatmentNotes;
        private String customerFeedback;
        private String followUpNotes;
        private Integer treatmentProgress;
        private LocalDateTime treatmentDate;
        private String beforeImageUrl;
        private String afterImageUrl;
        
        // Constructors
        public TreatmentRecordDTO() {}
        
        public TreatmentRecordDTO(TreatmentRecord record) {
            this.recordId = record.getRecordId();
            this.preTreatmentNotes = record.getPreTreatmentNotes();
            this.postTreatmentNotes = record.getPostTreatmentNotes();
            this.customerFeedback = record.getCustomerFeedback();
            this.followUpNotes = record.getFollowUpNotes();
            this.treatmentProgress = record.getTreatmentProgress();
            this.treatmentDate = record.getTreatmentDate();
            this.beforeImageUrl = record.getBeforeImageUrl();
            this.afterImageUrl = record.getAfterImageUrl();
        }
        
        // Getters and Setters
        public Integer getRecordId() { return recordId; }
        public void setRecordId(Integer recordId) { this.recordId = recordId; }
        
        public String getPreTreatmentNotes() { return preTreatmentNotes; }
        public void setPreTreatmentNotes(String preTreatmentNotes) { this.preTreatmentNotes = preTreatmentNotes; }
        
        public String getPostTreatmentNotes() { return postTreatmentNotes; }
        public void setPostTreatmentNotes(String postTreatmentNotes) { this.postTreatmentNotes = postTreatmentNotes; }
        
        public String getCustomerFeedback() { return customerFeedback; }
        public void setCustomerFeedback(String customerFeedback) { this.customerFeedback = customerFeedback; }
        
        public String getFollowUpNotes() { return followUpNotes; }
        public void setFollowUpNotes(String followUpNotes) { this.followUpNotes = followUpNotes; }
        
        public Integer getTreatmentProgress() { return treatmentProgress; }
        public void setTreatmentProgress(Integer treatmentProgress) { this.treatmentProgress = treatmentProgress; }
        
        public LocalDateTime getTreatmentDate() { return treatmentDate; }
        public void setTreatmentDate(LocalDateTime treatmentDate) { this.treatmentDate = treatmentDate; }
        
        public String getBeforeImageUrl() { return beforeImageUrl; }
        public void setBeforeImageUrl(String beforeImageUrl) { this.beforeImageUrl = beforeImageUrl; }
        
        public String getAfterImageUrl() { return afterImageUrl; }
        public void setAfterImageUrl(String afterImageUrl) { this.afterImageUrl = afterImageUrl; }
    }
    
    // Inner class for service usage statistics
    public static class ServiceUsageDTO {
        private String serviceName;
        private Integer usageCount;
        private String serviceCategory;
        
        public ServiceUsageDTO() {}
        
        public ServiceUsageDTO(String serviceName, Integer usageCount, String serviceCategory) {
            this.serviceName = serviceName;
            this.usageCount = usageCount;
            this.serviceCategory = serviceCategory;
        }
        
        // Getters and Setters
        public String getServiceName() { return serviceName; }
        public void setServiceName(String serviceName) { this.serviceName = serviceName; }
        
        public Integer getUsageCount() { return usageCount; }
        public void setUsageCount(Integer usageCount) { this.usageCount = usageCount; }
        
        public String getServiceCategory() { return serviceCategory; }
        public void setServiceCategory(String serviceCategory) { this.serviceCategory = serviceCategory; }
    }
    
    // Main class getters and setters
    public Integer getScheduleId() { return scheduleId; }
    public void setScheduleId(Integer scheduleId) { this.scheduleId = scheduleId; }
    
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }
    
    public String getUserFullName() { return userFullName; }
    public void setUserFullName(String userFullName) { this.userFullName = userFullName; }
    
    public String getUserRole() { return userRole; }
    public void setUserRole(String userRole) { this.userRole = userRole; }
    
    public Integer getBranchId() { return branchId; }
    public void setBranchId(Integer branchId) { this.branchId = branchId; }
    
    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }
    
    public LocalDate getWorkDate() { return workDate; }
    public void setWorkDate(LocalDate workDate) { this.workDate = workDate; }
    
    public LocalTime getStartTime() { return startTime; }
    public void setStartTime(LocalTime startTime) { this.startTime = startTime; }
    
    public LocalTime getEndTime() { return endTime; }
    public void setEndTime(LocalTime endTime) { this.endTime = endTime; }
    
    public ShiftType getShiftType() { return shiftType; }
    public void setShiftType(ShiftType shiftType) { this.shiftType = shiftType; }
    
    public ScheduleStatus getStatus() { return status; }
    public void setStatus(ScheduleStatus status) { this.status = status; }
    
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    
    public List<AppointmentDetailDTO> getAppointments() { return appointments; }
    public void setAppointments(List<AppointmentDetailDTO> appointments) { this.appointments = appointments; }
    
    public Integer getTotalAppointments() { return totalAppointments; }
    public void setTotalAppointments(Integer totalAppointments) { this.totalAppointments = totalAppointments; }
    
    public Integer getCompletedAppointments() { return completedAppointments; }
    public void setCompletedAppointments(Integer completedAppointments) { this.completedAppointments = completedAppointments; }
    
    public Integer getPendingAppointments() { return pendingAppointments; }
    public void setPendingAppointments(Integer pendingAppointments) { this.pendingAppointments = pendingAppointments; }
    
    public List<ServiceUsageDTO> getServicesUsed() { return servicesUsed; }
    public void setServicesUsed(List<ServiceUsageDTO> servicesUsed) { this.servicesUsed = servicesUsed; }
    
    public String getMostPopularService() { return mostPopularService; }
    public void setMostPopularService(String mostPopularService) { this.mostPopularService = mostPopularService; }
    
    public Integer getTotalServicesProvided() { return totalServicesProvided; }
    public void setTotalServicesProvided(Integer totalServicesProvided) { this.totalServicesProvided = totalServicesProvided; }
}
