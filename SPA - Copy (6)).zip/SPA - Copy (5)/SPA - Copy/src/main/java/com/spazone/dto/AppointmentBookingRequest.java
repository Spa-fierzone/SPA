package com.spazone.dto;

import java.util.List;

public class AppointmentBookingRequest {
    private List<Integer> serviceIds;
    private Integer branchId;
    private Integer technicianId;
    private String datePart;
    private String timePart;
    private Integer roomId;
    private String notes;

    public AppointmentBookingRequest() {
    }

    public AppointmentBookingRequest(List<Integer> serviceIds, Integer branchId, Integer technicianId, 
                                   String datePart, String timePart, Integer roomId, String notes) {
        this.serviceIds = serviceIds;
        this.branchId = branchId;
        this.technicianId = technicianId;
        this.datePart = datePart;
        this.timePart = timePart;
        this.roomId = roomId;
        this.notes = notes;
    }

    public List<Integer> getServiceIds() {
        return serviceIds;
    }

    public void setServiceIds(List<Integer> serviceIds) {
        this.serviceIds = serviceIds;
    }

    public Integer getBranchId() {
        return branchId;
    }

    public void setBranchId(Integer branchId) {
        this.branchId = branchId;
    }

    public Integer getTechnicianId() {
        return technicianId;
    }

    public void setTechnicianId(Integer technicianId) {
        this.technicianId = technicianId;
    }

    public String getDatePart() {
        return datePart;
    }

    public void setDatePart(String datePart) {
        this.datePart = datePart;
    }

    public String getTimePart() {
        return timePart;
    }

    public void setTimePart(String timePart) {
        this.timePart = timePart;
    }

    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
