package com.spazone.service.impl;

import com.spazone.entity.Notification;
import com.spazone.entity.User;
import com.spazone.repository.NotificationRepository;
import com.spazone.repository.UserRepository;
import com.spazone.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public Notification createNotification(User user, String title, String message, Notification.NotificationType type) {
        Notification notification = new Notification(user, title, message, type);
        return notificationRepository.save(notification);
    }

    @Override
    public Notification createNotification(User user, User sender, String title, String message, Notification.NotificationType type) {
        Notification notification = new Notification(user, sender, title, message, type);
        return notificationRepository.save(notification);
    }

    @Override
    public Notification createNotificationWithEntity(User user, User sender, String title, String message, 
                                                   Notification.NotificationType type, String entityType, Integer entityId) {
        Notification notification = new Notification(user, sender, title, message, type);
        notification.setRelatedEntityType(entityType);
        notification.setRelatedEntityId(entityId);
        return notificationRepository.save(notification);
    }

    @Override
    public Notification createNotificationWithAction(User user, User sender, String title, String message, 
                                                    Notification.NotificationType type, String actionUrl) {
        Notification notification = new Notification(user, sender, title, message, type);
        notification.setActionUrl(actionUrl);
        return notificationRepository.save(notification);
    }

    @Override
    public List<Notification> getNotificationsForUser(User user) {
        return notificationRepository.findByUserOrderByCreatedAtDesc(user);
    }

    @Override
    public Page<Notification> getNotificationsForUser(User user, Pageable pageable) {
        return notificationRepository.findByUserOrderByCreatedAtDesc(user, pageable);
    }

    @Override
    public List<Notification> getUnreadNotifications(User user) {
        return notificationRepository.findUnreadNotificationsByUser(user);
    }

    @Override
    public Long countUnreadNotifications(User user) {
        return notificationRepository.countUnreadNotificationsByUser(user);
    }

    @Override
    public void markAsRead(Integer notificationId) {
        notificationRepository.markAsRead(notificationId, LocalDateTime.now());
    }

    @Override
    public void markAllAsRead(User user) {
        notificationRepository.markAllAsReadForUser(user, LocalDateTime.now());
    }

    @Override
    public void deleteNotification(Integer notificationId) {
        notificationRepository.deleteById(notificationId);
    }

    @Override
    public Notification getNotificationById(Integer notificationId) {
        return notificationRepository.findById(notificationId)
                .orElseThrow(() -> new RuntimeException("Notification not found"));
    }

    @Override
    public void sendScheduleChangeNotification(User employee, User manager, String scheduleDetails) {
        String title = "Thay đổi lịch làm việc";
        String message = "Lịch làm việc của bạn đã được cập nhật: " + scheduleDetails;
        createNotificationWithAction(employee, manager, title, message, 
                Notification.NotificationType.SCHEDULE_CHANGE, "/schedules/my-schedule");
    }

    @Override
    public void sendAppointmentUpdateNotification(User customer, String appointmentDetails, String status) {
        String title = "Cập nhật lịch hẹn";
        String message = "Lịch hẹn của bạn đã được " + status + ": " + appointmentDetails;
        createNotificationWithAction(customer, null, title, message, 
                Notification.NotificationType.APPOINTMENT_UPDATE, "/customer/appointments");
    }

    @Override
    public void sendTreatmentRecordUpdateNotification(User customer, User technician, String treatmentDetails) {
        String title = "Cập nhật hồ sơ điều trị";
        String message = "Hồ sơ điều trị của bạn đã được cập nhật: " + treatmentDetails;
        createNotificationWithAction(customer, technician, title, message, 
                Notification.NotificationType.TREATMENT_RECORD_UPDATE, "/customer/treatment-history");
    }

    @Override
    public void sendUserRoleChangeNotification(User user, String oldRole, String newRole, User changedBy) {
        String title = "Thay đổi quyền hạn";
        String message = "Quyền hạn của bạn đã được thay đổi từ " + oldRole + " thành " + newRole;
        createNotification(user, changedBy, title, message, Notification.NotificationType.USER_ROLE_CHANGE);
    }

    @Override
    public void sendPasswordChangeNotification(User user) {
        String title = "Mật khẩu đã được thay đổi";
        String message = "Mật khẩu của bạn đã được thay đổi thành công. Nếu bạn không thực hiện thay đổi này, vui lòng liên hệ quản trị viên.";
        createNotification(user, null, title, message, Notification.NotificationType.PASSWORD_CHANGE);
    }

    @Override
    public void sendSystemAlert(List<User> users, String title, String message) {
        for (User user : users) {
            createNotification(user, null, title, message, Notification.NotificationType.SYSTEM_ALERT);
        }
    }

    @Override
    public void sendReminder(User user, String title, String message, LocalDateTime reminderTime) {
        Notification notification = createNotification(user, null, title, message, Notification.NotificationType.REMINDER);
        notification.setExpiresAt(reminderTime.plusDays(1)); // Reminder expires after 1 day
        notificationRepository.save(notification);
    }

    @Override
    public void sendApprovalRequest(User approver, User requester, String requestDetails, String actionUrl) {
        String title = "Yêu cầu phê duyệt";
        String message = requester.getFullName() + " đã gửi yêu cầu phê duyệt: " + requestDetails;
        createNotificationWithAction(approver, requester, title, message, 
                Notification.NotificationType.APPROVAL_REQUEST, actionUrl);
    }

    @Override
    public void cleanupOldNotifications(int daysToKeep) {
        LocalDateTime cutoffDate = LocalDateTime.now().minusDays(daysToKeep);
        notificationRepository.deleteOldNotifications(cutoffDate);
    }

    @Override
    public List<Notification> getRecentNotifications(User user, int days) {
        LocalDateTime since = LocalDateTime.now().minusDays(days);
        return notificationRepository.findRecentNotificationsByUser(user, since);
    }

    @Override
    public List<Notification> getNotificationsByType(User user, Notification.NotificationType type) {
        return notificationRepository.findByUserAndTypeOrderByCreatedAtDesc(user, type);
    }

    @Override
    public void broadcastNotification(List<User> users, String title, String message, Notification.NotificationType type) {
        for (User user : users) {
            createNotification(user, null, title, message, type);
        }
    }

    @Override
    public void sendToAllManagers(String title, String message, Notification.NotificationType type) {
        List<User> managers = userRepository.findUsersByRoleName("MANAGER");
        broadcastNotification(managers, title, message, type);
    }

    @Override
    public void sendToUsersWithRole(String roleName, String title, String message, Notification.NotificationType type) {
        List<User> users = userRepository.findUsersByRoleName(roleName);
        broadcastNotification(users, title, message, type);
    }

    @Override
    public void sendWelcomeNotification(User customer) {
        String title = "Chào mừng đến với SpaZone!";
        String message = "Chào mừng " + customer.getFullName() + " đến với SpaZone! " +
                "Cảm ơn bạn đã đăng ký tài khoản. Hãy khám phá các dịch vụ spa tuyệt vời của chúng tôi. " +
                "Bạn có thể đặt lịch hẹn, xem lịch sử điều trị và nhận thông báo quan trọng tại đây.";
        createNotificationWithAction(customer, null, title, message,
                Notification.NotificationType.GENERAL, "/services");
    }
}
