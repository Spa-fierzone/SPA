package com.spazone.service.impl;

import com.spazone.entity.Invoice;
import com.spazone.entity.User;
import com.spazone.exception.InvalidTokenException;
import com.spazone.exception.ResourceNotFoundException;
import com.spazone.service.EmailService;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.time.LocalDateTime;

@Service
public class EmailServiceImpl implements EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private TemplateEngine templateEngine;

    @Value("${app.base-url}")
    private String baseUrl;

    @Override
    public void sendVerificationEmail(String to, String otpCode) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            Context context = new Context();
            context.setVariable("otpCode", otpCode);

            String htmlContent = templateEngine.process("email/verification-email", context);

            helper.setTo(to);
            helper.setSubject("Your OTP Verification Code");
            helper.setText(htmlContent, true);

            mailSender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }



    @Override
    public void sendPasswordResetEmail(String to, String token) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            Context context = new Context();
            context.setVariable("resetUrl", baseUrl + "/auth/password-reset?token=" + token);

            String htmlContent = templateEngine.process("email/password-reset-email", context);

            helper.setTo(to);
            helper.setSubject("Password Reset Request");
            helper.setText(htmlContent, true);

            mailSender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void sendPasswordChangeConfirmation(String to) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject("Your password has been changed");
        message.setText("This is a confirmation that your password has been successfully changed. " +
                "If you did not perform this change, please contact support immediately.");

        mailSender.send(message);
    }

    @Override
    public void sendInvoiceEmail(Invoice invoice) {
        String to = invoice.getCustomer().getEmail();
        String subject = "Hóa đơn thanh toán SpaZone #" + invoice.getInvoiceNumber();
        // Get service names for email
        java.util.List<com.spazone.entity.Service> services = invoice.getAppointment().getServices();
        String serviceNames = services.isEmpty() ? "Không có dịch vụ" :
            services.stream().map(com.spazone.entity.Service::getName).collect(java.util.stream.Collectors.joining(", "));

        String body = "Chào " + invoice.getCustomer().getFullName() + ",\n\n"
                + "Cảm ơn bạn đã sử dụng dịch vụ. Dưới đây là thông tin hóa đơn:\n"
                + "Dịch vụ: " + serviceNames + "\n"
                + "Tổng cộng: " + invoice.getFinalAmount() + " VNĐ\n"
                + "Phương thức thanh toán: " + invoice.getPaymentMethod() + "Thanh Toán Tiền Mặt\n\n"
                + "Trân trọng,\nSpaZone";

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(body);
        mailSender.send(message);
    }

    @Override
    public void sendRefundConfirmationEmail(String to, Invoice invoice) {
        String subject = "Xác nhận hoàn tiền - SpaZone";

        String serviceNames = "Không có dịch vụ";
        if (invoice.getAppointment() != null && invoice.getAppointment().getServices() != null && !invoice.getAppointment().getServices().isEmpty()) {
            serviceNames = invoice.getAppointment().getServices().stream()
                    .map(service -> service.getName())
                    .reduce((s1, s2) -> s1 + ", " + s2)
                    .orElse("Không có dịch vụ");
        }

        String body = "Chào " + invoice.getCustomer().getFullName() + ",\n\n"
                + "Chúng tôi xác nhận đã xử lý hoàn tiền cho lịch hẹn đã hủy:\n"
                + "Mã hóa đơn: " + invoice.getInvoiceNumber() + "\n"
                + "Dịch vụ: " + serviceNames + "\n"
                + "Số tiền hoàn: " + invoice.getFinalAmount() + " VNĐ\n"
                + "Phương thức thanh toán: " + invoice.getPaymentMethod() + "\n\n"
                + "Số tiền sẽ được hoàn về tài khoản của bạn trong vòng 3-5 ngày làm việc.\n\n"
                + "Cảm ơn bạn đã sử dụng dịch vụ của chúng tôi.\n\n"
                + "Trân trọng,\nSpaZone";

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(body);
        mailSender.send(message);
    }

    @Override
    public void sendPaymentConfirmationEmail(String to, Invoice invoice) {
        String subject = "Xác nhận thanh toán thành công - SpaZone";

        String serviceNames = "Không có dịch vụ";
        if (invoice.getAppointment() != null && invoice.getAppointment().getServices() != null && !invoice.getAppointment().getServices().isEmpty()) {
            serviceNames = invoice.getAppointment().getServices().stream()
                    .map(service -> service.getName())
                    .reduce((s1, s2) -> s1 + ", " + s2)
                    .orElse("Không có dịch vụ");
        }

        String body = "Chào " + invoice.getCustomer().getFullName() + ",\n\n"
                + "Cảm ơn bạn đã thanh toán thành công!\n\n"
                + "Thông tin thanh toán:\n"
                + "Mã hóa đơn: " + invoice.getInvoiceNumber() + "\n"
                + "Dịch vụ: " + serviceNames + "\n"
                + "Số tiền: " + invoice.getFinalAmount() + " VNĐ\n"
                + "Phương thức: " + invoice.getPaymentMethod() + "\n"
                + "Thời gian: " + invoice.getPaymentDate() + "\n\n"
                + "Lịch hẹn của bạn đã được xác nhận. Vui lòng đến đúng giờ hẹn.\n\n"
                + "Trân trọng,\nSpaZone";

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(body);
        mailSender.send(message);
    }
}
