package com.spazone.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when manager image upload validation fails
 */
@ResponseStatus(HttpStatus.BAD_REQUEST)
public class ManagerImageUploadException extends RuntimeException {
    
    public ManagerImageUploadException(String message) {
        super(message);
    }
    
    public ManagerImageUploadException(String message, Throwable cause) {
        super(message, cause);
    }
}
