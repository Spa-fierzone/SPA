package com.spazone.service;

import com.spazone.entity.Service;
import com.spazone.entity.ServiceRating;
import com.spazone.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@org.springframework.stereotype.Service
public class ManagerServiceAnalyticsService {
    
    @Autowired
    private ServiceRepository serviceRepository;
    
    // Using existing ServiceRating instead of ServiceReview
    
    @Autowired
    private ServiceRatingRepository serviceRatingRepository;
    
    @Autowired
    private AppointmentRepository appointmentRepository;
    
    @Autowired
    private InvoiceRepository invoiceRepository;
    
    @Autowired
    private ServiceStatisticsService serviceStatisticsService;

    @Autowired
    private ServiceRatingService serviceRatingService;
    
    /**
     * Get comprehensive service dashboard data for managers
     */
    public Map<String, Object> getServiceDashboardData(LocalDate startDate, LocalDate endDate) {
        Map<String, Object> dashboardData = new HashMap<>();
        
        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.atTime(23, 59, 59);
        
        // Basic service statistics
        List<Service> allServices = serviceRepository.findByStatusOrderByCreatedAtDesc("active");
        dashboardData.put("totalServices", allServices.size());
        
        // Service usage statistics
        Map<String, Object> serviceStats = serviceStatisticsService.getServiceStatisticsSummary(startDate, endDate);
        dashboardData.put("serviceStatistics", serviceStats);
        
        // Revenue by service
        List<Map<String, Object>> serviceRevenue = getServiceRevenueData(startDateTime, endDateTime);
        dashboardData.put("serviceRevenue", serviceRevenue);
        
        // Review analytics
        Map<String, Object> reviewAnalytics = getReviewAnalytics(startDateTime, endDateTime);
        dashboardData.put("reviewAnalytics", reviewAnalytics);
        
        // Top performing services
        List<Map<String, Object>> topServices = getTopPerformingServices(10);
        dashboardData.put("topServices", topServices);
        
        // Services needing attention (low ratings)
        List<Map<String, Object>> lowRatedServices = getLowRatedServices(5);
        dashboardData.put("lowRatedServices", lowRatedServices);
        
        return dashboardData;
    }
    
    /**
     * Get detailed service performance metrics
     */
    public Map<String, Object> getServicePerformanceMetrics(Integer serviceId, LocalDate startDate, LocalDate endDate) {
        Service service = serviceRepository.findById(serviceId)
                .orElseThrow(() -> new RuntimeException("Service not found"));
        
        Map<String, Object> metrics = new HashMap<>();
        
        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.atTime(23, 59, 59);
        
        // Basic service info
        metrics.put("service", service);
        
        // Appointment statistics
        Long appointmentCount = appointmentRepository.countByServiceAndAppointmentDateBetween(
                service, startDateTime, endDateTime);
        metrics.put("appointmentCount", appointmentCount);
        
        // Revenue statistics
        BigDecimal revenue = invoiceRepository.getRevenueByServiceAndDateRange(
                service.getServiceId(), startDateTime, endDateTime);
        metrics.put("revenue", revenue != null ? revenue : BigDecimal.ZERO);
        
        // Review statistics
        Map<String, Object> reviewStats = getServiceReviewStatistics(service, startDateTime, endDateTime);
        metrics.put("reviewStatistics", reviewStats);
        
        // Technician performance for this service
        List<Map<String, Object>> technicianPerformance = getTechnicianPerformanceByService(service, startDate, endDate);
        metrics.put("technicianPerformance", technicianPerformance);
        
        return metrics;
    }
    
    /**
     * Get service revenue data
     */
    private List<Map<String, Object>> getServiceRevenueData(LocalDateTime startDate, LocalDateTime endDate) {
        try {
            return invoiceRepository.getRevenueByService(startDate, endDate);
        } catch (Exception e) {
            // Fallback implementation
            return new ArrayList<>();
        }
    }
    
    /**
     * Get review analytics for the date range using ServiceRating
     */
    private Map<String, Object> getReviewAnalytics(LocalDateTime startDate, LocalDateTime endDate) {
        Map<String, Object> analytics = new HashMap<>();

        try {
            // Get all ratings within date range
            List<ServiceRating> ratings = serviceRatingRepository.findAll().stream()
                    .filter(rating -> rating.getCreatedAt().isAfter(startDate) && rating.getCreatedAt().isBefore(endDate))
                    .collect(Collectors.toList());

            analytics.put("totalReviews", ratings.size());

            if (!ratings.isEmpty()) {
                double avgRating = ratings.stream()
                        .mapToInt(ServiceRating::getRating)
                        .average()
                        .orElse(0.0);
                analytics.put("averageRating", Math.round(avgRating * 100.0) / 100.0);

                // Rating distribution
                Map<Integer, Long> ratingDist = ratings.stream()
                        .collect(Collectors.groupingBy(ServiceRating::getRating, Collectors.counting()));
                analytics.put("ratingDistribution", ratingDist);
            } else {
                analytics.put("averageRating", 0.0);
                analytics.put("ratingDistribution", new HashMap<>());
            }
        } catch (Exception e) {
            // Fallback to empty analytics
            analytics.put("totalReviews", 0);
            analytics.put("averageRating", 0.0);
            analytics.put("ratingDistribution", new HashMap<>());
        }

        return analytics;
    }
    
    /**
     * Get top performing services based on ratings and usage
     */
    private List<Map<String, Object>> getTopPerformingServices(int limit) {
        List<Service> services = serviceRepository.findByStatusOrderByCreatedAtDesc("active");

        return services.stream()
                .map(service -> {
                    Map<String, Object> serviceData = new HashMap<>();
                    serviceData.put("service", service);

                    // Get ratings for this service
                    List<ServiceRating> serviceRatings = serviceRatingService.getRatingsByService(service);

                    // Calculate average rating
                    double avgRating = serviceRatings.stream()
                            .mapToInt(ServiceRating::getRating)
                            .average()
                            .orElse(0.0);
                    serviceData.put("averageRating", Math.round(avgRating * 100.0) / 100.0);

                    // Get review count
                    Long reviewCount = (long) serviceRatings.size();
                    serviceData.put("reviewCount", reviewCount);

                    // Calculate performance score (rating * log(reviews + 1))
                    double performanceScore = avgRating * Math.log(reviewCount + 1);
                    serviceData.put("performanceScore", performanceScore);

                    return serviceData;
                })
                .sorted((a, b) -> Double.compare((Double) b.get("performanceScore"), (Double) a.get("performanceScore")))
                .limit(limit)
                .collect(Collectors.toList());
    }
    
    /**
     * Get services with low ratings that need attention
     */
    private List<Map<String, Object>> getLowRatedServices(int limit) {
        List<Service> services = serviceRepository.findByStatusOrderByCreatedAtDesc("active");

        return services.stream()
                .map(service -> {
                    Map<String, Object> serviceData = new HashMap<>();
                    serviceData.put("service", service);

                    // Get ratings for this service
                    List<ServiceRating> serviceRatings = serviceRatingService.getRatingsByService(service);

                    // Calculate average rating
                    double avgRating = serviceRatings.stream()
                            .mapToInt(ServiceRating::getRating)
                            .average()
                            .orElse(0.0);
                    serviceData.put("averageRating", Math.round(avgRating * 100.0) / 100.0);

                    Long reviewCount = (long) serviceRatings.size();
                    serviceData.put("reviewCount", reviewCount);

                    return serviceData;
                })
                .filter(data -> (Double) data.get("averageRating") > 0 && (Double) data.get("averageRating") < 3.5)
                .sorted((a, b) -> Double.compare((Double) a.get("averageRating"), (Double) b.get("averageRating")))
                .limit(limit)
                .collect(Collectors.toList());
    }
    
    /**
     * Get service review statistics using ServiceRating
     */
    private Map<String, Object> getServiceReviewStatistics(Service service, LocalDateTime startDate, LocalDateTime endDate) {
        Map<String, Object> stats = new HashMap<>();

        try {
            // Get all ratings for this service within date range
            List<ServiceRating> ratings = serviceRatingService.getRatingsByService(service).stream()
                    .filter(rating -> rating.getCreatedAt().isAfter(startDate) && rating.getCreatedAt().isBefore(endDate))
                    .collect(Collectors.toList());

            stats.put("totalReviews", ratings.size());

            if (!ratings.isEmpty()) {
                double avgRating = ratings.stream()
                        .mapToInt(ServiceRating::getRating)
                        .average()
                        .orElse(0.0);
                stats.put("averageRating", Math.round(avgRating * 100.0) / 100.0);

                Map<Integer, Long> ratingDist = ratings.stream()
                        .collect(Collectors.groupingBy(ServiceRating::getRating, Collectors.counting()));
                stats.put("ratingDistribution", ratingDist);
            } else {
                stats.put("averageRating", 0.0);
                stats.put("ratingDistribution", new HashMap<>());
            }
        } catch (Exception e) {
            stats.put("totalReviews", 0);
            stats.put("averageRating", 0.0);
            stats.put("ratingDistribution", new HashMap<>());
        }

        return stats;
    }
    
    /**
     * Get technician performance by service
     */
    private List<Map<String, Object>> getTechnicianPerformanceByService(Service service, LocalDate startDate, LocalDate endDate) {
        // This would require more complex queries - simplified implementation
        return new ArrayList<>();
    }
}
