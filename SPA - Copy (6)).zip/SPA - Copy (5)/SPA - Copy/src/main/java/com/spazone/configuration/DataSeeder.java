package com.spazone.configuration;

import com.spazone.entity.Branch;
import com.spazone.entity.Role;
import com.spazone.entity.User;
import com.spazone.enums.Gender;
import com.spazone.repository.BranchRepository;
import com.spazone.repository.RoleRepository;
import com.spazone.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;

@Configuration
public class DataSeeder {

    @Bean
    public CommandLineRunner seedUsers(UserRepository userRepo, RoleRepository roleRepo, BranchRepository branchRepo, PasswordEncoder passwordEncoder) {
        return args -> {

            // Array of branches for easy assignment
            // Seed ADMIN role
            Role adminRole = roleRepo.findByRoleName("ADMIN")
                    .orElseGet(() -> {
                        Role newRole = new Role();
                        newRole.setRoleName("ADMIN");
                        newRole.setDescription("System Administrator Role");
                        return roleRepo.save(newRole);
                    });

            // Create 1 Admin user (assign to branch1)
            String adminUsername = "admin";
            String adminEmail = "admin@spazone.com";
            if (userRepo.findByUsername(adminUsername).isEmpty() && userRepo.findByEmail(adminEmail).isEmpty()) {
                User admin = new User();
                admin.setUsername(adminUsername);
                admin.setPassword(passwordEncoder.encode("admin123"));
                admin.setEmail(adminEmail);
                admin.setFullName("System Administrator");
                admin.setPhone("0901000001");
                admin.setGender(Gender.MALE);
                admin.setDateOfBirth(LocalDate.of(1985, 1, 1));
                admin.setAddress("Địa chỉ Admin");
                admin.setStatus("active");
                admin.setEnabled(true);
                admin.setBookingEnabled(true);
                admin.setRoles(Collections.singleton(adminRole));
                userRepo.save(admin);
            }

            // Seed RECEPTIONIST role
            Role receptionistRole = roleRepo.findByRoleName("RECEPTIONIST")
                    .orElseGet(() -> {
                        Role newRole = new Role();
                        newRole.setRoleName("RECEPTIONIST");
                        newRole.setDescription("Front Desk Receptionist Role");
                        return roleRepo.save(newRole);
                    });

            // Create 3 Receptionist users (distribute across branches)
            for (int i = 1; i <= 3; i++) {
                String username = "receptionist" + i;
                String email = username + "@spazone.com";
                if (userRepo.findByUsername(username).isEmpty() && userRepo.findByEmail(email).isEmpty()) {
                    User receptionist = new User();
                    receptionist.setUsername(username);
                    receptionist.setPassword(passwordEncoder.encode("reception123"));
                    receptionist.setEmail(email);
                    receptionist.setFullName("Receptionist " + i);
                    receptionist.setPhone("090300000" + i);
                    receptionist.setGender(i % 2 == 0 ? Gender.MALE : Gender.FEMALE);
                    receptionist.setDateOfBirth(LocalDate.of(1995, 3, i));
                    receptionist.setAddress("Địa chỉ lễ tân số " + i);
                    receptionist.setStatus("active");
                    receptionist.setEnabled(true);
                    receptionist.setBookingEnabled(true);
                    receptionist.setRoles(Collections.singleton(receptionistRole));
                    userRepo.save(receptionist);
                }
            }

            // Seed MANAGER role
            Role managerRole = roleRepo.findByRoleName("MANAGER")
                    .orElseGet(() -> {
                        Role newRole = new Role();
                        newRole.setRoleName("MANAGER");
                        newRole.setDescription("Branch Manager Role");
                        return roleRepo.save(newRole);
                    });

            for (int i = 1; i <= 5; i++) {
                String username = "manager" + i;
                String email = username + "@spa.com";
                if (userRepo.findByUsername(username).isEmpty() && userRepo.findByEmail(email).isEmpty()) {
                    User user = new User();
                    user.setUsername(username);
                    user.setPassword(passwordEncoder.encode("password"));
                    user.setEmail(email);
                    user.setFullName("Manager " + i);
                    user.setPhone("090100000" + i);
                    user.setGender(Gender.MALE);
                    user.setDateOfBirth(LocalDate.of(1990, 1, i));
                    user.setAddress("Địa chỉ số " + i);
                    user.setStatus("active");
                    user.setEnabled(true);
                    user.setBookingEnabled(true);
                    user.setRoles(Collections.singleton(managerRole));
                    userRepo.save(user);
                }
            }

            // Seed TECHNICIAN role
            Role technicianRole = roleRepo.findByRoleName("TECHNICIAN")
                    .orElseGet(() -> {
                        Role newRole = new Role();
                        newRole.setRoleName("TECHNICIAN");
                        newRole.setDescription("Technician Role");
                        return roleRepo.save(newRole);
                    });

            for (int i = 1; i <= 5; i++) {
                String username = "tech" + i;
                String email = username + "@spa.com";
                if (userRepo.findByUsername(username).isEmpty() && userRepo.findByEmail(email).isEmpty()) {
                    User user = new User();
                    user.setUsername(username);
                    user.setPassword(passwordEncoder.encode("password"));
                    user.setEmail(email);
                    user.setFullName("Technician " + i);
                    user.setPhone("090200000" + i);
                    user.setGender(Gender.FEMALE);
                    user.setDateOfBirth(LocalDate.of(1992, 2, i));
                    user.setAddress("Kỹ thuật viên số " + i);
                    user.setStatus("active");
                    user.setEnabled(true);
                    user.setBookingEnabled(true);
                    user.setRoles(Collections.singleton(technicianRole));
                    userRepo.save(user);
                }
            }

            // Seed CUSTOMER role
            roleRepo.findByRoleName("CUSTOMER")
                    .orElseGet(() -> {
                        Role newRole = new Role();
                        newRole.setRoleName("CUSTOMER");
                        newRole.setDescription("Customer Role");
                        return roleRepo.save(newRole);
                    });

            System.out.println("Data seeding completed successfully!");
            System.out.println("Created roles: ADMIN, RECEPTIONIST, MANAGER, TECHNICIAN, CUSTOMER");
            System.out.println("Created users: 1 Admin, 3 Receptionists, 5 Managers, 5 Technicians");
        };
    }

}
