package com.spazone.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * ChatRoom entity representing chat rooms in the system
 * Supports different room types: DIRECT, GROUP, BRANCH, SYSTEM
 * Integrates with existing User and Branch entities
 */
@Entity
@Table(name = "chat_rooms")
public class ChatRoom {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "room_id")
    private Integer roomId;

    @Column(name = "room_name", nullable = false, length = 100, columnDefinition = "NVARCHAR(100)")
    private String roomName;

    @Column(name = "room_type", nullable = false, length = 20, columnDefinition = "NVARCHAR(20)")
    private String roomType; // DIRECT, GROUP, BRANCH, SYSTEM

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "branch_id")
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private Branch branch;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by", nullable = false)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private User createdBy;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @Column(name = "is_active")
    private Boolean isActive = true;

    @Column(name = "room_description", length = 500, columnDefinition = "NVARCHAR(500)")
    private String roomDescription;

    @Column(name = "max_participants")
    private Integer maxParticipants = 50;

    // One-to-Many relationship with ChatParticipant
    @OneToMany(mappedBy = "chatRoom", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnoreProperties("chatRoom")
    private List<ChatParticipant> participants = new ArrayList<>();

    // One-to-Many relationship with ChatMessage
    @OneToMany(mappedBy = "chatRoom", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnoreProperties("chatRoom")
    private List<ChatMessage> messages = new ArrayList<>();

    // Constructors
    public ChatRoom() {
    }

    public ChatRoom(String roomName, String roomType, User createdBy) {
        this.roomName = roomName;
        this.roomType = roomType;
        this.createdBy = createdBy;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public ChatRoom(String roomName, String roomType, User createdBy, Branch branch) {
        this(roomName, roomType, createdBy);
        this.branch = branch;
    }

    // Lifecycle methods
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        if (updatedAt == null) {
            updatedAt = LocalDateTime.now();
        }
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Helper methods
    public boolean isDirectMessage() {
        return "DIRECT".equals(roomType);
    }

    public boolean isBranchRoom() {
        return "BRANCH".equals(roomType);
    }

    public boolean isGroupRoom() {
        return "GROUP".equals(roomType);
    }

    public boolean isSystemRoom() {
        return "SYSTEM".equals(roomType);
    }

    public int getParticipantCount() {
        return participants != null ? (int) participants.stream()
                .filter(p -> p.getIsActive())
                .count() : 0;
    }

    public boolean isFull() {
        return getParticipantCount() >= maxParticipants;
    }

    // Getters and Setters
    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public String getRoomName() {
        return roomName;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public Branch getBranch() {
        return branch;
    }

    public void setBranch(Branch branch) {
        this.branch = branch;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public String getRoomDescription() {
        return roomDescription;
    }

    public void setRoomDescription(String roomDescription) {
        this.roomDescription = roomDescription;
    }

    public Integer getMaxParticipants() {
        return maxParticipants;
    }

    public void setMaxParticipants(Integer maxParticipants) {
        this.maxParticipants = maxParticipants;
    }

    public List<ChatParticipant> getParticipants() {
        return participants;
    }

    public void setParticipants(List<ChatParticipant> participants) {
        this.participants = participants;
    }

    public List<ChatMessage> getMessages() {
        return messages;
    }

    public void setMessages(List<ChatMessage> messages) {
        this.messages = messages;
    }

    @Override
    public String toString() {
        return "ChatRoom{" +
                "roomId=" + roomId +
                ", roomName='" + roomName + '\'' +
                ", roomType='" + roomType + '\'' +
                ", isActive=" + isActive +
                '}';
    }
}
