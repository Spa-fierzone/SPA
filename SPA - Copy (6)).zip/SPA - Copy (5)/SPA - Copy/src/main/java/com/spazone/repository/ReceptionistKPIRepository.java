package com.spazone.repository;

import com.spazone.entity.ReceptionistKPI;
import com.spazone.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ReceptionistKPIRepository extends JpaRepository<ReceptionistKPI, Integer> {

    // Find KPI by receptionist, month and year
    Optional<ReceptionistKPI> findByReceptionistAndMonthAndYear(User receptionist, Integer month, Integer year);

    // Find all KPIs for a receptionist
    List<ReceptionistKPI> findByReceptionistOrderByYearDescMonthDesc(User receptionist);

    // Find KPIs by manager
    List<ReceptionistKPI> findByManagerOrderByYearDescMonthDesc(User manager);

    // Find KPIs by month/year
    List<ReceptionistKPI> findByMonthAndYearOrderByReceptionistFullNameAsc(Integer month, Integer year);

    // Find active KPIs
    List<ReceptionistKPI> findByStatusOrderByYearDescMonthDesc(String status);

    // Find KPIs by receptionist and status
    List<ReceptionistKPI> findByReceptionistAndStatusOrderByYearDescMonthDesc(User receptionist, String status);

    // Query to get active KPIs by receptionist
    @Query("SELECT k FROM ReceptionistKPI k WHERE k.receptionist.userId = :receptionistId AND k.status = 'active' ORDER BY k.year DESC, k.month DESC")
    List<ReceptionistKPI> findActiveKPIsByReceptionist(@Param("receptionistId") Integer receptionistId);

    // Query to check if KPI exists
    @Query("SELECT CASE WHEN COUNT(k) > 0 THEN true ELSE false END FROM ReceptionistKPI k WHERE k.receptionist.userId = :receptionistId AND k.month = :month AND k.year = :year")
    boolean existsByReceptionistAndMonthAndYear(@Param("receptionistId") Integer receptionistId, @Param("month") Integer month, @Param("year") Integer year);

    // Query to get KPIs by manager and month/year
    @Query("SELECT k FROM ReceptionistKPI k WHERE k.manager.userId = :managerId AND k.month = :month AND k.year = :year ORDER BY k.receptionist.fullName")
    List<ReceptionistKPI> findByManagerAndMonthAndYear(@Param("managerId") Integer managerId, @Param("month") Integer month, @Param("year") Integer year);

    // Methods for Report Service
    @Query("SELECT r.fullName as receptionistName, k.targetAppointments as targetAppt, k.actualAppointments as actualAppt, " +
           "k.targetInvoices as targetInv, k.actualInvoices as actualInv, k.targetRevenue as targetRev, " +
           "k.actualRevenue as actualRev, k.status as status FROM ReceptionistKPI k JOIN k.receptionist r " +
           "WHERE k.month = :month AND k.year = :year ORDER BY r.fullName")
    List<Object[]> getKPIReportByMonthRaw(@Param("month") Integer month, @Param("year") Integer year);

    // Query to get KPI summary for dashboard
    @Query("SELECT COUNT(k), " +
           "COALESCE(SUM(CASE WHEN k.actualAppointments >= k.targetAppointments THEN 1 ELSE 0 END), 0), " +
           "COALESCE(SUM(CASE WHEN k.actualInvoices >= k.targetInvoices THEN 1 ELSE 0 END), 0), " +
           "COALESCE(AVG(CASE WHEN k.targetAppointments > 0 THEN k.actualAppointments * 100.0 / k.targetAppointments ELSE 0 END), 0) " +
           "FROM ReceptionistKPI k WHERE k.month = :month AND k.year = :year AND k.status = 'active'")
    Object[] getKPISummaryByMonth(@Param("month") Integer month, @Param("year") Integer year);

    // Query to get top performing receptionists
    @Query("SELECT k FROM ReceptionistKPI k WHERE k.month = :month AND k.year = :year AND k.status = 'active' " +
           "ORDER BY (k.actualAppointments * 100.0 / k.targetAppointments) DESC")
    List<ReceptionistKPI> getTopPerformingReceptionists(@Param("month") Integer month, @Param("year") Integer year);

    // Query to get KPI history for a receptionist
    @Query("SELECT k FROM ReceptionistKPI k WHERE k.receptionist = :receptionist AND k.createdAt >= :startDate ORDER BY k.year DESC, k.month DESC")
    List<ReceptionistKPI> findByReceptionistAndCreatedAtAfterOrderByYearDescMonthDesc(@Param("receptionist") User receptionist, @Param("startDate") LocalDateTime startDate);

    // Query to find KPIs by receptionist ID, month and year - returns List to avoid NonUniqueResultException
    @Query("SELECT k FROM ReceptionistKPI k WHERE k.receptionist.userId = :receptionistId AND k.month = :month AND k.year = :year ORDER BY k.createdAt DESC")
    List<ReceptionistKPI> findKPIsByReceptionistAndMonthAndYear(@Param("receptionistId") Integer receptionistId, @Param("month") Integer month, @Param("year") Integer year);

    // Query to get performance trends
    @Query("SELECT k.month, k.year, AVG(k.actualAppointments * 100.0 / k.targetAppointments) as avgPerformance " +
           "FROM ReceptionistKPI k WHERE k.receptionist.userId = :receptionistId AND k.status = 'active' " +
           "GROUP BY k.year, k.month ORDER BY k.year DESC, k.month DESC")
    List<Object[]> getPerformanceTrendsByReceptionist(@Param("receptionistId") Integer receptionistId);

    // Query to get branch-wise KPI summary - Simplified version
    @Query("SELECT COALESCE(b.name, 'No Branch'), COUNT(k), " +
           "AVG(CASE WHEN k.targetAppointments > 0 THEN k.actualAppointments * 100.0 / k.targetAppointments ELSE 0 END), " +
           "AVG(CASE WHEN k.targetRevenue > 0 THEN k.actualRevenue * 100.0 / k.targetRevenue ELSE 0 END) " +
           "FROM ReceptionistKPI k JOIN k.receptionist r LEFT JOIN r.branch b " +
           "WHERE k.month = :month AND k.year = :year AND k.status = 'active' " +
           "GROUP BY b.name ORDER BY AVG(CASE WHEN k.targetAppointments > 0 THEN k.actualAppointments * 100.0 / k.targetAppointments ELSE 0 END) DESC")
    List<Object[]> getBranchWiseKPISummary(@Param("month") Integer month, @Param("year") Integer year);

    // Query to get underperforming receptionists (below 80% target)
    @Query("SELECT k FROM ReceptionistKPI k WHERE k.month = :month AND k.year = :year AND k.status = 'active' " +
           "AND (k.actualAppointments * 100.0 / k.targetAppointments) < 80 " +
           "ORDER BY (k.actualAppointments * 100.0 / k.targetAppointments) ASC")
    List<ReceptionistKPI> getUnderperformingReceptionists(@Param("month") Integer month, @Param("year") Integer year);

    // Query to get revenue performance
    @Query("SELECT SUM(k.actualRevenue) as totalActualRevenue, SUM(k.targetRevenue) as totalTargetRevenue " +
           "FROM ReceptionistKPI k WHERE k.month = :month AND k.year = :year AND k.status = 'active'")
    Object[] getRevenuePerformanceByMonth(@Param("month") Integer month, @Param("year") Integer year);

    // Query to get monthly comparison
    @Query("SELECT k.month, k.year, COUNT(k) as totalReceptionists, " +
           "AVG(k.actualAppointments) as avgAppointments, AVG(k.actualRevenue) as avgRevenue " +
           "FROM ReceptionistKPI k WHERE k.status = 'active' " +
           "GROUP BY k.year, k.month ORDER BY k.year DESC, k.month DESC")
    List<Object[]> getMonthlyComparison();

    // Query to find KPIs that need attention (targets not met)
    @Query("SELECT k FROM ReceptionistKPI k WHERE k.month = :month AND k.year = :year AND k.status = 'active' " +
           "AND (k.actualAppointments < k.targetAppointments OR k.actualInvoices < k.targetInvoices OR k.actualRevenue < k.targetRevenue)")
    List<ReceptionistKPI> getKPIsNeedingAttention(@Param("month") Integer month, @Param("year") Integer year);

    // Query for manager dashboard - get all receptionists under a manager
    @Query("SELECT k FROM ReceptionistKPI k WHERE k.manager.userId = :managerId AND k.status = 'active' " +
           "ORDER BY k.year DESC, k.month DESC, k.receptionist.fullName")
    List<ReceptionistKPI> findActiveKPIsByManager(@Param("managerId") Integer managerId);

    // Query to get current month KPIs for a manager
    @Query("SELECT k FROM ReceptionistKPI k WHERE k.manager.userId = :managerId AND k.month = :month AND k.year = :year AND k.status = 'active'")
    List<ReceptionistKPI> findCurrentMonthKPIsByManager(@Param("managerId") Integer managerId, @Param("month") Integer month, @Param("year") Integer year);
}
