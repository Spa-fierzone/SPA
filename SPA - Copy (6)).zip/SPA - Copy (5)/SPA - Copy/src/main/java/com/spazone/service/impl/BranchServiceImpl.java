package com.spazone.service.impl;

import com.spazone.entity.Branch;
import com.spazone.exception.BranchValidationException;
import com.spazone.exception.DuplicateResourceException;
import com.spazone.exception.ResourceNotFoundException;
import com.spazone.repository.BranchRepository;
import com.spazone.service.BranchService;
import com.spazone.util.BranchValidationUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class BranchServiceImpl implements BranchService {

    private static final Logger logger = LoggerFactory.getLogger(BranchServiceImpl.class);

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private BranchValidationUtil validationUtil;

    @Override
    public Page<Branch> searchBranches(String keyword, Integer managerId, Pageable pageable) {
        return branchRepository.searchBranches(
                (keyword != null && !keyword.trim().isEmpty()) ? keyword : null,
                managerId,
                pageable
        );
    }

    @Override
    public List<Branch> getAllBranches() {
        return branchRepository.findAll();
    }

    @Override
    public Optional<Branch> findById(Integer branchId) {
        return branchRepository.findById(branchId);
    }

    @Override
    public Branch save(Branch branch) {
        logger.info("Saving branch: {}", branch.getName());

        try {
            // Determine if this is a create or update operation
            boolean isUpdate = branch.getBranchId() != null;

            if (isUpdate) {
                logger.debug("Updating existing branch with ID: {}", branch.getBranchId());
                validateBranchForUpdate(branch);

                // Preserve creation timestamp
                branchRepository.findById(branch.getBranchId())
                        .ifPresent(existing -> branch.setCreatedAt(existing.getCreatedAt()));
            } else {
                logger.debug("Creating new branch");
                validateBranchForCreate(branch);
            }

            // Normalize data before saving
            normalizeBranchData(branch);

            branch.setUpdatedAt(LocalDateTime.now());
            Branch savedBranch = branchRepository.save(branch);

            logger.info("Successfully saved branch with ID: {}", savedBranch.getBranchId());
            return savedBranch;

        } catch (BranchValidationException | DuplicateResourceException e) {
            logger.error("Validation failed for branch: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            logger.error("Unexpected error while saving branch: {}", e.getMessage(), e);
            throw new RuntimeException("Lỗi hệ thống khi lưu thông tin chi nhánh", e);
        }
    }

    @Override
    public void deleteById(Integer branchId) {
        branchRepository.deleteById(branchId);
    }

    @Override
    public List<Branch> findAll() {
        return branchRepository.findAll();
    }

    @Override
    public Branch getById(Integer branchId) {
        return branchRepository.findById(branchId).orElse(null);
    }

    @Override
    public void toggleStatus(Integer id) {
        Branch branch = branchRepository.findById(id).orElse(null);
        if (branch != null) {
            String current = branch.getStatus();
            switch (current) {
                case "active" -> branch.setStatus("inactive");
                case "inactive" -> branch.setStatus("active");
            }
            branch.setUpdatedAt(LocalDateTime.now());
            branchRepository.save(branch);
        }
    }

    @Override
    public List<Branch> findAllActive() {
        return branchRepository.findByIsActiveTrue();
    }

    @Override
    public List<Branch> findByManagerId(Integer managerId) {
        return branchRepository.findByManagerId(managerId);
    }

    // ==================== VALIDATION METHODS ====================

    /**
     * Validates branch data for create operation
     * @param branch the branch to validate
     * @throws BranchValidationException if validation fails
     * @throws DuplicateResourceException if duplicate data is found
     */
    private void validateBranchForCreate(Branch branch) {
        logger.debug("Validating branch for create operation");

        // Basic field validations
        validateBranchFields(branch);

        // Uniqueness validations for create
        validateUniquenessForCreate(branch);
    }

    /**
     * Validates branch data for update operation
     * @param branch the branch to validate
     * @throws BranchValidationException if validation fails
     * @throws DuplicateResourceException if duplicate data is found
     */
    private void validateBranchForUpdate(Branch branch) {
        logger.debug("Validating branch for update operation with ID: {}", branch.getBranchId());

        // Check if branch exists
        if (!branchRepository.existsById(branch.getBranchId())) {
            throw new ResourceNotFoundException("Không tìm thấy chi nhánh với ID: " + branch.getBranchId());
        }

        // Basic field validations
        validateBranchFields(branch);

        // Uniqueness validations for update
        validateUniquenessForUpdate(branch);
    }

    /**
     * Validates basic branch fields
     * @param branch the branch to validate
     * @throws BranchValidationException if validation fails
     */
    private void validateBranchFields(Branch branch) {
        logger.debug("Validating basic branch fields");

        // Validate required fields
        validationUtil.validateBranchName(branch.getName());
        validationUtil.validateAddress(branch.getAddress());

        // Validate optional fields if provided
        validationUtil.validatePhoneNumber(branch.getPhone());
        validationUtil.validateEmail(branch.getEmail());

        // Additional business validations
        validateCapacity(branch.getCapacity());
        validateStatus(branch.getStatus());
    }

    /**
     * Validates uniqueness constraints for create operation
     * @param branch the branch to validate
     * @throws DuplicateResourceException if duplicate data is found
     */
    private void validateUniquenessForCreate(Branch branch) {
        logger.debug("Validating uniqueness constraints for create operation");

        // Check name uniqueness
        if (branchRepository.existsByNameIgnoreCase(branch.getName())) {
            throw new DuplicateResourceException("Tên chi nhánh '" + branch.getName() + "' đã tồn tại trong hệ thống");
        }

        // Check phone uniqueness (if provided)
        String normalizedPhone = validationUtil.normalizePhoneNumber(branch.getPhone());
        if (normalizedPhone != null && branchRepository.existsByPhone(normalizedPhone)) {
            throw new DuplicateResourceException("Số điện thoại '" + branch.getPhone() + "' đã được sử dụng bởi chi nhánh khác");
        }

        // Check email uniqueness (if provided)
        String normalizedEmail = validationUtil.normalizeEmail(branch.getEmail());
        if (normalizedEmail != null && branchRepository.existsByEmailIgnoreCase(normalizedEmail)) {
            throw new DuplicateResourceException("Địa chỉ email '" + branch.getEmail() + "' đã được sử dụng bởi chi nhánh khác");
        }

        // Optional: Check address uniqueness if business rules require it
        // if (branchRepository.existsByAddressIgnoreCase(branch.getAddress())) {
        //     throw new DuplicateResourceException("Địa chỉ '" + branch.getAddress() + "' đã được sử dụng bởi chi nhánh khác");
        // }
    }

    /**
     * Validates uniqueness constraints for update operation
     * @param branch the branch to validate
     * @throws DuplicateResourceException if duplicate data is found
     */
    private void validateUniquenessForUpdate(Branch branch) {
        logger.debug("Validating uniqueness constraints for update operation");

        // Check name uniqueness (excluding current branch)
        if (branchRepository.existsByNameIgnoreCaseAndBranchIdNot(branch.getName(), branch.getBranchId())) {
            throw new DuplicateResourceException("Tên chi nhánh '" + branch.getName() + "' đã tồn tại trong hệ thống");
        }

        // Check phone uniqueness (if provided, excluding current branch)
        String normalizedPhone = validationUtil.normalizePhoneNumber(branch.getPhone());
        if (normalizedPhone != null && branchRepository.existsByPhoneAndBranchIdNot(normalizedPhone, branch.getBranchId())) {
            throw new DuplicateResourceException("Số điện thoại '" + branch.getPhone() + "' đã được sử dụng bởi chi nhánh khác");
        }

        // Check email uniqueness (if provided, excluding current branch)
        String normalizedEmail = validationUtil.normalizeEmail(branch.getEmail());
        if (normalizedEmail != null && branchRepository.existsByEmailIgnoreCaseAndBranchIdNot(normalizedEmail, branch.getBranchId())) {
            throw new DuplicateResourceException("Địa chỉ email '" + branch.getEmail() + "' đã được sử dụng bởi chi nhánh khác");
        }

        // Optional: Check address uniqueness if business rules require it
        // if (branchRepository.existsByAddressIgnoreCaseAndBranchIdNot(branch.getAddress(), branch.getBranchId())) {
        //     throw new DuplicateResourceException("Địa chỉ '" + branch.getAddress() + "' đã được sử dụng bởi chi nhánh khác");
        // }
    }

    /**
     * Validates branch capacity
     * @param capacity the capacity to validate
     * @throws BranchValidationException if validation fails
     */
    private void validateCapacity(Integer capacity) {
        if (capacity != null && capacity <= 0) {
            throw new BranchValidationException("Sức chứa chi nhánh phải là số dương");
        }
        if (capacity != null && capacity > 1000) {
            throw new BranchValidationException("Sức chứa chi nhánh không được vượt quá 1000");
        }
    }

    /**
     * Validates branch status
     * @param status the status to validate
     * @throws BranchValidationException if validation fails
     */
    private void validateStatus(String status) {
        if (status != null && !status.trim().isEmpty()) {
            String normalizedStatus = status.trim().toLowerCase();
            if (!normalizedStatus.matches("^(active|inactive|suspended|maintenance)$")) {
                throw new BranchValidationException(
                    "Trạng thái chi nhánh không hợp lệ. Chỉ chấp nhận: active, inactive, suspended, maintenance"
                );
            }
        }
    }

    /**
     * Normalizes branch data before saving
     * @param branch the branch to normalize
     */
    private void normalizeBranchData(Branch branch) {
        logger.debug("Normalizing branch data");

        // Normalize name
        branch.setName(validationUtil.normalizeName(branch.getName()));

        // Normalize address
        branch.setAddress(validationUtil.normalizeAddress(branch.getAddress()));

        // Normalize phone
        branch.setPhone(validationUtil.normalizePhoneNumber(branch.getPhone()));

        // Normalize email
        branch.setEmail(validationUtil.normalizeEmail(branch.getEmail()));

        // Normalize other text fields
        if (branch.getOpeningHours() != null) {
            branch.setOpeningHours(branch.getOpeningHours().trim());
        }
        if (branch.getOperatingHours() != null) {
            branch.setOperatingHours(branch.getOperatingHours().trim());
        }
        if (branch.getHolidaySchedule() != null) {
            branch.setHolidaySchedule(branch.getHolidaySchedule().trim());
        }
        if (branch.getStatus() != null) {
            branch.setStatus(branch.getStatus().trim().toLowerCase());
        }
    }
}
