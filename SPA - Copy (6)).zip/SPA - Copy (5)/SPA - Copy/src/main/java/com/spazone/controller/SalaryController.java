package com.spazone.controller;

import com.spazone.dto.SalaryCalculationDto;
import com.spazone.entity.Attendance;
import com.spazone.entity.Branch;
import com.spazone.entity.SalaryRecord;
import com.spazone.entity.User;
import com.spazone.repository.BranchRepository;
import com.spazone.service.AttendanceService;
import com.spazone.service.UserService;
import com.spazone.service.impl.SalaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/salary")
public class SalaryController {

    @Autowired
    private SalaryService salaryService;

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private AttendanceService attendanceService;

    @GetMapping("/calculate")
    public String showSalaryCalculation(Model model,
                                        @RequestParam(value = "month", required = false) Integer month,
                                        @RequestParam(value = "year", required = false) Integer year,
                                        @RequestParam(value = "branchId", required = false) Integer branchId) {

        // Set default values if not provided
        LocalDate now = LocalDate.now();
        if (month == null) month = now.getMonthValue();
        if (year == null) year = now.getYear();

        // Load branches for dropdown
        List<Branch> branches = branchRepository.findByIsActiveTrue();

        // Calculate salaries
        List<SalaryCalculationDto> calculations = salaryService.calculateMonthlySalary(month, year, branchId);

        model.addAttribute("calculations", calculations);
        model.addAttribute("branches", branches);
        model.addAttribute("selectedMonth", month);
        model.addAttribute("selectedYear", year);
        model.addAttribute("selectedBranchId", branchId);
        model.addAttribute("monthName", getMonthName(month));

        return "salary/calculate";
    }

    @GetMapping("/admin/user/{userId}/set-base-salary")
    public String showSetBaseSalaryForm(@PathVariable Integer userId, Model model) {
        User user = userService.getUserById(userId);
        model.addAttribute("user", user);
        return "salary/set-base-salary";
    }

    @PostMapping("/admin/user/{userId}/set-base-salary")
    public String setBaseSalary(@PathVariable Integer userId,
                                @RequestParam("baseSalary") BigDecimal baseSalary,
                                Model model) {
        User user = userService.getUserById(userId);
        user.setBaseSalary(baseSalary);
        userService.saveUser(user);

        model.addAttribute("success", "Lương cơ bản đã được cập nhật thành công!");
        return "redirect:/salary/calculate";
    }

    @PostMapping("/save")
    public String saveSalaryRecords(@RequestParam("month") Integer month,
                                    @RequestParam("year") Integer year,
                                    @RequestParam(value = "branchId", required = false) Integer branchId,
                                    @RequestParam(value = "userIds", required = false) List<Integer> userIds,
                                    RedirectAttributes redirectAttributes) {

        try {
            List<SalaryCalculationDto> calculations = salaryService.calculateMonthlySalary(month, year, branchId);

            if (userIds != null && !userIds.isEmpty()) {
                calculations = calculations.stream()
                        .filter(calc -> calc.getUser() != null &&
                                calc.getUser().getUserId() != null &&
                                userIds.contains(calc.getUser().getUserId()))
                        .toList();
            }

            List<SalaryCalculationDto> newRecords = calculations.stream()
                    .filter(calc -> !calc.isHasSalaryRecord())
                    .toList();

            if (!newRecords.isEmpty()) {
                salaryService.saveBatchSalaryRecords(newRecords, branchId);
                redirectAttributes.addFlashAttribute("success",
                        "Đã lưu " + newRecords.size() + " bản ghi lương thành công!");
            } else {
                redirectAttributes.addFlashAttribute("warning",
                        "Không có bản ghi lương mới nào để lưu. Tất cả đã được tính toán trước đó.");
            }

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error",
                    "Có lỗi xảy ra khi lưu bản ghi lương: " + e.getMessage());
        }

        return "redirect:/salary/calculate?month=" + month + "&year=" + year +
                (branchId != null ? "&branchId=" + branchId : "");
    }

    @GetMapping("/records")
    public String showSalaryRecords(Model model,
                                    @RequestParam(value = "month", required = false) Integer month,
                                    @RequestParam(value = "year", required = false) Integer year,
                                    @RequestParam(value = "branchId", required = false) Integer branchId) {

        // Set default values if not provided
        LocalDate now = LocalDate.now();
        if (month == null) month = now.getMonthValue();
        if (year == null) year = now.getYear();

        // Load data
        List<Branch> branches = branchRepository.findByIsActiveTrue();
        List<SalaryRecord> salaryRecords = salaryService.getSalaryRecords(month, year, branchId);

        model.addAttribute("salaryRecords", salaryRecords);
        model.addAttribute("branches", branches);
        model.addAttribute("selectedMonth", month);
        model.addAttribute("selectedYear", year);
        model.addAttribute("selectedBranchId", branchId);
        model.addAttribute("monthName", getMonthName(month));

        return "salary/records";
    }

    @GetMapping("/detail/{userId}")
    public String showSalaryDetail(@PathVariable Integer userId,
                                   @RequestParam("month") Integer month,
                                   @RequestParam("year") Integer year,
                                   Model model) {

        // Calculate salary for specific user
        User user = userService.getUserById(userId);
        SalaryCalculationDto calculation = salaryService.calculateUserSalary(user, month, year);

        // Get attendance records for the month
        LocalDate startDate = LocalDate.of(year, month, 1);
        LocalDate endDate = startDate.withDayOfMonth(startDate.lengthOfMonth());
        List<Attendance> attendanceRecords = attendanceService.getUserAttendanceByDateRange(userId, startDate, endDate);

        model.addAttribute("calculation", calculation);
        model.addAttribute("monthName", getMonthName(month));
        model.addAttribute("attendanceRecords", attendanceRecords);

        return "salary/detail";
    }

    @GetMapping("/manager/branch-salaries")
    public String viewBranchSalaries(Model model,
                                     @RequestParam(value = "month", required = false) Integer month,
                                     @RequestParam(value = "year", required = false) Integer year,
                                     Authentication authentication) {
        // Get current manager
        User manager = userService.findByUsername(authentication.getName());
        Integer branchId = manager.getBranch().getBranchId();

        // Set default values if not provided
        LocalDate now = LocalDate.now();
        if (month == null) month = now.getMonthValue();
        if (year == null) year = now.getYear();

        // Calculate salaries for manager's branch only
        List<SalaryCalculationDto> calculations = salaryService.calculateMonthlySalary(month, year, branchId);

        model.addAttribute("calculations", calculations);
        model.addAttribute("branch", manager.getBranch());
        model.addAttribute("selectedMonth", month);
        model.addAttribute("selectedYear", year);
        model.addAttribute("monthName", getMonthName(month));

        return "manager/salary-view";
    }

    @GetMapping("/manager/salary-history")
    public String viewSalaryHistory(Model model,
                                    @RequestParam(value = "userId", required = false) Integer userId,
                                    @RequestParam(value = "startMonth", required = false) Integer startMonth,
                                    @RequestParam(value = "startYear", required = false) Integer startYear,
                                    @RequestParam(value = "endMonth", required = false) Integer endMonth,
                                    @RequestParam(value = "endYear", required = false) Integer endYear,
                                    Authentication authentication) {
        // Get current manager
        User manager = userService.findByUsername(authentication.getName());
        Integer branchId = manager.getBranch().getBranchId();

        // Set default values (last 6 months)
        LocalDate now = LocalDate.now();
        if (startMonth == null || startYear == null) {
            LocalDate sixMonthsAgo = now.minusMonths(6);
            startMonth = sixMonthsAgo.getMonthValue();
            startYear = sixMonthsAgo.getYear();
        }
        if (endMonth == null || endYear == null) {
            endMonth = now.getMonthValue();
            endYear = now.getYear();
        }

        // Get employees in manager's branch
        List<User> branchEmployees = userService.findActiveUsersByBranch(branchId);

        // Get salary history
        List<SalaryRecord> salaryHistory = salaryService.getSalaryHistoryByDateRange(
            userId, branchId, startMonth, startYear, endMonth, endYear);

        model.addAttribute("salaryHistory", salaryHistory);
        model.addAttribute("branchEmployees", branchEmployees);
        model.addAttribute("selectedUserId", userId);
        model.addAttribute("startMonth", startMonth);
        model.addAttribute("startYear", startYear);
        model.addAttribute("endMonth", endMonth);
        model.addAttribute("endYear", endYear);
        model.addAttribute("branch", manager.getBranch());

        return "manager/salary-history";
    }

    // Helper method to get month name in Vietnamese
    private String getMonthName(Integer month) {
        String[] monthNames = {
                "", "Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6",
                "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"
        };
        return monthNames[month];
    }


}