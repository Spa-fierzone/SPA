package com.spazone.service;

import com.spazone.dto.ManagerScheduleDetailDTO.ServiceUsageDTO;
import com.spazone.entity.Appointment;
import com.spazone.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ServiceStatisticsService {
    
    @Autowired
    private AppointmentRepository appointmentRepository;
    
    /**
     * Get service usage statistics for a specific technician on a specific date
     */
    public List<ServiceUsageDTO> getServiceUsageByTechnicianAndDate(Integer technicianId, LocalDate date) {
        LocalDateTime startOfDay = date.atStartOfDay();
        LocalDateTime endOfDay = date.atTime(23, 59, 59);
        
        List<Appointment> appointments = appointmentRepository
                .findByTechnicianUserIdAndAppointmentDateBetween(technicianId, startOfDay, endOfDay);
        
        // Flatten all services from all appointments
        Map<String, Long> serviceUsageMap = appointments.stream()
                .flatMap(appointment -> appointment.getServices().stream())
                .collect(Collectors.groupingBy(
                        com.spazone.entity.Service::getName,
                        Collectors.counting()
                ));

        return serviceUsageMap.entrySet().stream()
                .map(entry -> {
                    String serviceName = entry.getKey();
                    Integer usageCount = entry.getValue().intValue();

                    // Get service category from the first service with this name
                    String serviceCategory = appointments.stream()
                            .flatMap(app -> app.getServices().stream())
                            .filter(service -> service.getName().equals(serviceName))
                            .findFirst()
                            .map(service -> service.getCategory() != null ?
                                    service.getCategory().getName() : "Uncategorized")
                            .orElse("Uncategorized");

                    return new ServiceUsageDTO(serviceName, usageCount, serviceCategory);
                })
                .sorted((a, b) -> b.getUsageCount().compareTo(a.getUsageCount()))
                .collect(Collectors.toList());
    }
    
    /**
     * Get the most popular service for a technician on a specific date
     */
    public String getMostPopularServiceByTechnicianAndDate(Integer technicianId, LocalDate date) {
        List<ServiceUsageDTO> serviceUsage = getServiceUsageByTechnicianAndDate(technicianId, date);
        
        return serviceUsage.isEmpty() ? "No services" : serviceUsage.get(0).getServiceName();
    }
    
    /**
     * Get total number of services provided by a technician on a specific date
     */
    public Integer getTotalServicesProvidedByTechnicianAndDate(Integer technicianId, LocalDate date) {
        LocalDateTime startOfDay = date.atStartOfDay();
        LocalDateTime endOfDay = date.atTime(23, 59, 59);
        
        return appointmentRepository
                .countByTechnicianUserIdAndAppointmentDateBetween(technicianId, startOfDay, endOfDay)
                .intValue();
    }
    
    /**
     * Get service usage statistics for a specific receptionist on a specific date
     * (appointments they helped schedule or manage)
     */
    public List<ServiceUsageDTO> getServiceUsageByReceptionistAndDate(Integer receptionistId, LocalDate date) {
        LocalDateTime startOfDay = date.atStartOfDay();
        LocalDateTime endOfDay = date.atTime(23, 59, 59);
        
        // For receptionists, we'll look at appointments created on that date
        // This assumes receptionists are involved in appointment creation
        List<Appointment> appointments = appointmentRepository
                .findByCreatedAtBetween(startOfDay, endOfDay);
        
        Map<String, Long> serviceUsageMap = appointments.stream()
                .flatMap(appointment -> appointment.getServices().stream())
                .collect(Collectors.groupingBy(
                        com.spazone.entity.Service::getName,
                        Collectors.counting()
                ));

        return serviceUsageMap.entrySet().stream()
                .map(entry -> {
                    String serviceName = entry.getKey();
                    Integer usageCount = entry.getValue().intValue();

                    String serviceCategory = appointments.stream()
                            .flatMap(app -> app.getServices().stream())
                            .filter(service -> service.getName().equals(serviceName))
                            .findFirst()
                            .map(service -> service.getCategory() != null ?
                                    service.getCategory().getName() : "Uncategorized")
                            .orElse("Uncategorized");
                    
                    return new ServiceUsageDTO(serviceName, usageCount, serviceCategory);
                })
                .sorted((a, b) -> b.getUsageCount().compareTo(a.getUsageCount()))
                .collect(Collectors.toList());
    }
    
    /**
     * Get popular services across all branches for a specific date range
     */
    public List<ServiceUsageDTO> getPopularServicesInDateRange(LocalDate startDate, LocalDate endDate) {
        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.atTime(23, 59, 59);
        
        List<Appointment> appointments = appointmentRepository
                .findByAppointmentDateBetween(startDateTime, endDateTime);
        
        Map<String, Long> serviceUsageMap = appointments.stream()
                .flatMap(appointment -> appointment.getServices().stream())
                .collect(Collectors.groupingBy(
                        com.spazone.entity.Service::getName,
                        Collectors.counting()
                ));

        return serviceUsageMap.entrySet().stream()
                .map(entry -> {
                    String serviceName = entry.getKey();
                    Integer usageCount = entry.getValue().intValue();

                    String serviceCategory = appointments.stream()
                            .flatMap(app -> app.getServices().stream())
                            .filter(service -> service.getName().equals(serviceName))
                            .findFirst()
                            .map(service -> service.getCategory() != null ?
                                    service.getCategory().getName() : "Uncategorized")
                            .orElse("Uncategorized");
                    
                    return new ServiceUsageDTO(serviceName, usageCount, serviceCategory);
                })
                .sorted((a, b) -> b.getUsageCount().compareTo(a.getUsageCount()))
                .limit(10) // Top 10 popular services
                .collect(Collectors.toList());
    }
    
    /**
     * Get popular services for a specific branch in a date range
     */
    public List<ServiceUsageDTO> getPopularServicesByBranchInDateRange(Integer branchId, LocalDate startDate, LocalDate endDate) {
        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.atTime(23, 59, 59);
        
        List<Appointment> appointments = appointmentRepository
                .findByBranchBranchIdAndAppointmentDateBetween(branchId, startDateTime, endDateTime);
        
        Map<String, Long> serviceUsageMap = appointments.stream()
                .flatMap(appointment -> appointment.getServices().stream())
                .collect(Collectors.groupingBy(
                        com.spazone.entity.Service::getName,
                        Collectors.counting()
                ));

        return serviceUsageMap.entrySet().stream()
                .map(entry -> {
                    String serviceName = entry.getKey();
                    Integer usageCount = entry.getValue().intValue();

                    String serviceCategory = appointments.stream()
                            .flatMap(app -> app.getServices().stream())
                            .filter(service -> service.getName().equals(serviceName))
                            .findFirst()
                            .map(service -> service.getCategory() != null ?
                                    service.getCategory().getName() : "Uncategorized")
                            .orElse("Uncategorized");
                    
                    return new ServiceUsageDTO(serviceName, usageCount, serviceCategory);
                })
                .sorted((a, b) -> b.getUsageCount().compareTo(a.getUsageCount()))
                .limit(10) // Top 10 popular services for this branch
                .collect(Collectors.toList());
    }
    
    /**
     * Get service statistics summary for dashboard
     */
    public Map<String, Object> getServiceStatisticsSummary(LocalDate startDate, LocalDate endDate) {
        List<ServiceUsageDTO> popularServices = getPopularServicesInDateRange(startDate, endDate);
        
        Integer totalServices = popularServices.stream()
                .mapToInt(ServiceUsageDTO::getUsageCount)
                .sum();
        
        String mostPopularService = popularServices.isEmpty() ? 
                "No services" : popularServices.get(0).getServiceName();
        
        return Map.of(
                "popularServices", popularServices,
                "totalServices", totalServices,
                "mostPopularService", mostPopularService,
                "totalServiceTypes", popularServices.size()
        );
    }
}
