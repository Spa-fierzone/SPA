package com.spazone.util;

import com.spazone.exception.ServiceValidationException;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

/**
 * Utility class for service validation operations
 */
@Component
public class ServiceValidationUtil {
    
    // Constants for validation
    private static final int MIN_NAME_LENGTH = 2;
    private static final int MAX_NAME_LENGTH = 255;
    private static final int MIN_DESCRIPTION_LENGTH = 10;
    private static final int MAX_DESCRIPTION_LENGTH = 4000;
    private static final BigDecimal MIN_PRICE = new BigDecimal("10000"); // 10,000 VND
    private static final BigDecimal MAX_PRICE = new BigDecimal("10000000"); // 10,000,000 VND
    private static final int MIN_DURATION = 15; // 15 minutes
    private static final int MAX_DURATION = 480; // 8 hours
    private static final int DURATION_INCREMENT = 15; // Must be multiples of 15 minutes
    
    // Valid status values
    private static final List<String> VALID_STATUSES = Arrays.asList("active", "inactive", "discontinued");
    
    /**
     * Validates service name
     * @param name the service name to validate
     * @throws ServiceValidationException if validation fails
     */
    public void validateServiceName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new ServiceValidationException("Tên dịch vụ không được để trống");
        }
        
        String trimmedName = name.trim();
        if (trimmedName.length() < MIN_NAME_LENGTH) {
            throw new ServiceValidationException(
                String.format("Tên dịch vụ phải có ít nhất %d ký tự", MIN_NAME_LENGTH)
            );
        }
        
        if (trimmedName.length() > MAX_NAME_LENGTH) {
            throw new ServiceValidationException(
                String.format("Tên dịch vụ không được vượt quá %d ký tự", MAX_NAME_LENGTH)
            );
        }
        
        // Check for valid characters (letters, numbers, spaces, and common Vietnamese characters)
        if (!trimmedName.matches("^[\\p{L}\\p{N}\\s\\-.,()&/]+$")) {
            throw new ServiceValidationException("Tên dịch vụ chỉ được chứa chữ cái, số, khoảng trắng và các ký tự đặc biệt cơ bản");
        }
    }
    
    /**
     * Validates service price
     * @param price the price to validate
     * @throws ServiceValidationException if validation fails
     */
    public void validatePrice(BigDecimal price) {
        if (price == null) {
            throw new ServiceValidationException("Giá dịch vụ không được để trống");
        }
        
        if (price.compareTo(BigDecimal.ZERO) <= 0) {
            throw new ServiceValidationException("Giá dịch vụ phải là số dương");
        }
        
        if (price.compareTo(MIN_PRICE) < 0) {
            throw new ServiceValidationException(
                String.format("Giá dịch vụ không được thấp hơn %,d VND", MIN_PRICE.longValue())
            );
        }
        
        if (price.compareTo(MAX_PRICE) > 0) {
            throw new ServiceValidationException(
                String.format("Giá dịch vụ không được cao hơn %,d VND", MAX_PRICE.longValue())
            );
        }
        
        // Check for reasonable decimal places (max 2 decimal places)
        if (price.scale() > 2) {
            throw new ServiceValidationException("Giá dịch vụ chỉ được có tối đa 2 chữ số thập phân");
        }
    }
    
    /**
     * Validates service duration
     * @param duration the duration to validate (in minutes)
     * @throws ServiceValidationException if validation fails
     */
    public void validateDuration(Integer duration) {
        if (duration == null) {
            throw new ServiceValidationException("Thời gian thực hiện dịch vụ không được để trống");
        }
        
        if (duration <= 0) {
            throw new ServiceValidationException("Thời gian thực hiện dịch vụ phải là số dương");
        }
        
        if (duration < MIN_DURATION) {
            throw new ServiceValidationException(
                String.format("Thời gian thực hiện dịch vụ không được ít hơn %d phút", MIN_DURATION)
            );
        }
        
        if (duration > MAX_DURATION) {
            throw new ServiceValidationException(
                String.format("Thời gian thực hiện dịch vụ không được vượt quá %d phút (%d giờ)", 
                    MAX_DURATION, MAX_DURATION / 60)
            );
        }
        
        if (duration % DURATION_INCREMENT != 0) {
            throw new ServiceValidationException(
                String.format("Thời gian thực hiện dịch vụ phải là bội số của %d phút", DURATION_INCREMENT)
            );
        }
    }
    
    /**
     * Validates service description
     * @param description the description to validate
     * @param isActiveService whether the service is active (active services require description)
     * @throws ServiceValidationException if validation fails
     */
    public void validateDescription(String description, boolean isActiveService) {
        if (isActiveService && (description == null || description.trim().isEmpty())) {
            throw new ServiceValidationException("Mô tả dịch vụ không được để trống đối với dịch vụ đang hoạt động");
        }
        
        if (description != null && !description.trim().isEmpty()) {
            String trimmedDescription = description.trim();
            
            if (trimmedDescription.length() < MIN_DESCRIPTION_LENGTH) {
                throw new ServiceValidationException(
                    String.format("Mô tả dịch vụ phải có ít nhất %d ký tự", MIN_DESCRIPTION_LENGTH)
                );
            }
            
            if (trimmedDescription.length() > MAX_DESCRIPTION_LENGTH) {
                throw new ServiceValidationException(
                    String.format("Mô tả dịch vụ không được vượt quá %d ký tự", MAX_DESCRIPTION_LENGTH)
                );
            }
            
            // Basic content validation - check for meaningful content
            if (trimmedDescription.matches("^[\\s\\p{Punct}]*$")) {
                throw new ServiceValidationException("Mô tả dịch vụ phải chứa nội dung có ý nghĩa");
            }
        }
    }
    
    /**
     * Validates service status
     * @param status the status to validate
     * @throws ServiceValidationException if validation fails
     */
    public void validateStatus(String status) {
        if (status == null || status.trim().isEmpty()) {
            throw new ServiceValidationException("Trạng thái dịch vụ không được để trống");
        }

        String normalizedStatus = status.trim().toLowerCase();
        if (!VALID_STATUSES.contains(normalizedStatus)) {
            throw new ServiceValidationException(
                String.format("Trạng thái dịch vụ không hợp lệ. Chỉ chấp nhận: %s",
                    String.join(", ", VALID_STATUSES))
            );
        }
    }

    /**
     * Validates service branch
     * @param branchId the branch ID to validate
     * @throws ServiceValidationException if validation fails
     */
    public void validateBranch(Integer branchId) {
        if (branchId == null) {
            throw new ServiceValidationException("Chi nhánh không được để trống");
        }

        if (branchId <= 0) {
            throw new ServiceValidationException("Chi nhánh không hợp lệ");
        }
    }
    
    /**
     * Validates status transition business rules
     * @param currentStatus the current status
     * @param newStatus the new status
     * @throws ServiceValidationException if transition is not allowed
     */
    public void validateStatusTransition(String currentStatus, String newStatus) {
        if (currentStatus == null || newStatus == null) {
            return; // Skip validation if either status is null
        }
        
        String current = currentStatus.trim().toLowerCase();
        String newStat = newStatus.trim().toLowerCase();
        
        // Business rules for status transitions
        if ("discontinued".equals(current) && !"discontinued".equals(newStat)) {
            throw new ServiceValidationException(
                "Không thể thay đổi trạng thái của dịch vụ đã ngừng cung cấp"
            );
        }
        
        // Additional business rules can be added here
        // For example: services with active appointments cannot be discontinued
    }
    
    /**
     * Normalizes service name for storage and comparison
     * @param name the name to normalize
     * @return normalized name or null if input is null/empty
     */
    public String normalizeName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return null;
        }
        return name.trim();
    }
    
    /**
     * Normalizes service description for storage
     * @param description the description to normalize
     * @return normalized description or null if input is null/empty
     */
    public String normalizeDescription(String description) {
        if (description == null || description.trim().isEmpty()) {
            return null;
        }
        return description.trim();
    }
    
    /**
     * Normalizes service status for storage
     * @param status the status to normalize
     * @return normalized status or null if input is null/empty
     */
    public String normalizeStatus(String status) {
        if (status == null || status.trim().isEmpty()) {
            return null;
        }
        return status.trim().toLowerCase();
    }
    
    /**
     * Formats duration for display
     * @param duration duration in minutes
     * @return formatted duration string
     */
    public String formatDuration(Integer duration) {
        if (duration == null) {
            return "";
        }
        
        if (duration < 60) {
            return duration + " phút";
        } else {
            int hours = duration / 60;
            int minutes = duration % 60;
            if (minutes == 0) {
                return hours + " giờ";
            } else {
                return hours + " giờ " + minutes + " phút";
            }
        }
    }
    
    /**
     * Formats price for display
     * @param price the price to format
     * @return formatted price string
     */
    public String formatPrice(BigDecimal price) {
        if (price == null) {
            return "";
        }
        return String.format("%,d VND", price.longValue());
    }
}
