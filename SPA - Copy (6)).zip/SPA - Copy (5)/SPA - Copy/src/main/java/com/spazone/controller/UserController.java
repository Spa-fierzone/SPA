package com.spazone.controller;

import com.spazone.dto.CreateUserDto;
import com.spazone.entity.User;
import com.spazone.exception.UserValidationException;
import com.spazone.service.BranchService;
import com.spazone.service.UserService;
import com.spazone.repository.RoleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.http.ResponseEntity;
import java.util.Map;

import java.util.Set;

@Controller
@RequestMapping("/admin/users")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private BranchService branchService;

    @GetMapping
    public String listUsers(
            @RequestParam(value = "keyword", required = false) String keyword,
            @RequestParam(value = "status", required = false) String status,
            @RequestParam(value = "role", required = false) String role,
            @RequestParam(value = "page", defaultValue = "0") int page,
            Model model
    ) {
        int size = 10;
        Page<User> userPage = userService.getUsersWithFilters(keyword, status, role, page, size);

        model.addAttribute("users", userPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", userPage.getTotalPages());
        model.addAttribute("keyword", keyword);
        model.addAttribute("status", status);
        model.addAttribute("role", role);
        model.addAttribute("roles", roleRepository.findByRoleNameNot("ADMIN"));
        model.addAttribute("branches", branchService.findAllActive());
        model.addAttribute("userDto", new CreateUserDto());
        return "admin/user-management";
    }

    @PostMapping("/{id}/status")
    public String changeStatus(@PathVariable Integer id,
                               @RequestParam String status,
                               RedirectAttributes redirectAttributes) {
        userService.changeUserStatus(id, status);
        redirectAttributes.addFlashAttribute("message", "Đã cập nhật trạng thái người dùng.");
        return "redirect:/admin/users";
    }


    // Xử lý form tạo user
    @PostMapping("/create")
    public String createUser(@ModelAttribute("userDto") CreateUserDto userDto,
                             RedirectAttributes redirectAttributes) {
        try {
            userService.createUserWithRoleAndSalary(userDto);
            redirectAttributes.addFlashAttribute("message", "Tạo người dùng thành công!");
            logger.info("Admin created new user: {}", userDto.getUsername());
        } catch (UserValidationException e) {
            logger.warn("User validation failed: {}", e.getMessage());
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        } catch (Exception e) {
            logger.error("Error creating user: {}", e.getMessage(), e);
            redirectAttributes.addFlashAttribute("errorMessage", "Có lỗi xảy ra khi tạo người dùng: " + e.getMessage());
        }
        return "redirect:/admin/users";
    }

    // AJAX endpoint for user creation
    @PostMapping("/create-ajax")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> createUserAjax(@ModelAttribute("userDto") CreateUserDto userDto) {
        try {
            userService.createUserWithRoleAndSalary(userDto);
            logger.info("Admin created new user via AJAX: {}", userDto.getUsername());

            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Tạo người dùng thành công!",
                "username", userDto.getUsername()
            ));

        } catch (UserValidationException e) {
            logger.warn("User validation failed via AJAX: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));

        } catch (Exception e) {
            logger.error("Error creating user via AJAX: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", "Có lỗi xảy ra khi tạo người dùng: " + e.getMessage()
            ));
        }
    }

    // Update user information
    @PostMapping("/{id}/update")
    public String updateUser(@PathVariable Integer id,
                            @ModelAttribute("userDto") CreateUserDto userDto,
                            RedirectAttributes redirectAttributes) {
        try {
            userService.updateUser(id, userDto);
            redirectAttributes.addFlashAttribute("message", "Cập nhật thông tin người dùng thành công!");
            logger.info("Admin updated user ID: {}", id);
        } catch (UserValidationException e) {
            logger.warn("User validation failed for update: {}", e.getMessage());
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        } catch (Exception e) {
            logger.error("Error updating user: {}", e.getMessage(), e);
            redirectAttributes.addFlashAttribute("errorMessage", "Có lỗi xảy ra khi cập nhật người dùng: " + e.getMessage());
        }
        return "redirect:/admin/users";
    }

    // AJAX endpoint for user update
    @PostMapping("/{id}/update-ajax")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> updateUserAjax(@PathVariable Integer id,
                                                             @ModelAttribute("userDto") CreateUserDto userDto) {
        try {
            userService.updateUser(id, userDto);
            logger.info("Admin updated user via AJAX, ID: {}", id);

            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Cập nhật thông tin người dùng thành công!",
                "userId", id
            ));

        } catch (UserValidationException e) {
            logger.warn("User validation failed for update via AJAX: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));

        } catch (Exception e) {
            logger.error("Error updating user via AJAX: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", "Có lỗi xảy ra khi cập nhật người dùng: " + e.getMessage()
            ));
        }
    }

    // 4. Cập nhật role cho người dùng
    @PostMapping("/{id}/roles")
    public String updateUserRoles(@PathVariable Integer id,
                                  @RequestParam(value = "roleIds", required = false) Set<Integer> roleIds,
                                  RedirectAttributes redirectAttributes) {
        userService.updateUserRoles(id, roleIds != null ? roleIds : Set.of());
        redirectAttributes.addFlashAttribute("message", "Cập nhật quyền người dùng thành công.");
        return "redirect:/admin/users";
    }
}
