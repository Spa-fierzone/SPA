package com.spazone.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ValidationResult {
    private boolean valid;
    private List<String> errorMessages;
    private List<ConflictDetail> conflicts;
    private List<LocalDateTime> suggestedTimeSlots;
    
    public ValidationResult() {
        this.valid = true;
        this.errorMessages = new ArrayList<>();
        this.conflicts = new ArrayList<>();
        this.suggestedTimeSlots = new ArrayList<>();
    }
    
    public ValidationResult(boolean valid) {
        this();
        this.valid = valid;
    }
    
    // Static factory methods
    public static ValidationResult success() {
        return new ValidationResult(true);
    }
    
    public static ValidationResult failure(String errorMessage) {
        ValidationResult result = new ValidationResult(false);
        result.addErrorMessage(errorMessage);
        return result;
    }
    
    public static ValidationResult failure(List<String> errorMessages) {
        ValidationResult result = new ValidationResult(false);
        result.errorMessages.addAll(errorMessages);
        return result;
    }
    
    // Helper methods
    public void addErrorMessage(String message) {
        this.errorMessages.add(message);
        this.valid = false;
    }
    
    public void addConflict(ConflictDetail conflict) {
        this.conflicts.add(conflict);
        this.valid = false;
    }
    
    public void addSuggestedTimeSlot(LocalDateTime timeSlot) {
        this.suggestedTimeSlots.add(timeSlot);
    }
    
    public String getFormattedErrorMessage() {
        if (valid) {
            return null;
        }
        return String.join("; ", errorMessages);
    }
    
    public boolean hasConflicts() {
        return !conflicts.isEmpty();
    }
    
    public boolean hasSuggestions() {
        return !suggestedTimeSlots.isEmpty();
    }
    
    // Getters and Setters
    public boolean isValid() {
        return valid;
    }
    
    public void setValid(boolean valid) {
        this.valid = valid;
    }
    
    public List<String> getErrorMessages() {
        return errorMessages;
    }
    
    public void setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
    }
    
    public List<ConflictDetail> getConflicts() {
        return conflicts;
    }
    
    public void setConflicts(List<ConflictDetail> conflicts) {
        this.conflicts = conflicts;
    }
    
    public List<LocalDateTime> getSuggestedTimeSlots() {
        return suggestedTimeSlots;
    }
    
    public void setSuggestedTimeSlots(List<LocalDateTime> suggestedTimeSlots) {
        this.suggestedTimeSlots = suggestedTimeSlots;
    }
    
    // Inner class for conflict details
    public static class ConflictDetail {
        private ConflictType type;
        private String resourceName;
        private LocalDateTime conflictStart;
        private LocalDateTime conflictEnd;
        private Integer conflictingAppointmentId;
        
        public ConflictDetail(ConflictType type, String resourceName, 
                             LocalDateTime conflictStart, LocalDateTime conflictEnd, 
                             Integer conflictingAppointmentId) {
            this.type = type;
            this.resourceName = resourceName;
            this.conflictStart = conflictStart;
            this.conflictEnd = conflictEnd;
            this.conflictingAppointmentId = conflictingAppointmentId;
        }
        
        // Getters and Setters
        public ConflictType getType() { return type; }
        public void setType(ConflictType type) { this.type = type; }
        
        public String getResourceName() { return resourceName; }
        public void setResourceName(String resourceName) { this.resourceName = resourceName; }
        
        public LocalDateTime getConflictStart() { return conflictStart; }
        public void setConflictStart(LocalDateTime conflictStart) { this.conflictStart = conflictStart; }
        
        public LocalDateTime getConflictEnd() { return conflictEnd; }
        public void setConflictEnd(LocalDateTime conflictEnd) { this.conflictEnd = conflictEnd; }
        
        public Integer getConflictingAppointmentId() { return conflictingAppointmentId; }
        public void setConflictingAppointmentId(Integer conflictingAppointmentId) { this.conflictingAppointmentId = conflictingAppointmentId; }
    }
    
    public enum ConflictType {
        TECHNICIAN_CONFLICT,
        ROOM_CONFLICT
    }
}
