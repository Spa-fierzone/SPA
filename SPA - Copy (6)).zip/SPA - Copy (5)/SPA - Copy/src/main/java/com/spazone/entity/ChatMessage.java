package com.spazone.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * ChatMessage entity representing individual messages in chat rooms
 * Supports different message types: TEXT, FILE, IMAGE, SYSTEM
 * Includes support for message threading, editing, and file attachments
 */
@Entity
@Table(name = "chat_messages")
public class ChatMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "message_id")
    private Integer messageId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "room_id", nullable = false)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler", "messages", "participants"})
    private ChatRoom chatRoom;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sender_id", nullable = false)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private User sender;

    @Column(name = "message_content", nullable = false, length = 4000, columnDefinition = "NVARCHAR(4000)")
    private String messageContent;

    @Column(name = "message_type", length = 20, columnDefinition = "NVARCHAR(20)")
    private String messageType = "TEXT"; // TEXT, FILE, IMAGE, SYSTEM

    @Column(name = "file_url", length = 500, columnDefinition = "NVARCHAR(500)")
    private String fileUrl;

    @Column(name = "file_name", length = 255, columnDefinition = "NVARCHAR(255)")
    private String fileName;

    @Column(name = "file_size")
    private Long fileSize;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "reply_to_message_id")
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private ChatMessage replyToMessage;

    @Column(name = "sent_at", nullable = false)
    private LocalDateTime sentAt;

    @Column(name = "edited_at")
    private LocalDateTime editedAt;

    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

    @Column(name = "is_system_message")
    private Boolean isSystemMessage = false;

    // Constructors
    public ChatMessage() {
    }

    public ChatMessage(ChatRoom chatRoom, User sender, String messageContent) {
        this.chatRoom = chatRoom;
        this.sender = sender;
        this.messageContent = messageContent;
        this.sentAt = LocalDateTime.now();
        this.messageType = "TEXT";
    }

    public ChatMessage(ChatRoom chatRoom, User sender, String messageContent, String messageType) {
        this(chatRoom, sender, messageContent);
        this.messageType = messageType;
    }

    // Lifecycle methods
    @PrePersist
    protected void onCreate() {
        if (sentAt == null) {
            sentAt = LocalDateTime.now();
        }
    }

    @PreUpdate
    protected void onUpdate() {
        if (editedAt == null) {
            editedAt = LocalDateTime.now();
        }
    }

    // Helper methods
    public boolean isTextMessage() {
        return "TEXT".equals(messageType);
    }

    public boolean isFileMessage() {
        return "FILE".equals(messageType);
    }

    public boolean isImageMessage() {
        return "IMAGE".equals(messageType);
    }

    public boolean isSystemMessage() {
        return "SYSTEM".equals(messageType) || Boolean.TRUE.equals(isSystemMessage);
    }

    public boolean isReply() {
        return replyToMessage != null;
    }

    public boolean isEdited() {
        return editedAt != null;
    }

    public boolean hasFile() {
        return fileUrl != null && !fileUrl.trim().isEmpty();
    }

    public void markAsDeleted() {
        this.isDeleted = true;
        this.messageContent = "[Tin nhắn đã bị xóa]"; // Vietnamese for "Message deleted"
    }

    public void editMessage(String newContent) {
        this.messageContent = newContent;
        this.editedAt = LocalDateTime.now();
    }

    public String getDisplayContent() {
        if (Boolean.TRUE.equals(isDeleted)) {
            return "[Tin nhắn đã bị xóa]";
        }
        return messageContent;
    }

    public String getFileSizeFormatted() {
        if (fileSize == null) {
            return null;
        }
        
        if (fileSize < 1024) {
            return fileSize + " B";
        } else if (fileSize < 1024 * 1024) {
            return String.format("%.1f KB", fileSize / 1024.0);
        } else {
            return String.format("%.1f MB", fileSize / (1024.0 * 1024.0));
        }
    }

    // Getters and Setters
    public Integer getMessageId() {
        return messageId;
    }

    public void setMessageId(Integer messageId) {
        this.messageId = messageId;
    }

    public ChatRoom getChatRoom() {
        return chatRoom;
    }

    public void setChatRoom(ChatRoom chatRoom) {
        this.chatRoom = chatRoom;
    }

    public User getSender() {
        return sender;
    }

    public void setSender(User sender) {
        this.sender = sender;
    }

    public String getMessageContent() {
        return messageContent;
    }

    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public ChatMessage getReplyToMessage() {
        return replyToMessage;
    }

    public void setReplyToMessage(ChatMessage replyToMessage) {
        this.replyToMessage = replyToMessage;
    }

    public LocalDateTime getSentAt() {
        return sentAt;
    }

    public void setSentAt(LocalDateTime sentAt) {
        this.sentAt = sentAt;
    }

    public LocalDateTime getEditedAt() {
        return editedAt;
    }

    public void setEditedAt(LocalDateTime editedAt) {
        this.editedAt = editedAt;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Boolean getIsSystemMessage() {
        return isSystemMessage;
    }

    public void setIsSystemMessage(Boolean isSystemMessage) {
        this.isSystemMessage = isSystemMessage;
    }

    @Override
    public String toString() {
        return "ChatMessage{" +
                "messageId=" + messageId +
                ", messageType='" + messageType + '\'' +
                ", sentAt=" + sentAt +
                ", isDeleted=" + isDeleted +
                '}';
    }
}
