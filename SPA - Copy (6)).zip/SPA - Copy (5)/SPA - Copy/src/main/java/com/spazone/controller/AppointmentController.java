package com.spazone.controller;

import com.spazone.dto.ApiResponse;
import com.spazone.dto.AppointmentBookingRequest;
import com.spazone.dto.AppointmentBookingResponse;
import com.spazone.entity.*;
import com.spazone.repository.AppointmentRepository;
import com.spazone.repository.AppointmentServiceRepository;
import com.spazone.repository.UserRepository;
import com.spazone.service.*;
import com.spazone.dto.ValidationResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/appointments")
public class AppointmentController {

    private static final Logger logger = LoggerFactory.getLogger(AppointmentController.class);

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private UserService userService;

    @Autowired
    private BranchService branchService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private InvoiceService invoiceService;

    @Autowired
    private AppointmentValidationService appointmentValidationService;

    @Autowired
    private SpaServiceService spaServiceService;

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private AppointmentServiceRepository appointmentServiceRepository;

    @Autowired
    private RoomService roomService;

    @Autowired
    private CancellationService cancellationService;

    private boolean isAuthenticatedUser(Authentication authentication) {
        return authentication != null &&
                authentication.isAuthenticated() &&
                !"anonymousUser".equals(authentication.getPrincipal());
    }

    /**
     * REST API: Get services by branch for AJAX requests
     */
    @GetMapping("/api/services/by-branch/{branchId}")
    @ResponseBody
    public List<Service> getServicesByBranch(@PathVariable Integer branchId) {
        return spaServiceService.findActiveByBranchId(branchId);
    }

    /**
     * AJAX API: Create appointment with JSON response
     */
    @PostMapping("/api/book")
    @ResponseBody
    public ResponseEntity<?> createAppointmentAjax(@RequestBody AppointmentBookingRequest request,
                                                  Authentication authentication) {
        if (!isAuthenticatedUser(authentication)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new ApiResponse(false, "Vui lòng đăng nhập để đặt lịch hẹn"));
        }

        try {
            // Validate request
            if (request.getServiceIds() == null || request.getServiceIds().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Vui lòng chọn ít nhất một dịch vụ"));
            }

            if (request.getBranchId() == null) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Vui lòng chọn chi nhánh"));
            }

            if (request.getDatePart() == null || request.getTimePart() == null) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Vui lòng chọn ngày và giờ hẹn"));
            }

            // Parse date and time
            LocalDateTime startTime = LocalDateTime.parse(request.getDatePart() + "T" + request.getTimePart());
            LocalDateTime maxAllowed = LocalDateTime.now().plusMonths(3);

            if (startTime.isAfter(maxAllowed)) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Bạn chỉ có thể đặt lịch trong vòng 3 tháng tới"));
            }

            if (startTime.isBefore(LocalDateTime.now())) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Không thể đặt lịch trong quá khứ"));
            }

            // Get entities
            Branch branch = branchService.getById(request.getBranchId());
            User customer = userService.findByUsername(authentication.getName());

            // Create appointment with multiple services
            Appointment appointment = new Appointment();
            appointment.setCustomer(customer);
            appointment.setBranch(branch);
            appointment.setAppointmentDate(startTime);
            appointment.setStartTime(startTime);
            appointment.setNotes(request.getNotes());


            // Add all services to the appointment
            for (Integer serviceId : request.getServiceIds()) {
                Service service = spaServiceService.getServiceById(serviceId);
                appointment.addService(service);
            }

            // Handle technician assignment
            User technician;
            if (request.getTechnicianId() == null || request.getTechnicianId() == 0) {
                // Auto-assign technician
                List<User> availableTechnicians = userService.findTechniciansByBranch(request.getBranchId());
                int totalDuration = appointment.getTotalDuration();
                LocalDateTime endTime = startTime.plusMinutes(totalDuration);

                List<User> freeTechnicians = availableTechnicians.stream()
                        .filter(t -> appointmentRepository.findConflictingAppointments(t.getUserId(), startTime, endTime).isEmpty())
                        .collect(java.util.stream.Collectors.toList());

                if (freeTechnicians.isEmpty()) {
                    return ResponseEntity.badRequest()
                            .body(new ApiResponse(false, "Không có kỹ thuật viên nào rảnh tại thời gian đã chọn"));
                }


                if (appointment.getRoom() == null && appointment.getBranch() != null) {
                    Room assignedRoom = roomService.autoAssignRoom(appointment.getBranch(), startTime, endTime);
                    if (assignedRoom == null) {
                        return ResponseEntity.badRequest()
                                .body(new ApiResponse(false, "Khong co phong co san trong thoi gian nay"));

                    }
                    appointment.setRoom(assignedRoom);
                }

                java.util.Collections.shuffle(freeTechnicians);
                technician = freeTechnicians.get(0);
            } else {
                technician = userService.getUserById(request.getTechnicianId());
            }

            appointment.setTechnician(technician);

            // BUSINESS RULE VALIDATION: Check for conflicts before creating appointment
            ValidationResult validation = appointmentValidationService.validateForCreation(
                technician.getUserId(),
                appointment.getRoom() != null ? appointment.getRoom().getId() : null,
                appointment.getStartTime(), appointment.getEndTime());

            if (!validation.isValid()) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, validation.getFormattedErrorMessage()));
            }

            // Create the appointment using the service layer
            appointmentService.create(appointment);

            // Create invoice
            Invoice invoice = invoiceService.generateInvoiceForAppointment(appointment);

            return ResponseEntity.ok(new AppointmentBookingResponse(true,
                    "Đặt lịch thành công với " + request.getServiceIds().size() + " dịch vụ!",
                    appointment.getAppointmentId(),
                    invoice.getInvoiceId()));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponse(false, "Không thể đặt lịch: " + e.getMessage()));
        }
    }

    private int validateAndCalculateDuration(Appointment appointment) {
        // Check if appointment has services
        if (appointment.getAppointmentServices() != null && !appointment.getAppointmentServices().isEmpty()) {
            // Validate each service
            for (com.spazone.entity.AppointmentServiceEntity appointmentService : appointment.getAppointmentServices()) {
                if (appointmentService.getService() == null) {
                    throw new IllegalArgumentException("Một trong các dịch vụ không hợp lệ.");
                }
                if (appointmentService.getService().getDuration() <= 0) {
                    throw new IllegalArgumentException("Thời lượng dịch vụ '" + appointmentService.getService().getName() + "' không hợp lệ.");
                }
                if (appointmentService.getQuantity() == null || appointmentService.getQuantity() <= 0) {
                    throw new IllegalArgumentException("Số lượng dịch vụ '" + appointmentService.getService().getName() + "' không hợp lệ.");
                }
            }
            return appointment.getTotalDuration();
        }
        else {
            throw new IllegalArgumentException("Cuộc hẹn phải có ít nhất một dịch vụ.");
        }
    }




    @GetMapping("/technicians-by-branch")
    @ResponseBody
    public List<Map<String, Object>> getTechniciansByBranch(@RequestParam(required = false) Integer branchId) {
        try {
            // Return empty list if branchId is not provided
            if (branchId == null) {
                return new ArrayList<>();
            }

            List<User> technicians = userRepository.findByBranchIdAndRoleName(branchId, "TECHNICIAN");
            return technicians.stream().map(technician -> {
                Map<String, Object> technicianMap = new HashMap<>();
                technicianMap.put("userId", technician.getUserId());
                technicianMap.put("fullName", technician.getFullName());
                technicianMap.put("username", technician.getUsername());
                technicianMap.put("email", technician.getEmail());
                technicianMap.put("phone", technician.getPhone());
                return technicianMap;
            }).collect(Collectors.toList());
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    @GetMapping("/api/branches/{branchId}/technicians")
    @ResponseBody
    public List<Map<String, Object>> getTechniciansByBranchApi(@PathVariable Integer branchId) {
        try {
            List<User> technicians = userRepository.findByBranchIdAndRoleName(branchId, "TECHNICIAN");
            return technicians.stream().map(technician -> {
                Map<String, Object> technicianMap = new HashMap<>();
                technicianMap.put("userId", technician.getUserId());
                technicianMap.put("fullName", technician.getFullName());
                technicianMap.put("username", technician.getUsername());
                technicianMap.put("email", technician.getEmail());
                technicianMap.put("phone", technician.getPhone());
                return technicianMap;
            }).collect(Collectors.toList());
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    @GetMapping("/available-rooms-for-edit")
    @ResponseBody
    public List<Room> getAvailableRoomsForEdit(@RequestParam(required = false) Integer appointmentId,
                                              @RequestParam(required = false) Integer branchId) {
        try {
            // Return empty list if required parameters are not provided
            if (appointmentId == null || branchId == null) {
                return new ArrayList<>();
            }

            Appointment appointment = appointmentService.findById(appointmentId);
            if (appointment == null) {
                return new ArrayList<>();
            }

            // Use total duration from all services in the appointment
            int totalDuration = appointment.getTotalDuration();
            if (totalDuration <= 0) {
                return new ArrayList<>();
            }

            // Calculate new end time based on total duration of all services
            LocalDateTime startTime = appointment.getStartTime();
            LocalDateTime endTime = startTime.plusMinutes(totalDuration);

            Branch branch = branchService.getById(branchId);
            List<Room> availableRooms = roomService.findAvailableRooms(branch, startTime, endTime);

            // Add current room if not already included
            if (appointment.getRoom() != null &&
                availableRooms.stream().noneMatch(room -> room.getId().equals(appointment.getRoom().getId()))) {
                availableRooms.add(appointment.getRoom());
            }

            return availableRooms;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    @GetMapping("/book")
    public String showBookingFormMulti(@RequestParam(value = "serviceIds", required = false) List<Integer> serviceIds,
                                       @RequestParam(value = "branchId", required = false) Integer branchId,
                                       @RequestParam(value = "datePart", required = false) String datePart,
                                       @RequestParam(value = "timePart", required = false) String timePart,
                                       Model model) {
        model.addAttribute("branches", branchService.findAllActive());
        model.addAttribute("technicians", userRepository.findUsersByRole("TECHNICIAN"));
        model.addAttribute("services", spaServiceService.findAllActive());
        model.addAttribute("selectedServiceIds", serviceIds);
        model.addAttribute("preSelectedBranchId", branchId); // Add pre-selected branch

        // Use findAvailableRooms if enough info is provided
        if (branchId != null && datePart != null && timePart != null) {
            Branch branch = branchService.getById(branchId);
            LocalDateTime startTime = LocalDateTime.parse(datePart + "T" + timePart);
            // For demo, assume 1 hour duration if not known
            LocalDateTime endTime = startTime.plusHours(1);
            List<Room> availableRooms = roomService.findAvailableRooms(branch, startTime, endTime);
            model.addAttribute("availableRooms", availableRooms);
        } else {
            model.addAttribute("availableRooms", java.util.Collections.emptyList());
        }
        return "appointment/form";
    }

    /**
     * Single Service Booking Form with Branch Pre-selection
     */
    @GetMapping("/book/{serviceId}")
    public String showSingleServiceBookingForm(@PathVariable Integer serviceId,
                                             @RequestParam(value = "branchId", required = false) Integer branchId,
                                             Model model) {
        Service service = spaServiceService.getServiceById(serviceId);
        if (service == null || !"active".equals(service.getStatus())) {
            return "redirect:/services";
        }

        // Create appointment object with pre-filled service
        Appointment appointment = new Appointment();
        appointment.addService(service);

        model.addAttribute("appointment", appointment);
        model.addAttribute("service", service);
        model.addAttribute("branches", branchService.findAllActive());
        model.addAttribute("technicians", userRepository.findUsersByRole("TECHNICIAN"));
        model.addAttribute("preSelectedBranchId", branchId != null ? branchId : service.getBranch().getBranchId());
        model.addAttribute("availableRooms", java.util.Collections.emptyList());

        return "appointment/single-service-form";
    }

    /**
     * Flow 1: Submit Single Service Booking
     * Creates appointment with single service using new data structure
     */
    @PostMapping("/book")
    public String submitSingleServiceBooking(@RequestParam("serviceId") Integer serviceId,
                                           @RequestParam(value = "branchId", required = false) Integer branchId,
                                           @RequestParam(value = "technicianId", required = false) Integer technicianId,
                                           @RequestParam("datePart") String datePart,
                                           @RequestParam("timePart") String timePart,
                                           @RequestParam(value = "roomId", required = false) Integer roomId,
                                           @RequestParam(value = "notes", required = false) String notes,
                                           Authentication authentication,
                                           RedirectAttributes redirectAttributes) {
        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }
        try {
            // Validate required parameters
            if (branchId == null) {
                redirectAttributes.addFlashAttribute("errorMessage", "Vui lòng chọn chi nhánh.");
                return "redirect:/appointments/book/" + serviceId;
            }
            LocalDateTime startTime = LocalDateTime.parse(datePart + "T" + timePart);
            LocalDateTime maxAllowed = LocalDateTime.now().plusMonths(3);
            if (startTime.isAfter(maxAllowed)) {
                redirectAttributes.addFlashAttribute("errorMessage", "Bạn chỉ có thể đặt lịch trong vòng 3 tháng tới.");
                return "redirect:/appointments/book";
            }
            Branch branch = branchService.getById(branchId);
            User customer = userService.findByUsername(authentication.getName());
            Service service = spaServiceService.getServiceById(serviceId);
            int duration = service.getDuration();
            LocalDateTime endTime = startTime.plusMinutes(duration);

            // Room validation
            Room selectedRoom = null;
            if (roomId != null) {
                selectedRoom = roomService.findById(roomId);
                if (selectedRoom == null) {
                    redirectAttributes.addFlashAttribute("errorMessage", "Phòng được chọn không tồn tại.");
                    return "redirect:/appointments/book/" + serviceId;
                }

                // Check if room is available
                List<Room> availableRooms = roomService.findAvailableRooms(branch, startTime, endTime);
                if (!availableRooms.contains(selectedRoom)) {
                    redirectAttributes.addFlashAttribute("errorMessage",
                        "Phòng " + selectedRoom.getName() + " đã được đặt trong thời gian này. Vui lòng chọn phòng khác.");
                    return "redirect:/appointments/book/" + serviceId;
                }
            }

            User technician;
            if (technicianId == null || technicianId == 0) {
                List<User> availableTechnicians = userService.findTechniciansByBranch(branchId);
                List<User> freeTechnicians = availableTechnicians.stream()
                        .filter(t -> appointmentRepository.findConflictingAppointments(t.getUserId(), startTime, endTime).isEmpty())
                        .collect(Collectors.toList());
                if (freeTechnicians.isEmpty()) {
                    redirectAttributes.addFlashAttribute("errorMessage", "Không có kỹ thuật viên nào rảnh tại thời gian đã chọn cho dịch vụ: " + service.getName());
                    return "redirect:/appointments/book";
                }
                Collections.shuffle(freeTechnicians);
                technician = freeTechnicians.get(0);
            } else {
                technician = userService.getUserById(technicianId);
            }

            // BUSINESS RULE VALIDATION: Check for conflicts before creating appointment
            ValidationResult validation = appointmentValidationService.validateForCreation(
                technician.getUserId(), roomId, startTime, endTime);

            if (!validation.isValid()) {
                redirectAttributes.addFlashAttribute("errorMessage", validation.getFormattedErrorMessage());
                return "redirect:/appointments/book";
            }

            // Create appointment using new structure (single service)
            Appointment appointment = new Appointment();
            appointment.setBranch(branch);
            appointment.setTechnician(technician);
            appointment.setCustomer(customer);
            appointment.setRoom(selectedRoom);
            appointment.setStartTime(startTime);
            appointment.setAppointmentDate(startTime);
            appointment.setNotes(notes);

            // Add service using new structure
            appointment.addService(service);

            // Also set legacy service field for backward compatibility

            appointmentService.create(appointment);

            // Create invoice and redirect to invoice detail page for payment
            Invoice invoice = invoiceService.generateInvoiceForAppointment(appointment);
            return "redirect:/invoices/" + invoice.getInvoiceId();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Không thể đặt lịch: " + e.getMessage());
            return "redirect:/appointments/book";
        }
    }

    @PostMapping("/book-multi")
    public String submitBookingMulti(@RequestParam("serviceIds") List<Integer> serviceIds,
                                     @RequestParam(value = "branchId", required = false) Integer branchId,
                                     @RequestParam(value = "technicianId", required = false) Integer technicianId,
                                     @RequestParam("datePart") String datePart,
                                     @RequestParam("timePart") String timePart,
                                     @RequestParam(value = "notes", required = false) String notes,
                                     Authentication authentication,
                                     RedirectAttributes redirectAttributes) {
        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }

        // Validate required parameters
        if (branchId == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Vui lòng chọn chi nhánh.");
            return "redirect:/appointments/book-multi";
        }
        try {
            LocalDateTime startTime = LocalDateTime.parse(datePart + "T" + timePart);
            LocalDateTime maxAllowed = LocalDateTime.now().plusMonths(3);
            if (startTime.isAfter(maxAllowed)) {
                redirectAttributes.addFlashAttribute("errorMessage", "Bạn chỉ có thể đặt lịch trong vòng 3 tháng tới.");
                return "redirect:/appointments/book";
            }
            Branch branch = branchService.getById(branchId);
            User customer = userService.findByUsername(authentication.getName());
            List<Appointment> createdAppointments = new java.util.ArrayList<>();
            for (Integer serviceId : serviceIds) {
                Service service = spaServiceService.getServiceById(serviceId);
                int duration = service.getDuration();
                LocalDateTime endTime = startTime.plusMinutes(duration);
                User technician;
                if (technicianId == null || technicianId == 0) {
                    List<User> availableTechnicians = userService.findTechniciansByBranch(branchId);
                    List<User> freeTechnicians = availableTechnicians.stream()
                            .filter(t -> appointmentRepository.findConflictingAppointments(t.getUserId(), startTime, endTime).isEmpty())
                            .collect(Collectors.toList());
                    if (freeTechnicians.isEmpty()) {
                        redirectAttributes.addFlashAttribute("errorMessage", "Không có kỹ thuật viên nào rảnh tại thời gian đã chọn cho dịch vụ: " + service.getName());
                        return "redirect:/appointments/book";
                    }
                    Collections.shuffle(freeTechnicians);
                    technician = freeTechnicians.get(0);
                } else {
                    technician = userService.getUserById(technicianId);
                }
                Appointment appointment = new Appointment();
                appointment.setBranch(branch);
                appointment.setTechnician(technician);
                appointment.setCustomer(customer);
                appointment.setStartTime(startTime);
                appointment.setAppointmentDate(startTime);
                appointment.setNotes(notes);
                appointmentService.create(appointment);
                createdAppointments.add(appointment);
            }
            // Generate a single invoice for all appointments
            Invoice invoice = invoiceService.createInvoiceForAppointments(createdAppointments, "PAYOS", notes);
            return "redirect:/payment/payos/" + invoice.getInvoiceId();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Không thể đặt lịch: " + e.getMessage());
            return "redirect:/appointments/book";
        }
    }

    @GetMapping("/my")
    public String viewMyAppointments(Model model,
                                     Authentication authentication,
                                     @RequestParam(defaultValue = "0") int page,
                                     @RequestParam(defaultValue = "6") int size) {
        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }
        String username = authentication.getName();
        User customer = userService.findByUsername(username);

        Pageable pageable = PageRequest.of(page, size);
        Page<Appointment> appointments = appointmentService.getByCustomer(customer, pageable);

        model.addAttribute("appointments", appointments);
        return "appointment/list";
    }

    @PostMapping("/cancel/{appointmentId}")
    public String cancelAppointment(@PathVariable Integer appointmentId,
                                    Authentication authentication,
                                    RedirectAttributes redirectAttributes) {
        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }

        try {
            String username = authentication.getName();
            User customer = userService.findByUsername(username);
            Appointment appointment = appointmentService.findById(appointmentId);

            if (appointment == null) {
                redirectAttributes.addFlashAttribute("errorMessage", "Không tìm thấy lịch hẹn.");
                return "redirect:/appointments/my";
            }

            // Use the new cancellation service for validation
            CancellationService.CancellationValidationResult validation = cancellationService.validateCancellation(appointment, customer);

            if (!validation.isCanCancel()) {
                redirectAttributes.addFlashAttribute("errorMessage", validation.getMessage());
                return "redirect:/appointments/my";
            }

            // Handle different cancellation types
            if ("STANDARD".equals(validation.getCancellationType())) {
                // Standard cancellation
                CancellationService.CancellationResult result = cancellationService.performStandardCancellation(
                    appointmentId, customer.getUserId(), "Khách hàng hủy lịch");

                if (result.isSuccess()) {
                    String message = result.getMessage();
                    if (result.isRefundProcessed()) {
                        message += " Tiền sẽ được hoàn lại trong 3-5 ngày làm việc.";
                    }
                    redirectAttributes.addFlashAttribute("successMessage", message);
                } else {
                    redirectAttributes.addFlashAttribute("errorMessage", result.getMessage());
                }
                return "redirect:/appointments/my";

            } else if ("LATE_UNPAID".equals(validation.getCancellationType())) {
                // Late cancellation - redirect to confirmation page
                redirectAttributes.addFlashAttribute("appointmentId", appointmentId);
                redirectAttributes.addFlashAttribute("warningMessage", validation.getWarningMessage());
                return "redirect:/appointments/cancel-confirmation";

            } else {
                redirectAttributes.addFlashAttribute("errorMessage", validation.getMessage());
                return "redirect:/appointments/my";
            }

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Có lỗi xảy ra khi hủy lịch hẹn: " + e.getMessage());
            return "redirect:/appointments/my";
        }
    }

    /**
     * Show late cancellation confirmation page
     */
    @GetMapping("/cancel-confirmation")
    public String showCancelConfirmation(@RequestParam(required = false) Integer appointmentId,
                                       @ModelAttribute("warningMessage") String warningMessage,
                                       Authentication authentication,
                                       Model model,
                                       RedirectAttributes redirectAttributes) {
        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }

        if (appointmentId == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Không tìm thấy lịch hẹn.");
            return "redirect:/appointments/my";
        }

        try {
            Appointment appointment = appointmentService.findById(appointmentId);
            if (appointment == null) {
                redirectAttributes.addFlashAttribute("errorMessage", "Không tìm thấy lịch hẹn.");
                return "redirect:/appointments/my";
            }

            model.addAttribute("appointment", appointment);
            model.addAttribute("warningMessage", warningMessage);
            return "appointment/cancel-confirmation";

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Có lỗi xảy ra: " + e.getMessage());
            return "redirect:/appointments/my";
        }
    }

    /**
     * Process late cancellation confirmation
     */
    @PostMapping("/cancel-late")
    public String processLateCancellation(@RequestParam Integer appointmentId,
                                        @RequestParam(required = false) String reason,
                                        Authentication authentication,
                                        RedirectAttributes redirectAttributes) {
        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }

        try {
            String username = authentication.getName();
            User customer = userService.findByUsername(username);

            CancellationService.CancellationResult result = cancellationService.performLateCancellation(
                appointmentId, customer.getUserId(), reason != null ? reason : "Khách hàng hủy muộn", true);

            if (result.isSuccess()) {
                redirectAttributes.addFlashAttribute("warningMessage", result.getMessage());
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", result.getMessage());
            }

            return "redirect:/appointments/my";

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Có lỗi xảy ra khi hủy lịch hẹn: " + e.getMessage());
            return "redirect:/appointments/my";
        }
    }

    @GetMapping("/{id}/treatment-records")
    public String viewTreatmentRecords(@PathVariable("id") Integer appointmentId, Model model) {
        Appointment appointment = appointmentService.findByIdWithTreatmentRecords(appointmentId);
        if (appointment == null) {
            return "redirect:/appointments?error=AppointmentNotFound";
        }

        model.addAttribute("appointment", appointment);
        model.addAttribute("treatmentRecords", appointment.getTreatmentRecords());
        return "appointment/treatment-records";
    }

    /**
     * Flow 2: Multiple Services Booking Form
     * Shows form for selecting multiple services for one appointment
     */
    @GetMapping("/book-multi")
    public String showMultiServiceBookingForm(@RequestParam(value = "serviceIds", required = false) String serviceIds,
                                            @RequestParam(value = "branchId", required = false) Integer branchId,
                                            Model model) {
        try {
            logger.info("Loading multi-service booking form with serviceIds: {}, branchId: {}", serviceIds, branchId);

            // Add basic model attributes with error handling
            List<Branch> branches = branchService.findAllActive();
            List<User> technicians = userRepository.findUsersByRole("TECHNICIAN");
            List<Service> allServices = spaServiceService.findAllActive();

            logger.debug("Found {} branches, {} technicians, {} services",
                branches != null ? branches.size() : 0,
                technicians != null ? technicians.size() : 0,
                allServices != null ? allServices.size() : 0);

            // Filter out services without branches to prevent template errors
            List<Service> validServices = allServices != null ?
                allServices.stream()
                    .filter(service -> service != null && service.getBranch() != null && service.getBranch().getBranchId() != null)
                    .collect(java.util.stream.Collectors.toList()) :
                java.util.Collections.emptyList();

            model.addAttribute("branches", branches != null ? branches : java.util.Collections.emptyList());
            model.addAttribute("technicians", technicians != null ? technicians : java.util.Collections.emptyList());
            model.addAttribute("services", validServices);
            model.addAttribute("bookingType", "multiple");

            // Handle pre-selected services from cart or URL
            if (serviceIds != null && !serviceIds.trim().isEmpty()) {
                try {
                    List<Integer> selectedServiceIds = java.util.Arrays.stream(serviceIds.split(","))
                            .map(String::trim)
                            .map(Integer::parseInt)
                            .collect(java.util.stream.Collectors.toList());
                    model.addAttribute("selectedServiceIds", selectedServiceIds);
                } catch (NumberFormatException e) {
                    // Invalid service IDs, ignore
                    model.addAttribute("selectedServiceIds", java.util.Collections.emptyList());
                }
            } else {
                model.addAttribute("selectedServiceIds", java.util.Collections.emptyList());
            }

            model.addAttribute("preSelectedBranchId", branchId);
            return "appointment/multi-service-form";

        } catch (Exception e) {
            // Log the error and redirect to a safe page
            logger.error("Error in showMultiServiceBookingForm: {}", e.getMessage(), e);
            model.addAttribute("errorMessage", "Có lỗi xảy ra khi tải trang đặt lịch. Vui lòng thử lại.");
            return "redirect:/services?error=booking_form_error";
        }
    }

    /**
     * New method: Create a single appointment with multiple services
     */
    @PostMapping("/book-single-with-services")
    @ResponseBody
    public ResponseEntity<?> submitSingleAppointmentWithServices(
            @RequestParam("serviceIds") List<Integer> serviceIds,
            @RequestParam(value = "branchId", required = false) Integer branchId,
            @RequestParam(value = "technicianId", required = false) Integer technicianId,
            @RequestParam("datePart") String datePart,
            @RequestParam("timePart") String timePart,
            @RequestParam(value = "roomId", required = false) Integer roomId,
            @RequestParam(value = "notes", required = false) String notes,
            Authentication authentication) {

        if (!isAuthenticatedUser(authentication)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new ApiResponse(false, "Vui lòng đăng nhập để đặt lịch hẹn"));
        }

        // Validate required parameters
        if (branchId == null) {
            return ResponseEntity.badRequest()
                    .body(new ApiResponse(false, "Vui lòng chọn chi nhánh"));
        }

        try {
            // Validate request parameters
            if (serviceIds == null || serviceIds.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Vui lòng chọn ít nhất một dịch vụ"));
            }

            if (branchId == null) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Vui lòng chọn chi nhánh"));
            }

            if (datePart == null || timePart == null) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Vui lòng chọn ngày và giờ hẹn"));
            }

            // Parse and validate date/time
            LocalDateTime startTime = LocalDateTime.parse(datePart + "T" + timePart);
            LocalDateTime maxAllowed = LocalDateTime.now().plusMonths(3);

            if (startTime.isAfter(maxAllowed)) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Bạn chỉ có thể đặt lịch trong vòng 3 tháng tới"));
            }

            if (startTime.isBefore(LocalDateTime.now())) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Không thể đặt lịch trong quá khứ"));
            }

            // Get entities
            Branch branch = branchService.getById(branchId);
            User customer = userService.findByUsername(authentication.getName());

            // Handle technician assignment
            User technician;
            if (technicianId == null || technicianId == 0) {
                // Auto-assign technician
                List<User> availableTechnicians = userService.findTechniciansByBranch(branchId);
                if (availableTechnicians.isEmpty()) {
                    return ResponseEntity.badRequest()
                            .body(new ApiResponse(false, "Không có kỹ thuật viên nào tại chi nhánh này"));
                }
                // We'll check availability after calculating total duration
                technician = null; // Will be assigned later
            } else {
                technician = userService.getUserById(technicianId);
                if (technician == null) {
                    return ResponseEntity.badRequest()
                            .body(new ApiResponse(false, "Kỹ thuật viên không tồn tại"));
                }
            }

            // Create appointment with multiple services
            Appointment appointment = new Appointment();
            appointment.setCustomer(customer);
            appointment.setBranch(branch);
            appointment.setAppointmentDate(startTime);
            appointment.setStartTime(startTime);
            appointment.setNotes(notes);

            // Add all services to the appointment
            for (Integer serviceId : serviceIds) {
                Service service = spaServiceService.getServiceById(serviceId);
                if (service == null) {
                    return ResponseEntity.badRequest()
                            .body(new ApiResponse(false, "Dịch vụ với ID " + serviceId + " không tồn tại"));
                }
                appointment.addService(service);
            }

            // Calculate total duration and end time
            int totalDuration = appointment.getTotalDuration();
            LocalDateTime endTime = startTime.plusMinutes(totalDuration);

            // Assign technician if auto-assignment was requested
            if (technician == null) {
                List<User> availableTechnicians = userService.findTechniciansByBranch(branchId);
                List<User> freeTechnicians = availableTechnicians.stream()
                        .filter(t -> appointmentRepository.findConflictingAppointments(t.getUserId(), startTime, endTime).isEmpty())
                        .collect(java.util.stream.Collectors.toList());

                if (freeTechnicians.isEmpty()) {
                    return ResponseEntity.badRequest()
                            .body(new ApiResponse(false, "Không có kỹ thuật viên nào rảnh tại thời gian đã chọn"));
                }

                java.util.Collections.shuffle(freeTechnicians);
                technician = freeTechnicians.get(0);
            } else {
                // Check technician availability for the total duration
                List<Appointment> conflicts = appointmentRepository.findConflictingAppointments(
                        technician.getUserId(), startTime, endTime);
                if (!conflicts.isEmpty()) {
                    return ResponseEntity.badRequest()
                            .body(new ApiResponse(false,
                                "Kỹ thuật viên không rảnh trong khoảng thời gian này (tổng thời gian: " + totalDuration + " phút)"));
                }
            }

            appointment.setTechnician(technician);

            // Handle room assignment
            Room selectedRoom = null;
            if (roomId != null) {
                selectedRoom = roomService.findById(roomId);
                if (selectedRoom == null) {
                    return ResponseEntity.badRequest()
                            .body(new ApiResponse(false, "Phòng được chọn không tồn tại"));
                }
            } else {
                // Auto-assign room
                selectedRoom = roomService.autoAssignRoom(branch, startTime, endTime);
                if (selectedRoom == null) {
                    return ResponseEntity.badRequest()
                            .body(new ApiResponse(false, "Không có phòng nào khả dụng cho thời gian này"));
                }
            }
            appointment.setRoom(selectedRoom);

            // BUSINESS RULE VALIDATION: Check for conflicts before creating appointment
            ValidationResult validation = appointmentValidationService.validateForCreation(
                technician.getUserId(),
                selectedRoom != null ? selectedRoom.getId() : null,
                appointment.getStartTime(), appointment.getEndTime());

            if (!validation.isValid()) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, validation.getFormattedErrorMessage()));
            }

            // Create the appointment using the service layer
            appointmentService.create(appointment);

            // Create invoice
            Invoice invoice = invoiceService.generateInvoiceForAppointment(appointment);

            return ResponseEntity.ok(new AppointmentBookingResponse(true,
                    "Đặt lịch thành công với " + serviceIds.size() + " dịch vụ!",
                    appointment.getAppointmentId(),
                    invoice.getInvoiceId()));

        } catch (Exception e) {
            logger.error("Error in submitSingleAppointmentWithServices: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponse(false, "Không thể đặt lịch: " + e.getMessage()));
        }
    }

    @GetMapping("/edit/{id}")
    public String showEditAppointmentForm(@PathVariable("id") Integer id, Model model) {
        try {
            Appointment appointment = appointmentService.findById(id);
            if (appointment == null) {
                return "redirect:/reception/appointments?error=AppointmentNotFound";
            }

            // Check if appointment is in the past
            LocalDate appointmentDate = appointment.getAppointmentDate().toLocalDate();
            LocalDate today = LocalDate.now();
            boolean isPastAppointment = appointmentDate.isBefore(today);

        List<Room> availableRooms = roomService.findAvailableRooms(
            appointment.getBranch(),
            appointment.getStartTime(),
            appointment.getEndTime()
        );

        // Add current room to available rooms if not already included
        if (appointment.getRoom() != null &&
            availableRooms.stream().noneMatch(room -> room.getId().equals(appointment.getRoom().getId()))) {
            availableRooms.add(appointment.getRoom());
        }

        boolean canCheckout = appointment.getCheckinTime() != null && appointment.getCheckoutTime() == null;

            model.addAttribute("appointment", appointment);
            model.addAttribute("availableRooms", availableRooms);
            model.addAttribute("branches", branchService.findAllActive());
            model.addAttribute("technicians", userRepository.findUsersByRole("TECHNICIAN"));
            model.addAttribute("customers", userRepository.findUsersByRole("CUSTOMER"));
            model.addAttribute("services", spaServiceService.findAllActive());
            model.addAttribute("canCheckout", canCheckout);
            model.addAttribute("isPastAppointment", isPastAppointment);
            model.addAttribute("isReadOnly", isPastAppointment);

            return "reception/appointment-update";

        } catch (Exception e) {
            System.err.println("Error loading appointment edit form: " + e.getMessage());
            e.printStackTrace();
            return "redirect:/reception/appointments?error=LoadError";
        }
    }

    @PostMapping("/edit/{id}")
    public String updateAppointment(@PathVariable("id") Integer id,
                                    @RequestParam(value = "serviceId", required = false) Integer serviceId,
                                    @RequestParam(value = "roomId", required = false) Integer roomId,
                                    @RequestParam(value = "checkinTime", required = false) String checkinTimeStr,
                                    @RequestParam(value = "checkoutTime", required = false) String checkoutTimeStr,
                                    RedirectAttributes redirectAttributes,
                                    Authentication authentication) {
        Appointment appointment = appointmentService.findById(id);
        if (appointment == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Không tìm thấy lịch hẹn.");
            return "redirect:/reception/appointments";
        }

        // Check if appointment is in the past - prevent editing past appointments
        LocalDate appointmentDate = appointment.getAppointmentDate().toLocalDate();
        LocalDate today = LocalDate.now();
        if (appointmentDate.isBefore(today)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Không thể chỉnh sửa lịch hẹn trong quá khứ.");
            return "redirect:/reception/appointments";
        }

        try {
            // TODO: Update this method to handle multiple services instead of legacy single service
            // For now, we'll disable service editing until multi-service edit is implemented
            boolean serviceChanged = false;

            // Get first service from appointment services (temporary workaround)
            List<Service> currentServices = appointment.getServices();
            Service oldService = currentServices.isEmpty() ? null : currentServices.get(0);

            // Update service if provided and different from current
            if (serviceId != null && oldService != null && !serviceId.equals(oldService.getServiceId())) {
                // TODO: Implement multi-service editing
                redirectAttributes.addFlashAttribute("errorMessage", "Chỉnh sửa dịch vụ hiện chưa được hỗ trợ cho lịch hẹn nhiều dịch vụ. Vui lòng hủy và tạo lịch hẹn mới.");
                return "redirect:/appointments/edit/" + id;
            }

            // Update room if provided and validate availability
            if (roomId != null && roomId > 0) {
                Room newRoom = roomService.findById(roomId);
                if (newRoom == null) {
                    redirectAttributes.addFlashAttribute("errorMessage", "Phòng được chọn không tồn tại.");
                    return "redirect:/appointments/edit/" + id;
                }

                // Validate room availability for the appointment time slot
                List<Room> availableRooms = roomService.findAvailableRooms(
                    appointment.getBranch(),
                    appointment.getStartTime(),
                    appointment.getEndTime()
                );

                // Check if the selected room is available (excluding current appointment)
                boolean isRoomAvailable = availableRooms.stream()
                    .anyMatch(room -> room.getId().equals(roomId)) ||
                    (appointment.getRoom() != null && appointment.getRoom().getId().equals(roomId));

                if (!isRoomAvailable) {
                    redirectAttributes.addFlashAttribute("errorMessage",
                        "Phòng " + newRoom.getName() + " không khả dụng trong thời gian này. Vui lòng chọn phòng khác.");
                    return "redirect:/appointments/edit/" + id;
                }

                appointment.setRoom(newRoom);
            }

            // Update check-in time if provided
            if (checkinTimeStr != null && !checkinTimeStr.isEmpty()) {
                try {
                    LocalDateTime checkinTime = LocalDateTime.parse(checkinTimeStr);
                    appointment.setCheckinTime(checkinTime);
                    // Update status if not already checked in
                    if ("scheduled".equals(appointment.getStatus())) {
                        appointment.setStatus("CHECK_IN");
                    }
                } catch (Exception e) {
                    redirectAttributes.addFlashAttribute("errorMessage", "Định dạng thời gian check-in không hợp lệ.");
                    return "redirect:/appointments/edit/" + id;
                }
            }

            // Update check-out time if provided
            if (checkoutTimeStr != null && !checkoutTimeStr.isEmpty()) {
                try {
                    LocalDateTime checkoutTime = LocalDateTime.parse(checkoutTimeStr);
                    // Validate that check-out is after check-in
                    if (appointment.getCheckinTime() != null && checkoutTime.isBefore(appointment.getCheckinTime())) {
                        redirectAttributes.addFlashAttribute("errorMessage", "Thời gian check-out phải sau thời gian check-in.");
                        return "redirect:/appointments/edit/" + id;
                    }
                    appointment.setCheckoutTime(checkoutTime);
                    appointment.setStatus("CHECKED_OUT");
                } catch (Exception e) {
                    redirectAttributes.addFlashAttribute("errorMessage", "Định dạng thời gian check-out không hợp lệ.");
                    return "redirect:/appointments/edit/" + id;
                }
            }

            appointmentService.update(appointment);

            // Update invoice if service was changed
            if (serviceChanged) {
                updateInvoiceForServiceChange(appointment, oldService);
                redirectAttributes.addFlashAttribute("successMessage", "Cập nhật lịch hẹn và hóa đơn thành công.");
            } else {
                redirectAttributes.addFlashAttribute("successMessage", "Cập nhật lịch hẹn thành công.");
            }
            return "redirect:/reception/appointments";

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Lỗi khi cập nhật lịch hẹn: " + e.getMessage());
            return "redirect:/appointments/edit/" + id;
        }
    }

    @PostMapping("/reception/cancel/{id}")
    public String cancelAppointmentAdmin(@PathVariable("id") Integer id,
                                         @RequestParam String cancellationReason,
                                         RedirectAttributes redirectAttributes) {
        boolean success = appointmentService.cancelAppointment(id, cancellationReason);
        if (success) {
            redirectAttributes.addFlashAttribute("successMessage", "Hủy lịch hẹn thành công. Capacity phòng đã được hoàn lại.");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Không thể hủy lịch hẹn.");
        }
        return "redirect:/reception/appointments";
    }

    @PostMapping("/delete/{id}")
    public String deleteAppointment(@PathVariable("id") Integer id,
                                    RedirectAttributes redirectAttributes) {
        boolean success = appointmentService.deleteAppointment(id);
        if (success) {
            redirectAttributes.addFlashAttribute("successMessage", "Xóa lịch hẹn thành công. Capacity phòng đã được hoàn lại.");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Không thể xóa lịch hẹn.");
        }
        return "redirect:/reception/appointments";
    }



    /**
     * View appointment details with all services
     */
    @GetMapping("/details/{id}")
    public String viewAppointmentDetails(@PathVariable("id") Integer id, Model model, Authentication authentication) {
        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }

        Appointment appointment = appointmentService.findById(id);
        if (appointment == null) {
            return "redirect:/appointments/my?error=AppointmentNotFound";
        }

        // Check if user has permission to view this appointment
        User currentUser = userService.findByUsername(authentication.getName());
        boolean canView = appointment.getCustomer().getUserId().equals(currentUser.getUserId()) ||
                         appointment.getTechnician().getUserId().equals(currentUser.getUserId()) ||
                         currentUser.getRole().equals("ADMIN") ||
                         currentUser.getRole().equals("MANAGER") ||
                         currentUser.getRole().equals("RECEPTIONIST");

        if (!canView) {
            return "redirect:/appointments/my?error=Unauthorized";
        }

        // Get all services for this appointment (supports both legacy and new structure)
        List<Service> services = appointment.getServices();
        List<AppointmentServiceEntity> appointmentServices = appointment.getAppointmentServices();

        model.addAttribute("appointment", appointment);
        model.addAttribute("services", services);
        model.addAttribute("appointmentServices", appointmentServices);
        model.addAttribute("hasMultipleServices", appointmentServices != null && !appointmentServices.isEmpty());
        model.addAttribute("totalDuration", appointment.getTotalDuration());
        model.addAttribute("totalPrice", appointment.getTotalPrice());
        model.addAttribute("serviceCount", appointment.getServiceCount());

        return "appointment/details";
    }

    /**
     * Enhanced Appointment Detail View with Editing Capabilities
     */
    @GetMapping("/edit-detailed/{id}")
    public String showDetailedEditForm(@PathVariable("id") Integer id, Model model, Authentication authentication) {
        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }

        Appointment appointment = appointmentService.findById(id);
        if (appointment == null) {
            return "redirect:/appointments/my?error=AppointmentNotFound";
        }

        // Check permissions
        User currentUser = userService.findByUsername(authentication.getName());
        boolean canEdit = appointment.getCustomer().getUserId().equals(currentUser.getUserId()) ||
                         currentUser.getRole().equals("ADMIN") ||
                         currentUser.getRole().equals("MANAGER") ||
                         currentUser.getRole().equals("RECEPTIONIST");

        if (!canEdit) {
            return "redirect:/appointments/my?error=Unauthorized";
        }

        // Check if appointment is in the past
        LocalDate appointmentDate = appointment.getAppointmentDate().toLocalDate();
        LocalDate today = LocalDate.now();
        boolean isPastAppointment = appointmentDate.isBefore(today);

        // Get available rooms for the current time slot
        List<Room> availableRooms = roomService.findAvailableRooms(
            appointment.getBranch(),
            appointment.getStartTime(),
            appointment.getEndTime()
        );

        // Add current room to available rooms if not already included
        if (appointment.getRoom() != null &&
            availableRooms.stream().noneMatch(room -> room.getId().equals(appointment.getRoom().getId()))) {
            availableRooms.add(appointment.getRoom());
        }

        // Get all services for selection and convert to DTOs to avoid circular references
        List<Service> allServices = spaServiceService.findAllActive();
        List<com.spazone.dto.ServiceDTO> allServiceDTOs = allServices.stream()
                .map(com.spazone.dto.ServiceDTO::new)
                .collect(java.util.stream.Collectors.toList());

        // Convert current appointment services to DTOs
        List<com.spazone.dto.AppointmentServiceDTO> currentServiceDTOs = appointment.getAppointmentServices().stream()
                .map(com.spazone.dto.AppointmentServiceDTO::fromEntity)
                .collect(java.util.stream.Collectors.toList());

        // Get current services (both legacy and new structure)
        List<Service> currentServices = appointment.getServices();
        List<com.spazone.entity.AppointmentServiceEntity> appointmentServices = appointment.getAppointmentServices();

        model.addAttribute("appointment", appointment);
        model.addAttribute("currentServices", currentServiceDTOs);
        model.addAttribute("appointmentServices", appointmentServices);
        model.addAttribute("allServices", allServiceDTOs);
        model.addAttribute("availableRooms", availableRooms);
        model.addAttribute("branches", branchService.findAllActive());
        model.addAttribute("technicians", userRepository.findByBranchIdAndRoleName(appointment.getBranch().getBranchId(), "TECHNICIAN"));
        model.addAttribute("isPastAppointment", isPastAppointment);
        model.addAttribute("isReadOnly", isPastAppointment);
        model.addAttribute("hasMultipleServices", appointmentServices != null && !appointmentServices.isEmpty());
        model.addAttribute("totalDuration", appointment.getTotalDuration());
        model.addAttribute("totalPrice", appointment.getTotalPrice());

        return "customer/appointment-edit-multi";
    }

    /**
     * Handle detailed appointment editing
     */
    @PostMapping("/edit-detailed/{id}")
    public String updateDetailedAppointment(@PathVariable("id") Integer id,
                                          @RequestParam(value = "serviceIds", required = false) List<Integer> serviceIds,
                                          @RequestParam(value = "quantities", required = false) List<Integer> quantities,
                                          @RequestParam(value = "customPrices", required = false) List<String> customPrices,
                                          @RequestParam(value = "serviceNotes", required = false) List<String> serviceNotes,
                                          @RequestParam(value = "datePart", required = false) String datePart,
                                          @RequestParam(value = "timePart", required = false) String timePart,
                                          @RequestParam(value = "technicianId", required = false) Integer technicianId,
                                          @RequestParam(value = "roomId", required = false) Integer roomId,
                                          @RequestParam(value = "notes", required = false) String notes,
                                          RedirectAttributes redirectAttributes,
                                          Authentication authentication) {

        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }

        try {
            Appointment appointment = appointmentService.findById(id);
            if (appointment == null) {
                redirectAttributes.addFlashAttribute("errorMessage", "Không tìm thấy lịch hẹn.");
                return "redirect:/appointments/my";
            }

            // Check permissions
            User currentUser = userService.findByUsername(authentication.getName());
            boolean canEdit = appointment.getCustomer().getUserId().equals(currentUser.getUserId()) ||
                             currentUser.getRole().equals("ADMIN") ||
                             currentUser.getRole().equals("MANAGER") ||
                             currentUser.getRole().equals("RECEPTIONIST");

            if (!canEdit) {
                redirectAttributes.addFlashAttribute("errorMessage", "Bạn không có quyền chỉnh sửa lịch hẹn này.");
                return "redirect:/appointments/my";
            }

            // Check if appointment is in the past
            LocalDate appointmentDate = appointment.getAppointmentDate().toLocalDate();
            LocalDate today = LocalDate.now();
            if (appointmentDate.isBefore(today)) {
                redirectAttributes.addFlashAttribute("errorMessage", "Không thể chỉnh sửa lịch hẹn trong quá khứ.");
                return "redirect:/appointments/edit-detailed/" + id;
            }

            boolean appointmentChanged = false;

            // Update services if provided
            if (serviceIds != null && !serviceIds.isEmpty()) {
                // Use service method to update services (handles transaction properly)
                appointmentService.updateAppointmentServices(appointment.getAppointmentId(), serviceIds, quantities);
                appointmentChanged = true;

                // Refresh the appointment to get updated services
                appointment = appointmentService.findById(id);
            }

            // Update appointment date/time if provided
            if (datePart != null && timePart != null && !datePart.isEmpty() && !timePart.isEmpty()) {
                LocalDateTime newStartTime = LocalDateTime.parse(datePart + "T" + timePart);
                LocalDateTime maxAllowed = LocalDateTime.now().plusMonths(3);

                if (newStartTime.isAfter(maxAllowed)) {
                    redirectAttributes.addFlashAttribute("errorMessage", "Bạn chỉ có thể đặt lịch trong vòng 3 tháng tới.");
                    return "redirect:/appointments/edit-detailed/" + id;
                }

                if (!newStartTime.equals(appointment.getStartTime())) {
                    // BUSINESS RULE VALIDATION: Check for conflicts when changing appointment time
                    int totalDuration = appointment.getTotalDuration();
                    LocalDateTime newEndTime = newStartTime.plusMinutes(totalDuration);

                    ValidationResult validation = appointmentValidationService.validateForEditing(
                        id,
                        appointment.getTechnician().getUserId(),
                        appointment.getRoom() != null ? appointment.getRoom().getId() : null,
                        newStartTime, newEndTime);

                    if (!validation.isValid()) {
                        redirectAttributes.addFlashAttribute("errorMessage", validation.getFormattedErrorMessage());
                        return "redirect:/appointments/edit-detailed/" + id;
                    }

                    appointment.setStartTime(newStartTime);
                    appointment.setAppointmentDate(newStartTime);
                    appointment.setEndTime(newEndTime);
                    appointmentChanged = true;
                }
            }

            // Update technician if provided
            if (technicianId != null && !technicianId.equals(appointment.getTechnician().getUserId())) {
                User newTechnician = userService.getUserById(technicianId);
                if (newTechnician != null) {
                    // BUSINESS RULE VALIDATION: Check new technician availability
                    ValidationResult validation = appointmentValidationService.validateForEditing(
                        id,
                        technicianId,
                        appointment.getRoom() != null ? appointment.getRoom().getId() : null,
                        appointment.getStartTime(), appointment.getEndTime());

                    if (!validation.isValid()) {
                        redirectAttributes.addFlashAttribute("errorMessage", validation.getFormattedErrorMessage());
                        return "redirect:/appointments/edit-detailed/" + id;
                    }

                    appointment.setTechnician(newTechnician);
                    appointmentChanged = true;
                }
            }

            // Update room if provided
            if (roomId != null && (appointment.getRoom() == null || !roomId.equals(appointment.getRoom().getId()))) {
                Room newRoom = roomService.findById(roomId);
                if (newRoom != null) {
                    // BUSINESS RULE VALIDATION: Check new room availability
                    ValidationResult validation = appointmentValidationService.validateForEditing(
                        id,
                        appointment.getTechnician().getUserId(),
                        roomId,
                        appointment.getStartTime(), appointment.getEndTime());

                    if (!validation.isValid()) {
                        redirectAttributes.addFlashAttribute("errorMessage", validation.getFormattedErrorMessage());
                        return "redirect:/appointments/edit-detailed/" + id;
                    }

                    appointment.setRoom(newRoom);
                    appointmentChanged = true;
                }
            }

            // Update notes if provided
            if (notes != null) {
                appointment.setNotes(notes);
                appointmentChanged = true;
            }

            if (appointmentChanged) {
                appointmentService.update(appointment);
                redirectAttributes.addFlashAttribute("successMessage", "Cập nhật lịch hẹn thành công!");
            }

            return "redirect:/appointments/edit-detailed/" + id;

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Lỗi khi cập nhật lịch hẹn: " + e.getMessage());
            return "redirect:/appointments/edit-detailed/" + id;
        }
    }

    /**
     * API endpoint for getting available rooms (single service)
     */
    @GetMapping("/api/rooms/available")
    @ResponseBody
    public List<Room> getAvailableRooms(@RequestParam Integer branchId,
                                       @RequestParam String datePart,
                                       @RequestParam String timePart,
                                       @RequestParam(required = false) Integer serviceId) {
        try {
            LocalDateTime startTime = LocalDateTime.parse(datePart + "T" + timePart);

            // Calculate end time based on service duration or default
            int duration = 60; // Default duration
            if (serviceId != null) {
                Service service = spaServiceService.getServiceById(serviceId);
                if (service != null) {
                    duration = service.getDuration();
                }
            }

            LocalDateTime endTime = startTime.plusMinutes(duration);
            Branch branch = branchService.getById(branchId);

            if (branch != null) {
                return roomService.findAvailableRooms(branch, startTime, endTime);
            }
        } catch (Exception e) {
            // Log error and return empty list
            System.err.println("Error getting available rooms: " + e.getMessage());
        }

        return new ArrayList<>();
    }

    /**
     * API endpoint for getting available rooms (multiple services)
     */
    @GetMapping("/api/rooms/available-multi")
    @ResponseBody
    public List<Room> getAvailableRoomsForMultiServices(@RequestParam Integer branchId,
                                                        @RequestParam String datePart,
                                                        @RequestParam String timePart,
                                                        @RequestParam List<Integer> serviceIds) {
        try {
            LocalDateTime startTime = LocalDateTime.parse(datePart + "T" + timePart);

            // Calculate total duration for all services
            int totalDuration = 0;
            for (Integer serviceId : serviceIds) {
                Service service = spaServiceService.getServiceById(serviceId);
                if (service != null) {
                    totalDuration += service.getDuration();
                }
            }

            // Default to 60 minutes if no services selected
            if (totalDuration == 0) {
                totalDuration = 60;
            }

            LocalDateTime endTime = startTime.plusMinutes(totalDuration);
            Branch branch = branchService.getById(branchId);

            if (branch != null) {
                return roomService.findAvailableRooms(branch, startTime, endTime);
            }
        } catch (Exception e) {
            // Log error and return empty list
            System.err.println("Error getting available rooms for multi-services: " + e.getMessage());
        }

        return new ArrayList<>();
    }




    private void updateInvoiceForServiceChange(Appointment appointment, Service oldService) {
        try {
            // Find the invoice for this appointment
            List<Invoice> invoices = invoiceService.getByCustomer(appointment.getCustomer());
            Invoice appointmentInvoice = invoices.stream()
                .filter(invoice -> invoice.getAppointment() != null &&
                        invoice.getAppointment().getAppointmentId().equals(appointment.getAppointmentId()))
                .findFirst()
                .orElse(null);

            if (appointmentInvoice != null) {
                // Calculate price difference
                BigDecimal oldPrice = oldService.getPrice();
                BigDecimal newPrice = appointment.getAppointmentServices().getFirst().getTotalPrice();
                BigDecimal priceDifference = newPrice.subtract(oldPrice);

                // Update both total amount and final amount
                BigDecimal newTotalAmount = appointmentInvoice.getTotalAmount().add(priceDifference);
                appointmentInvoice.setTotalAmount(newTotalAmount);

                // Update final amount (considering any existing discounts)
                BigDecimal currentDiscount = appointmentInvoice.getDiscountAmount() != null ?
                    appointmentInvoice.getDiscountAmount() : BigDecimal.ZERO;
                BigDecimal newFinalAmount = newTotalAmount.subtract(currentDiscount);
                appointmentInvoice.setFinalAmount(newFinalAmount);

                // Update timestamp
                appointmentInvoice.setUpdatedAt(LocalDateTime.now());

                // Add note about the service change
                String currentNotes = appointmentInvoice.getPaymentNotes() != null ? appointmentInvoice.getPaymentNotes() : "";
                String serviceChangeNote = String.format("\n[%s] Dịch vụ được thay đổi từ '%s' sang '%s'. Chênh lệch: %s VND",
                    LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")),
                    oldService.getName(),
                    appointment.getServices().getFirst().getName(),
                    priceDifference.compareTo(BigDecimal.ZERO) >= 0 ? "+" + priceDifference : priceDifference.toString());
                appointmentInvoice.setPaymentNotes(currentNotes + serviceChangeNote);

                invoiceService.save(appointmentInvoice);

                System.out.println("Invoice updated successfully for appointment " + appointment.getAppointmentId() +
                    ". New total: " + newTotalAmount + ", New final amount: " + newFinalAmount);
            } else {
                System.err.println("No invoice found for appointment " + appointment.getAppointmentId());
            }
        } catch (Exception e) {
            // Log error but don't fail the appointment update
            System.err.println("Error updating invoice for service change: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
