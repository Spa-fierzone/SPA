package com.spazone.enums;

public enum ShiftType {
    MORNING,
    AFTERNOON,
    EVENING,
    NIGHT,
    FULL_DAY
}
