package com.spazone.service;

import com.spazone.entity.Appointment;
import com.spazone.entity.Room;
import com.spazone.entity.User;
import com.spazone.dto.ValidationResult;

import java.time.LocalDateTime;
import java.util.List;

public interface AppointmentValidationService {
    
    /**
     * Validates if a technician is available for the specified time period
     * @param technicianId The technician to check
     * @param startTime Start time of the appointment
     * @param endTime End time of the appointment
     * @param excludeAppointmentId Appointment ID to exclude from conflict check (for editing)
     * @return ValidationResult with conflict details
     */
    ValidationResult validateTechnicianAvailability(Integer technicianId, LocalDateTime startTime, 
                                                   LocalDateTime endTime, Integer excludeAppointmentId);
    
    /**
     * Validates if a room is available for the specified time period
     * @param roomId The room to check
     * @param startTime Start time of the appointment
     * @param endTime End time of the appointment
     * @param excludeAppointmentId Appointment ID to exclude from conflict check (for editing)
     * @return ValidationResult with conflict details
     */
    ValidationResult validateRoomAvailability(Integer roomId, LocalDateTime startTime, 
                                             LocalDateTime endTime, Integer excludeAppointmentId);
    
    /**
     * Comprehensive validation for appointment creation/modification
     * @param technicianId The assigned technician
     * @param roomId The assigned room (can be null)
     * @param startTime Start time of the appointment
     * @param endTime End time of the appointment
     * @param excludeAppointmentId Appointment ID to exclude from conflict check (for editing)
     * @return ValidationResult with all conflict details
     */
    ValidationResult validateAppointmentScheduling(Integer technicianId, Integer roomId, 
                                                   LocalDateTime startTime, LocalDateTime endTime, 
                                                   Integer excludeAppointmentId);
    
    /**
     * Get suggested alternative time slots when conflicts exist
     * @param technicianId The assigned technician
     * @param roomId The assigned room (can be null)
     * @param preferredStartTime Preferred start time
     * @param durationMinutes Duration in minutes
     * @param excludeAppointmentId Appointment ID to exclude from conflict check
     * @return List of suggested time slots
     */
    List<LocalDateTime> getSuggestedTimeSlots(Integer technicianId, Integer roomId, 
                                             LocalDateTime preferredStartTime, int durationMinutes, 
                                             Integer excludeAppointmentId);
    
    /**
     * Validates appointment for creation (convenience method)
     * @param technicianId The assigned technician
     * @param roomId The assigned room (can be null)
     * @param startTime Start time of the appointment
     * @param endTime End time of the appointment
     * @return ValidationResult with conflict details
     */
    default ValidationResult validateForCreation(Integer technicianId, Integer roomId, 
                                                LocalDateTime startTime, LocalDateTime endTime) {
        return validateAppointmentScheduling(technicianId, roomId, startTime, endTime, null);
    }
    
    /**
     * Validates appointment for editing (convenience method)
     * @param appointmentId The appointment being edited
     * @param technicianId The assigned technician
     * @param roomId The assigned room (can be null)
     * @param startTime Start time of the appointment
     * @param endTime End time of the appointment
     * @return ValidationResult with conflict details
     */
    default ValidationResult validateForEditing(Integer appointmentId, Integer technicianId, Integer roomId, 
                                               LocalDateTime startTime, LocalDateTime endTime) {
        return validateAppointmentScheduling(technicianId, roomId, startTime, endTime, appointmentId);
    }
}
