package com.spazone.service;

import com.spazone.entity.AppealRequest;
import com.spazone.entity.CustomerViolation;
import com.spazone.entity.User;

import java.util.List;

public interface AppealService {
    
    /**
     * Submit a new appeal request
     */
    AppealRequest submitAppeal(User customer, CustomerViolation violation, String appealType, String reason, String supportingDocuments);
    
    /**
     * Submit appeal for booking restriction removal
     */
    AppealRequest submitBookingRestrictionAppeal(User customer, String reason, String supportingDocuments);
    
    /**
     * Get all appeals for a customer
     */
    List<AppealRequest> getCustomerAppeals(User customer);
    
    /**
     * Get pending appeals for review
     */
    List<AppealRequest> getPendingAppeals();
    
    /**
     * Get appeals by status
     */
    List<AppealRequest> getAppealsByStatus(String status);
    
    /**
     * Review an appeal (approve/reject)
     */
    AppealResult reviewAppeal(Integer appealId, Integer reviewerId, String decision, String reviewNotes, String resolution);
    
    /**
     * Check if customer has pending appeals of a specific type
     */
    boolean hasPendingAppeal(User customer, String appealType);
    
    /**
     * Get appeal by ID
     */
    AppealRequest getAppealById(Integer appealId);
    
    /**
     * Update appeal status
     */
    void updateAppealStatus(Integer appealId, String status);
    
    /**
     * Result class for appeal operations
     */
    class AppealResult {
        private boolean success;
        private String message;
        private AppealRequest appeal;
        private boolean customerRestrictionRemoved;
        
        public AppealResult(boolean success, String message) {
            this.success = success;
            this.message = message;
        }
        
        public AppealResult(boolean success, String message, AppealRequest appeal) {
            this.success = success;
            this.message = message;
            this.appeal = appeal;
        }
        
        // Getters and setters
        public boolean isSuccess() { return success; }
        public void setSuccess(boolean success) { this.success = success; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public AppealRequest getAppeal() { return appeal; }
        public void setAppeal(AppealRequest appeal) { this.appeal = appeal; }
        public boolean isCustomerRestrictionRemoved() { return customerRestrictionRemoved; }
        public void setCustomerRestrictionRemoved(boolean customerRestrictionRemoved) { this.customerRestrictionRemoved = customerRestrictionRemoved; }
    }
}
