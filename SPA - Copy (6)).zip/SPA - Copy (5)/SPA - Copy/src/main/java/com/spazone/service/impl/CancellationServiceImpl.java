package com.spazone.service.impl;

import com.spazone.entity.*;
import com.spazone.repository.*;
import com.spazone.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

@Service
public class CancellationServiceImpl implements CancellationService {

    @Autowired
    private AppointmentRepository appointmentRepository;
    
    @Autowired
    private InvoiceRepository invoiceRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private CustomerViolationRepository customerViolationRepository;
    
    @Autowired
    private AuditService auditService;
    
    @Autowired
    private PayOSService payOSService;
    
    @Autowired
    private EmailService emailService;
    
    @Autowired
    private RoomService roomService;

    @Override
    public CancellationValidationResult validateCancellation(Appointment appointment, User customer) {
        // Check if appointment belongs to customer
        if (!appointment.getCustomer().getUserId().equals(customer.getUserId())) {
            return new CancellationValidationResult(false, "UNAUTHORIZED", "Bạn không có quyền hủy lịch hẹn này.");
        }
        
        // Check if appointment is already cancelled or completed
        String status = appointment.getStatus();
        if ("cancelled".equals(status) || "CANCELLED".equals(status) || "late_cancelled".equals(status)) {
            return new CancellationValidationResult(false, "ALREADY_CANCELLED", "Lịch hẹn đã được hủy trước đó.");
        }
        
        if ("checked_in".equals(status) || "CHECK_IN".equals(status) || "performed".equals(status) || "CHECKED_OUT".equals(status)) {
            return new CancellationValidationResult(false, "CANNOT_CANCEL", "Không thể hủy lịch hẹn đã check-in hoặc hoàn thành.");
        }
        
        // Check if customer has booking restrictions
        if (!customer.isBookingEnabled()) {
            return new CancellationValidationResult(false, "BOOKING_RESTRICTED", "Tài khoản của bạn đã bị hạn chế đặt lịch. Vui lòng liên hệ quản lý để được hỗ trợ.");
        }
        
        long hoursUntilAppointment = getHoursUntilAppointment(appointment);
        Invoice invoice = invoiceRepository.findByAppointment(appointment);
        boolean isPaid = invoice != null && "paid".equals(invoice.getPaymentStatus());
        
        if (hoursUntilAppointment >= 2) {
            // Standard cancellation
            CancellationValidationResult result = new CancellationValidationResult(true, "STANDARD", "Có thể hủy lịch hẹn.");
            return result;
        } else {
            // Late cancellation (< 2 hours)
            if (!isPaid) {
                // Late cancellation for unpaid appointment
                boolean hasUsedLateCancellation = hasCustomerUsedLateCancellation(customer);
                if (hasUsedLateCancellation) {
                    return new CancellationValidationResult(false, "LATE_ALREADY_USED", "Bạn đã sử dụng quyền hủy muộn một lần. Không thể hủy lịch hẹn này.");
                }
                
                CancellationValidationResult result = new CancellationValidationResult(true, "LATE_UNPAID", "Có thể hủy muộn (một lần duy nhất).");
                result.setRequiresConfirmation(true);
                result.setWarningMessage("Bạn đang hủy lịch hẹn vào phút chót. Theo chính sách của chúng tôi, bạn chỉ được phép làm điều này một lần. Sau lần này, tài khoản của bạn sẽ bị hạn chế vĩnh viễn khỏi việc đặt dịch vụ. Nếu bạn muốn khiếu nại, vui lòng liên hệ Quản lý Chi nhánh hoặc Quản trị viên để được phê duyệt.");
                return result;
            } else {
                // Late cancellation for paid appointment - blocked
                return new CancellationValidationResult(false, "LATE_PAID_BLOCKED", "Bạn không thể hủy lịch hẹn vì đã quá thời gian cho phép. Theo chính sách của chúng tôi, việc hủy vào phút chót không đủ điều kiện để được hoàn tiền. Nếu bạn có hoàn cảnh đặc biệt, vui lòng liên hệ lễ tân hoặc quản lý để được hỗ trợ.");
            }
        }
    }

    @Override
    @Transactional
    public CancellationResult performStandardCancellation(Integer appointmentId, Integer customerId, String reason) {
        try {
            Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);
            User customer = userRepository.findById(customerId).orElse(null);
            
            if (appointment == null || customer == null) {
                return new CancellationResult(false, "Không tìm thấy lịch hẹn hoặc khách hàng.");
            }
            
            CancellationValidationResult validation = validateCancellation(appointment, customer);
            if (!validation.isCanCancel() || !"STANDARD".equals(validation.getCancellationType())) {
                return new CancellationResult(false, validation.getMessage());
            }
            
            // Update appointment status
            appointment.setStatus("cancelled");
            appointment.setCancellationReason(reason);
            appointmentRepository.save(appointment);
            
            // Restore room capacity
            if (appointment.getRoom() != null) {
                roomService.increaseCapacity(appointment.getRoom().getId());
            }
            
            // Handle invoice and refund if paid
            Invoice invoice = invoiceRepository.findByAppointment(appointment);
            CancellationResult result = new CancellationResult(true, "Hủy lịch hẹn thành công.");
            result.setNewAppointmentStatus("cancelled");
            
            if (invoice != null && "paid".equals(invoice.getPaymentStatus())) {
                // Process refund
                invoice.setPaymentStatus("refunded");
                invoiceRepository.save(invoice);
                result.setNewInvoiceStatus("refunded");
                result.setRefundProcessed(true);
                
                // Process actual refund through payment gateway
                // Note: This would need to be implemented based on the payment gateway
                auditService.logRefundAction(invoice.getInvoiceId(), customerId, "Standard cancellation refund");
                
                // Send refund confirmation email
                emailService.sendRefundConfirmationEmail(customer.getEmail(), invoice);
            }
            
            // Log the cancellation
            auditService.logCancellationAction(appointmentId, customerId, "STANDARD", reason);
            
            return result;
            
        } catch (Exception e) {
            return new CancellationResult(false, "Lỗi hệ thống: " + e.getMessage());
        }
    }

    @Override
    @Transactional
    public CancellationResult performLateCancellation(Integer appointmentId, Integer customerId, String reason, boolean customerConfirmed) {
        try {
            if (!customerConfirmed) {
                return new CancellationResult(false, "Khách hàng chưa xác nhận hủy muộn.");
            }

            Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);
            User customer = userRepository.findById(customerId).orElse(null);

            if (appointment == null || customer == null) {
                return new CancellationResult(false, "Không tìm thấy lịch hẹn hoặc khách hàng.");
            }

            CancellationValidationResult validation = validateCancellation(appointment, customer);
            if (!validation.isCanCancel() || !"LATE_UNPAID".equals(validation.getCancellationType())) {
                return new CancellationResult(false, validation.getMessage());
            }

            // Update appointment status
            appointment.setStatus("late_cancelled");
            appointment.setCancellationReason(reason);
            appointmentRepository.save(appointment);

            // Restore room capacity
            if (appointment.getRoom() != null) {
                roomService.increaseCapacity(appointment.getRoom().getId());
            }

            // Restrict customer booking
            customer.setBookingEnabled(false);
            customer.setLateCancellationCount(customer.getLateCancellationCount() + 1);
            customer.setLastLateCancellationDate(LocalDateTime.now());
            userRepository.save(customer);

            // Create violation record
            CustomerViolation violation = new CustomerViolation(customer, appointment, "LATE_CANCELLATION",
                "Hủy lịch hẹn muộn (dưới 2 tiếng): " + reason);
            violation.setPenaltyApplied(true);
            violation.setPenaltyDescription("Tài khoản bị hạn chế đặt lịch");
            customerViolationRepository.save(violation);

            // Log the cancellation
            auditService.logCancellationAction(appointmentId, customerId, "LATE", reason);

            CancellationResult result = new CancellationResult(true, "Hủy lịch hẹn thành công. Tài khoản của bạn đã bị hạn chế đặt lịch.");
            result.setNewAppointmentStatus("late_cancelled");
            result.setCustomerRestricted(true);

            return result;

        } catch (Exception e) {
            return new CancellationResult(false, "Lỗi hệ thống: " + e.getMessage());
        }
    }

    @Override
    public CancellationResult attemptLatePaidCancellation(Integer appointmentId, Integer customerId) {
        return new CancellationResult(false, "Bạn không thể hủy lịch hẹn vì đã quá thời gian cho phép. Theo chính sách của chúng tôi, việc hủy vào phút chót không đủ điều kiện để được hoàn tiền. Nếu bạn có hoàn cảnh đặc biệt, vui lòng liên hệ lễ tân hoặc quản lý để được hỗ trợ.");
    }

    @Override
    @Transactional
    public CancellationResult performManualCancellation(Integer appointmentId, Integer staffId, String reason, String justification) {
        try {
            Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);
            User staff = userRepository.findById(staffId).orElse(null);

            if (appointment == null || staff == null) {
                return new CancellationResult(false, "Không tìm thấy lịch hẹn hoặc nhân viên.");
            }

            // Update appointment status
            appointment.setStatus("cancelled");
            appointment.setCancellationReason("Manual cancellation by staff: " + reason);
            appointmentRepository.save(appointment);

            // Restore room capacity
            if (appointment.getRoom() != null) {
                roomService.increaseCapacity(appointment.getRoom().getId());
            }

            // Handle invoice - for manual cancellation, keep as paid (no refund)
            Invoice invoice = invoiceRepository.findByAppointment(appointment);
            CancellationResult result = new CancellationResult(true, "Hủy lịch hẹn thành công bởi nhân viên.");
            result.setNewAppointmentStatus("cancelled");

            if (invoice != null && "paid".equals(invoice.getPaymentStatus())) {
                // Keep invoice as paid - no refund for manual late cancellation
                result.setNewInvoiceStatus("paid");
                result.setRefundProcessed(false);
            }

            // Log the manual cancellation with justification
            auditService.logAction("APPOINTMENT", appointmentId, "MANUAL_CANCEL", staffId, "STAFF",
                "Manual cancellation - Reason: " + reason + " - Justification: " + justification);

            return result;

        } catch (Exception e) {
            return new CancellationResult(false, "Lỗi hệ thống: " + e.getMessage());
        }
    }

    @Override
    public boolean isCustomerBookingRestricted(User customer) {
        return !customer.isBookingEnabled();
    }

    @Override
    public int getCustomerLateCancellationCount(User customer) {
        return customer.getLateCancellationCount() != null ? customer.getLateCancellationCount() : 0;
    }

    @Override
    public boolean hasCustomerUsedLateCancellation(User customer) {
        return getCustomerLateCancellationCount(customer) > 0;
    }

    @Override
    public long getHoursUntilAppointment(Appointment appointment) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime appointmentTime = appointment.getStartTime();
        return ChronoUnit.HOURS.between(now, appointmentTime);
    }
}
