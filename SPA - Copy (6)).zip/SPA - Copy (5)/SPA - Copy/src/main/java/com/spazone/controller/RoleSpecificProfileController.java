package com.spazone.controller;

import com.spazone.dto.*;
import com.spazone.entity.User;
import com.spazone.service.UserService;
import com.spazone.service.RoleSpecificProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/profile")
public class RoleSpecificProfileController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private RoleSpecificProfileService roleSpecificProfileService;

    private boolean isAuthenticatedUser(Authentication authentication) {
        return authentication != null &&
                authentication.isAuthenticated() &&
                !"anonymousUser".equals(authentication.getPrincipal());
    }

    @GetMapping("/customer")
    public String showCustomerProfile(Authentication authentication, Model model) {
        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }
        
        String username = authentication.getName();
        try {
            User user = userService.findByUsername(username);
            
            // Check if user has CUSTOMER role
            boolean hasCustomerRole = user.getRoles().stream()
                    .anyMatch(role -> "CUSTOMER".equals(role.getRoleName()));
            
            if (!hasCustomerRole) {
                return "redirect:/profile"; // Redirect to generic profile if not a customer
            }
            
            CustomerProfileDto profile = roleSpecificProfileService.getCustomerProfile(username);
            model.addAttribute("profile", profile);
            return "profile/customer-profile";
        } catch (Exception e) {
            model.addAttribute("error", "Unable to load customer profile: " + e.getMessage());
            return "profile/customer-profile";
        }
    }

    @GetMapping("/technician")
    public String showTechnicianProfile(Authentication authentication, Model model) {
        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }
        
        String username = authentication.getName();
        try {
            User user = userService.findByUsername(username);
            
            // Check if user has TECHNICIAN role
            boolean hasTechnicianRole = user.getRoles().stream()
                    .anyMatch(role -> "TECHNICIAN".equals(role.getRoleName()));
            
            if (!hasTechnicianRole) {
                return "redirect:/profile"; // Redirect to generic profile if not a technician
            }
            
            TechnicianProfileDto profile = roleSpecificProfileService.getTechnicianProfile(username);
            model.addAttribute("profile", profile);
            return "profile/technician-profile";
        } catch (Exception e) {
            model.addAttribute("error", "Unable to load technician profile: " + e.getMessage());
            return "profile/technician-profile";
        }
    }

    @GetMapping("/manager")
    public String showManagerProfile(Authentication authentication, Model model) {
        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }
        
        String username = authentication.getName();
        try {
            User user = userService.findByUsername(username);
            
            // Check if user has MANAGER role
            boolean hasManagerRole = user.getRoles().stream()
                    .anyMatch(role -> "MANAGER".equals(role.getRoleName()));
            
            if (!hasManagerRole) {
                return "redirect:/profile"; // Redirect to generic profile if not a manager
            }
            
            ManagerProfileDto profile = roleSpecificProfileService.getManagerProfile(username);
            model.addAttribute("profile", profile);
            return "profile/manager-profile";
        } catch (Exception e) {
            model.addAttribute("error", "Unable to load manager profile: " + e.getMessage());
            return "profile/manager-profile";
        }
    }

    @GetMapping("/receptionist")
    public String showReceptionistProfile(Authentication authentication, Model model) {
        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }
        
        String username = authentication.getName();
        try {
            User user = userService.findByUsername(username);
            
            // Check if user has RECEPTIONIST role
            boolean hasReceptionistRole = user.getRoles().stream()
                    .anyMatch(role -> "RECEPTIONIST".equals(role.getRoleName()));
            
            if (!hasReceptionistRole) {
                return "redirect:/profile"; // Redirect to generic profile if not a receptionist
            }
            
            ReceptionistProfileDto profile = roleSpecificProfileService.getReceptionistProfile(username);
            model.addAttribute("profile", profile);
            return "profile/receptionist-profile";
        } catch (Exception e) {
            model.addAttribute("error", "Unable to load receptionist profile: " + e.getMessage());
            return "profile/receptionist-profile";
        }
    }

    @GetMapping("/admin")
    public String showAdminProfile(Authentication authentication, Model model) {
        if (!isAuthenticatedUser(authentication)) {
            return "redirect:/auth/login";
        }
        
        String username = authentication.getName();
        try {
            User user = userService.findByUsername(username);
            
            // Check if user has ADMIN role
            boolean hasAdminRole = user.getRoles().stream()
                    .anyMatch(role -> "ADMIN".equals(role.getRoleName()));
            
            if (!hasAdminRole) {
                return "redirect:/profile"; // Redirect to generic profile if not an admin
            }
            
            AdminProfileDto profile = roleSpecificProfileService.getAdminProfile(username);
            model.addAttribute("profile", profile);
            return "profile/admin-profile";
        } catch (Exception e) {
            model.addAttribute("error", "Unable to load admin profile: " + e.getMessage());
            return "profile/admin-profile";
        }
    }
}
