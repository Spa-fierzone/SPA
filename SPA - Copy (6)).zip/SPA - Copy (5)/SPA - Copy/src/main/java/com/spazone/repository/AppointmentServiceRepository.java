package com.spazone.repository;

import com.spazone.entity.Appointment;
import com.spazone.entity.AppointmentServiceEntity;
import com.spazone.entity.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AppointmentServiceRepository extends JpaRepository<AppointmentServiceEntity, Integer> {

    /**
     * Find all services for a specific appointment
     */
    List<AppointmentServiceEntity> findByAppointment(Appointment appointment);

    /**
     * Find all services for a specific appointment by appointment ID
     */
    List<AppointmentServiceEntity> findByAppointmentAppointmentId(Integer appointmentId);

    /**
     * Find all appointments that use a specific service
     */
    List<AppointmentServiceEntity> findByService(Service service);

    /**
     * Find all appointments that use a specific service by service ID
     */
    List<AppointmentServiceEntity> findByServiceServiceId(Integer serviceId);

    /**
     * Check if an appointment has a specific service
     */
    boolean existsByAppointmentAndService(Appointment appointment, Service service);

    /**
     * Check if an appointment has a specific service by IDs
     */
    boolean existsByAppointmentAppointmentIdAndServiceServiceId(Integer appointmentId, Integer serviceId);

    /**
     * Find specific AppointmentServiceEntity by appointment ID and service ID
     */
    AppointmentServiceEntity findByAppointmentAppointmentIdAndServiceServiceId(Integer appointmentId, Integer serviceId);

    /**
     * Delete all services for a specific appointment
     */
    @Modifying
    void deleteByAppointment(Appointment appointment);

    /**
     * Delete all services for a specific appointment by appointment ID
     */
    @Modifying
    void deleteByAppointmentAppointmentId(Integer appointmentId);

    /**
     * Delete specific service from appointment by IDs
     */
    @Modifying
    @Query("DELETE FROM AppointmentServiceEntity ase WHERE ase.appointment.appointmentId = :appointmentId AND ase.service.serviceId = :serviceId")
    void deleteByAppointmentAppointmentIdAndServiceServiceId(@Param("appointmentId") Integer appointmentId, @Param("serviceId") Integer serviceId);

    /**
     * Get total count of services for an appointment
     */
    @Query("SELECT COUNT(ase) FROM AppointmentServiceEntity ase WHERE ase.appointment.appointmentId = :appointmentId")
    Long countServicesByAppointmentId(@Param("appointmentId") Integer appointmentId);

    /**
     * Get services for an appointment with eager loading
     */
    @Query("SELECT ase FROM AppointmentServiceEntity ase JOIN FETCH ase.service WHERE ase.appointment.appointmentId = :appointmentId")
    List<AppointmentServiceEntity> findByAppointmentIdWithService(@Param("appointmentId") Integer appointmentId);

    /**
     * Find appointments by service and date range (for reporting)
     */
    @Query("SELECT ase FROM AppointmentServiceEntity ase WHERE ase.service.serviceId = :serviceId " +
           "AND ase.appointment.appointmentDate BETWEEN :startDate AND :endDate")
    List<AppointmentServiceEntity> findByServiceAndDateRange(
            @Param("serviceId") Integer serviceId,
            @Param("startDate") java.time.LocalDateTime startDate,
            @Param("endDate") java.time.LocalDateTime endDate
    );

    /**
     * Get most popular services (by appointment count)
     */
    @Query("SELECT ase.service.serviceId, ase.service.name, COUNT(ase) as appointmentCount " +
           "FROM AppointmentServiceEntity ase " +
           "GROUP BY ase.service.serviceId, ase.service.name " +
           "ORDER BY COUNT(ase) DESC")
    List<Object[]> findMostPopularServices();

    /**
     * Get total revenue by service
     */
    @Query("SELECT ase.service.serviceId, ase.service.name, " +
           "SUM(CASE WHEN ase.customPrice IS NOT NULL THEN ase.customPrice * ase.quantity ELSE ase.service.price * ase.quantity END) as totalRevenue " +
           "FROM AppointmentServiceEntity ase " +
           "WHERE ase.appointment.status = 'completed' " +
           "GROUP BY ase.service.serviceId, ase.service.name " +
           "ORDER BY totalRevenue DESC")
    List<Object[]> findRevenueByService();

    // Service status tracking methods
    /**
     * Find services by appointment ID and status
     */
    List<AppointmentServiceEntity> findByAppointmentAppointmentIdAndStatus(Integer appointmentId, String status);

    /**
     * Find services by technician and status
     */
    List<AppointmentServiceEntity> findByAppointmentTechnicianUserIdAndStatus(Integer technicianId, String status);

    /**
     * Find services by technician and status with pagination
     */
    Page<AppointmentServiceEntity> findByAppointmentTechnicianUserIdAndStatus(Integer technicianId, String status, Pageable pageable);
}
