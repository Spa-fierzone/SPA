package com.spazone.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Utility class for validating password strength and rules
 */
public class PasswordValidator {
    
    // Password validation patterns
    private static final Pattern UPPERCASE_PATTERN = Pattern.compile(".*[A-Z].*");
    private static final Pattern LOWERCASE_PATTERN = Pattern.compile(".*[a-z].*");
    private static final Pattern DIGIT_PATTERN = Pattern.compile(".*[0-9].*");
    private static final Pattern SPECIAL_CHAR_PATTERN = Pattern.compile(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*");
    
    // Minimum password length
    private static final int MIN_LENGTH = 8;
    private static final int MAX_LENGTH = 128;
    
    /**
     * Validates password strength and returns list of validation errors
     * @param password The password to validate
     * @param currentPassword The current password (to prevent reuse)
     * @param username The username (to prevent password containing username)
     * @param email The email (to prevent password containing email parts)
     * @return List of validation error messages, empty if valid
     */
    public static List<String> validatePassword(String password, String currentPassword, String username, String email) {
        List<String> errors = new ArrayList<>();
        
        if (password == null || password.trim().isEmpty()) {
            errors.add("Mật khẩu không được để trống");
            return errors;
        }
        
        // Check minimum length
        if (password.length() < MIN_LENGTH) {
            errors.add("Mật khẩu phải có ít nhất " + MIN_LENGTH + " ký tự");
        }
        
        // Check maximum length
        if (password.length() > MAX_LENGTH) {
            errors.add("Mật khẩu không được vượt quá " + MAX_LENGTH + " ký tự");
        }
        
        // Check for uppercase letter
        if (!UPPERCASE_PATTERN.matcher(password).matches()) {
            errors.add("Mật khẩu phải chứa ít nhất một chữ cái viết hoa");
        }
        
        // Check for lowercase letter
        if (!LOWERCASE_PATTERN.matcher(password).matches()) {
            errors.add("Mật khẩu phải chứa ít nhất một chữ cái viết thường");
        }
        
        // Check for digit
        if (!DIGIT_PATTERN.matcher(password).matches()) {
            errors.add("Mật khẩu phải chứa ít nhất một chữ số");
        }
        
        // Check for special character
        if (!SPECIAL_CHAR_PATTERN.matcher(password).matches()) {
            errors.add("Mật khẩu phải chứa ít nhất một ký tự đặc biệt (!@#$%^&*()_+-=[]{}|;':\"\\,.<>?/)");
        }
        
        // Check if password is same as current password
        if (currentPassword != null && password.equals(currentPassword)) {
            errors.add("Mật khẩu mới không được giống mật khẩu hiện tại");
        }
        
        // Check if password contains username
        if (username != null && !username.trim().isEmpty() && 
            password.toLowerCase().contains(username.toLowerCase())) {
            errors.add("Mật khẩu không được chứa tên đăng nhập");
        }
        
        // Check if password contains email parts
        if (email != null && !email.trim().isEmpty()) {
            String emailPrefix = email.split("@")[0];
            if (password.toLowerCase().contains(emailPrefix.toLowerCase())) {
                errors.add("Mật khẩu không được chứa phần tên của email");
            }
        }
        
        // Check for common weak passwords
        if (isCommonWeakPassword(password)) {
            errors.add("Mật khẩu này quá phổ biến và không an toàn");
        }
        
        return errors;
    }
    
    /**
     * Quick validation for password strength (returns true if valid)
     */
    public static boolean isValidPassword(String password) {
        return validatePassword(password, null, null, null).isEmpty();
    }
    
    /**
     * Check if password is in common weak passwords list
     */
    private static boolean isCommonWeakPassword(String password) {
        String[] commonPasswords = {
            "password", "123456", "123456789", "12345678", "12345", "1234567",
            "password123", "admin", "qwerty", "abc123", "Password1", "password1",
            "123123", "000000", "iloveyou", "1234567890", "123321", "654321",
            "666666", "987654321", "123", "456789", "welcome", "admin123",
            "Password123", "qwerty123", "letmein", "monkey", "dragon"
        };
        
        String lowerPassword = password.toLowerCase();
        for (String common : commonPasswords) {
            if (lowerPassword.equals(common.toLowerCase())) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Get password strength score (0-100)
     */
    public static int getPasswordStrength(String password) {
        if (password == null || password.isEmpty()) {
            return 0;
        }
        
        int score = 0;
        
        // Length score (max 25 points)
        if (password.length() >= 8) score += 10;
        if (password.length() >= 12) score += 10;
        if (password.length() >= 16) score += 5;
        
        // Character variety (max 40 points)
        if (UPPERCASE_PATTERN.matcher(password).matches()) score += 10;
        if (LOWERCASE_PATTERN.matcher(password).matches()) score += 10;
        if (DIGIT_PATTERN.matcher(password).matches()) score += 10;
        if (SPECIAL_CHAR_PATTERN.matcher(password).matches()) score += 10;
        
        // Complexity bonus (max 35 points)
        if (password.length() >= 10 && hasMultipleCharTypes(password)) score += 15;
        if (!isCommonWeakPassword(password)) score += 10;
        if (hasNoRepeatingChars(password)) score += 10;
        
        return Math.min(score, 100);
    }
    
    private static boolean hasMultipleCharTypes(String password) {
        int types = 0;
        if (UPPERCASE_PATTERN.matcher(password).matches()) types++;
        if (LOWERCASE_PATTERN.matcher(password).matches()) types++;
        if (DIGIT_PATTERN.matcher(password).matches()) types++;
        if (SPECIAL_CHAR_PATTERN.matcher(password).matches()) types++;
        return types >= 3;
    }
    
    private static boolean hasNoRepeatingChars(String password) {
        for (int i = 0; i < password.length() - 2; i++) {
            if (password.charAt(i) == password.charAt(i + 1) && 
                password.charAt(i) == password.charAt(i + 2)) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Get password strength description
     */
    public static String getPasswordStrengthDescription(int score) {
        if (score < 30) return "Rất yếu";
        if (score < 50) return "Yếu";
        if (score < 70) return "Trung bình";
        if (score < 90) return "Mạnh";
        return "Rất mạnh";
    }
}
