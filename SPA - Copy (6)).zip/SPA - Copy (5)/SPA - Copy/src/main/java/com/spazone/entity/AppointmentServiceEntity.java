package com.spazone.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "appointment_services")
public class AppointmentServiceEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "appointment_id", nullable = false)
    private Appointment appointment;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "service_id", nullable = false)
    private Service service;

    @Column(name = "quantity")
    private Integer quantity = 1;

    @Column(name = "custom_price", precision = 10, scale = 2)
    private BigDecimal customPrice;

    @Column(name = "notes", length = 1000, columnDefinition = "NVARCHAR(1000)")
    private String notes;

    @Column(name = "status", length = 20, columnDefinition = "NVARCHAR(255)")
    private String status = "pending"; // pending, in-progress, completed

    @Column(name = "started_at")
    private LocalDateTime startedAt;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    // Constructors
    public AppointmentServiceEntity() {
    }

    public AppointmentServiceEntity(Appointment appointment, Service service) {
        this.appointment = appointment;
        this.service = service;
        this.quantity = 1;
    }

    public AppointmentServiceEntity(Appointment appointment, Service service, Integer quantity) {
        this.appointment = appointment;
        this.service = service;
        this.quantity = quantity;
    }

    public AppointmentServiceEntity(Appointment appointment, Service service, Integer quantity, BigDecimal customPrice, String notes) {
        this.appointment = appointment;
        this.service = service;
        this.quantity = quantity;
        this.customPrice = customPrice;
        this.notes = notes;
    }

    // Helper methods
    public BigDecimal getEffectivePrice() {
        return customPrice != null ? customPrice : service.getPrice();
    }

    public BigDecimal getTotalPrice() {
        return getEffectivePrice().multiply(BigDecimal.valueOf(quantity));
    }

    public int getTotalDuration() {
        return service.getDuration() * quantity;
    }

    // Status management helper methods
    public void startService() {
        this.status = "in-progress";
        this.startedAt = LocalDateTime.now();
    }

    public void completeService() {
        this.status = "completed";
        this.completedAt = LocalDateTime.now();
    }

    public boolean isPending() {
        return "pending".equals(this.status);
    }

    public boolean isInProgress() {
        return "in-progress".equals(this.status);
    }

    public boolean isCompleted() {
        return "completed".equals(this.status);
    }

    // Getters and Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Appointment getAppointment() {
        return appointment;
    }

    public void setAppointment(Appointment appointment) {
        this.appointment = appointment;
    }

    public Service getService() {
        return service;
    }

    public void setService(Service service) {
        this.service = service;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getCustomPrice() {
        return customPrice;
    }

    public void setCustomPrice(BigDecimal customPrice) {
        this.customPrice = customPrice;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(LocalDateTime startedAt) {
        this.startedAt = startedAt;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }

    @Override
    public String toString() {
        return "AppointmentServiceEntity{" +
                "id=" + id +
                ", service=" + (service != null ? service.getName() : "null") +
                ", quantity=" + quantity +
                ", customPrice=" + customPrice +
                ", notes='" + notes + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AppointmentServiceEntity that = (AppointmentServiceEntity) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (appointment != null ? !appointment.getAppointmentId().equals(that.appointment.getAppointmentId()) : that.appointment != null) return false;
        return service != null ? service.getServiceId().equals(that.service.getServiceId()) : that.service == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (appointment != null ? appointment.getAppointmentId().hashCode() : 0);
        result = 31 * result + (service != null ? service.getServiceId().hashCode() : 0);
        return result;
    }
}
