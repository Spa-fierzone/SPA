package com.spazone.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * ChatParticipant entity representing user participation in chat rooms
 * Tracks user membership, roles, and read status in chat rooms
 * Supports participant roles: ADMIN, MODERATOR, MEMBER
 */
@Entity
@Table(name = "chat_participants", 
       uniqueConstraints = @UniqueConstraint(columnNames = {"room_id", "user_id"}))
public class ChatParticipant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "participant_id")
    private Integer participantId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "room_id", nullable = false)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler", "participants", "messages"})
    private ChatRoom chatRoom;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private User user;

    @Column(name = "joined_at", nullable = false)
    private LocalDateTime joinedAt;

    @Column(name = "last_read_at")
    private LocalDateTime lastReadAt;

    @Column(name = "is_active")
    private Boolean isActive = true;

    @Column(name = "role", length = 20, columnDefinition = "NVARCHAR(20)")
    private String role = "MEMBER"; // ADMIN, MODERATOR, MEMBER

    @Column(name = "notifications_enabled")
    private Boolean notificationsEnabled = true;

    // Constructors
    public ChatParticipant() {
    }

    public ChatParticipant(ChatRoom chatRoom, User user) {
        this.chatRoom = chatRoom;
        this.user = user;
        this.joinedAt = LocalDateTime.now();
        this.role = "MEMBER";
    }

    public ChatParticipant(ChatRoom chatRoom, User user, String role) {
        this(chatRoom, user);
        this.role = role;
    }

    // Lifecycle methods
    @PrePersist
    protected void onCreate() {
        if (joinedAt == null) {
            joinedAt = LocalDateTime.now();
        }
    }

    // Helper methods
    public boolean isAdmin() {
        return "ADMIN".equals(role);
    }

    public boolean isModerator() {
        return "MODERATOR".equals(role);
    }

    public boolean isMember() {
        return "MEMBER".equals(role);
    }

    public boolean canModerate() {
        return isAdmin() || isModerator();
    }

    public void markAsRead() {
        this.lastReadAt = LocalDateTime.now();
    }

    public boolean hasUnreadMessages() {
        if (lastReadAt == null) {
            return true; // Never read any messages
        }
        // This would need to be checked against the latest message timestamp
        // Implementation depends on how we track unread messages
        return false;
    }

    // Getters and Setters
    public Integer getParticipantId() {
        return participantId;
    }

    public void setParticipantId(Integer participantId) {
        this.participantId = participantId;
    }

    public ChatRoom getChatRoom() {
        return chatRoom;
    }

    public void setChatRoom(ChatRoom chatRoom) {
        this.chatRoom = chatRoom;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public LocalDateTime getJoinedAt() {
        return joinedAt;
    }

    public void setJoinedAt(LocalDateTime joinedAt) {
        this.joinedAt = joinedAt;
    }

    public LocalDateTime getLastReadAt() {
        return lastReadAt;
    }

    public void setLastReadAt(LocalDateTime lastReadAt) {
        this.lastReadAt = lastReadAt;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Boolean getNotificationsEnabled() {
        return notificationsEnabled;
    }

    public void setNotificationsEnabled(Boolean notificationsEnabled) {
        this.notificationsEnabled = notificationsEnabled;
    }

    @Override
    public String toString() {
        return "ChatParticipant{" +
                "participantId=" + participantId +
                ", role='" + role + '\'' +
                ", isActive=" + isActive +
                ", joinedAt=" + joinedAt +
                '}';
    }
}
