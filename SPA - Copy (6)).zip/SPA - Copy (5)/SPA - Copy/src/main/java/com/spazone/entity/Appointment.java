package com.spazone.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "appointments")
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer appointmentId;

    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private User customer;

    @ManyToOne
    @JoinColumn(name = "branch_id", nullable = false)
    private Branch branch;

    @ManyToOne
    @JoinColumn(name = "technician_id", nullable = false)
    private User technician;

    private LocalDateTime appointmentDate;
    private LocalDateTime startTime;
    private LocalDateTime endTime;

    @Column(name = "checkin_time")
    private LocalDateTime checkinTime;

    @Column(name = "checkout_time")
    private LocalDateTime checkoutTime;

    @Column(columnDefinition = "NVARCHAR(255)")
    private String status;
    @Column(length = 4000, columnDefinition = "NVARCHAR(4000)")
    private String notes;
    @Column(length = 4000, columnDefinition = "NVARCHAR(4000)")
    private String cancellationReason;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    private Boolean reminderSent;
    private LocalDateTime reminderSentAt;
    private LocalDateTime checkInTime;
    private LocalDateTime checkOutTime;

    @ManyToOne
    @JoinColumn(name = "preferred_technician_id")
    private User preferredTechnician;

    @Column(length = 4000, columnDefinition = "NVARCHAR(4000)")
    private String specialRequests;

    @Column(columnDefinition = "NVARCHAR(255)")
    private String reminderMethod;

    @OneToMany(mappedBy = "appointment", cascade = CascadeType.ALL)
    private List<TreatmentRecord> treatmentRecords;

    // New one-to-many relationship with services
    @OneToMany(mappedBy = "appointment", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<AppointmentServiceEntity> appointmentServices = new ArrayList<>();

    @ManyToOne
    @JoinColumn(name = "room_id")
    private Room room;

    // Follow-up appointment relationship
    @Column(name = "original_appointment_id")
    private Integer originalAppointmentId;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    public Appointment() {
    }

    public Appointment(Integer appointmentId, User customer, Branch branch, Service service, User technician, LocalDateTime appointmentDate, LocalDateTime startTime, LocalDateTime endTime, String status, String notes, String cancellationReason, LocalDateTime createdAt, LocalDateTime updatedAt, Boolean reminderSent, LocalDateTime reminderSentAt, LocalDateTime checkInTime, LocalDateTime checkOutTime, User preferredTechnician, String specialRequests, String reminderMethod, Room room) {
        this.appointmentId = appointmentId;
        this.customer = customer;
        this.branch = branch;
        this.technician = technician;
        this.appointmentDate = appointmentDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.status = status;
        this.notes = notes;
        this.cancellationReason = cancellationReason;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.reminderSent = reminderSent;
        this.reminderSentAt = reminderSentAt;
        this.checkInTime = checkInTime;
        this.checkOutTime = checkOutTime;
        this.preferredTechnician = preferredTechnician;
        this.specialRequests = specialRequests;
        this.reminderMethod = reminderMethod;
        this.room = room;
    }

    public LocalDateTime getCheckinTime() {
        return checkinTime;
    }

    public LocalDateTime getCheckoutTime() {
        return checkoutTime;
    }

    public List<TreatmentRecord> getTreatmentRecords() {
        return treatmentRecords;
    }

    public void setCheckinTime(LocalDateTime checkinTime) {
        this.checkinTime = checkinTime;
    }

    public void setCheckoutTime(LocalDateTime checkoutTime) {
        this.checkoutTime = checkoutTime;
    }

    public void setTreatmentRecords(List<TreatmentRecord> treatmentRecords) {
        this.treatmentRecords = treatmentRecords;
    }

    public Integer getAppointmentId() {
        return appointmentId;
    }

    public User getCustomer() {
        return customer;
    }

    public Branch getBranch() {
        return branch;
    }
    

    public User getTechnician() {
        return technician;
    }

    public LocalDateTime getAppointmentDate() {
        return appointmentDate;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public String getStatus() {
        return status;
    }

    public String getNotes() {
        return notes;
    }

    public String getCancellationReason() {
        return cancellationReason;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public Boolean getReminderSent() {
        return reminderSent;
    }

    public LocalDateTime getReminderSentAt() {
        return reminderSentAt;
    }

    public LocalDateTime getCheckInTime() {
        return checkInTime;
    }

    public LocalDateTime getCheckOutTime() {
        return checkOutTime;
    }

    public User getPreferredTechnician() {
        return preferredTechnician;
    }

    public String getSpecialRequests() {
        return specialRequests;
    }

    public String getReminderMethod() {
        return reminderMethod;
    }

    public Room getRoom() {
        return room;
    }

    public void setAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
    }

    public void setCustomer(User customer) {
        this.customer = customer;
    }

    public void setBranch(Branch branch) {
        this.branch = branch;
    }

    public void setTechnician(User technician) {
        this.technician = technician;
    }

    public void setAppointmentDate(LocalDateTime appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public void setCancellationReason(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public void setReminderSent(Boolean reminderSent) {
        this.reminderSent = reminderSent;
    }

    public void setReminderSentAt(LocalDateTime reminderSentAt) {
        this.reminderSentAt = reminderSentAt;
    }

    public void setCheckInTime(LocalDateTime checkInTime) {
        this.checkInTime = checkInTime;
    }

    public void setCheckOutTime(LocalDateTime checkOutTime) {
        this.checkOutTime = checkOutTime;
    }

    public void setPreferredTechnician(User preferredTechnician) {
        this.preferredTechnician = preferredTechnician;
    }

    public void setSpecialRequests(String specialRequests) {
        this.specialRequests = specialRequests;
    }

    public void setReminderMethod(String reminderMethod) {
        this.reminderMethod = reminderMethod;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public Integer getOriginalAppointmentId() {
        return originalAppointmentId;
    }

    public void setOriginalAppointmentId(Integer originalAppointmentId) {
        this.originalAppointmentId = originalAppointmentId;
    }

    public List<AppointmentServiceEntity> getAppointmentServices() {
        return appointmentServices;
    }

    public void setAppointmentServices(List<AppointmentServiceEntity> appointmentServices) {
        this.appointmentServices = appointmentServices;
    }

    // Helper methods for multiple services support

    /**
     * Get all services associated with this appointment
     */
    public List<Service> getServices() {
        if (appointmentServices == null || appointmentServices.isEmpty()) {
            return new ArrayList<>();
        }
        return appointmentServices.stream()
                .map(AppointmentServiceEntity::getService)
                .toList();
    }

    /**
     * Calculate total duration from all services
     */
    public int getTotalDuration() {
        if (appointmentServices == null || appointmentServices.isEmpty()) {
            return 0;
        }
        return appointmentServices.stream()
                .mapToInt(AppointmentServiceEntity::getTotalDuration)
                .sum();
    }

    /**
     * Calculate total price from all services
     */
    public BigDecimal getTotalPrice() {
        if (appointmentServices == null || appointmentServices.isEmpty()) {
            return BigDecimal.ZERO;
        }
        return appointmentServices.stream()
                .map(AppointmentServiceEntity::getTotalPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Add a service to this appointment
     */
    public void addService(Service service) {
        addService(service, 1, null, null);
    }

    /**
     * Add a service to this appointment with quantity
     */
    public void addService(Service service, Integer quantity) {
        addService(service, quantity, null, null);
    }

    /**
     * Add a service to this appointment with full details
     */
    public void addService(Service service, Integer quantity, BigDecimal customPrice, String notes) {
        if (appointmentServices == null) {
            appointmentServices = new ArrayList<>();
        }
        AppointmentServiceEntity appointmentService = new AppointmentServiceEntity(this, service, quantity, customPrice, notes);
        appointmentServices.add(appointmentService);
    }

    /**
     * Remove a service from this appointment
     */
    public void removeService(Service service) {
        if (appointmentServices != null) {
            appointmentServices.removeIf(as -> as.getService().getServiceId().equals(service.getServiceId()));
        }
    }

    /**
     * Check if this appointment has a specific service
     */
    public boolean hasService(Service service) {
        if (appointmentServices != null && !appointmentServices.isEmpty()) {
            return appointmentServices.stream()
                    .anyMatch(as -> as.getService().getServiceId().equals(service.getServiceId()));
        }
        return false;
    }

    /**
     * Get count of services in this appointment
     */
    public int getServiceCount() {
        if (appointmentServices == null || appointmentServices.isEmpty()) {
            return 0;
        }
        return appointmentServices.size();
    }
}
