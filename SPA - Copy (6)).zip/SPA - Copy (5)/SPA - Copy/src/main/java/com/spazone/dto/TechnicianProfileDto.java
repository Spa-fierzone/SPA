package com.spazone.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class TechnicianProfileDto {
    // Basic user information
    private Integer userId;
    private String username;
    private String email;
    private String fullName;
    private String phone;
    private LocalDate dateOfBirth;
    private String gender;
    private String address;
    private String profilePicture;
    private LocalDateTime createdAt;
    private LocalDateTime lastLogin;
    
    // Employee information
    private String status;
    private Integer branchId;
    private String branchName;
    private BigDecimal baseSalary;
    private LocalDateTime lastCheckIn;
    private LocalDateTime lastCheckOut;
    private BigDecimal totalWorkingHours;
    private BigDecimal performanceScore;
    
    // Technician-specific information
    private List<String> specializations;
    private Integer totalServicesCompleted;
    private Integer totalCustomersServed;
    private BigDecimal averageServiceRating;
    private Integer totalServiceReviews;
    private BigDecimal monthlyRevenue;
    private BigDecimal yearlyRevenue;
    
    // Performance metrics
    private Integer appointmentsThisMonth;
    private Integer appointmentsCompleted;
    private Integer appointmentsCancelled;
    private BigDecimal completionRate;
    private BigDecimal customerSatisfactionRate;
    private Integer repeatCustomers;
    
    // Schedule information
    private Integer upcomingAppointments;
    private LocalDateTime nextAppointment;
    private String nextAppointmentService;
    private String nextAppointmentCustomer;
    
    // Skills and certifications
    private List<String> certifications;
    private List<String> skills;
    private LocalDateTime lastTrainingDate;
    private String lastTrainingTopic;
    
    // Constructors
    public TechnicianProfileDto() {}
    
    // Getters and Setters
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getEmployeeId() {
        return userId != null ? String.format("NV%04d", userId) : "N/A";
    }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }
    
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getProfilePicture() { return profilePicture; }
    public void setProfilePicture(String profilePicture) { this.profilePicture = profilePicture; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getLastLogin() { return lastLogin; }
    public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Integer getBranchId() { return branchId; }
    public void setBranchId(Integer branchId) { this.branchId = branchId; }
    
    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }
    
    public BigDecimal getBaseSalary() { return baseSalary; }
    public void setBaseSalary(BigDecimal baseSalary) { this.baseSalary = baseSalary; }
    
    public LocalDateTime getLastCheckIn() { return lastCheckIn; }
    public void setLastCheckIn(LocalDateTime lastCheckIn) { this.lastCheckIn = lastCheckIn; }
    
    public LocalDateTime getLastCheckOut() { return lastCheckOut; }
    public void setLastCheckOut(LocalDateTime lastCheckOut) { this.lastCheckOut = lastCheckOut; }
    
    public BigDecimal getTotalWorkingHours() { return totalWorkingHours; }
    public void setTotalWorkingHours(BigDecimal totalWorkingHours) { this.totalWorkingHours = totalWorkingHours; }
    
    public BigDecimal getPerformanceScore() { return performanceScore; }
    public void setPerformanceScore(BigDecimal performanceScore) { this.performanceScore = performanceScore; }
    
    public List<String> getSpecializations() { return specializations; }
    public void setSpecializations(List<String> specializations) { this.specializations = specializations; }
    
    public Integer getTotalServicesCompleted() { return totalServicesCompleted; }
    public void setTotalServicesCompleted(Integer totalServicesCompleted) { this.totalServicesCompleted = totalServicesCompleted; }
    
    public Integer getTotalCustomersServed() { return totalCustomersServed; }
    public void setTotalCustomersServed(Integer totalCustomersServed) { this.totalCustomersServed = totalCustomersServed; }
    
    public BigDecimal getAverageServiceRating() { return averageServiceRating; }
    public void setAverageServiceRating(BigDecimal averageServiceRating) { this.averageServiceRating = averageServiceRating; }
    
    public Integer getTotalServiceReviews() { return totalServiceReviews; }
    public void setTotalServiceReviews(Integer totalServiceReviews) { this.totalServiceReviews = totalServiceReviews; }
    
    public BigDecimal getMonthlyRevenue() { return monthlyRevenue; }
    public void setMonthlyRevenue(BigDecimal monthlyRevenue) { this.monthlyRevenue = monthlyRevenue; }
    
    public BigDecimal getYearlyRevenue() { return yearlyRevenue; }
    public void setYearlyRevenue(BigDecimal yearlyRevenue) { this.yearlyRevenue = yearlyRevenue; }
    
    public Integer getAppointmentsThisMonth() { return appointmentsThisMonth; }
    public void setAppointmentsThisMonth(Integer appointmentsThisMonth) { this.appointmentsThisMonth = appointmentsThisMonth; }
    
    public Integer getAppointmentsCompleted() { return appointmentsCompleted; }
    public void setAppointmentsCompleted(Integer appointmentsCompleted) { this.appointmentsCompleted = appointmentsCompleted; }
    
    public Integer getAppointmentsCancelled() { return appointmentsCancelled; }
    public void setAppointmentsCancelled(Integer appointmentsCancelled) { this.appointmentsCancelled = appointmentsCancelled; }
    
    public BigDecimal getCompletionRate() { return completionRate; }
    public void setCompletionRate(BigDecimal completionRate) { this.completionRate = completionRate; }
    
    public BigDecimal getCustomerSatisfactionRate() { return customerSatisfactionRate; }
    public void setCustomerSatisfactionRate(BigDecimal customerSatisfactionRate) { this.customerSatisfactionRate = customerSatisfactionRate; }
    
    public Integer getRepeatCustomers() { return repeatCustomers; }
    public void setRepeatCustomers(Integer repeatCustomers) { this.repeatCustomers = repeatCustomers; }
    
    public Integer getUpcomingAppointments() { return upcomingAppointments; }
    public void setUpcomingAppointments(Integer upcomingAppointments) { this.upcomingAppointments = upcomingAppointments; }
    
    public LocalDateTime getNextAppointment() { return nextAppointment; }
    public void setNextAppointment(LocalDateTime nextAppointment) { this.nextAppointment = nextAppointment; }
    
    public String getNextAppointmentService() { return nextAppointmentService; }
    public void setNextAppointmentService(String nextAppointmentService) { this.nextAppointmentService = nextAppointmentService; }
    
    public String getNextAppointmentCustomer() { return nextAppointmentCustomer; }
    public void setNextAppointmentCustomer(String nextAppointmentCustomer) { this.nextAppointmentCustomer = nextAppointmentCustomer; }
    
    public List<String> getCertifications() { return certifications; }
    public void setCertifications(List<String> certifications) { this.certifications = certifications; }
    
    public List<String> getSkills() { return skills; }
    public void setSkills(List<String> skills) { this.skills = skills; }
    
    public LocalDateTime getLastTrainingDate() { return lastTrainingDate; }
    public void setLastTrainingDate(LocalDateTime lastTrainingDate) { this.lastTrainingDate = lastTrainingDate; }
    
    public String getLastTrainingTopic() { return lastTrainingTopic; }
    public void setLastTrainingTopic(String lastTrainingTopic) { this.lastTrainingTopic = lastTrainingTopic; }
}
