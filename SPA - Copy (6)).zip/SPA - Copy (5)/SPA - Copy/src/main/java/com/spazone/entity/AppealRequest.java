package com.spazone.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "appeal_requests")
public class AppealRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer appealId;

    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private User customer;

    @ManyToOne
    @JoinColumn(name = "violation_id")
    private CustomerViolation violation;

    @Column(name = "appeal_type", length = 50, nullable = false, columnDefinition = "NVARCHAR(50)")
    private String appealType; // BOOKING_RESTRICTION_REMOVAL, REFUND_REQUEST, etc.

    @Column(name = "reason", length = 2000, nullable = false, columnDefinition = "NVARCHAR(2000)")
    private String reason;

    @Column(name = "supporting_documents", length = 1000, columnDefinition = "NVARCHAR(1000)")
    private String supportingDocuments; // File paths or URLs

    @Column(name = "status", length = 20, nullable = false, columnDefinition = "NVARCHAR(20)")
    private String status = "PENDING"; // PENDING, APPROVED, REJECTED, UNDER_REVIEW

    @Column(name = "submitted_date", nullable = false)
    private LocalDateTime submittedDate = LocalDateTime.now();

    @Column(name = "reviewed_by")
    private Integer reviewedBy; // User ID of staff who reviewed

    @Column(name = "reviewed_date")
    private LocalDateTime reviewedDate;

    @Column(name = "review_notes", length = 2000, columnDefinition = "NVARCHAR(2000)")
    private String reviewNotes;

    @Column(name = "resolution", length = 2000, columnDefinition = "NVARCHAR(2000)")
    private String resolution;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Constructors
    public AppealRequest() {}

    public AppealRequest(User customer, CustomerViolation violation, String appealType, String reason) {
        this.customer = customer;
        this.violation = violation;
        this.appealType = appealType;
        this.reason = reason;
    }

    // Getters and Setters
    public Integer getAppealId() {
        return appealId;
    }

    public void setAppealId(Integer appealId) {
        this.appealId = appealId;
    }

    public User getCustomer() {
        return customer;
    }

    public void setCustomer(User customer) {
        this.customer = customer;
    }

    public CustomerViolation getViolation() {
        return violation;
    }

    public void setViolation(CustomerViolation violation) {
        this.violation = violation;
    }

    public String getAppealType() {
        return appealType;
    }

    public void setAppealType(String appealType) {
        this.appealType = appealType;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getSupportingDocuments() {
        return supportingDocuments;
    }

    public void setSupportingDocuments(String supportingDocuments) {
        this.supportingDocuments = supportingDocuments;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getSubmittedDate() {
        return submittedDate;
    }

    public void setSubmittedDate(LocalDateTime submittedDate) {
        this.submittedDate = submittedDate;
    }

    public Integer getReviewedBy() {
        return reviewedBy;
    }

    public void setReviewedBy(Integer reviewedBy) {
        this.reviewedBy = reviewedBy;
    }

    public LocalDateTime getReviewedDate() {
        return reviewedDate;
    }

    public void setReviewedDate(LocalDateTime reviewedDate) {
        this.reviewedDate = reviewedDate;
    }

    public String getReviewNotes() {
        return reviewNotes;
    }

    public void setReviewNotes(String reviewNotes) {
        this.reviewNotes = reviewNotes;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
