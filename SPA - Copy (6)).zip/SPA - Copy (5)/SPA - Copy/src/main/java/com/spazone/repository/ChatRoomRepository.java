package com.spazone.repository;

import com.spazone.entity.ChatRoom;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for ChatRoom entity
 * Provides custom queries for branch-based and role-based room access
 */
@Repository
public interface ChatRoomRepository extends JpaRepository<ChatRoom, Integer> {

    /**
     * Find all active chat rooms
     */
    List<ChatRoom> findByIsActiveTrue();

    /**
     * Find chat rooms by type and active status
     */
    List<ChatRoom> findByRoomTypeAndIsActiveTrue(String roomType);

    /**
     * Find chat rooms by branch and active status
     */
    List<ChatRoom> findByBranchBranchIdAndIsActiveTrue(Integer branchId);

    /**
     * Find chat rooms by branch and type
     */
    List<ChatRoom> findByBranchBranchIdAndRoomTypeAndIsActiveTrue(Integer branchId, String roomType);

    /**
     * Find chat rooms where a specific user is a participant
     */
    @Query("SELECT DISTINCT cr FROM ChatRoom cr " +
           "JOIN cr.participants cp " +
           "WHERE cp.user.userId = :userId " +
           "AND cp.isActive = true " +
           "AND cr.isActive = true " +
           "ORDER BY cr.updatedAt DESC")
    List<ChatRoom> findRoomsByUserId(@Param("userId") Integer userId);

    /**
     * Find chat rooms where a specific user is a participant with pagination
     */
    @Query("SELECT DISTINCT cr FROM ChatRoom cr " +
           "JOIN cr.participants cp " +
           "WHERE cp.user.userId = :userId " +
           "AND cp.isActive = true " +
           "AND cr.isActive = true " +
           "ORDER BY cr.updatedAt DESC")
    Page<ChatRoom> findRoomsByUserId(@Param("userId") Integer userId, Pageable pageable);

    /**
     * Find direct message room between two users
     */
    @Query("SELECT cr FROM ChatRoom cr " +
           "WHERE cr.roomType = 'DIRECT' " +
           "AND cr.isActive = true " +
           "AND EXISTS (SELECT 1 FROM ChatParticipant cp1 WHERE cp1.chatRoom = cr AND cp1.user.userId = :userId1 AND cp1.isActive = true) " +
           "AND EXISTS (SELECT 1 FROM ChatParticipant cp2 WHERE cp2.chatRoom = cr AND cp2.user.userId = :userId2 AND cp2.isActive = true)")
    Optional<ChatRoom> findDirectMessageRoom(@Param("userId1") Integer userId1, @Param("userId2") Integer userId2);

    /**
     * Find system announcement room
     */
    @Query("SELECT cr FROM ChatRoom cr " +
           "WHERE cr.roomType = 'SYSTEM' " +
           "AND cr.isActive = true " +
           "ORDER BY cr.createdAt ASC")
    List<ChatRoom> findSystemRooms();

    /**
     * Find rooms created by a specific user
     */
    List<ChatRoom> findByCreatedByUserIdAndIsActiveTrue(Integer createdByUserId);

    /**
     * Search rooms by name (case-insensitive, Vietnamese support)
     */
    @Query("SELECT cr FROM ChatRoom cr " +
           "WHERE LOWER(cr.roomName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) " +
           "AND cr.isActive = true " +
           "ORDER BY cr.roomName")
    List<ChatRoom> searchRoomsByName(@Param("searchTerm") String searchTerm);

    /**
     * Find rooms accessible by user based on branch and role
     */
    @Query("SELECT DISTINCT cr FROM ChatRoom cr " +
           "LEFT JOIN cr.participants cp " +
           "WHERE cr.isActive = true " +
           "AND (" +
           "  (cr.roomType = 'SYSTEM') OR " +
           "  (cr.roomType = 'BRANCH' AND cr.branch.branchId = :branchId) OR " +
           "  (cr.roomType IN ('DIRECT', 'GROUP') AND cp.user.userId = :userId AND cp.isActive = true)" +
           ") " +
           "ORDER BY cr.updatedAt DESC")
    List<ChatRoom> findAccessibleRooms(@Param("userId") Integer userId, @Param("branchId") Integer branchId);

    /**
     * Count active participants in a room
     */
    @Query("SELECT COUNT(cp) FROM ChatParticipant cp " +
           "WHERE cp.chatRoom.roomId = :roomId " +
           "AND cp.isActive = true")
    Long countActiveParticipants(@Param("roomId") Integer roomId);

    /**
     * Find rooms with unread messages for a user
     */
    @Query("SELECT DISTINCT cr FROM ChatRoom cr " +
           "JOIN cr.participants cp " +
           "JOIN cr.messages cm " +
           "WHERE cp.user.userId = :userId " +
           "AND cp.isActive = true " +
           "AND cr.isActive = true " +
           "AND (cp.lastReadAt IS NULL OR cm.sentAt > cp.lastReadAt) " +
           "AND cm.isDeleted = false " +
           "ORDER BY cr.updatedAt DESC")
    List<ChatRoom> findRoomsWithUnreadMessages(@Param("userId") Integer userId);

    /**
     * Find recent active rooms (with recent messages)
     */
    @Query("SELECT DISTINCT cr FROM ChatRoom cr " +
           "JOIN cr.messages cm " +
           "WHERE cr.isActive = true " +
           "AND cm.sentAt >= :since " +
           "AND cm.isDeleted = false " +
           "ORDER BY cm.sentAt DESC")
    List<ChatRoom> findRecentActiveRooms(@Param("since") java.time.LocalDateTime since);

    /**
     * Check if user can access a specific room
     */
    @Query("SELECT CASE WHEN COUNT(cr) > 0 THEN true ELSE false END FROM ChatRoom cr " +
           "LEFT JOIN cr.participants cp " +
           "WHERE cr.roomId = :roomId " +
           "AND cr.isActive = true " +
           "AND (" +
           "  (cr.roomType = 'SYSTEM') OR " +
           "  (cr.roomType = 'BRANCH' AND cr.branch.branchId = :branchId) OR " +
           "  (cr.roomType IN ('DIRECT', 'GROUP') AND cp.user.userId = :userId AND cp.isActive = true)" +
           ")")
    boolean canUserAccessRoom(@Param("userId") Integer userId, @Param("branchId") Integer branchId, @Param("roomId") Integer roomId);
}
