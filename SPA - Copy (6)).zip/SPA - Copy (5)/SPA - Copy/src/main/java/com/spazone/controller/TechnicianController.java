package com.spazone.controller;

import com.spazone.entity.Appointment;
import com.spazone.entity.AppointmentServiceEntity;
import com.spazone.entity.Branch;
import com.spazone.entity.Room;
import com.spazone.entity.Service;
import com.spazone.entity.TreatmentRecord;
import com.spazone.entity.User;
import com.spazone.repository.AppointmentRepository;
import com.spazone.repository.ServiceRepository;
import com.spazone.repository.UserRepository;
import com.spazone.service.AppointmentService;
import com.spazone.service.AppointmentServiceService;
import com.spazone.service.CloudinaryService;
import com.spazone.service.InvoiceService;
import com.spazone.service.RoomService;
import com.spazone.service.SpaServiceService;
import com.spazone.service.TreatmentRecordService;
import com.spazone.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
@RequestMapping("/technician")
@PreAuthorize("hasRole('TECHNICIAN')")
public class TechnicianController {

    private static final Logger logger = LoggerFactory.getLogger(TechnicianController.class);

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private UserService userService;

    @Autowired
    private TreatmentRecordService treatmentRecordService;

    @Autowired
    private AppointmentServiceService appointmentServiceService;

    @Autowired
    private SpaServiceService spaServiceService;

    @Autowired
    private CloudinaryService cloudinaryService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ServiceRepository serviceRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private RoomService roomService;

    @Autowired
    private InvoiceService invoiceService;

    /**
     * Enhanced Technician Dashboard
     * Displays daily appointment schedule with customer details, service details and duration,
     * filter appointments by date/status, and display previous treatment history for customers
     */
    @GetMapping("/dashboard")
    public String dashboard(@RequestParam(value = "date", required = false) String dateStr,
                           @RequestParam(value = "status", required = false) String status,
                           @RequestParam(value = "page", defaultValue = "0") int page,
                           @RequestParam(value = "size", defaultValue = "10") int size,
                           Authentication authentication,
                           Model model) {

        // Get current technician
        String username = authentication.getName();
        User currentTechnician = userService.findByUsername(username);

        // Parse date parameter or use today
        LocalDate selectedDate = dateStr != null ? LocalDate.parse(dateStr) : LocalDate.now();
        
        // Create date range for the selected day
        LocalDateTime startOfDay = selectedDate.atStartOfDay();
        LocalDateTime endOfDay = selectedDate.atTime(23, 59, 59);

        // Get appointments for the technician on the selected date
        Pageable pageable = PageRequest.of(page, size);
        Page<Appointment> appointmentsPage = appointmentService.getAppointmentsByTechnicianAndDateRange(
                currentTechnician.getUserId(), startOfDay, endOfDay, status, pageable);

        // Update appointment statuses based on treatment record completion
        for (Appointment appointment : appointmentsPage.getContent()) {
            appointmentService.updateAppointmentStatusBasedOnTreatmentRecords(appointment.getAppointmentId());
        }

        // Refresh the page data after status updates
        appointmentsPage = appointmentService.getAppointmentsByTechnicianAndDateRange(
                currentTechnician.getUserId(), startOfDay, endOfDay, status, pageable);

        // Get today's appointments count for quick stats
        LocalDateTime todayStart = LocalDate.now().atStartOfDay();
        LocalDateTime todayEnd = LocalDate.now().atTime(23, 59, 59);
        List<Appointment> todayAppointments = appointmentService.getAppointmentsByTechnicianAndDateRange(
                currentTechnician.getUserId(), todayStart, todayEnd);

        // Calculate statistics
        long totalToday = todayAppointments.size();
        long completedToday = todayAppointments.stream()
                .filter(apt -> "completed".equals(apt.getStatus()))
                .count();
        long pendingToday = todayAppointments.stream()
                .filter(apt -> "confirmed".equals(apt.getStatus()) || "checked-in".equals(apt.getStatus()))
                .count();

        // Get recent treatment records for context
        List<TreatmentRecord> recentTreatments = treatmentRecordService
                .getRecentTreatmentsByTechnician(currentTechnician.getUserId(), 5);

        model.addAttribute("currentTechnician", currentTechnician);
        model.addAttribute("appointmentsPage", appointmentsPage);
        model.addAttribute("selectedDate", selectedDate);
        model.addAttribute("selectedStatus", status);
        model.addAttribute("totalToday", totalToday);
        model.addAttribute("completedToday", completedToday);
        model.addAttribute("pendingToday", pendingToday);
        model.addAttribute("recentTreatments", recentTreatments);

        return "technician/dashboard";
    }

    /**
     * Get customer treatment history for a specific customer
     */
    @GetMapping("/customer/{customerId}/history")
    public String getCustomerHistory(@PathVariable Integer customerId,
                                   @RequestParam(value = "page", defaultValue = "0") int page,
                                   @RequestParam(value = "size", defaultValue = "10") int size,
                                   Authentication authentication,
                                   Model model) {

        // Get current technician
        String username = authentication.getName();
        User currentTechnician = userService.findByUsername(username);

        // Get customer information
        User customer = userService.findById(customerId);
        if (customer == null) {
            model.addAttribute("errorMessage", "Customer not found");
            return "redirect:/technician/dashboard";
        }

        // Get customer's treatment history
        Pageable pageable = PageRequest.of(page, size);
        Page<TreatmentRecord> treatmentHistory = treatmentRecordService
                .getTreatmentHistoryByCustomer(customerId, pageable);

        // Get customer's appointment history with this technician
        List<Appointment> appointmentHistory = appointmentService
                .getAppointmentsByCustomerAndTechnician(customerId, currentTechnician.getUserId());

        model.addAttribute("customer", customer);
        model.addAttribute("treatmentHistory", treatmentHistory);
        model.addAttribute("appointmentHistory", appointmentHistory);
        model.addAttribute("currentTechnician", currentTechnician);

        return "technician/customer-history";
    }

    /**
     * Quick appointment status update
     */
    @PostMapping("/appointment/{appointmentId}/status")
    @ResponseBody
    public String updateAppointmentStatus(@PathVariable Integer appointmentId,
                                        @RequestParam String newStatus,
                                        Authentication authentication) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Verify the appointment belongs to this technician
            Appointment appointment = appointmentService.findById(appointmentId);
            if (appointment == null || !appointment.getTechnician().getUserId().equals(currentTechnician.getUserId())) {
                return "error:Unauthorized access to appointment";
            }

            // Check if appointment is for today or past (prevent actions on future appointments)
            LocalDate appointmentDate = appointment.getAppointmentDate().toLocalDate();
            LocalDate today = LocalDate.now();
            if (appointmentDate.isAfter(today)) {
                return "error:Cannot modify appointments scheduled for future dates";
            }

            // Update appointment status
            appointmentService.updateAppointmentStatus(appointmentId, newStatus);
            return "success:Status updated successfully";

        } catch (Exception e) {
            return "error:" + e.getMessage();
        }
    }

    /**
     * Start a specific service (update status to in-progress)
     */
    @PostMapping("/service/{serviceId}/start")
    @ResponseBody
    public String startService(@PathVariable Integer serviceId,
                              Authentication authentication) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Verify the service belongs to this technician's appointment
            AppointmentServiceEntity appointmentService = appointmentServiceService.findById(serviceId);
            if (!appointmentService.getAppointment().getTechnician().getUserId().equals(currentTechnician.getUserId())) {
                return "error:Unauthorized access to service";
            }

            // Check if appointment is for today or past (prevent actions on future appointments)
            LocalDate appointmentDate = appointmentService.getAppointment().getAppointmentDate().toLocalDate();
            LocalDate today = LocalDate.now();
            if (appointmentDate.isAfter(today)) {
                return "error:Cannot start services for appointments scheduled for future dates";
            }

            // Start the service
            appointmentServiceService.startService(serviceId);
            return "success:Service started successfully";

        } catch (Exception e) {
            return "error:" + e.getMessage();
        }
    }

    /**
     * Complete a specific service (update status to completed)
     */
    @PostMapping("/service/{serviceId}/complete")
    @ResponseBody
    public String completeService(@PathVariable Integer serviceId,
                                 Authentication authentication) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Verify the service belongs to this technician's appointment
            AppointmentServiceEntity appointmentService = appointmentServiceService.findById(serviceId);
            if (!appointmentService.getAppointment().getTechnician().getUserId().equals(currentTechnician.getUserId())) {
                return "error:Unauthorized access to service";
            }

            // Check if appointment is for today or past (prevent actions on future appointments)
            LocalDate appointmentDate = appointmentService.getAppointment().getAppointmentDate().toLocalDate();
            LocalDate today = LocalDate.now();
            if (appointmentDate.isAfter(today)) {
                return "error:Cannot complete services for appointments scheduled for future dates";
            }

            // Complete the service
            appointmentServiceService.completeService(serviceId);

            // Check if all services are completed and update appointment status
            Integer appointmentId = appointmentService.getAppointment().getAppointmentId();
            if (appointmentServiceService.areAllServicesCompleted(appointmentId)) {
                this.appointmentService.updateAppointmentStatus(appointmentId, "completed");
            }

            return "success:Service completed successfully";

        } catch (Exception e) {
            return "error:" + e.getMessage();
        }
    }

    /**
     * Get services for an appointment with their status
     */
    @GetMapping("/appointment/{appointmentId}/services")
    @ResponseBody
    public List<Map<String, Object>> getAppointmentServices(@PathVariable Integer appointmentId,
                                                           Authentication authentication) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Verify the appointment belongs to this technician
            Appointment appointment = appointmentService.findById(appointmentId);
            if (appointment == null || !appointment.getTechnician().getUserId().equals(currentTechnician.getUserId())) {
                throw new RuntimeException("Unauthorized access to appointment");
            }

            List<AppointmentServiceEntity> services = appointmentServiceService.getServicesByAppointmentId(appointmentId);

            // Convert to simple maps to avoid serialization issues
            return services.stream().map(service -> {
                Map<String, Object> serviceMap = new HashMap<>();
                serviceMap.put("id", service.getId());
                serviceMap.put("serviceName", service.getService().getName());
                serviceMap.put("status", service.getStatus());
                serviceMap.put("quantity", service.getQuantity());
                serviceMap.put("totalPrice", service.getTotalPrice());
                serviceMap.put("totalDuration", service.getTotalDuration());
                return serviceMap;
            }).collect(Collectors.toList());

        } catch (Exception e) {
            throw new RuntimeException("Error retrieving services: " + e.getMessage());
        }
    }

    /**
     * View detailed appointment information with all services and treatment records
     */
    @GetMapping("/appointment/{appointmentId}")
    public String viewAppointmentDetails(@PathVariable Integer appointmentId,
                                       Authentication authentication,
                                       Model model) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Get appointment and verify access
            Appointment appointment = appointmentService.findById(appointmentId);
            if (appointment == null || !appointment.getTechnician().getUserId().equals(currentTechnician.getUserId())) {
                model.addAttribute("errorMessage", "Unauthorized access to appointment");
                return "redirect:/technician/dashboard";
            }

            // Get all services in the appointment with their status
            List<AppointmentServiceEntity> appointmentServices = appointmentServiceService.getServicesByAppointmentId(appointmentId);

            // Get treatment records for the appointment (supports multiple service-specific records)
            List<TreatmentRecord> treatmentRecords = treatmentRecordService.findByAppointmentAppointmentId(appointmentId);

            // Check if appointment is completed (all services have treatment records)
            boolean isAppointmentCompleted = appointmentService.isAppointmentCompleted(appointmentId);

            model.addAttribute("appointment", appointment);
            model.addAttribute("appointmentServices", appointmentServices);
            model.addAttribute("treatmentRecords", treatmentRecords);
            model.addAttribute("currentTechnician", currentTechnician);
            model.addAttribute("isAppointmentCompleted", isAppointmentCompleted);

            return "technician/appointment-details";

        } catch (Exception e) {
            logger.error("Error loading appointment details for appointment {}: {}", appointmentId, e.getMessage());
            model.addAttribute("errorMessage", "Error loading appointment details: " + e.getMessage());
            return "redirect:/technician/dashboard";
        }
    }

    /**
     * Show available services for addition during treatment
     */
    @GetMapping("/appointment/{appointmentId}/add-services")
    public String showAddServicesForm(@PathVariable Integer appointmentId,
                                    Authentication authentication,
                                    Model model) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Verify the appointment belongs to this technician
            Appointment appointment = appointmentService.findById(appointmentId);
            if (appointment == null || !appointment.getTechnician().getUserId().equals(currentTechnician.getUserId())) {
                model.addAttribute("errorMessage", "Unauthorized access to appointment");
                return "redirect:/technician/dashboard";
            }

            // Get available services (active services from the same branch)
            List<Service> availableServices = spaServiceService.findActiveByBranchId(appointment.getBranch().getBranchId());

            // Get current services in the appointment
            List<AppointmentServiceEntity> currentServices = appointmentServiceService.getServicesByAppointmentId(appointmentId);

            model.addAttribute("appointment", appointment);
            model.addAttribute("availableServices", availableServices);
            model.addAttribute("currentServices", currentServices);
            model.addAttribute("currentTechnician", currentTechnician);

            return "technician/add-services";

        } catch (Exception e) {
            model.addAttribute("errorMessage", "Error loading services: " + e.getMessage());
            return "redirect:/technician/dashboard";
        }
    }

    /**
     * Add services to appointment (requires customer approval)
     */
    @PostMapping("/appointment/{appointmentId}/add-services")
    @ResponseBody
    public String addServicesToAppointment(@PathVariable Integer appointmentId,
                                         @RequestParam("serviceIds") List<Integer> serviceIds,
                                         @RequestParam(value = "quantities", required = false) List<Integer> quantities,
                                         @RequestParam(value = "notes", required = false) String notes,
                                         Authentication authentication) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Verify the appointment belongs to this technician
            Appointment appointment = appointmentService.findById(appointmentId);
            if (appointment == null || !appointment.getTechnician().getUserId().equals(currentTechnician.getUserId())) {
                return "error:Unauthorized access to appointment";
            }

            // Validate input
            if (serviceIds == null || serviceIds.isEmpty()) {
                return "error:No services selected";
            }

            // Set default quantities if not provided
            if (quantities == null || quantities.size() != serviceIds.size()) {
                quantities = new ArrayList<>();
                for (int i = 0; i < serviceIds.size(); i++) {
                    quantities.add(1);
                }
            }

            // Add services to appointment (pending customer approval)
            appointmentService.addServicesToAppointment(appointmentId, serviceIds, quantities, notes, true);

            return "success:Services added successfully. Customer approval required.";

        } catch (Exception e) {
            return "error:" + e.getMessage();
        }
    }

    /**
     * Get suggested services based on current appointment services
     */
    @GetMapping("/appointment/{appointmentId}/suggested-services")
    @ResponseBody
    public List<Map<String, Object>> getSuggestedServices(@PathVariable Integer appointmentId,
                                                         Authentication authentication) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Verify the appointment belongs to this technician
            Appointment appointment = appointmentService.findById(appointmentId);
            if (appointment == null || !appointment.getTechnician().getUserId().equals(currentTechnician.getUserId())) {
                throw new RuntimeException("Unauthorized access to appointment");
            }

            // Get suggested services based on current services and customer history
            List<com.spazone.entity.Service> services = appointmentService.getSuggestedServices(appointmentId);

            // Convert to simple maps to avoid serialization issues
            return services.stream().map(service -> {
                Map<String, Object> serviceMap = new HashMap<>();
                serviceMap.put("id", service.getServiceId());
                serviceMap.put("name", service.getName());
                serviceMap.put("description", service.getDescription());
                serviceMap.put("price", service.getPrice());
                serviceMap.put("duration", service.getDuration());
                serviceMap.put("category", service.getCategory());
                return serviceMap;
            }).collect(Collectors.toList());

        } catch (Exception e) {
            throw new RuntimeException("Error getting suggested services: " + e.getMessage());
        }
    }

    /**
     * Create or manage treatment record for a specific service
     */
    @GetMapping("/service/{serviceId}/treatment")
    public String manageServiceTreatmentRecord(@PathVariable Integer serviceId,
                                             @RequestParam(required = false) Integer appointmentId,
                                             Authentication authentication,
                                             Model model) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Get the appointment service entity
            AppointmentServiceEntity appointmentService = appointmentServiceService.findById(serviceId);
            if (appointmentService == null) {
                model.addAttribute("errorMessage", "Service not found");
                return "redirect:/technician/dashboard";
            }

            // Verify technician access
            if (!appointmentService.getAppointment().getTechnician().getUserId().equals(currentTechnician.getUserId())) {
                model.addAttribute("errorMessage", "Unauthorized access to service");
                return "redirect:/technician/dashboard";
            }

            // Get existing treatment records for this service
            List<TreatmentRecord> existingRecords = treatmentRecordService.findByAppointmentAndService(
                appointmentService.getAppointment(), appointmentService.getService());

            model.addAttribute("appointmentService", appointmentService);
            model.addAttribute("appointment", appointmentService.getAppointment());
            model.addAttribute("service", appointmentService.getService());
            model.addAttribute("existingRecords", existingRecords);
            model.addAttribute("currentTechnician", currentTechnician);

            return "technician/service-treatment";

        } catch (Exception e) {
            logger.error("Error loading service treatment management for service {}: {}", serviceId, e.getMessage());
            model.addAttribute("errorMessage", "Error loading treatment management: " + e.getMessage());
            return "redirect:/technician/dashboard";
        }
    }

    /**
     * Create a new treatment record for a specific service
     */
    @PostMapping("/service/{serviceId}/treatment/create")
    @ResponseBody
    public String createServiceTreatmentRecord(@PathVariable Integer serviceId,
                                             @RequestParam String preTreatmentNotes,
                                             @RequestParam(required = false) String postTreatmentNotes,
                                             @RequestParam(required = false) String customerFeedback,
                                             @RequestParam(required = false) String followUpNotes,
                                             @RequestParam(required = false) Integer treatmentProgress,
                                             @RequestParam(required = false) MultipartFile beforeImage,
                                             @RequestParam(required = false) MultipartFile afterImage,
                                             Authentication authentication) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Get the appointment service entity
            AppointmentServiceEntity appointmentService = appointmentServiceService.findById(serviceId);
            if (appointmentService == null) {
                return "error:Service not found";
            }

            // Verify technician access
            if (!appointmentService.getAppointment().getTechnician().getUserId().equals(currentTechnician.getUserId())) {
                return "error:Unauthorized access to service";
            }

            // Handle image uploads
            String beforeImageUrl = null;
            String afterImageUrl = null;

            try {
                if (beforeImage != null && !beforeImage.isEmpty()) {
                    // Validate image file
                    if (!isValidImageFile(beforeImage)) {
                        return "error:Invalid before image file. Please upload JPG, PNG, or GIF files only.";
                    }
                    beforeImageUrl = cloudinaryService.uploadImage(beforeImage);
                    logger.info("Before image uploaded successfully: {}", beforeImageUrl);
                }

                if (afterImage != null && !afterImage.isEmpty()) {
                    // Validate image file
                    if (!isValidImageFile(afterImage)) {
                        return "error:Invalid after image file. Please upload JPG, PNG, or GIF files only.";
                    }
                    afterImageUrl = cloudinaryService.uploadImage(afterImage);
                    logger.info("After image uploaded successfully: {}", afterImageUrl);
                }
            } catch (Exception e) {
                logger.error("Error uploading images for treatment record: {}", e.getMessage());
                return "error:Failed to upload images: " + e.getMessage();
            }

            // Create new treatment record
            TreatmentRecord record = new TreatmentRecord();
            record.setAppointment(appointmentService.getAppointment());
            record.setService(appointmentService.getService());
            record.setTechnician(currentTechnician);
            record.setTreatmentDate(LocalDateTime.now());
            record.setPreTreatmentNotes(preTreatmentNotes);
            record.setPostTreatmentNotes(postTreatmentNotes);
            record.setCustomerFeedback(customerFeedback);
            record.setFollowUpNotes(followUpNotes);
            record.setTreatmentProgress(treatmentProgress != null ? treatmentProgress : 0);
            record.setBeforeImageUrl(beforeImageUrl);
            record.setAfterImageUrl(afterImageUrl);

            treatmentRecordService.save(record);

            // Update appointment status based on treatment record completion
            this.appointmentService.updateAppointmentStatusBasedOnTreatmentRecords(appointmentService.getAppointment().getAppointmentId());

            return "success:Treatment record created successfully";

        } catch (Exception e) {
            logger.error("Error creating service treatment record for service {}: {}", serviceId, e.getMessage());
            return "error:" + e.getMessage();
        }
    }

    /**
     * Validate image file type and size
     */
    private boolean isValidImageFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            return false;
        }

        // Check file size (max 10MB)
        if (file.getSize() > 10 * 1024 * 1024) {
            return false;
        }

        // Check content type
        String contentType = file.getContentType();
        return contentType != null && (
            contentType.equals("image/jpeg") ||
            contentType.equals("image/jpg") ||
            contentType.equals("image/png") ||
            contentType.equals("image/gif") ||
            contentType.equals("image/bmp") ||
            contentType.equals("image/webp")
        );
    }

    /**
     * Show follow-up appointment creation form
     */
    @GetMapping("/appointment/{appointmentId}/create-followup")
    public String showFollowUpAppointmentForm(@PathVariable Integer appointmentId,
                                            Authentication authentication,
                                            Model model) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Verify the appointment belongs to this technician
            Appointment appointment = appointmentService.findById(appointmentId);
            if (appointment == null || !appointment.getTechnician().getUserId().equals(currentTechnician.getUserId())) {
                model.addAttribute("errorMessage", "Unauthorized access to appointment");
                return "redirect:/technician/dashboard";
            }

            // Check if appointment is completed (has treatment records for all services)
            if (!appointmentService.isAppointmentCompleted(appointmentId)) {
                model.addAttribute("errorMessage", "Cannot create follow-up appointment: treatment records are not completed for all services");
                return "redirect:/technician/appointment/" + appointmentId;
            }

            // Get available services for the branch
            List<com.spazone.entity.Service> availableServices = spaServiceService.findAllActive()
                    .stream()
                    .filter(service -> service.getBranch().getBranchId().equals(appointment.getBranch().getBranchId()))
                    .collect(Collectors.toList());

            model.addAttribute("appointment", appointment);
            model.addAttribute("availableServices", availableServices);
            model.addAttribute("customer", appointment.getCustomer());
            model.addAttribute("branch", appointment.getBranch());

            return "technician/followup-appointment-form";

        } catch (Exception e) {
            model.addAttribute("errorMessage", "Error loading follow-up appointment form: " + e.getMessage());
            return "redirect:/technician/dashboard";
        }
    }

    /**
     * Create follow-up appointment
     */
    @PostMapping("/appointment/{appointmentId}/create-followup")
    @ResponseBody
    public String createFollowUpAppointment(@PathVariable Integer appointmentId,
                                          @RequestParam("serviceIds") List<Integer> serviceIds,
                                          @RequestParam(value = "quantities", required = false) List<Integer> quantities,
                                          @RequestParam(value = "schedulingType", defaultValue = "immediate") String schedulingType,
                                          @RequestParam(value = "customDateTime", required = false) String customDateTime,
                                          @RequestParam(value = "technicianId", required = false) Integer technicianId,
                                          Authentication authentication) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Verify the appointment belongs to this technician
            Appointment appointment = appointmentService.findById(appointmentId);
            if (appointment == null || !appointment.getTechnician().getUserId().equals(currentTechnician.getUserId())) {
                return "error:Unauthorized access to appointment";
            }

            // Validate service selection
            if (serviceIds == null || serviceIds.isEmpty()) {
                return "error:Please select at least one service";
            }

            // Parse custom date/time if provided
            LocalDateTime customDateTimeParsed = null;
            if ("future".equals(schedulingType) && customDateTime != null && !customDateTime.trim().isEmpty()) {
                try {
                    customDateTimeParsed = LocalDateTime.parse(customDateTime);
                } catch (Exception e) {
                    return "error:Invalid date/time format";
                }
            }

            // Use current technician as default if not specified
            if (technicianId == null) {
                technicianId = currentTechnician.getUserId();
            }

            // Create the follow-up appointment
            Appointment followUpAppointment = appointmentService.createFollowUpAppointment(
                    appointmentId, serviceIds, quantities, schedulingType, customDateTimeParsed, technicianId);

            return "success:Follow-up appointment created successfully. Appointment ID: " + followUpAppointment.getAppointmentId();

        } catch (Exception e) {
            return "error:" + e.getMessage();
        }
    }

    /**
     * Create new appointment from technician dashboard
     */
    @PostMapping("/appointments/create")
    @ResponseBody
    public String createNewAppointment(@RequestParam Integer customerId,
                                     @RequestParam Integer serviceId,
                                     @RequestParam String appointmentDateTime,
                                     @RequestParam(value = "notes", required = false) String notes,
                                     Authentication authentication) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Validate customer
            User customer = userRepository.findById(customerId)
                    .orElseThrow(() -> new IllegalArgumentException("Customer not found"));

            // Validate service
            com.spazone.entity.Service service = serviceRepository.findById(serviceId)
                    .orElseThrow(() -> new IllegalArgumentException("Service not found"));

            // Validate service belongs to technician's branch
            if (!service.getBranch().getBranchId().equals(currentTechnician.getBranch().getBranchId())) {
                return "error:Service is not available in your branch";
            }

            // Parse appointment date/time
            LocalDateTime startTime;
            try {
                startTime = LocalDateTime.parse(appointmentDateTime);
            } catch (Exception e) {
                return "error:Invalid date/time format";
            }

            // Validate appointment time is in the future
            if (startTime.isBefore(LocalDateTime.now().plusMinutes(15))) {
                return "error:Appointment time must be at least 15 minutes from now";
            }

            LocalDateTime endTime = startTime.plusMinutes(service.getDuration());

            // Check technician availability
            List<Appointment> conflicts = appointmentRepository.findConflictingAppointments(
                    currentTechnician.getUserId(), startTime, endTime);

            if (!conflicts.isEmpty()) {
                return "error:You have a conflicting appointment at this time";
            }

            // Auto-assign room
            Room assignedRoom = roomService.autoAssignRoom(currentTechnician.getBranch(), startTime, endTime);
            if (assignedRoom == null) {
                return "error:No rooms available for the selected time slot";
            }

            // Create appointment
            Appointment appointment = new Appointment();
            appointment.setCustomer(customer);
            appointment.setBranch(currentTechnician.getBranch());
            appointment.setTechnician(currentTechnician);
            appointment.setRoom(assignedRoom);
            appointment.setStartTime(startTime);
            appointment.setEndTime(endTime);
            appointment.setAppointmentDate(startTime);
            appointment.setStatus("scheduled");
            appointment.setNotes(notes);

            // Create appointment with service
            appointmentService.createWithServices(appointment, Arrays.asList(serviceId));

            // Generate invoice
            invoiceService.generateInvoiceForAppointment(appointment);

            return "success:Appointment created successfully. Appointment ID: " + appointment.getAppointmentId();

        } catch (Exception e) {
            return "error:" + e.getMessage();
        }
    }

    /**
     * Create new appointment with multiple services from technician dashboard
     */
    @PostMapping("/appointments/create-multiple")
    @ResponseBody
    public String createNewAppointmentWithMultipleServices(@RequestParam Integer customerId,
                                                         @RequestParam("serviceIds") List<Integer> serviceIds,
                                                         @RequestParam String appointmentDateTime,
                                                         @RequestParam(value = "roomId", required = false) String roomId,
                                                         @RequestParam(value = "notes", required = false) String notes,
                                                         Authentication authentication) {
        try {
            // Get current technician
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);

            // Validate customer
            User customer = userRepository.findById(customerId)
                    .orElseThrow(() -> new IllegalArgumentException("Customer not found"));

            // Validate services
            if (serviceIds == null || serviceIds.isEmpty()) {
                return "error:Please select at least one service";
            }

            List<com.spazone.entity.Service> services = new ArrayList<>();
            int totalDuration = 0;

            for (Integer serviceId : serviceIds) {
                com.spazone.entity.Service service = serviceRepository.findById(serviceId)
                        .orElseThrow(() -> new IllegalArgumentException("Service not found: " + serviceId));

                // Validate service belongs to technician's branch
                if (!service.getBranch().getBranchId().equals(currentTechnician.getBranch().getBranchId())) {
                    return "error:Service '" + service.getName() + "' is not available in your branch";
                }

                services.add(service);
                totalDuration += service.getDuration();
            }

            // Parse appointment date/time
            LocalDateTime startTime;
            try {
                startTime = LocalDateTime.parse(appointmentDateTime);
            } catch (Exception e) {
                return "error:Invalid date/time format";
            }

            // Validate appointment time is in the future
            if (startTime.isBefore(LocalDateTime.now().plusMinutes(15))) {
                return "error:Appointment time must be at least 15 minutes from now";
            }

            LocalDateTime endTime = startTime.plusMinutes(totalDuration);

            // Check technician availability
            List<Appointment> conflicts = appointmentRepository.findConflictingAppointments(
                    currentTechnician.getUserId(), startTime, endTime);

            if (!conflicts.isEmpty()) {
                return "error:You have a conflicting appointment during this time period";
            }

            // Handle room assignment
            Room assignedRoom;
            if (roomId != null && !roomId.isEmpty() && !"auto".equals(roomId)) {
                // Manual room selection
                try {
                    Integer selectedRoomId = Integer.parseInt(roomId);
                    assignedRoom = roomService.findById(selectedRoomId);
                    if (assignedRoom == null) {
                        return "error:Selected room not found";
                    }

                    // Check if room is available for the selected time
                    List<Room> availableRooms = roomService.findAvailableRooms(currentTechnician.getBranch(), startTime, endTime);
                    if (!availableRooms.contains(assignedRoom)) {
                        return "error:Selected room is not available for the chosen time slot";
                    }
                } catch (NumberFormatException e) {
                    return "error:Invalid room selection";
                }
            } else {
                // Auto-assign room
                assignedRoom = roomService.autoAssignRoom(currentTechnician.getBranch(), startTime, endTime);
                if (assignedRoom == null) {
                    return "error:No rooms available for the selected time slot";
                }
            }

            // Create appointment
            Appointment appointment = new Appointment();
            appointment.setCustomer(customer);
            appointment.setBranch(currentTechnician.getBranch());
            appointment.setTechnician(currentTechnician);
            appointment.setRoom(assignedRoom);
            appointment.setStartTime(startTime);
            appointment.setEndTime(endTime);
            appointment.setAppointmentDate(startTime);
            appointment.setStatus("scheduled");
            appointment.setNotes(notes);

            // Create appointment with multiple services
            appointmentService.createWithServices(appointment, serviceIds);

            // Generate invoice
            invoiceService.generateInvoiceForAppointment(appointment);

            return "success:Appointment created successfully with " + serviceIds.size() + " service(s). Appointment ID: " + appointment.getAppointmentId();

        } catch (Exception e) {
            return "error:" + e.getMessage();
        }
    }

    /**
     * API endpoint to get all customers for appointment creation
     */
    @GetMapping("/api/customers")
    @ResponseBody
    public List<Map<String, Object>> getAllCustomers() {
        try {
            List<User> customers = userRepository.findAllCustomers();
            return customers.stream().map(customer -> {
                Map<String, Object> customerMap = new HashMap<>();
                customerMap.put("userId", customer.getUserId());
                customerMap.put("fullName", customer.getFullName());
                customerMap.put("email", customer.getEmail());
                customerMap.put("phone", customer.getPhone());
                return customerMap;
            }).collect(Collectors.toList());
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    /**
     * API endpoint to get services by branch for appointment creation
     */
    @GetMapping("/api/services/branch/{branchId}")
    @ResponseBody
    public List<Map<String, Object>> getServicesByBranch(@PathVariable Integer branchId) {
        try {
            List<com.spazone.entity.Service> services = spaServiceService.findActiveByBranchId(branchId);
            return services.stream().map(service -> {
                Map<String, Object> serviceMap = new HashMap<>();
                serviceMap.put("serviceId", service.getServiceId());
                serviceMap.put("name", service.getName());
                serviceMap.put("description", service.getDescription());
                serviceMap.put("price", service.getPrice());
                serviceMap.put("duration", service.getDuration());
                return serviceMap;
            }).collect(Collectors.toList());
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    /**
     * API endpoint to get available rooms for appointment creation
     */
    @GetMapping("/api/rooms/available")
    @ResponseBody
    public List<Map<String, Object>> getAvailableRooms(@RequestParam Integer branchId,
                                                       @RequestParam String startTime,
                                                       @RequestParam Integer duration,
                                                       Authentication authentication) {
        try {
            LocalDateTime appointmentStart = LocalDateTime.parse(startTime);
            LocalDateTime appointmentEnd = appointmentStart.plusMinutes(duration);

            // Get current technician and their branch
            String username = authentication.getName();
            User currentTechnician = userService.findByUsername(username);
            Branch branch = currentTechnician.getBranch();

            // Get available rooms using existing method
            List<Room> availableRooms = roomService.findAvailableRooms(branch, appointmentStart, appointmentEnd);

            return availableRooms.stream().map(room -> {
                Map<String, Object> roomMap = new HashMap<>();
                roomMap.put("roomId", room.getId());
                roomMap.put("name", room.getName());
                roomMap.put("roomType", room.getStatus()); // Using status as room type
                roomMap.put("capacity", room.getCapacity());
                roomMap.put("description", room.getDescription());
                return roomMap;
            }).collect(Collectors.toList());

        } catch (Exception e) {
            System.err.println("Error loading available rooms: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}
