package com.spazone.service;

import com.spazone.entity.ReceptionistKPI;
import com.spazone.entity.User;
import com.spazone.entity.UserKPI;
import com.spazone.service.ReceptionistKPIService;
import com.spazone.service.UserKPIService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

/**
 * Service to handle KPI bonus calculations for employees who achieve their targets.
 * Provides 10% of base salary bonus when KPI targets are met.
 */
@Service
public class KPIBonusService {

    @Autowired
    private ReceptionistKPIService receptionistKPIService;

    @Autowired
    private UserKPIService userKPIService;

    private static final BigDecimal KPI_BONUS_PERCENTAGE = new BigDecimal("0.10"); // 10%

    /**
     * Check if a receptionist has achieved all their KPI targets for the given month/year.
     * For receptionists, all targets must be met: appointments, invoices, and revenue.
     *
     * @param userId The receptionist's user ID
     * @param month The month to check
     * @param year The year to check
     * @return true if all KPI targets are achieved, false otherwise
     */
    public boolean isReceptionistKPIAchieved(Integer userId, Integer month, Integer year) {
        try {
            List<ReceptionistKPI> kpis = receptionistKPIService.getKPIsByReceptionistAndMonthAndYear(userId, month, year);
            
            if (kpis.isEmpty()) {
                return false; // No KPI set for this month
            }

            ReceptionistKPI kpi = kpis.get(0); // Get the first (active) KPI
            
            // Check if all targets are achieved
            return kpi.isAppointmentTargetAchieved() && 
                   kpi.isInvoiceTargetAchieved() && 
                   kpi.isRevenueTargetAchieved();
                   
        } catch (Exception e) {
            System.err.println("Error checking receptionist KPI achievement for user " + userId + ": " + e.getMessage());
            return false;
        }
    }

    /**
     * Check if a technician has achieved their KPI target for the given month/year.
     * For technicians, only the appointment target needs to be met.
     *
     * @param userId The technician's user ID
     * @param month The month to check
     * @param year The year to check
     * @return true if KPI target is achieved, false otherwise
     */
    public boolean isTechnicianKPIAchieved(Integer userId, Integer month, Integer year) {
        try {
            List<UserKPI> kpis = userKPIService.getKPIsByTechnicianAndMonthAndYear(userId, month, year);
            
            if (kpis.isEmpty()) {
                return false; // No KPI set for this month
            }

            UserKPI kpi = kpis.get(0); // Get the first (active) KPI
            
            return kpi.isTargetAchieved();
            
        } catch (Exception e) {
            System.err.println("Error checking technician KPI achievement for user " + userId + ": " + e.getMessage());
            return false;
        }
    }

    /**
     * Calculate KPI bonus for an employee based on their role and KPI achievement.
     * Returns 10% of base salary if KPI targets are met, otherwise returns zero.
     *
     * @param user The employee
     * @param month The month to check
     * @param year The year to check
     * @return The bonus amount (10% of base salary if KPI achieved, zero otherwise)
     */
    public BigDecimal calculateKPIBonus(User user, Integer month, Integer year) {
        if (user == null || user.getBaseSalary() == null) {
            return BigDecimal.ZERO;
        }

        boolean kpiAchieved = false;

        // Check user roles to determine which KPI to check
        if (user.getRoles().stream().anyMatch(role -> "RECEPTIONIST".equals(role.getRoleName()))) {
            kpiAchieved = isReceptionistKPIAchieved(user.getUserId(), month, year);
        } else if (user.getRoles().stream().anyMatch(role -> "TECHNICIAN".equals(role.getRoleName()))) {
            kpiAchieved = isTechnicianKPIAchieved(user.getUserId(), month, year);
        }

        if (kpiAchieved) {
            return user.getBaseSalary().multiply(KPI_BONUS_PERCENTAGE);
        }

        return BigDecimal.ZERO;
    }

    /**
     * Get KPI achievement status for an employee.
     *
     * @param user The employee
     * @param month The month to check
     * @param year The year to check
     * @return true if KPI targets are achieved, false otherwise
     */
    public boolean isKPIAchieved(User user, Integer month, Integer year) {
        if (user == null) {
            return false;
        }

        if (user.getRoles().stream().anyMatch(role -> "RECEPTIONIST".equals(role.getRoleName()))) {
            return isReceptionistKPIAchieved(user.getUserId(), month, year);
        } else if (user.getRoles().stream().anyMatch(role -> "TECHNICIAN".equals(role.getRoleName()))) {
            return isTechnicianKPIAchieved(user.getUserId(), month, year);
        }

        return false; // Other roles don't have KPI bonuses
    }

    /**
     * Get detailed KPI achievement information for debugging/logging.
     *
     * @param user The employee
     * @param month The month to check
     * @param year The year to check
     * @return String describing KPI achievement status
     */
    public String getKPIAchievementDetails(User user, Integer month, Integer year) {
        if (user == null) {
            return "User is null";
        }

        if (user.getRoles().stream().anyMatch(role -> "RECEPTIONIST".equals(role.getRoleName()))) {
            try {
                List<ReceptionistKPI> kpis = receptionistKPIService.getKPIsByReceptionistAndMonthAndYear(user.getUserId(), month, year);
                if (kpis.isEmpty()) {
                    return "No receptionist KPI found for " + month + "/" + year;
                }
                ReceptionistKPI kpi = kpis.get(0);
                return String.format("Receptionist KPI - Appointments: %s, Invoices: %s, Revenue: %s", 
                    kpi.isAppointmentTargetAchieved(), kpi.isInvoiceTargetAchieved(), kpi.isRevenueTargetAchieved());
            } catch (Exception e) {
                return "Error checking receptionist KPI: " + e.getMessage();
            }
        } else if (user.getRoles().stream().anyMatch(role -> "TECHNICIAN".equals(role.getRoleName()))) {
            try {
                List<UserKPI> kpis = userKPIService.getKPIsByTechnicianAndMonthAndYear(user.getUserId(), month, year);
                if (kpis.isEmpty()) {
                    return "No technician KPI found for " + month + "/" + year;
                }
                UserKPI kpi = kpis.get(0);
                return String.format("Technician KPI - Target: %d, Actual: %d, Achieved: %s", 
                    kpi.getTargetAppointments(), kpi.getActualAppointments(), kpi.isTargetAchieved());
            } catch (Exception e) {
                return "Error checking technician KPI: " + e.getMessage();
            }
        }

        return "Role does not have KPI bonus eligibility";
    }
}
