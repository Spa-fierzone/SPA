package com.spazone.service.impl;

import com.spazone.entity.AppointmentServiceEntity;
import com.spazone.repository.AppointmentServiceRepository;
import com.spazone.service.AppointmentServiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class AppointmentServiceServiceImpl implements AppointmentServiceService {

    @Autowired
    private AppointmentServiceRepository appointmentServiceRepository;

    @Override
    public void startService(Integer appointmentServiceId) {
        AppointmentServiceEntity appointmentService = findById(appointmentServiceId);
        appointmentService.startService();
        appointmentServiceRepository.save(appointmentService);
    }

    @Override
    public void completeService(Integer appointmentServiceId) {
        AppointmentServiceEntity appointmentService = findById(appointmentServiceId);
        appointmentService.completeService();
        appointmentServiceRepository.save(appointmentService);
    }

    @Override
    public void updateServiceStatus(Integer appointmentServiceId, String status) {
        AppointmentServiceEntity appointmentService = findById(appointmentServiceId);
        appointmentService.setStatus(status);
        
        // Set timestamps based on status
        if ("in-progress".equals(status) && appointmentService.getStartedAt() == null) {
            appointmentService.setStartedAt(LocalDateTime.now());
        } else if ("completed".equals(status) && appointmentService.getCompletedAt() == null) {
            appointmentService.setCompletedAt(LocalDateTime.now());
        }
        
        appointmentServiceRepository.save(appointmentService);
    }

    @Override
    public List<AppointmentServiceEntity> getServicesByAppointmentId(Integer appointmentId) {
        return appointmentServiceRepository.findByAppointmentAppointmentId(appointmentId);
    }

    @Override
    public List<AppointmentServiceEntity> getServicesByAppointmentIdAndStatus(Integer appointmentId, String status) {
        return appointmentServiceRepository.findByAppointmentAppointmentIdAndStatus(appointmentId, status);
    }

    @Override
    public Page<AppointmentServiceEntity> getServicesByTechnicianAndStatus(Integer technicianId, String status, Pageable pageable) {
        return appointmentServiceRepository.findByAppointmentTechnicianUserIdAndStatus(technicianId, status, pageable);
    }

    @Override
    public List<AppointmentServiceEntity> getPendingServicesByTechnician(Integer technicianId) {
        return appointmentServiceRepository.findByAppointmentTechnicianUserIdAndStatus(technicianId, "pending");
    }

    @Override
    public List<AppointmentServiceEntity> getInProgressServicesByTechnician(Integer technicianId) {
        return appointmentServiceRepository.findByAppointmentTechnicianUserIdAndStatus(technicianId, "in-progress");
    }

    @Override
    public boolean areAllServicesCompleted(Integer appointmentId) {
        List<AppointmentServiceEntity> services = getServicesByAppointmentId(appointmentId);
        return services.stream().allMatch(AppointmentServiceEntity::isCompleted);
    }

    @Override
    public AppointmentServiceEntity findById(Integer id) {
        return appointmentServiceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("AppointmentService not found with id: " + id));
    }

    @Override
    public AppointmentServiceEntity save(AppointmentServiceEntity appointmentService) {
        return appointmentServiceRepository.save(appointmentService);
    }
}
