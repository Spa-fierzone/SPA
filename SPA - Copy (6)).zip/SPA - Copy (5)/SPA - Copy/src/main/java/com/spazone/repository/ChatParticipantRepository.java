package com.spazone.repository;

import com.spazone.entity.ChatParticipant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for ChatParticipant entity
 * Provides custom queries for participant management and read status tracking
 */
@Repository
public interface ChatParticipantRepository extends JpaRepository<ChatParticipant, Integer> {

    /**
     * Find participant by room and user
     */
    Optional<ChatParticipant> findByChatRoomRoomIdAndUserUserId(Integer roomId, Integer userId);

    /**
     * Find all active participants in a room
     */
    List<ChatParticipant> findByChatRoomRoomIdAndIsActiveTrue(Integer roomId);

    /**
     * Find all active participants in a room ordered by join date
     */
    List<ChatParticipant> findByChatRoomRoomIdAndIsActiveTrueOrderByJoinedAtAsc(Integer roomId);

    /**
     * Find all rooms where user is an active participant
     */
    List<ChatParticipant> findByUserUserIdAndIsActiveTrue(Integer userId);

    /**
     * Find participants by role in a specific room
     */
    List<ChatParticipant> findByChatRoomRoomIdAndRoleAndIsActiveTrue(Integer roomId, String role);

    /**
     * Find room administrators
     */
    List<ChatParticipant> findByChatRoomRoomIdAndRoleInAndIsActiveTrue(Integer roomId, List<String> roles);

    /**
     * Check if user is participant in room
     */
    @Query("SELECT CASE WHEN COUNT(cp) > 0 THEN true ELSE false END FROM ChatParticipant cp " +
           "WHERE cp.chatRoom.roomId = :roomId " +
           "AND cp.user.userId = :userId " +
           "AND cp.isActive = true")
    boolean isUserParticipant(@Param("roomId") Integer roomId, @Param("userId") Integer userId);

    /**
     * Check if user is admin or moderator in room
     */
    @Query("SELECT CASE WHEN COUNT(cp) > 0 THEN true ELSE false END FROM ChatParticipant cp " +
           "WHERE cp.chatRoom.roomId = :roomId " +
           "AND cp.user.userId = :userId " +
           "AND cp.role IN ('ADMIN', 'MODERATOR') " +
           "AND cp.isActive = true")
    boolean canUserModerateRoom(@Param("roomId") Integer roomId, @Param("userId") Integer userId);

    /**
     * Get participant role in room
     */
    @Query("SELECT cp.role FROM ChatParticipant cp " +
           "WHERE cp.chatRoom.roomId = :roomId " +
           "AND cp.user.userId = :userId " +
           "AND cp.isActive = true")
    Optional<String> getUserRoleInRoom(@Param("roomId") Integer roomId, @Param("userId") Integer userId);

    /**
     * Count active participants in room
     */
    Long countByChatRoomRoomIdAndIsActiveTrue(Integer roomId);

    /**
     * Find participants with notifications enabled
     */
    List<ChatParticipant> findByChatRoomRoomIdAndNotificationsEnabledTrueAndIsActiveTrue(Integer roomId);

    /**
     * Find participants who haven't read recent messages
     */
    @Query("SELECT cp FROM ChatParticipant cp " +
           "WHERE cp.chatRoom.roomId = :roomId " +
           "AND cp.isActive = true " +
           "AND (cp.lastReadAt IS NULL OR cp.lastReadAt < :messageTime)")
    List<ChatParticipant> findParticipantsWithUnreadMessages(@Param("roomId") Integer roomId, 
                                                            @Param("messageTime") LocalDateTime messageTime);

    /**
     * Update last read time for participant
     */
    @Modifying
    @Query("UPDATE ChatParticipant cp " +
           "SET cp.lastReadAt = :readTime " +
           "WHERE cp.chatRoom.roomId = :roomId " +
           "AND cp.user.userId = :userId")
    int updateLastReadTime(@Param("roomId") Integer roomId, 
                          @Param("userId") Integer userId, 
                          @Param("readTime") LocalDateTime readTime);

    /**
     * Remove participant from room (soft delete)
     */
    @Modifying
    @Query("UPDATE ChatParticipant cp " +
           "SET cp.isActive = false " +
           "WHERE cp.chatRoom.roomId = :roomId " +
           "AND cp.user.userId = :userId")
    int removeParticipant(@Param("roomId") Integer roomId, @Param("userId") Integer userId);

    /**
     * Add participant back to room
     */
    @Modifying
    @Query("UPDATE ChatParticipant cp " +
           "SET cp.isActive = true, cp.joinedAt = :joinTime " +
           "WHERE cp.chatRoom.roomId = :roomId " +
           "AND cp.user.userId = :userId")
    int reactivateParticipant(@Param("roomId") Integer roomId, 
                             @Param("userId") Integer userId, 
                             @Param("joinTime") LocalDateTime joinTime);

    /**
     * Update participant role
     */
    @Modifying
    @Query("UPDATE ChatParticipant cp " +
           "SET cp.role = :role " +
           "WHERE cp.chatRoom.roomId = :roomId " +
           "AND cp.user.userId = :userId " +
           "AND cp.isActive = true")
    int updateParticipantRole(@Param("roomId") Integer roomId, 
                             @Param("userId") Integer userId, 
                             @Param("role") String role);

    /**
     * Toggle notifications for participant
     */
    @Modifying
    @Query("UPDATE ChatParticipant cp " +
           "SET cp.notificationsEnabled = :enabled " +
           "WHERE cp.chatRoom.roomId = :roomId " +
           "AND cp.user.userId = :userId " +
           "AND cp.isActive = true")
    int updateNotificationSettings(@Param("roomId") Integer roomId, 
                                  @Param("userId") Integer userId, 
                                  @Param("enabled") Boolean enabled);

    /**
     * Find participants by branch (for branch-wide operations)
     */
    @Query("SELECT cp FROM ChatParticipant cp " +
           "WHERE cp.user.branch.branchId = :branchId " +
           "AND cp.isActive = true")
    List<ChatParticipant> findByUserBranch(@Param("branchId") Integer branchId);

    /**
     * Find participants by user role (MANAGER, TECHNICIAN, etc.)
     */
    @Query("SELECT cp FROM ChatParticipant cp " +
           "JOIN cp.user.roles r " +
           "WHERE r.roleName = :roleName " +
           "AND cp.chatRoom.roomId = :roomId " +
           "AND cp.isActive = true")
    List<ChatParticipant> findByUserRoleInRoom(@Param("roomId") Integer roomId, @Param("roleName") String roleName);

    /**
     * Get unread message count for user in room
     */
    @Query("SELECT COUNT(cm) FROM ChatMessage cm " +
           "JOIN ChatParticipant cp ON cp.chatRoom = cm.chatRoom " +
           "WHERE cp.user.userId = :userId " +
           "AND cm.chatRoom.roomId = :roomId " +
           "AND cp.isActive = true " +
           "AND (cp.lastReadAt IS NULL OR cm.sentAt > cp.lastReadAt) " +
           "AND cm.isDeleted = false")
    Long getUnreadMessageCount(@Param("userId") Integer userId, @Param("roomId") Integer roomId);

    /**
     * Find recently active participants (who have read messages recently)
     */
    @Query("SELECT cp FROM ChatParticipant cp " +
           "WHERE cp.chatRoom.roomId = :roomId " +
           "AND cp.isActive = true " +
           "AND cp.lastReadAt >= :since " +
           "ORDER BY cp.lastReadAt DESC")
    List<ChatParticipant> findRecentlyActiveParticipants(@Param("roomId") Integer roomId, 
                                                        @Param("since") LocalDateTime since);
}
