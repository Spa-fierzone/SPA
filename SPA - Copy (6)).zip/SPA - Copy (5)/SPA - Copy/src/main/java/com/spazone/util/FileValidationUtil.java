package com.spazone.util;

import com.spazone.exception.ManagerImageUploadException;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;
import java.util.List;

/**
 * Utility class for file validation operations, specifically for image uploads
 */
@Component
public class FileValidationUtil {
    
    // File size constants
    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
    
    // Supported image content types
    private static final List<String> SUPPORTED_CONTENT_TYPES = Arrays.asList(
        "image/jpeg", "image/jpg", "image/png", "image/gif", 
        "image/bmp", "image/webp"
    );
    
    // Supported file extensions
    private static final List<String> SUPPORTED_EXTENSIONS = Arrays.asList(
        ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp"
    );
    
    /**
     * Validates an image file for upload
     * @param file the file to validate
     * @throws ManagerImageUploadException if validation fails
     */
    public void validateImageFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new ManagerImageUploadException("Vui lòng chọn một tệp hình ảnh để tải lên");
        }
        
        validateFileSize(file);
        validateContentType(file);
        validateFileExtension(file);
    }
    
    /**
     * Validates an image file for upload (optional file - allows empty)
     * @param file the file to validate
     * @throws ManagerImageUploadException if validation fails
     */
    public void validateOptionalImageFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            return; // Optional file, so empty is allowed
        }
        
        validateFileSize(file);
        validateContentType(file);
        validateFileExtension(file);
    }
    
    /**
     * Validates file size
     * @param file the file to validate
     * @throws ManagerImageUploadException if file is too large
     */
    private void validateFileSize(MultipartFile file) {
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new ManagerImageUploadException(
                "Kích thước tệp phải nhỏ hơn " + (MAX_FILE_SIZE / (1024 * 1024)) + "MB. " +
                "Tệp hiện tại: " + String.format("%.2f", file.getSize() / (1024.0 * 1024.0)) + "MB"
            );
        }
    }
    
    /**
     * Validates content type
     * @param file the file to validate
     * @throws ManagerImageUploadException if content type is not supported
     */
    private void validateContentType(MultipartFile file) {
        String contentType = file.getContentType();
        if (contentType == null || !SUPPORTED_CONTENT_TYPES.contains(contentType.toLowerCase())) {
            throw new ManagerImageUploadException(
                "Loại tệp không được hỗ trợ. Vui lòng chọn tệp hình ảnh hợp lệ " +
                "(JPG, JPEG, PNG, GIF, BMP, WebP). Loại tệp hiện tại: " + 
                (contentType != null ? contentType : "không xác định")
            );
        }
    }
    
    /**
     * Validates file extension
     * @param file the file to validate
     * @throws ManagerImageUploadException if file extension is not supported
     */
    private void validateFileExtension(MultipartFile file) {
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || originalFilename.trim().isEmpty()) {
            throw new ManagerImageUploadException("Tên tệp không hợp lệ");
        }
        
        String extension = getFileExtension(originalFilename);
        if (!SUPPORTED_EXTENSIONS.contains(extension.toLowerCase())) {
            throw new ManagerImageUploadException(
                "Phần mở rộng tệp không được hỗ trợ. Vui lòng sử dụng: " +
                String.join(", ", SUPPORTED_EXTENSIONS.stream()
                    .map(ext -> ext.toUpperCase().substring(1))
                    .toArray(String[]::new)) +
                ". Phần mở rộng hiện tại: " + extension
            );
        }
    }
    
    /**
     * Gets file extension from filename
     * @param filename the filename
     * @return the file extension (including the dot)
     */
    private String getFileExtension(String filename) {
        int lastDotIndex = filename.lastIndexOf('.');
        if (lastDotIndex == -1 || lastDotIndex == filename.length() - 1) {
            return "";
        }
        return filename.substring(lastDotIndex);
    }
    
    /**
     * Checks if a file is a valid image file (without throwing exception)
     * @param file the file to check
     * @return true if valid, false otherwise
     */
    public boolean isValidImageFile(MultipartFile file) {
        try {
            validateOptionalImageFile(file);
            return true;
        } catch (ManagerImageUploadException e) {
            return false;
        }
    }
    
    /**
     * Gets human-readable file size
     * @param sizeInBytes the size in bytes
     * @return formatted file size string
     */
    public String getFormattedFileSize(long sizeInBytes) {
        if (sizeInBytes < 1024) {
            return sizeInBytes + " bytes";
        } else if (sizeInBytes < 1024 * 1024) {
            return String.format("%.2f KB", sizeInBytes / 1024.0);
        } else {
            return String.format("%.2f MB", sizeInBytes / (1024.0 * 1024.0));
        }
    }
}
