package com.spazone.dto;

import java.math.BigDecimal;

/**
 * DTO for transferring appointment service data
 */
public class AppointmentServiceDTO {
    
    private Integer serviceId;
    private String serviceName;
    private Integer quantity;
    private BigDecimal price;
    private BigDecimal customPrice;
    private String notes;
    private Integer duration;
    private BigDecimal totalPrice;
    private Integer totalDuration;

    public AppointmentServiceDTO() {
    }

    public AppointmentServiceDTO(Integer serviceId, String serviceName, Integer quantity, 
                               BigDecimal price, BigDecimal customPrice, String notes, Integer duration) {
        this.serviceId = serviceId;
        this.serviceName = serviceName;
        this.quantity = quantity;
        this.price = price;
        this.customPrice = customPrice;
        this.notes = notes;
        this.duration = duration;
        this.totalPrice = (customPrice != null ? customPrice : price).multiply(BigDecimal.valueOf(quantity));
        this.totalDuration = duration * quantity;
    }

    // Static factory method to create from AppointmentServiceEntity entity
    public static AppointmentServiceDTO fromEntity(com.spazone.entity.AppointmentServiceEntity appointmentService) {
        return new AppointmentServiceDTO(
            appointmentService.getService().getServiceId(),
            appointmentService.getService().getName(),
            appointmentService.getQuantity(),
            appointmentService.getService().getPrice(),
            appointmentService.getCustomPrice(),
            appointmentService.getNotes(),
            appointmentService.getService().getDuration()
        );
    }

    // Getters and Setters
    public Integer getServiceId() {
        return serviceId;
    }

    public void setServiceId(Integer serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
        // Recalculate totals when quantity changes
        if (this.price != null && this.duration != null) {
            this.totalPrice = getEffectivePrice().multiply(BigDecimal.valueOf(quantity));
            this.totalDuration = this.duration * quantity;
        }
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
        // Recalculate total price when price changes
        if (this.quantity != null) {
            this.totalPrice = getEffectivePrice().multiply(BigDecimal.valueOf(quantity));
        }
    }

    public BigDecimal getCustomPrice() {
        return customPrice;
    }

    public void setCustomPrice(BigDecimal customPrice) {
        this.customPrice = customPrice;
        // Recalculate total price when custom price changes
        if (this.quantity != null) {
            this.totalPrice = getEffectivePrice().multiply(BigDecimal.valueOf(quantity));
        }
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
        // Recalculate total duration when duration changes
        if (this.quantity != null) {
            this.totalDuration = duration * quantity;
        }
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Integer getTotalDuration() {
        return totalDuration;
    }

    public void setTotalDuration(Integer totalDuration) {
        this.totalDuration = totalDuration;
    }

    // Helper methods
    public BigDecimal getEffectivePrice() {
        return customPrice != null ? customPrice : price;
    }

    public boolean hasCustomPrice() {
        return customPrice != null;
    }

    @Override
    public String toString() {
        return "AppointmentServiceDTO{" +
                "serviceId=" + serviceId +
                ", serviceName='" + serviceName + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                ", customPrice=" + customPrice +
                ", totalPrice=" + totalPrice +
                ", totalDuration=" + totalDuration +
                '}';
    }
}
