package com.spazone.repository;

import com.spazone.entity.ChatMessage;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for ChatMessage entity
 * Provides custom queries for message retrieval, search, and management
 */
@Repository
public interface ChatMessageRepository extends JpaRepository<ChatMessage, Integer> {

    /**
     * Find messages in a room ordered by sent time (most recent first)
     */
    Page<ChatMessage> findByChatRoomRoomIdAndIsDeletedFalseOrderBySentAtDesc(Integer roomId, Pageable pageable);

    /**
     * Find messages in a room ordered by sent time (oldest first)
     */
    Page<ChatMessage> findByChatRoomRoomIdAndIsDeletedFalseOrderBySentAtAsc(Integer roomId, Pageable pageable);

    /**
     * Find recent messages in a room (last N messages)
     */
    @Query("SELECT cm FROM ChatMessage cm " +
           "WHERE cm.chatRoom.roomId = :roomId " +
           "AND cm.isDeleted = false " +
           "ORDER BY cm.sentAt DESC")
    List<ChatMessage> findRecentMessages(@Param("roomId") Integer roomId, Pageable pageable);

    /**
     * Find messages sent by a specific user
     */
    Page<ChatMessage> findBySenderUserIdAndIsDeletedFalseOrderBySentAtDesc(Integer senderId, Pageable pageable);

    /**
     * Find messages sent by a user in a specific room
     */
    List<ChatMessage> findByChatRoomRoomIdAndSenderUserIdAndIsDeletedFalseOrderBySentAtDesc(Integer roomId, Integer senderId);

    /**
     * Search messages by content (case-insensitive, Vietnamese support)
     */
    @Query("SELECT cm FROM ChatMessage cm " +
           "WHERE cm.chatRoom.roomId = :roomId " +
           "AND LOWER(cm.messageContent) LIKE LOWER(CONCAT('%', :searchTerm, '%')) " +
           "AND cm.isDeleted = false " +
           "ORDER BY cm.sentAt DESC")
    Page<ChatMessage> searchMessagesInRoom(@Param("roomId") Integer roomId, 
                                          @Param("searchTerm") String searchTerm, 
                                          Pageable pageable);

    /**
     * Search messages across all accessible rooms for a user
     */
    @Query("SELECT cm FROM ChatMessage cm " +
           "JOIN cm.chatRoom cr " +
           "JOIN cr.participants cp " +
           "WHERE cp.user.userId = :userId " +
           "AND cp.isActive = true " +
           "AND LOWER(cm.messageContent) LIKE LOWER(CONCAT('%', :searchTerm, '%')) " +
           "AND cm.isDeleted = false " +
           "ORDER BY cm.sentAt DESC")
    Page<ChatMessage> searchMessagesForUser(@Param("userId") Integer userId, 
                                           @Param("searchTerm") String searchTerm, 
                                           Pageable pageable);

    /**
     * Find messages after a specific timestamp
     */
    List<ChatMessage> findByChatRoomRoomIdAndSentAtAfterAndIsDeletedFalseOrderBySentAtAsc(Integer roomId, LocalDateTime after);

    /**
     * Find messages before a specific timestamp (for pagination)
     */
    Page<ChatMessage> findByChatRoomRoomIdAndSentAtBeforeAndIsDeletedFalseOrderBySentAtDesc(Integer roomId, LocalDateTime before, Pageable pageable);

    /**
     * Find unread messages for a user in a room
     */
    @Query("SELECT cm FROM ChatMessage cm " +
           "JOIN ChatParticipant cp ON cp.chatRoom = cm.chatRoom " +
           "WHERE cp.user.userId = :userId " +
           "AND cm.chatRoom.roomId = :roomId " +
           "AND cp.isActive = true " +
           "AND (cp.lastReadAt IS NULL OR cm.sentAt > cp.lastReadAt) " +
           "AND cm.isDeleted = false " +
           "ORDER BY cm.sentAt ASC")
    List<ChatMessage> findUnreadMessages(@Param("userId") Integer userId, @Param("roomId") Integer roomId);

    /**
     * Count unread messages for a user in a room
     */
    @Query("SELECT COUNT(cm) FROM ChatMessage cm " +
           "JOIN ChatParticipant cp ON cp.chatRoom = cm.chatRoom " +
           "WHERE cp.user.userId = :userId " +
           "AND cm.chatRoom.roomId = :roomId " +
           "AND cp.isActive = true " +
           "AND (cp.lastReadAt IS NULL OR cm.sentAt > cp.lastReadAt) " +
           "AND cm.isDeleted = false")
    Long countUnreadMessages(@Param("userId") Integer userId, @Param("roomId") Integer roomId);

    /**
     * Find messages with files/attachments
     */
    @Query("SELECT cm FROM ChatMessage cm " +
           "WHERE cm.chatRoom.roomId = :roomId " +
           "AND cm.fileUrl IS NOT NULL " +
           "AND cm.isDeleted = false " +
           "ORDER BY cm.sentAt DESC")
    Page<ChatMessage> findMessagesWithFiles(@Param("roomId") Integer roomId, Pageable pageable);

    /**
     * Find messages by type
     */
    List<ChatMessage> findByChatRoomRoomIdAndMessageTypeAndIsDeletedFalseOrderBySentAtDesc(Integer roomId, String messageType);

    /**
     * Find reply messages to a specific message
     */
    List<ChatMessage> findByReplyToMessageMessageIdAndIsDeletedFalseOrderBySentAtAsc(Integer replyToMessageId);

    /**
     * Find latest message in a room
     */
    @Query("SELECT cm FROM ChatMessage cm " +
           "WHERE cm.chatRoom.roomId = :roomId " +
           "AND cm.isDeleted = false " +
           "ORDER BY cm.sentAt DESC")
    List<ChatMessage> findLatestMessage(@Param("roomId") Integer roomId, Pageable pageable);

    /**
     * Count total messages in a room
     */
    Long countByChatRoomRoomIdAndIsDeletedFalse(Integer roomId);

    /**
     * Count messages sent by a user in a room
     */
    Long countByChatRoomRoomIdAndSenderUserIdAndIsDeletedFalse(Integer roomId, Integer senderId);

    /**
     * Find messages sent in a date range
     */
    @Query("SELECT cm FROM ChatMessage cm " +
           "WHERE cm.chatRoom.roomId = :roomId " +
           "AND cm.sentAt BETWEEN :startDate AND :endDate " +
           "AND cm.isDeleted = false " +
           "ORDER BY cm.sentAt DESC")
    Page<ChatMessage> findMessagesByDateRange(@Param("roomId") Integer roomId, 
                                             @Param("startDate") LocalDateTime startDate, 
                                             @Param("endDate") LocalDateTime endDate, 
                                             Pageable pageable);

    /**
     * Soft delete a message
     */
    @Modifying
    @Query("UPDATE ChatMessage cm " +
           "SET cm.isDeleted = true, cm.messageContent = '[Tin nhắn đã bị xóa]' " +
           "WHERE cm.messageId = :messageId " +
           "AND cm.sender.userId = :senderId")
    int softDeleteMessage(@Param("messageId") Integer messageId, @Param("senderId") Integer senderId);

    /**
     * Update message content (for editing)
     */
    @Modifying
    @Query("UPDATE ChatMessage cm " +
           "SET cm.messageContent = :newContent, cm.editedAt = :editTime " +
           "WHERE cm.messageId = :messageId " +
           "AND cm.sender.userId = :senderId " +
           "AND cm.isDeleted = false")
    int updateMessageContent(@Param("messageId") Integer messageId, 
                            @Param("senderId") Integer senderId, 
                            @Param("newContent") String newContent, 
                            @Param("editTime") LocalDateTime editTime);

    /**
     * Find system messages in a room
     */
    List<ChatMessage> findByChatRoomRoomIdAndIsSystemMessageTrueAndIsDeletedFalseOrderBySentAtDesc(Integer roomId);

    /**
     * Find messages that mention a user (contains @username)
     */
    @Query("SELECT cm FROM ChatMessage cm " +
           "WHERE cm.chatRoom.roomId = :roomId " +
           "AND LOWER(cm.messageContent) LIKE LOWER(CONCAT('%@', :username, '%')) " +
           "AND cm.isDeleted = false " +
           "ORDER BY cm.sentAt DESC")
    List<ChatMessage> findMessagesMentioningUser(@Param("roomId") Integer roomId, @Param("username") String username);

    /**
     * Get message statistics for a room
     */
    @Query("SELECT " +
           "COUNT(cm) as totalMessages, " +
           "COUNT(DISTINCT cm.sender) as uniqueSenders, " +
           "COUNT(CASE WHEN cm.messageType = 'FILE' THEN 1 END) as fileMessages, " +
           "COUNT(CASE WHEN cm.messageType = 'IMAGE' THEN 1 END) as imageMessages " +
           "FROM ChatMessage cm " +
           "WHERE cm.chatRoom.roomId = :roomId " +
           "AND cm.isDeleted = false")
    Object[] getMessageStatistics(@Param("roomId") Integer roomId);

    /**
     * Find messages for export (all messages in chronological order)
     */
    @Query("SELECT cm FROM ChatMessage cm " +
           "WHERE cm.chatRoom.roomId = :roomId " +
           "AND cm.isDeleted = false " +
           "ORDER BY cm.sentAt ASC")
    List<ChatMessage> findAllMessagesForExport(@Param("roomId") Integer roomId);

    /**
     * Clean up old deleted messages (for maintenance)
     */
    @Modifying
    @Query("DELETE FROM ChatMessage cm " +
           "WHERE cm.isDeleted = true " +
           "AND cm.sentAt < :cutoffDate")
    int cleanupOldDeletedMessages(@Param("cutoffDate") LocalDateTime cutoffDate);
}
