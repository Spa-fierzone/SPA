package com.spazone.service;

import com.spazone.entity.AppointmentServiceEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface AppointmentServiceService {
    
    /**
     * Update service status to in-progress
     */
    void startService(Integer appointmentServiceId);
    
    /**
     * Update service status to completed
     */
    void completeService(Integer appointmentServiceId);
    
    /**
     * Update service status
     */
    void updateServiceStatus(Integer appointmentServiceId, String status);
    
    /**
     * Get services by appointment ID
     */
    List<AppointmentServiceEntity> getServicesByAppointmentId(Integer appointmentId);
    
    /**
     * Get services by appointment ID with status filter
     */
    List<AppointmentServiceEntity> getServicesByAppointmentIdAndStatus(Integer appointmentId, String status);
    
    /**
     * Get services by technician and status
     */
    Page<AppointmentServiceEntity> getServicesByTechnicianAndStatus(Integer technicianId, String status, Pageable pageable);
    
    /**
     * Get all pending services for a technician
     */
    List<AppointmentServiceEntity> getPendingServicesByTechnician(Integer technicianId);
    
    /**
     * Get all in-progress services for a technician
     */
    List<AppointmentServiceEntity> getInProgressServicesByTechnician(Integer technicianId);
    
    /**
     * Check if all services in an appointment are completed
     */
    boolean areAllServicesCompleted(Integer appointmentId);
    
    /**
     * Get service by ID
     */
    AppointmentServiceEntity findById(Integer id);
    
    /**
     * Save appointment service
     */
    AppointmentServiceEntity save(AppointmentServiceEntity appointmentService);
}
