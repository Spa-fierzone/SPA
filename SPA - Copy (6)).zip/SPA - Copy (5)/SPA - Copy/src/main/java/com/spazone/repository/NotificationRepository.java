package com.spazone.repository;

import com.spazone.entity.Notification;
import com.spazone.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Integer> {

    /**
     * Find notifications for a specific user
     */
    List<Notification> findByUserOrderByCreatedAtDesc(User user);

    /**
     * Find notifications for a specific user with pagination
     */
    Page<Notification> findByUserOrderByCreatedAtDesc(User user, Pageable pageable);

    /**
     * Find unread notifications for a user
     */
    @Query("SELECT n FROM Notification n WHERE n.user = :user AND (n.isRead = false OR n.isRead IS NULL) ORDER BY n.createdAt DESC")
    List<Notification> findUnreadNotificationsByUser(@Param("user") User user);

    /**
     * Count unread notifications for a user
     */
    @Query("SELECT COUNT(n) FROM Notification n WHERE n.user = :user AND (n.isRead = false OR n.isRead IS NULL)")
    Long countUnreadNotificationsByUser(@Param("user") User user);

    /**
     * Find notifications by type for a user
     */
    List<Notification> findByUserAndTypeOrderByCreatedAtDesc(User user, Notification.NotificationType type);

    /**
     * Find notifications by read status for a user
     */
    List<Notification> findByUserAndIsReadOrderByCreatedAtDesc(User user, Boolean isRead);

    /**
     * Find notifications related to a specific entity
     */
    @Query("SELECT n FROM Notification n WHERE n.relatedEntityType = :entityType AND n.relatedEntityId = :entityId ORDER BY n.createdAt DESC")
    List<Notification> findByRelatedEntity(@Param("entityType") String entityType, @Param("entityId") Integer entityId);

    /**
     * Find expired notifications
     */
    @Query("SELECT n FROM Notification n WHERE n.expiresAt IS NOT NULL AND n.expiresAt < :now")
    List<Notification> findExpiredNotifications(@Param("now") LocalDateTime now);

    /**
     * Mark notification as read
     */
    @Modifying
    @Query("UPDATE Notification n SET n.isRead = true, n.readAt = :readAt WHERE n.notificationId = :notificationId")
    void markAsRead(@Param("notificationId") Integer notificationId, @Param("readAt") LocalDateTime readAt);

    /**
     * Mark all notifications as read for a user
     */
    @Modifying
    @Query("UPDATE Notification n SET n.isRead = true, n.readAt = :readAt WHERE n.user = :user AND (n.isRead = false OR n.isRead IS NULL)")
    void markAllAsReadForUser(@Param("user") User user, @Param("readAt") LocalDateTime readAt);

    /**
     * Delete old notifications (older than specified date)
     */
    @Modifying
    @Query("DELETE FROM Notification n WHERE n.createdAt < :cutoffDate")
    void deleteOldNotifications(@Param("cutoffDate") LocalDateTime cutoffDate);

    /**
     * Find recent notifications for a user (last N days)
     */
    @Query("SELECT n FROM Notification n WHERE n.user = :user AND n.createdAt >= :since ORDER BY n.createdAt DESC")
    List<Notification> findRecentNotificationsByUser(@Param("user") User user, @Param("since") LocalDateTime since);

    /**
     * Find notifications by multiple users (for admin/manager views)
     */
    @Query("SELECT n FROM Notification n WHERE n.user IN :users ORDER BY n.createdAt DESC")
    List<Notification> findByUsersOrderByCreatedAtDesc(@Param("users") List<User> users);

    /**
     * Find notifications sent by a specific user
     */
    List<Notification> findBySenderOrderByCreatedAtDesc(User sender);

    /**
     * Count notifications by type for analytics
     */
    @Query("SELECT n.type, COUNT(n) FROM Notification n WHERE n.createdAt >= :since GROUP BY n.type")
    List<Object[]> countNotificationsByTypeSince(@Param("since") LocalDateTime since);

    /**
     * Find notifications that need to be sent (for batch processing)
     */
    @Query("SELECT n FROM Notification n WHERE (n.isRead = false OR n.isRead IS NULL) AND (n.expiresAt IS NULL OR n.expiresAt > :now)")
    List<Notification> findNotificationsToSend(@Param("now") LocalDateTime now);
}
