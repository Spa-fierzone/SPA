package com.spazone.controller;

import com.spazone.entity.ReceptionistKPI;
import com.spazone.entity.User;
import com.spazone.service.ReceptionistKPIService;
import com.spazone.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/manager/receptionist-kpi")
public class ReceptionistKPIController {

    @Autowired
    private ReceptionistKPIService receptionistKPIService;

    @Autowired
    private UserService userService;

    // Display KPI management dashboard
    @GetMapping
    public String viewKPIDashboard(@RequestParam(value = "month", required = false) Integer month,
                                   @RequestParam(value = "year", required = false) Integer year,
                                   Authentication authentication,
                                   Model model) {

        // Get current manager
        String username = authentication.getName();
        User currentManager = userService.findByUsername(username);

        LocalDate now = LocalDate.now();
        if (month == null) month = now.getMonthValue();
        if (year == null) year = now.getYear();

        List<ReceptionistKPI> kpis = receptionistKPIService.getKPIsByManagerAndMonthAndYear(currentManager.getUserId(), month, year);

        model.addAttribute("kpis", kpis);
        model.addAttribute("selectedMonth", month);
        model.addAttribute("selectedYear", year);
        model.addAttribute("currentManager", currentManager);

        // Add summary data
        Object[] summary = receptionistKPIService.getKPISummaryByMonth(month, year);
        if (summary == null) {
            summary = new Object[]{0, 0, 0, 0.0}; // Default values: totalKPIs, achievedAppointments, achievedInvoices, avgPerformance
        }
        model.addAttribute("kpiSummary", summary);

        // Add top performers
        List<ReceptionistKPI> topPerformers = receptionistKPIService.getTopPerformingReceptionists(month, year);
        model.addAttribute("topPerformers", topPerformers);

        // Add underperformers
        List<ReceptionistKPI> underperformers = receptionistKPIService.getUnderperformingReceptionists(month, year);
        model.addAttribute("underperformers", underperformers);

        return "manager/receptionist-kpi-dashboard";
    }

    // Show create KPI form
    @GetMapping("/create")
    public String showCreateForm(Model model) {
        List<User> receptionists = receptionistKPIService.getAllReceptionists();

        LocalDate now = LocalDate.now();

        model.addAttribute("receptionists", receptionists);
        model.addAttribute("currentMonth", now.getMonthValue());
        model.addAttribute("currentYear", now.getYear());

        return "manager/receptionist-kpi-form";
    }

    // Create new KPI
    @PostMapping("/create")
    public String createKPI(@RequestParam Integer receptionistId,
                            @RequestParam Integer month,
                            @RequestParam Integer year,
                            @RequestParam Integer targetAppointments,
                            @RequestParam(required = false) Integer targetInvoices,
                            @RequestParam(required = false) BigDecimal targetRevenue,
                            Authentication authentication,
                            RedirectAttributes redirectAttributes) {

        try {
            // Debug logging
            System.out.println("DEBUG: Controller received - receptionistId=" + receptionistId +
                    ", month=" + month + ", year=" + year +
                    ", targetAppointments=" + targetAppointments);

            String username = authentication.getName();
            User currentManager = userService.findByUsername(username);

            // Check if KPI already exists
            if (receptionistKPIService.isKPIExists(receptionistId, month, year)) {
                redirectAttributes.addFlashAttribute("errorMessage",
                        "KPI for this receptionist in " + month + "/" + year + " already exists!");
                return "redirect:/manager/receptionist-kpi/create";
            }

            // Set default values if not provided
            if (targetInvoices == null) targetInvoices = targetAppointments;
            if (targetRevenue == null)
                targetRevenue = BigDecimal.valueOf(targetAppointments * 500000); // Default 500k per appointment

            ReceptionistKPI kpi = receptionistKPIService.createOrUpdateKPI(
                    receptionistId, currentManager.getUserId(), month, year,
                    targetAppointments, targetInvoices, targetRevenue);

            redirectAttributes.addFlashAttribute("successMessage", "KPI created successfully!");
            return "redirect:/manager/receptionist-kpi";

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error occurred: " + e.getMessage());
            return "redirect:/manager/receptionist-kpi/create";
        }
    }

    // Show edit KPI form
    @GetMapping("/edit/{kpiId}")
    public String showEditForm(@PathVariable Integer kpiId, Model model) {
        Optional<ReceptionistKPI> kpiOpt = receptionistKPIService.getKPIById(kpiId);

        if (kpiOpt.isEmpty()) {
            model.addAttribute("errorMessage", "KPI not found!");
            return "redirect:/manager/receptionist-kpi";
        }

        ReceptionistKPI kpi = kpiOpt.get();
        List<User> receptionists = receptionistKPIService.getAllReceptionists();

        model.addAttribute("kpi", kpi);
        model.addAttribute("receptionists", receptionists);

        return "manager/receptionist-kpi-edit";
    }

    // Update KPI
    @PostMapping("/edit/{kpiId}")
    public String updateKPI(@PathVariable Integer kpiId,
                            @RequestParam Integer targetAppointments,
                            @RequestParam(required = false) Integer targetInvoices,
                            @RequestParam(required = false) BigDecimal targetRevenue,
                            Authentication authentication,
                            RedirectAttributes redirectAttributes) {

        try {
            Optional<ReceptionistKPI> existingKPI = receptionistKPIService.getKPIById(kpiId);
            if (existingKPI.isEmpty()) {
                redirectAttributes.addFlashAttribute("errorMessage", "KPI not found!");
                return "redirect:/manager/receptionist-kpi";
            }

            String username = authentication.getName();
            User currentManager = userService.findByUsername(username);

            ReceptionistKPI kpi = existingKPI.get();

            // Set default values if not provided
            if (targetInvoices == null) targetInvoices = targetAppointments;
            if (targetRevenue == null) targetRevenue = BigDecimal.valueOf(targetAppointments * 500000);

            receptionistKPIService.createOrUpdateKPI(
                    kpi.getReceptionist().getUserId(),
                    currentManager.getUserId(),
                    kpi.getMonth(),
                    kpi.getYear(),
                    targetAppointments,
                    targetInvoices,
                    targetRevenue
            );

            redirectAttributes.addFlashAttribute("successMessage", "KPI updated successfully!");
            return "redirect:/manager/receptionist-kpi";

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error occurred: " + e.getMessage());
            return "redirect:/manager/receptionist-kpi";
        }
    }

    // Delete KPI
    @PostMapping("/delete/{kpiId}")
    public String deleteKPI(@PathVariable Integer kpiId,
                            Authentication authentication,
                            RedirectAttributes redirectAttributes) {
        try {
            // Validate kpiId
            if (kpiId == null || kpiId <= 0) {
                redirectAttributes.addFlashAttribute("errorMessage", "Invalid KPI ID provided.");
                return "redirect:/manager/receptionist-kpi";
            }

            // Get current manager for authorization check
            String username = authentication.getName();
            User currentManager = userService.findByUsername(username);

            // Check if KPI exists and belongs to current manager
            Optional<ReceptionistKPI> kpiOpt = receptionistKPIService.getKPIById(kpiId);
            if (kpiOpt.isEmpty()) {
                redirectAttributes.addFlashAttribute("errorMessage", "KPI not found.");
                return "redirect:/manager/receptionist-kpi";
            }

            ReceptionistKPI kpi = kpiOpt.get();
            if (!kpi.getManager().getUserId().equals(currentManager.getUserId())) {
                redirectAttributes.addFlashAttribute("errorMessage", "You are not authorized to delete this KPI.");
                return "redirect:/manager/receptionist-kpi";
            }

            // Perform deletion
            receptionistKPIService.deleteKPI(kpiId);
            redirectAttributes.addFlashAttribute("successMessage",
                    "KPI for " + kpi.getReceptionist().getFullName() +
                            " (" + kpi.getMonth() + "/" + kpi.getYear() + ") deleted successfully!");

        } catch (Exception e) {
            System.err.println("Error deleting KPI with ID " + kpiId + ": " + e.getMessage());
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("errorMessage", "Error deleting KPI: " + e.getMessage());
        }
        return "redirect:/manager/receptionist-kpi";
    }

    // Update KPI status (activate/deactivate)
    @PostMapping("/status/{kpiId}")
    public String updateKPIStatus(@PathVariable Integer kpiId,
                                  @RequestParam String status,
                                  RedirectAttributes redirectAttributes) {
        try {
            receptionistKPIService.updateKPIStatus(kpiId, status);
            redirectAttributes.addFlashAttribute("successMessage", "KPI status updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error updating status: " + e.getMessage());
        }
        return "redirect:/manager/receptionist-kpi";
    }

    // View KPI details
    @GetMapping("/detail/{kpiId}")
    public String viewKPIDetail(@PathVariable Integer kpiId, Model model) {
        Optional<ReceptionistKPI> kpiOpt = receptionistKPIService.getKPIById(kpiId);

        if (kpiOpt.isEmpty()) {
            model.addAttribute("errorMessage", "KPI not found!");
            return "redirect:/manager/receptionist-kpi";
        }

        ReceptionistKPI kpi = kpiOpt.get();

        // Get performance trends for this receptionist
        List<Object[]> trends = receptionistKPIService.getPerformanceTrendsByReceptionist(kpi.getReceptionist().getUserId());

        model.addAttribute("kpi", kpi);
        model.addAttribute("performanceTrends", trends);

        return "manager/receptionist-kpi-detail";
    }

    // Refresh actual metrics for current month
    @PostMapping("/refresh-metrics")
    public String refreshMetrics(@RequestParam(required = false) Integer month,
                                 @RequestParam(required = false) Integer year,
                                 RedirectAttributes redirectAttributes) {
        try {
            LocalDate now = LocalDate.now();
            if (month == null) month = now.getMonthValue();
            if (year == null) year = now.getYear();

            receptionistKPIService.updateAllActualMetricsForMonth(month, year);
            redirectAttributes.addFlashAttribute("successMessage", "Metrics refreshed successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error refreshing metrics: " + e.getMessage());
        }
        return "redirect:/manager/receptionist-kpi";
    }

    // Export KPI report
    @GetMapping("/export")
    public String exportKPIReport(@RequestParam(required = false) Integer month,
                                  @RequestParam(required = false) Integer year,
                                  Model model) {
        LocalDate now = LocalDate.now();
        if (month == null) month = now.getMonthValue();
        if (year == null) year = now.getYear();

        List<Object[]> reportData = receptionistKPIService.getKPIReportByMonth(month, year);

        model.addAttribute("reportData", reportData);
        model.addAttribute("month", month);
        model.addAttribute("year", year);

        return "manager/receptionist-kpi-report";
    }

    // Branch-wise KPI summary
    @GetMapping("/branch-summary")
    public String viewBranchSummary(@RequestParam(required = false) Integer month,
                                    @RequestParam(required = false) Integer year,
                                    Model model) {
        LocalDate now = LocalDate.now();
        if (month == null) month = now.getMonthValue();
        if (year == null) year = now.getYear();

        List<Object[]> branchSummary = receptionistKPIService.getBranchWiseKPISummary(month, year);

        model.addAttribute("branchSummary", branchSummary);
        model.addAttribute("selectedMonth", month);
        model.addAttribute("selectedYear", year);

        return "manager/receptionist-kpi-branch-summary";
    }

    // Test endpoint to verify KPI exists before deletion (for debugging)
    @GetMapping("/test-delete/{kpiId}")
    @ResponseBody
    public String testDelete(@PathVariable Integer kpiId, Authentication authentication) {
        try {
            String username = authentication.getName();
            User currentManager = userService.findByUsername(username);

            Optional<ReceptionistKPI> kpiOpt = receptionistKPIService.getKPIById(kpiId);
            if (kpiOpt.isEmpty()) {
                return "KPI with ID " + kpiId + " not found";
            }

            ReceptionistKPI kpi = kpiOpt.get();
            return "KPI found: ID=" + kpiId +
                    ", Receptionist=" + kpi.getReceptionist().getFullName() +
                    ", Manager=" + kpi.getManager().getFullName() +
                    ", Current Manager=" + currentManager.getFullName() +
                    ", Month/Year=" + kpi.getMonth() + "/" + kpi.getYear() +
                    ", Status=" + kpi.getStatus();

        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}

 