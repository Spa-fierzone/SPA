package com.spazone.util;

import com.spazone.exception.BranchValidationException;
import org.springframework.stereotype.Component;

import java.util.regex.Pattern;

/**
 * Utility class for branch validation operations
 */
@Component
public class BranchValidationUtil {
    
    // Vietnamese phone number patterns
    private static final Pattern VIETNAMESE_PHONE_PATTERN = Pattern.compile(
        "^(\\+84|84|0)(3[2-9]|5[689]|7[06-9]|8[1-689]|9[0-46-9])[0-9]{7}$"
    );
    
    // Email validation pattern (RFC 5322 compliant)
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
    );
    
    // Constants for validation
    private static final int MIN_NAME_LENGTH = 2;
    private static final int MAX_NAME_LENGTH = 255;
    private static final int MIN_ADDRESS_LENGTH = 10;
    private static final int MAX_ADDRESS_LENGTH = 500;
    
    /**
     * Validates branch name
     * @param name the branch name to validate
     * @throws BranchValidationException if validation fails
     */
    public void validateBranchName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new BranchValidationException("Tên chi nhánh không được để trống");
        }
        
        String trimmedName = name.trim();
        if (trimmedName.length() < MIN_NAME_LENGTH) {
            throw new BranchValidationException(
                String.format("Tên chi nhánh phải có ít nhất %d ký tự", MIN_NAME_LENGTH)
            );
        }
        
        if (trimmedName.length() > MAX_NAME_LENGTH) {
            throw new BranchValidationException(
                String.format("Tên chi nhánh không được vượt quá %d ký tự", MAX_NAME_LENGTH)
            );
        }
        
        // Check for valid characters (letters, numbers, spaces, and common Vietnamese characters)
        if (!trimmedName.matches("^[\\p{L}\\p{N}\\s\\-.,()]+$")) {
            throw new BranchValidationException("Tên chi nhánh chỉ được chứa chữ cái, số, khoảng trắng và các ký tự đặc biệt cơ bản");
        }
    }
    
    /**
     * Validates Vietnamese phone number
     * @param phone the phone number to validate
     * @throws BranchValidationException if validation fails
     */
    public void validatePhoneNumber(String phone) {
        if (phone == null || phone.trim().isEmpty()) {
            return; // Phone is optional, so null/empty is allowed
        }
        
        String cleanPhone = phone.trim().replaceAll("\\s+", "");
        
        if (!VIETNAMESE_PHONE_PATTERN.matcher(cleanPhone).matches()) {
            throw new BranchValidationException(
                "Số điện thoại không hợp lệ. Vui lòng nhập số điện thoại Việt Nam hợp lệ " +
                "(ví dụ: 0901234567, +84901234567)"
            );
        }
    }
    
    /**
     * Validates email address
     * @param email the email to validate
     * @throws BranchValidationException if validation fails
     */
    public void validateEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return; // Email is optional, so null/empty is allowed
        }
        
        String trimmedEmail = email.trim();
        
        if (trimmedEmail.length() > 254) { // RFC 5321 limit
            throw new BranchValidationException("Địa chỉ email quá dài (tối đa 254 ký tự)");
        }
        
        if (!EMAIL_PATTERN.matcher(trimmedEmail).matches()) {
            throw new BranchValidationException(
                "Địa chỉ email không hợp lệ. Vui lòng nhập email đúng định dạng (ví dụ: example@domain.com)"
            );
        }
    }
    
    /**
     * Validates branch address
     * @param address the address to validate
     * @throws BranchValidationException if validation fails
     */
    public void validateAddress(String address) {
        if (address == null || address.trim().isEmpty()) {
            throw new BranchValidationException("Địa chỉ chi nhánh không được để trống");
        }
        
        String trimmedAddress = address.trim();
        
        if (trimmedAddress.length() < MIN_ADDRESS_LENGTH) {
            throw new BranchValidationException(
                String.format("Địa chỉ phải có ít nhất %d ký tự", MIN_ADDRESS_LENGTH)
            );
        }
        
        if (trimmedAddress.length() > MAX_ADDRESS_LENGTH) {
            throw new BranchValidationException(
                String.format("Địa chỉ không được vượt quá %d ký tự", MAX_ADDRESS_LENGTH)
            );
        }
        
        // Basic address format validation (allow letters, numbers, spaces, and common punctuation)
        if (!trimmedAddress.matches("^[\\p{L}\\p{N}\\s\\-.,/()]+$")) {
            throw new BranchValidationException(
                "Địa chỉ chỉ được chứa chữ cái, số, khoảng trắng và các ký tự đặc biệt cơ bản"
            );
        }
    }
    
    /**
     * Normalizes phone number for storage and comparison
     * @param phone the phone number to normalize
     * @return normalized phone number or null if input is null/empty
     */
    public String normalizePhoneNumber(String phone) {
        if (phone == null || phone.trim().isEmpty()) {
            return null;
        }
        
        String cleanPhone = phone.trim().replaceAll("\\s+", "");
        
        // Convert to standard format starting with 0
        if (cleanPhone.startsWith("+84")) {
            return "0" + cleanPhone.substring(3);
        } else if (cleanPhone.startsWith("84")) {
            return "0" + cleanPhone.substring(2);
        }
        
        return cleanPhone;
    }
    
    /**
     * Normalizes email for storage and comparison
     * @param email the email to normalize
     * @return normalized email or null if input is null/empty
     */
    public String normalizeEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return null;
        }
        return email.trim().toLowerCase();
    }
    
    /**
     * Normalizes name for comparison
     * @param name the name to normalize
     * @return normalized name or null if input is null/empty
     */
    public String normalizeName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return null;
        }
        return name.trim();
    }
    
    /**
     * Normalizes address for comparison
     * @param address the address to normalize
     * @return normalized address or null if input is null/empty
     */
    public String normalizeAddress(String address) {
        if (address == null || address.trim().isEmpty()) {
            return null;
        }
        return address.trim();
    }
}
