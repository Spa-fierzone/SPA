package com.spazone.repository;

import com.spazone.entity.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ServiceRepository extends JpaRepository<Service, Integer> {
    Page<Service> findByNameContainingIgnoreCase(String name, Pageable pageable);

    List<Service> findTop6ByStatusOrderByCreatedAtDesc(String status);
    List<Service> findByStatusOrderByCreatedAtDesc(String status);

    // Branch-specific validation queries (services are unique within a branch only)

    // Check if service name exists within a specific branch (case-insensitive)
    @Query("SELECT COUNT(s) > 0 FROM Service s WHERE LOWER(TRIM(s.name)) = LOWER(TRIM(:name)) AND s.branch.branchId = :branchId")
    boolean existsByNameIgnoreCaseAndBranchId(@Param("name") String name, @Param("branchId") Integer branchId);

    // Check if service name exists within a specific branch excluding current service (for updates)
    @Query("SELECT COUNT(s) > 0 FROM Service s WHERE LOWER(TRIM(s.name)) = LOWER(TRIM(:name)) AND s.branch.branchId = :branchId AND s.serviceId != :serviceId")
    boolean existsByNameIgnoreCaseAndBranchIdAndServiceIdNot(@Param("name") String name, @Param("branchId") Integer branchId, @Param("serviceId") Integer serviceId);

    // Find services by branch
    @Query("SELECT s FROM Service s WHERE s.branch.branchId = :branchId ORDER BY s.name")
    List<Service> findByBranchId(@Param("branchId") Integer branchId);

    // Find active services by branch
    @Query("SELECT s FROM Service s WHERE s.branch.branchId = :branchId AND s.status = 'active' ORDER BY s.name")
    List<Service> findActiveByBranchId(@Param("branchId") Integer branchId);

    // Find services by branch with pagination
    @Query("SELECT s FROM Service s WHERE s.branch.branchId = :branchId AND (:name IS NULL OR LOWER(s.name) LIKE LOWER(CONCAT('%', :name, '%')))")
    Page<Service> findByBranchIdAndNameContaining(@Param("branchId") Integer branchId, @Param("name") String name, Pageable pageable);

    // Find services by category for validation
    @Query("SELECT COUNT(s) > 0 FROM Service s WHERE s.category.categoryId = :categoryId AND s.status = 'active'")
    boolean existsActiveByCategoryId(@Param("categoryId") Integer categoryId);

    // Check if service has active appointments (for status transition validation) - updated for multi-service relationship
    @Query("""
        SELECT COUNT(DISTINCT a) > 0
        FROM Appointment a
        JOIN a.appointmentServices aps
        WHERE aps.service.serviceId = :serviceId
        AND a.status IN ('scheduled', 'confirmed', 'in_progress')
        """)
    boolean hasActiveAppointments(@Param("serviceId") Integer serviceId);
}


