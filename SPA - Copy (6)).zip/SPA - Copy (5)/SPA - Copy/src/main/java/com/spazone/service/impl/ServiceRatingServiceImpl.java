package com.spazone.service.impl;

import com.spazone.entity.ServiceRating;
import com.spazone.entity.Service;
import com.spazone.entity.User;
import com.spazone.repository.ServiceRatingRepository;
import com.spazone.service.ServiceRatingService;
import org.springframework.beans.factory.annotation.Autowired;
import com.spazone.repository.AppointmentRepository;

import java.util.List;

@org.springframework.stereotype.Service
public class ServiceRatingServiceImpl implements ServiceRatingService {
    @Autowired
    private ServiceRatingRepository serviceRatingRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Override
    public List<ServiceRating> getRatingsByService(Service service) {
        return serviceRatingRepository.findByService(service);
    }

    @Override
    public boolean hasUserRatedService(User user, Service service) {
        return serviceRatingRepository.existsByServiceAndCustomer(service, user);
    }

    private boolean hasCompletedAppointment(User user, Service service) {
        return appointmentRepository.existsByCustomerAndServiceAndStatus(user, service, "completed");
    }

    @Override
    public ServiceRating saveRating(ServiceRating rating) {
        // Optional: Check for completed appointment (commented out for testing)
        // if (!hasCompletedAppointment(rating.getCustomer(), rating.getService())) {
        //     throw new IllegalArgumentException("User must have a completed appointment with the service to submit a review.");
        // }
        return serviceRatingRepository.save(rating);
    }
}
