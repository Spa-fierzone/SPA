package com.spazone.service.impl;

import com.spazone.entity.Branch;
import com.spazone.entity.Service;
import com.spazone.entity.ServiceCategory;
import com.spazone.exception.DuplicateResourceException;
import com.spazone.exception.ResourceNotFoundException;
import com.spazone.exception.ServiceValidationException;
import com.spazone.repository.BranchRepository;
import com.spazone.repository.ServiceCategoryRepository;
import com.spazone.repository.ServiceRepository;
import com.spazone.service.SpaServiceService;
import com.spazone.util.ServiceValidationUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class SpaServiceServiceImpl implements SpaServiceService {

    private static final Logger logger = LoggerFactory.getLogger(SpaServiceServiceImpl.class);

    @Autowired
    private ServiceRepository serviceRepository;

    @Autowired
    private ServiceCategoryRepository categoryRepository;

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private ServiceValidationUtil validationUtil;

    @Override
    public Page<Service> searchByName(String keyword, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        if (keyword != null && !keyword.trim().isEmpty()) {
            return serviceRepository.findByNameContainingIgnoreCase(keyword, pageable);
        }
        return serviceRepository.findAll(pageable);
    }

    @Override
    public Service getById(Integer id) {
        return serviceRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Service not found"));
    }

    @Override
    public Service save(Service service) {
        logger.info("Saving service: {}", service.getName());

        try {
            // Determine if this is a create or update operation
            boolean isUpdate = service.getServiceId() != null;

            if (isUpdate) {
                logger.debug("Updating existing service with ID: {}", service.getServiceId());
                validateServiceForUpdate(service);

                // Preserve creation timestamp
                serviceRepository.findById(service.getServiceId())
                        .ifPresent(existing -> service.setCreatedAt(existing.getCreatedAt()));
            } else {
                logger.debug("Creating new service");
                validateServiceForCreate(service);
            }

            // Normalize data before saving
            normalizeServiceData(service);

            service.setUpdatedAt(LocalDateTime.now());
            Service savedService = serviceRepository.save(service);

            logger.info("Successfully saved service with ID: {}", savedService.getServiceId());
            return savedService;

        } catch (ServiceValidationException | DuplicateResourceException e) {
            logger.error("Validation failed for service: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            logger.error("Unexpected error while saving service: {}", e.getMessage(), e);
            throw new RuntimeException("Lỗi hệ thống khi lưu thông tin dịch vụ", e);
        }
    }

    @Override
    public void deleteById(Integer id) {
        serviceRepository.deleteById(id);
    }

    @Override
    public void toggleStatus(Integer serviceId) {
        Service service = serviceRepository.findById(serviceId)
                .orElseThrow(() -> new ResourceNotFoundException("Service not found"));

        String newStatus = "active".equals(service.getStatus()) ? "inactive" : "active";
        service.setStatus(newStatus);
        serviceRepository.save(service);
    }

    @Override
    public List<Service> getTop6() {
        return serviceRepository.findTop6ByStatusOrderByCreatedAtDesc("active");
    }

    @Override
    public List<Service> findAllActive() {
        return serviceRepository.findByStatusOrderByCreatedAtDesc("active");
    }

    @Override
    public Service getServiceById(Integer serviceId) {
        return serviceRepository.findById(serviceId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy dịch vụ."));
    }

    // ==================== BRANCH-SPECIFIC METHODS FOR MANAGER ====================

    @Override
    public Page<Service> findByBranchId(Integer branchId, Pageable pageable) {
        logger.debug("Finding services for branch ID: {}", branchId);
        return serviceRepository.findByBranchIdAndNameContaining(branchId, null, pageable);
    }

    @Override
    public Page<Service> searchByNameAndBranchId(String keyword, Integer branchId, Pageable pageable) {
        logger.debug("Searching services by keyword '{}' for branch ID: {}", keyword, branchId);
        String searchKeyword = (keyword != null && !keyword.trim().isEmpty()) ? keyword.trim() : null;
        return serviceRepository.findByBranchIdAndNameContaining(branchId, searchKeyword, pageable);
    }

    @Override
    public List<Service> findActiveByBranchId(Integer branchId) {
        logger.debug("Finding active services for branch ID: {}", branchId);
        return serviceRepository.findActiveByBranchId(branchId);
    }

    @Override
    public boolean validateManagerAccess(Integer serviceId, Integer managerBranchId) {
        logger.debug("Validating manager access for service ID: {} and branch ID: {}", serviceId, managerBranchId);

        if (serviceId == null || managerBranchId == null) {
            return false;
        }

        Service service = serviceRepository.findById(serviceId).orElse(null);
        if (service == null || service.getBranch() == null) {
            return false;
        }

        return service.getBranch().getBranchId().equals(managerBranchId);
    }

    // ==================== VALIDATION METHODS ====================

    /**
     * Validates service data for create operation
     * @param service the service to validate
     * @throws ServiceValidationException if validation fails
     * @throws DuplicateResourceException if duplicate data is found
     */
    private void validateServiceForCreate(Service service) {
        logger.debug("Validating service for create operation");

        // Basic field validations
        validateServiceFields(service);

        // Uniqueness validations for create
        validateUniquenessForCreate(service);

        // Category validation
        validateCategory(service.getCategory());

        // Branch validation
        validateBranch(service.getBranch());
    }

    /**
     * Validates service data for update operation
     * @param service the service to validate
     * @throws ServiceValidationException if validation fails
     * @throws DuplicateResourceException if duplicate data is found
     */
    private void validateServiceForUpdate(Service service) {
        logger.debug("Validating service for update operation with ID: {}", service.getServiceId());

        // Check if service exists
        Service existingService = serviceRepository.findById(service.getServiceId())
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy dịch vụ với ID: " + service.getServiceId()));

        // Basic field validations
        validateServiceFields(service);

        // Uniqueness validations for update
        validateUniquenessForUpdate(service);

        // Category validation
        validateCategory(service.getCategory());

        // Branch validation
        validateBranch(service.getBranch());

        // Status transition validation
        validationUtil.validateStatusTransition(existingService.getStatus(), service.getStatus());

        // Business rule: Cannot discontinue service with active appointments
        if ("discontinued".equals(service.getStatus()) &&
            serviceRepository.hasActiveAppointments(service.getServiceId())) {
            throw new ServiceValidationException(
                "Không thể ngừng cung cấp dịch vụ đang có lịch hẹn hoạt động"
            );
        }
    }

    /**
     * Validates basic service fields
     * @param service the service to validate
     * @throws ServiceValidationException if validation fails
     */
    private void validateServiceFields(Service service) {
        logger.debug("Validating basic service fields");

        // Validate required fields
        validationUtil.validateServiceName(service.getName());
        validationUtil.validatePrice(service.getPrice());
        validationUtil.validateDuration(service.getDuration());
        validationUtil.validateStatus(service.getStatus());

        // Validate branch (required)
        if (service.getBranch() == null || service.getBranch().getBranchId() == null) {
            throw new ServiceValidationException("Chi nhánh không được để trống");
        }
        validationUtil.validateBranch(service.getBranch().getBranchId());

        // Validate description based on status
        boolean isActiveService = "active".equals(service.getStatus());
        validationUtil.validateDescription(service.getDescription(), isActiveService);
    }

    /**
     * Validates uniqueness constraints for create operation (within branch only)
     * @param service the service to validate
     * @throws DuplicateResourceException if duplicate data is found
     */
    private void validateUniquenessForCreate(Service service) {
        logger.debug("Validating uniqueness constraints for create operation within branch: {}",
                    service.getBranch() != null ? service.getBranch().getBranchId() : "null");

        // Check name uniqueness within the same branch only
        if (service.getBranch() != null &&
            serviceRepository.existsByNameIgnoreCaseAndBranchId(service.getName(), service.getBranch().getBranchId())) {
            throw new DuplicateResourceException(
                String.format("Tên dịch vụ '%s' đã tồn tại trong chi nhánh này", service.getName())
            );
        }
    }

    /**
     * Validates uniqueness constraints for update operation (within branch only)
     * @param service the service to validate
     * @throws DuplicateResourceException if duplicate data is found
     */
    private void validateUniquenessForUpdate(Service service) {
        logger.debug("Validating uniqueness constraints for update operation within branch: {}",
                    service.getBranch() != null ? service.getBranch().getBranchId() : "null");

        // Check name uniqueness within the same branch only (excluding current service)
        if (service.getBranch() != null &&
            serviceRepository.existsByNameIgnoreCaseAndBranchIdAndServiceIdNot(
                service.getName(), service.getBranch().getBranchId(), service.getServiceId())) {
            throw new DuplicateResourceException(
                String.format("Tên dịch vụ '%s' đã tồn tại trong chi nhánh này", service.getName())
            );
        }
    }

    /**
     * Validates service category
     * @param category the category to validate
     * @throws ServiceValidationException if validation fails
     */
    private void validateCategory(ServiceCategory category) {
        if (category == null || category.getCategoryId() == null) {
            throw new ServiceValidationException("Danh mục dịch vụ không được để trống");
        }

        // Check if category exists
        if (!categoryRepository.existsById(category.getCategoryId())) {
            throw new ServiceValidationException("Danh mục dịch vụ không tồn tại trong hệ thống");
        }

        logger.debug("Category validation passed for category ID: {}", category.getCategoryId());
    }

    /**
     * Validates service branch
     * @param branch the branch to validate
     * @throws ServiceValidationException if validation fails
     */
    private void validateBranch(Branch branch) {
        if (branch == null || branch.getBranchId() == null) {
            throw new ServiceValidationException("Chi nhánh không được để trống");
        }

        // Check if branch exists and is active
        Branch existingBranch = branchRepository.findById(branch.getBranchId())
                .orElseThrow(() -> new ServiceValidationException("Chi nhánh không tồn tại trong hệ thống"));

        if (!Boolean.TRUE.equals(existingBranch.getActive())) {
            throw new ServiceValidationException("Không thể tạo dịch vụ cho chi nhánh đã ngừng hoạt động");
        }

        logger.debug("Branch validation passed for branch ID: {}", branch.getBranchId());
    }

    /**
     * Normalizes service data before saving
     * @param service the service to normalize
     */
    private void normalizeServiceData(Service service) {
        logger.debug("Normalizing service data");

        // Normalize text fields
        service.setName(validationUtil.normalizeName(service.getName()));
        service.setDescription(validationUtil.normalizeDescription(service.getDescription()));
        service.setStatus(validationUtil.normalizeStatus(service.getStatus()));

        // Normalize image URL
        if (service.getImageUrl() != null) {
            service.setImageUrl(service.getImageUrl().trim());
        }
    }
}
