package com.spazone.dto;

import com.spazone.entity.Service;
import java.math.BigDecimal;

public class ServiceDTO {
    private Integer serviceId;
    private String name;
    private BigDecimal price;
    private Integer duration;
    private String categoryName;

    public ServiceDTO() {}

    public ServiceDTO(Service service) {
        this.serviceId = service.getServiceId();
        this.name = service.getName();
        this.price = service.getPrice();
        this.duration = service.getDuration();
        this.categoryName = service.getCategory() != null ? service.getCategory().getName() : null;
    }

    // Getters and setters
    public Integer getServiceId() {
        return serviceId;
    }

    public void setServiceId(Integer serviceId) {
        this.serviceId = serviceId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
}
