package com.spazone.service.impl;

import com.spazone.dto.ValidationResult;
import com.spazone.dto.ValidationResult.ConflictDetail;
import com.spazone.dto.ValidationResult.ConflictType;
import com.spazone.entity.Appointment;
import com.spazone.entity.Room;
import com.spazone.entity.User;
import com.spazone.repository.AppointmentRepository;
import com.spazone.repository.RoomRepository;
import com.spazone.repository.UserRepository;
import com.spazone.service.AppointmentValidationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AppointmentValidationServiceImpl implements AppointmentValidationService {
    
    @Autowired
    private AppointmentRepository appointmentRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private RoomRepository roomRepository;
    
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm dd/MM/yyyy");
    
    @Override
    public ValidationResult validateTechnicianAvailability(Integer technicianId, LocalDateTime startTime, 
                                                          LocalDateTime endTime, Integer excludeAppointmentId) {
        ValidationResult result = new ValidationResult();
        
        try {
            // Get technician info
            User technician = userRepository.findById(technicianId).orElse(null);
            if (technician == null) {
                result.addErrorMessage("Kỹ thuật viên không tồn tại.");
                return result;
            }
            
            // Find conflicting appointments for this technician
            List<Appointment> conflictingAppointments = findConflictingAppointments(
                technicianId, null, startTime, endTime, excludeAppointmentId);
            
            if (!conflictingAppointments.isEmpty()) {
                for (Appointment conflict : conflictingAppointments) {
                    String errorMessage = String.format(
                        "Kỹ thuật viên %s đã có lịch hẹn từ %s đến %s (Mã lịch hẹn: #%d)",
                        technician.getFullName(),
                        conflict.getStartTime().format(TIME_FORMATTER),
                        conflict.getEndTime().format(TIME_FORMATTER),
                        conflict.getAppointmentId()
                    );
                    result.addErrorMessage(errorMessage);
                    
                    ConflictDetail conflictDetail = new ConflictDetail(
                        ConflictType.TECHNICIAN_CONFLICT,
                        technician.getFullName(),
                        conflict.getStartTime(),
                        conflict.getEndTime(),
                        conflict.getAppointmentId()
                    );
                    result.addConflict(conflictDetail);
                }
            }
            
        } catch (Exception e) {
            result.addErrorMessage("Lỗi khi kiểm tra lịch trình kỹ thuật viên: " + e.getMessage());
        }
        
        return result;
    }
    
    @Override
    public ValidationResult validateRoomAvailability(Integer roomId, LocalDateTime startTime, 
                                                    LocalDateTime endTime, Integer excludeAppointmentId) {
        ValidationResult result = new ValidationResult();
        
        if (roomId == null) {
            // Room is optional, so no validation needed
            return result;
        }
        
        try {
            // Get room info
            Room room = roomRepository.findById(roomId).orElse(null);
            if (room == null) {
                result.addErrorMessage("Phòng không tồn tại.");
                return result;
            }
            
            // Find conflicting appointments for this room
            List<Appointment> conflictingAppointments = findConflictingAppointments(
                null, roomId, startTime, endTime, excludeAppointmentId);
            
            if (!conflictingAppointments.isEmpty()) {
                for (Appointment conflict : conflictingAppointments) {
                    String technicianName = conflict.getTechnician() != null ? 
                        conflict.getTechnician().getFullName() : "N/A";
                    
                    String errorMessage = String.format(
                        "Phòng %s đã được đặt từ %s đến %s bởi kỹ thuật viên %s (Mã lịch hẹn: #%d)",
                        room.getName(),
                        conflict.getStartTime().format(TIME_FORMATTER),
                        conflict.getEndTime().format(TIME_FORMATTER),
                        technicianName,
                        conflict.getAppointmentId()
                    );
                    result.addErrorMessage(errorMessage);
                    
                    ConflictDetail conflictDetail = new ConflictDetail(
                        ConflictType.ROOM_CONFLICT,
                        room.getName(),
                        conflict.getStartTime(),
                        conflict.getEndTime(),
                        conflict.getAppointmentId()
                    );
                    result.addConflict(conflictDetail);
                }
            }
            
        } catch (Exception e) {
            result.addErrorMessage("Lỗi khi kiểm tra tình trạng phòng: " + e.getMessage());
        }
        
        return result;
    }
    
    @Override
    public ValidationResult validateAppointmentScheduling(Integer technicianId, Integer roomId, 
                                                         LocalDateTime startTime, LocalDateTime endTime, 
                                                         Integer excludeAppointmentId) {
        ValidationResult result = new ValidationResult();
        
        // Check if appointment is in the past
        if (startTime.isBefore(LocalDateTime.now())) {
            result.addErrorMessage("Không thể tạo lịch hẹn trong quá khứ.");
            return result;
        }
        
        // Validate technician availability
        ValidationResult technicianValidation = validateTechnicianAvailability(
            technicianId, startTime, endTime, excludeAppointmentId);
        
        if (!technicianValidation.isValid()) {
            result.getErrorMessages().addAll(technicianValidation.getErrorMessages());
            result.getConflicts().addAll(technicianValidation.getConflicts());
            result.setValid(false);
        }
        
        // Validate room availability (if room is specified)
        if (roomId != null) {
            ValidationResult roomValidation = validateRoomAvailability(
                roomId, startTime, endTime, excludeAppointmentId);
            
            if (!roomValidation.isValid()) {
                result.getErrorMessages().addAll(roomValidation.getErrorMessages());
                result.getConflicts().addAll(roomValidation.getConflicts());
                result.setValid(false);
            }
        }
        
        return result;
    }

    @Override
    public List<LocalDateTime> getSuggestedTimeSlots(Integer technicianId, Integer roomId,
                                                    LocalDateTime preferredStartTime, int durationMinutes,
                                                    Integer excludeAppointmentId) {
        List<LocalDateTime> suggestions = new ArrayList<>();

        try {
            // Generate suggestions for the same day first
            LocalDateTime currentTime = preferredStartTime;
            LocalDateTime dayEnd = preferredStartTime.toLocalDate().atTime(18, 0); // Assume working hours end at 6 PM

            // Try slots every 30 minutes
            while (currentTime.isBefore(dayEnd) && suggestions.size() < 5) {
                LocalDateTime slotEnd = currentTime.plusMinutes(durationMinutes);

                if (slotEnd.isAfter(dayEnd)) {
                    break;
                }

                ValidationResult validation = validateAppointmentScheduling(
                    technicianId, roomId, currentTime, slotEnd, excludeAppointmentId);

                if (validation.isValid()) {
                    suggestions.add(currentTime);
                }

                currentTime = currentTime.plusMinutes(30);
            }

            // If not enough suggestions for the same day, try next day
            if (suggestions.size() < 3) {
                LocalDateTime nextDay = preferredStartTime.plusDays(1).toLocalDate().atTime(9, 0); // Start at 9 AM next day
                LocalDateTime nextDayEnd = nextDay.toLocalDate().atTime(18, 0);

                currentTime = nextDay;
                while (currentTime.isBefore(nextDayEnd) && suggestions.size() < 5) {
                    LocalDateTime slotEnd = currentTime.plusMinutes(durationMinutes);

                    if (slotEnd.isAfter(nextDayEnd)) {
                        break;
                    }

                    ValidationResult validation = validateAppointmentScheduling(
                        technicianId, roomId, currentTime, slotEnd, excludeAppointmentId);

                    if (validation.isValid()) {
                        suggestions.add(currentTime);
                    }

                    currentTime = currentTime.plusMinutes(30);
                }
            }

        } catch (Exception e) {
            System.err.println("Error generating suggested time slots: " + e.getMessage());
        }

        return suggestions;
    }

    /**
     * Helper method to find conflicting appointments
     */
    private List<Appointment> findConflictingAppointments(Integer technicianId, Integer roomId,
                                                         LocalDateTime startTime, LocalDateTime endTime,
                                                         Integer excludeAppointmentId) {
        List<Appointment> conflictingAppointments;

        if (technicianId != null) {
            // Use optimized query for technician conflicts
            conflictingAppointments = appointmentRepository.findConflictingAppointmentsByTechnician(
                technicianId, startTime, endTime);
        } else if (roomId != null) {
            // Use optimized query for room conflicts
            conflictingAppointments = appointmentRepository.findConflictingAppointmentsByRoom(
                roomId, startTime, endTime);
        } else {
            return new ArrayList<>();
        }

        // Filter out the appointment being edited
        if (excludeAppointmentId != null) {
            conflictingAppointments = conflictingAppointments.stream()
                .filter(appointment -> !appointment.getAppointmentId().equals(excludeAppointmentId))
                .collect(Collectors.toList());
        }

        return conflictingAppointments;
    }

    /**
     * Helper method to check if two time periods overlap
     */
    private boolean hasTimeOverlap(LocalDateTime start1, LocalDateTime end1,
                                  LocalDateTime start2, LocalDateTime end2) {
        // Two time periods overlap if:
        // start1 < end2 AND start2 < end1
        // This handles all overlap cases including exact start/end times
        return start1.isBefore(end2) && start2.isBefore(end1);
    }
}
