package com.spazone.service;

import com.spazone.entity.Appointment;
import com.spazone.entity.User;

public interface CancellationService {
    
    /**
     * Validates if an appointment can be cancelled based on business rules
     */
    CancellationValidationResult validateCancellation(Appointment appointment, User customer);
    
    /**
     * Performs standard cancellation (more than 2 hours before appointment)
     */
    CancellationResult performStandardCancellation(Integer appointmentId, Integer customerId, String reason);
    
    /**
     * Performs late cancellation (less than 2 hours before appointment, unpaid)
     */
    CancellationResult performLateCancellation(Integer appointmentId, Integer customerId, String reason, boolean customerConfirmed);
    
    /**
     * Attempts late cancellation for paid appointments (should be blocked for customers)
     */
    CancellationResult attemptLatePaidCancellation(Integer appointmentId, Integer customerId);
    
    /**
     * Manual cancellation override by staff (for paid late cancellations)
     */
    CancellationResult performManualCancellation(Integer appointmentId, Integer staffId, String reason, String justification);
    
    /**
     * Checks if customer has booking restrictions
     */
    boolean isCustomerBookingRestricted(User customer);
    
    /**
     * Gets customer's late cancellation count
     */
    int getCustomerLateCancellationCount(User customer);
    
    /**
     * Checks if customer has already used their one-time late cancellation
     */
    boolean hasCustomerUsedLateCancellation(User customer);
    
    /**
     * Calculates time until appointment
     */
    long getHoursUntilAppointment(Appointment appointment);
    
    /**
     * Inner classes for results
     */
    class CancellationValidationResult {
        private boolean canCancel;
        private String cancellationType; // STANDARD, LATE_UNPAID, LATE_PAID_BLOCKED
        private String message;
        private boolean requiresConfirmation;
        private String warningMessage;
        
        public CancellationValidationResult(boolean canCancel, String cancellationType, String message) {
            this.canCancel = canCancel;
            this.cancellationType = cancellationType;
            this.message = message;
        }
        
        // Getters and setters
        public boolean isCanCancel() { return canCancel; }
        public void setCanCancel(boolean canCancel) { this.canCancel = canCancel; }
        public String getCancellationType() { return cancellationType; }
        public void setCancellationType(String cancellationType) { this.cancellationType = cancellationType; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public boolean isRequiresConfirmation() { return requiresConfirmation; }
        public void setRequiresConfirmation(boolean requiresConfirmation) { this.requiresConfirmation = requiresConfirmation; }
        public String getWarningMessage() { return warningMessage; }
        public void setWarningMessage(String warningMessage) { this.warningMessage = warningMessage; }
    }
    
    class CancellationResult {
        private boolean success;
        private String message;
        private String newAppointmentStatus;
        private String newInvoiceStatus;
        private boolean refundProcessed;
        private boolean customerRestricted;
        
        public CancellationResult(boolean success, String message) {
            this.success = success;
            this.message = message;
        }
        
        // Getters and setters
        public boolean isSuccess() { return success; }
        public void setSuccess(boolean success) { this.success = success; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public String getNewAppointmentStatus() { return newAppointmentStatus; }
        public void setNewAppointmentStatus(String newAppointmentStatus) { this.newAppointmentStatus = newAppointmentStatus; }
        public String getNewInvoiceStatus() { return newInvoiceStatus; }
        public void setNewInvoiceStatus(String newInvoiceStatus) { this.newInvoiceStatus = newInvoiceStatus; }
        public boolean isRefundProcessed() { return refundProcessed; }
        public void setRefundProcessed(boolean refundProcessed) { this.refundProcessed = refundProcessed; }
        public boolean isCustomerRestricted() { return customerRestricted; }
        public void setCustomerRestricted(boolean customerRestricted) { this.customerRestricted = customerRestricted; }
    }
}
