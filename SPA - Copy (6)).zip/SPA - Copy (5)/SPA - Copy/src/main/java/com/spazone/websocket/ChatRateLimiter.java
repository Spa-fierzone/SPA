package com.spazone.websocket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Rate limiter for chat operations
 * Prevents spam and abuse in chat system
 * Implements sliding window rate limiting
 */
@Component
public class ChatRateLimiter {

    private static final Logger logger = LoggerFactory.getLogger(ChatRateLimiter.class);

    // Rate limiting configuration
    private static final int MESSAGE_LIMIT_PER_MINUTE = 30;
    private static final int TYPING_LIMIT_PER_MINUTE = 60;
    private static final int FILE_LIMIT_PER_HOUR = 10;

    // Track user activity
    private final Map<String, UserActivity> userActivities = new ConcurrentHashMap<>();

    /**
     * Check if user can send a message
     */
    public boolean allowMessage(String userId) {
        return checkRateLimit(userId, ActivityType.MESSAGE, MESSAGE_LIMIT_PER_MINUTE, 1);
    }

    /**
     * Check if user can send typing indicator
     */
    public boolean allowTyping(String userId) {
        return checkRateLimit(userId, ActivityType.TYPING, TYPING_LIMIT_PER_MINUTE, 1);
    }

    /**
     * Check if user can upload file
     */
    public boolean allowFileUpload(String userId) {
        return checkRateLimit(userId, ActivityType.FILE_UPLOAD, FILE_LIMIT_PER_HOUR, 60);
    }

    /**
     * Get remaining message quota for user
     */
    public int getRemainingMessageQuota(String userId) {
        UserActivity activity = userActivities.get(userId);
        if (activity == null) {
            return MESSAGE_LIMIT_PER_MINUTE;
        }
        
        cleanupOldEntries(activity.messageTimestamps, 1);
        return Math.max(0, MESSAGE_LIMIT_PER_MINUTE - activity.messageTimestamps.size());
    }

    /**
     * Check if user is currently rate limited
     */
    public boolean isRateLimited(String userId) {
        UserActivity activity = userActivities.get(userId);
        if (activity == null) {
            return false;
        }

        // Check if user has exceeded any limits recently
        cleanupOldEntries(activity.messageTimestamps, 1);
        cleanupOldEntries(activity.typingTimestamps, 1);
        cleanupOldEntries(activity.fileUploadTimestamps, 60);

        return activity.messageTimestamps.size() >= MESSAGE_LIMIT_PER_MINUTE ||
               activity.typingTimestamps.size() >= TYPING_LIMIT_PER_MINUTE ||
               activity.fileUploadTimestamps.size() >= FILE_LIMIT_PER_HOUR;
    }

    /**
     * Reset rate limits for a user (admin function)
     */
    public void resetUserLimits(String userId) {
        userActivities.remove(userId);
        logger.info("Reset rate limits for user: {}", userId);
    }

    /**
     * Get rate limit status for user
     */
    public RateLimitStatus getRateLimitStatus(String userId) {
        UserActivity activity = userActivities.get(userId);
        if (activity == null) {
            return new RateLimitStatus(
                MESSAGE_LIMIT_PER_MINUTE, 
                TYPING_LIMIT_PER_MINUTE, 
                FILE_LIMIT_PER_HOUR, 
                false
            );
        }

        cleanupOldEntries(activity.messageTimestamps, 1);
        cleanupOldEntries(activity.typingTimestamps, 1);
        cleanupOldEntries(activity.fileUploadTimestamps, 60);

        return new RateLimitStatus(
            MESSAGE_LIMIT_PER_MINUTE - activity.messageTimestamps.size(),
            TYPING_LIMIT_PER_MINUTE - activity.typingTimestamps.size(),
            FILE_LIMIT_PER_HOUR - activity.fileUploadTimestamps.size(),
            isRateLimited(userId)
        );
    }

    // Private helper methods

    private boolean checkRateLimit(String userId, ActivityType type, int limit, int windowMinutes) {
        UserActivity activity = userActivities.computeIfAbsent(userId, k -> new UserActivity());
        
        Map<LocalDateTime, Integer> timestamps = getTimestampsForType(activity, type);
        
        // Clean up old entries
        cleanupOldEntries(timestamps, windowMinutes);
        
        // Check if limit exceeded
        if (timestamps.size() >= limit) {
            logger.warn("Rate limit exceeded for user {} - type: {}, current: {}, limit: {}", 
                       userId, type, timestamps.size(), limit);
            return false;
        }
        
        // Add current timestamp
        timestamps.put(LocalDateTime.now(), 1);
        return true;
    }

    private Map<LocalDateTime, Integer> getTimestampsForType(UserActivity activity, ActivityType type) {
        switch (type) {
            case MESSAGE:
                return activity.messageTimestamps;
            case TYPING:
                return activity.typingTimestamps;
            case FILE_UPLOAD:
                return activity.fileUploadTimestamps;
            default:
                throw new IllegalArgumentException("Unknown activity type: " + type);
        }
    }

    private void cleanupOldEntries(Map<LocalDateTime, Integer> timestamps, int windowMinutes) {
        LocalDateTime cutoff = LocalDateTime.now().minus(windowMinutes, ChronoUnit.MINUTES);
        timestamps.entrySet().removeIf(entry -> entry.getKey().isBefore(cutoff));
    }

    // Inner classes

    private enum ActivityType {
        MESSAGE, TYPING, FILE_UPLOAD
    }

    private static class UserActivity {
        final Map<LocalDateTime, Integer> messageTimestamps = new ConcurrentHashMap<>();
        final Map<LocalDateTime, Integer> typingTimestamps = new ConcurrentHashMap<>();
        final Map<LocalDateTime, Integer> fileUploadTimestamps = new ConcurrentHashMap<>();
    }

    public static class RateLimitStatus {
        private final int remainingMessages;
        private final int remainingTyping;
        private final int remainingFileUploads;
        private final boolean isLimited;

        public RateLimitStatus(int remainingMessages, int remainingTyping, int remainingFileUploads, boolean isLimited) {
            this.remainingMessages = remainingMessages;
            this.remainingTyping = remainingTyping;
            this.remainingFileUploads = remainingFileUploads;
            this.isLimited = isLimited;
        }

        public int getRemainingMessages() {
            return remainingMessages;
        }

        public int getRemainingTyping() {
            return remainingTyping;
        }

        public int getRemainingFileUploads() {
            return remainingFileUploads;
        }

        public boolean isLimited() {
            return isLimited;
        }
    }
}
