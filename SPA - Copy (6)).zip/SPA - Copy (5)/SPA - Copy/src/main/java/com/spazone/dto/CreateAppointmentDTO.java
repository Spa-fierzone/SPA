package com.spazone.dto;

import java.time.LocalDateTime;
import java.util.List;

/**
 * DTO for creating appointments with multiple services
 */
public class CreateAppointmentDTO {
    
    private Integer customerId;
    private Integer branchId;
    private Integer technicianId;
    private Integer roomId;
    private LocalDateTime appointmentDateTime;
    private String notes;
    private String specialRequests;
    private List<Integer> serviceIds;
    private List<Integer> quantities;
    private List<String> serviceNotes;

    public CreateAppointmentDTO() {
    }

    public CreateAppointmentDTO(Integer customerId, Integer branchId, Integer technicianId, 
                              LocalDateTime appointmentDateTime, List<Integer> serviceIds) {
        this.customerId = customerId;
        this.branchId = branchId;
        this.technicianId = technicianId;
        this.appointmentDateTime = appointmentDateTime;
        this.serviceIds = serviceIds;
    }

    // Validation methods
    public boolean isValid() {
        return customerId != null && 
               branchId != null && 
               technicianId != null && 
               appointmentDateTime != null && 
               serviceIds != null && 
               !serviceIds.isEmpty();
    }

    public String getValidationError() {
        if (customerId == null) return "Customer ID is required";
        if (branchId == null) return "Branch ID is required";
        if (technicianId == null) return "Technician ID is required";
        if (appointmentDateTime == null) return "Appointment date time is required";
        if (serviceIds == null || serviceIds.isEmpty()) return "At least one service is required";
        
        if (quantities != null && quantities.size() != serviceIds.size()) {
            return "Quantities list size must match services list size";
        }
        
        if (serviceNotes != null && serviceNotes.size() != serviceIds.size()) {
            return "Service notes list size must match services list size";
        }
        
        return null;
    }

    // Getters and Setters
    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public Integer getBranchId() {
        return branchId;
    }

    public void setBranchId(Integer branchId) {
        this.branchId = branchId;
    }

    public Integer getTechnicianId() {
        return technicianId;
    }

    public void setTechnicianId(Integer technicianId) {
        this.technicianId = technicianId;
    }

    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public LocalDateTime getAppointmentDateTime() {
        return appointmentDateTime;
    }

    public void setAppointmentDateTime(LocalDateTime appointmentDateTime) {
        this.appointmentDateTime = appointmentDateTime;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getSpecialRequests() {
        return specialRequests;
    }

    public void setSpecialRequests(String specialRequests) {
        this.specialRequests = specialRequests;
    }

    public List<Integer> getServiceIds() {
        return serviceIds;
    }

    public void setServiceIds(List<Integer> serviceIds) {
        this.serviceIds = serviceIds;
    }

    public List<Integer> getQuantities() {
        return quantities;
    }

    public void setQuantities(List<Integer> quantities) {
        this.quantities = quantities;
    }

    public List<String> getServiceNotes() {
        return serviceNotes;
    }

    public void setServiceNotes(List<String> serviceNotes) {
        this.serviceNotes = serviceNotes;
    }

    @Override
    public String toString() {
        return "CreateAppointmentDTO{" +
                "customerId=" + customerId +
                ", branchId=" + branchId +
                ", technicianId=" + technicianId +
                ", roomId=" + roomId +
                ", appointmentDateTime=" + appointmentDateTime +
                ", serviceIds=" + serviceIds +
                ", quantities=" + quantities +
                '}';
    }
}
