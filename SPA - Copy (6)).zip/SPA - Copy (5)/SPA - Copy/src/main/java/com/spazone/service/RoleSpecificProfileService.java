package com.spazone.service;

import com.spazone.dto.*;

public interface RoleSpecificProfileService {
    CustomerProfileDto getCustomerProfile(String username);
    TechnicianProfileDto getTechnicianProfile(String username);
    ManagerProfileDto getManagerProfile(String username);
    ReceptionistProfileDto getReceptionistProfile(String username);
    AdminProfileDto getAdminProfile(String username);
}
