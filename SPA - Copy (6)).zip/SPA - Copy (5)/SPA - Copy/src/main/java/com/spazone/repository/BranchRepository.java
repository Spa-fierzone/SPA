package com.spazone.repository;

import com.spazone.entity.Branch;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BranchRepository extends JpaRepository<Branch, Integer> {

    // Search branches with keyword and manager filter - MISSING METHOD FOR BRANCH SERVICE
    @Query("""
    SELECT b FROM Branch b 
    WHERE (:keyword IS NULL OR LOWER(b.name) LIKE LOWER(CONCAT('%', :keyword, '%')) 
           OR LOWER(b.address) LIKE LOWER(CONCAT('%', :keyword, '%')))
    AND (:managerId IS NULL OR b.managerId = :managerId)
    ORDER BY b.createdAt DESC
    """)
    Page<Branch> searchBranches(@Param("keyword") String keyword,
                               @Param("managerId") Integer managerId,
                               Pageable pageable);

    // Find all active branches - MISSING METHOD FOR BRANCH SERVICE
    @Query("SELECT b FROM Branch b WHERE b.status = 'active' ORDER BY b.name")
    List<Branch> findByIsActiveTrue();

    // Find branches by status
    List<Branch> findByStatus(String status);

    // Find branches by manager ID
    List<Branch> findByManagerId(Integer managerId);

    // Count branches by status
    @Query("SELECT COUNT(b) FROM Branch b WHERE b.status = :status")
    Long countByStatus(@Param("status") String status);

    // Find branches in a specific city or region
    @Query("SELECT b FROM Branch b WHERE LOWER(b.address) LIKE LOWER(CONCAT('%', :city, '%'))")
    List<Branch> findByCity(@Param("city") String city);

    // Validation queries for uniqueness checks

    // Check if branch name exists (case-insensitive)
    @Query("SELECT COUNT(b) > 0 FROM Branch b WHERE LOWER(TRIM(b.name)) = LOWER(TRIM(:name))")
    boolean existsByNameIgnoreCase(@Param("name") String name);

    // Check if branch name exists excluding current branch (for updates)
    @Query("SELECT COUNT(b) > 0 FROM Branch b WHERE LOWER(TRIM(b.name)) = LOWER(TRIM(:name)) AND b.branchId != :branchId")
    boolean existsByNameIgnoreCaseAndBranchIdNot(@Param("name") String name, @Param("branchId") Integer branchId);

    // Check if phone number exists
    @Query("SELECT COUNT(b) > 0 FROM Branch b WHERE b.phone = :phone")
    boolean existsByPhone(@Param("phone") String phone);

    // Check if phone number exists excluding current branch (for updates)
    @Query("SELECT COUNT(b) > 0 FROM Branch b WHERE b.phone = :phone AND b.branchId != :branchId")
    boolean existsByPhoneAndBranchIdNot(@Param("phone") String phone, @Param("branchId") Integer branchId);

    // Check if email exists (case-insensitive)
    @Query("SELECT COUNT(b) > 0 FROM Branch b WHERE LOWER(TRIM(b.email)) = LOWER(TRIM(:email))")
    boolean existsByEmailIgnoreCase(@Param("email") String email);

    // Check if email exists excluding current branch (for updates)
    @Query("SELECT COUNT(b) > 0 FROM Branch b WHERE LOWER(TRIM(b.email)) = LOWER(TRIM(:email)) AND b.branchId != :branchId")
    boolean existsByEmailIgnoreCaseAndBranchIdNot(@Param("email") String email, @Param("branchId") Integer branchId);

    // Check if address exists (case-insensitive) - optional for business rules
    @Query("SELECT COUNT(b) > 0 FROM Branch b WHERE LOWER(TRIM(b.address)) = LOWER(TRIM(:address))")
    boolean existsByAddressIgnoreCase(@Param("address") String address);

    // Check if address exists excluding current branch (for updates)
    @Query("SELECT COUNT(b) > 0 FROM Branch b WHERE LOWER(TRIM(b.address)) = LOWER(TRIM(:address)) AND b.branchId != :branchId")
    boolean existsByAddressIgnoreCaseAndBranchIdNot(@Param("address") String address, @Param("branchId") Integer branchId);
}
