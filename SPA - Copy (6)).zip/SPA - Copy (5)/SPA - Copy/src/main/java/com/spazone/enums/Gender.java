package com.spazone.enums;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
