package com.spazone.service;

import com.spazone.dto.TimeSlot;
import com.spazone.entity.Appointment;
import com.spazone.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface AppointmentService {
    void create(Appointment appointment);

    List<Appointment> getByCustomer(User customer);

    Page<Appointment> getByCustomer(User customer, Pageable pageable);

    List<TimeSlot> suggestFreeSlots(Integer technicianId, LocalDateTime date, int duration);

    List<Appointment> getTodayAppointments();

    Appointment findById(Integer id);

    Appointment checkIn(Integer appointmentId);

    Appointment checkInWithTime(Integer appointmentId, LocalDateTime checkinTime);

    void checkOut(Integer appointmentId);

    Appointment findByIdWithTreatmentRecords(Integer id);

    // For receptionist: create appointment by ids and datetime (legacy single service support)
    boolean createAppointment(Integer customerId, Integer serviceId, String appointmentDateTime, Integer technicianId, Integer branchId);

    Appointment findLatestAppointment(Integer customerId, Integer serviceId, Integer technicianId, Integer branchId);

    void update(Appointment appointment);

    // Cancel appointment and restore room capacity
    boolean cancelAppointment(Integer appointmentId, String cancellationReason);

    // Delete appointment and restore room capacity
    boolean deleteAppointment(Integer appointmentId);

    // Get appointments for a specific week (Monday to Sunday)
    List<Appointment> getWeeklyAppointments(LocalDate weekStart);

    // Get appointments by date range
    List<Appointment> getAppointmentsByDateRange(LocalDateTime start, LocalDateTime end);

    // New methods for multiple services support
    void createWithServices(Appointment appointment, List<Integer> serviceIds);
    void createWithServices(Appointment appointment, List<Integer> serviceIds, List<Integer> quantities);
    boolean createAppointmentWithServices(Integer customerId, List<Integer> serviceIds, String appointmentDateTime, Integer technicianId, Integer branchId);

    // Method to update appointment services
    void updateAppointmentServices(Integer appointmentId, List<Integer> serviceIds, List<Integer> quantities);

    // Enhanced check-in functionality
    boolean canCheckIn(Integer appointmentId);

    boolean isEarlyCheckInAllowed(Appointment appointment);

    List<Appointment> getCheckedInAppointments();

    List<Appointment> getCheckedInAppointmentsByBranch(Integer branchId);

    // Service addition functionality
    void addServiceToAppointment(Integer appointmentId, Integer serviceId, Integer quantity);

    void addServicesToAppointment(Integer appointmentId, List<Integer> serviceIds);

    Appointment createAdditionalServiceAppointment(Integer originalAppointmentId, List<Integer> serviceIds);

    boolean canAddServicesToUnpaidAppointment(Integer appointmentId);

    void recalculateAppointmentTotals(Integer appointmentId);

    void updateAppointmentDuration(Integer appointmentId);

    void removeServiceFromAppointment(Integer appointmentId, Integer serviceId);

    void updateServiceQuantity(Integer appointmentId, Integer serviceId, Integer quantity);

    void removeServiceAndRecalculate(Integer appointmentId, Integer serviceId);

    void updateServiceQuantityAndRecalculate(Integer appointmentId, Integer serviceId, Integer quantity);

    boolean checkTechnicianAvailabilityForExtension(Integer appointmentId, int additionalMinutes);

    // Notification functionality
    void notifyTechnicianOfCheckin(Appointment appointment);

    void notifyTechnicianOfServiceAddition(Appointment appointment, List<com.spazone.entity.Service> addedServices);

    // Enhanced technician dashboard methods
    Page<Appointment> getAppointmentsByTechnicianAndDateRange(Integer technicianId, LocalDateTime startDate, LocalDateTime endDate, String status, Pageable pageable);

    List<Appointment> getAppointmentsByTechnicianAndDateRange(Integer technicianId, LocalDateTime startDate, LocalDateTime endDate);

    List<Appointment> getAppointmentsByCustomerAndTechnician(Integer customerId, Integer technicianId);

    void updateAppointmentStatus(Integer appointmentId, String status);

    // Service addition methods
    void addServicesToAppointment(Integer appointmentId, List<Integer> serviceIds, List<Integer> quantities, String notes, boolean requiresApproval);

    List<com.spazone.entity.Service> getSuggestedServices(Integer appointmentId);

    /**
     * Check if all services in an appointment have treatment records and update appointment status accordingly
     */
    void updateAppointmentStatusBasedOnTreatmentRecords(Integer appointmentId);

    /**
     * Check if an appointment is completed (all services have treatment records)
     */
    boolean isAppointmentCompleted(Integer appointmentId);

    /**
     * Create a follow-up appointment for additional services after treatment completion
     * @param originalAppointmentId The ID of the completed appointment
     * @param serviceIds List of service IDs for the follow-up appointment
     * @param quantities List of quantities for each service (optional, defaults to 1)
     * @param schedulingType "immediate" for immediate scheduling or "future" for custom date/time
     * @param customDateTime Custom date/time for future scheduling (required if schedulingType is "future")
     * @param technicianId Technician ID (optional, will auto-assign if not provided)
     * @return The created follow-up appointment
     */
    Appointment createFollowUpAppointment(Integer originalAppointmentId, List<Integer> serviceIds,
                                        List<Integer> quantities, String schedulingType,
                                        LocalDateTime customDateTime, Integer technicianId);
}
