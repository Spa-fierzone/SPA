package com.spazone.controller;

import com.spazone.dto.ManagerScheduleDetailDTO;
import com.spazone.dto.ManagerScheduleDetailDTO.ServiceUsageDTO;
import com.spazone.service.BranchService;
import com.spazone.service.ManagerScheduleService;
import com.spazone.service.ServiceStatisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/manager/schedules")
@PreAuthorize("hasRole('MANAGER') or hasRole('ADMIN')")
public class ManagerScheduleController {
    
    @Autowired
    private ManagerScheduleService managerScheduleService;
    
    @Autowired
    private ServiceStatisticsService serviceStatisticsService;
    
    @Autowired
    private BranchService branchService;
    
    /**
     * Manager schedule overview page
     */
    @GetMapping
    public String showManagerScheduleOverview(Model model,
                                            @RequestParam(required = false) String date,
                                            @RequestParam(required = false) Integer branchId) {
        LocalDate viewDate = date != null ? LocalDate.parse(date) : LocalDate.now();
        
        // Get technician schedules for the date
        List<ManagerScheduleDetailDTO> technicianSchedules = 
                managerScheduleService.getTechnicianSchedulesForDate(viewDate);
        
        // Get receptionist schedules for the date
        List<ManagerScheduleDetailDTO> receptionistSchedules = 
                managerScheduleService.getReceptionistSchedulesForDate(viewDate);
        
        // Filter by branch if specified
        if (branchId != null) {
            technicianSchedules = technicianSchedules.stream()
                    .filter(s -> s.getBranchId().equals(branchId))
                    .toList();
            receptionistSchedules = receptionistSchedules.stream()
                    .filter(s -> s.getBranchId().equals(branchId))
                    .toList();
        }
        
        // Get service statistics for the week
        LocalDate weekStart = viewDate.with(java.time.DayOfWeek.MONDAY);
        LocalDate weekEnd = weekStart.plusDays(6);
        Map<String, Object> scheduleStats = managerScheduleService
                .getScheduleStatistics(weekStart, weekEnd);
        
        // Get popular services for the date range
        List<ServiceUsageDTO> popularServices = serviceStatisticsService
                .getPopularServicesInDateRange(weekStart, weekEnd);
        
        model.addAttribute("technicianSchedules", technicianSchedules);
        model.addAttribute("receptionistSchedules", receptionistSchedules);
        model.addAttribute("scheduleStats", scheduleStats);
        model.addAttribute("popularServices", popularServices);
        model.addAttribute("viewDate", viewDate);
        model.addAttribute("weekStart", weekStart);
        model.addAttribute("weekEnd", weekEnd);
        model.addAttribute("branches", branchService.getAllBranches());
        model.addAttribute("selectedBranchId", branchId);
        model.addAttribute("pageTitle", "Manager Schedule Overview");
        
        return "manager/schedule-overview";
    }
    
    /**
     * Technician schedules view
     */
    @GetMapping("/technicians")
    public String showTechnicianSchedules(Model model,
                                        @RequestParam(required = false) String date,
                                        @RequestParam(required = false) Integer branchId) {
        LocalDate viewDate = date != null ? LocalDate.parse(date) : LocalDate.now();
        
        List<ManagerScheduleDetailDTO> technicianSchedules = 
                managerScheduleService.getTechnicianSchedulesForDate(viewDate);
        
        if (branchId != null) {
            technicianSchedules = technicianSchedules.stream()
                    .filter(s -> s.getBranchId().equals(branchId))
                    .toList();
        }
        
        // Calculate statistics for the template
        int totalAppointments = technicianSchedules.stream()
                .mapToInt(s -> s.getTotalAppointments() != null ? s.getTotalAppointments() : 0)
                .sum();
        int completedAppointments = technicianSchedules.stream()
                .mapToInt(s -> s.getCompletedAppointments() != null ? s.getCompletedAppointments() : 0)
                .sum();
        long activeSchedules = technicianSchedules.stream()
                .filter(s -> s.getStatus() != null && "ACTIVE".equals(s.getStatus().name()))
                .count();

        model.addAttribute("schedules", technicianSchedules);
        model.addAttribute("totalAppointments", totalAppointments);
        model.addAttribute("completedAppointments", completedAppointments);
        model.addAttribute("activeSchedules", activeSchedules);
        model.addAttribute("viewDate", viewDate);
        model.addAttribute("branches", branchService.getAllBranches());
        model.addAttribute("selectedBranchId", branchId);
        model.addAttribute("pageTitle", "Technician Schedules");
        
        return "manager/technician-schedules";
    }
    
    /**
     * Receptionist schedules view
     */
    @GetMapping("/receptionists")
    public String showReceptionistSchedules(Model model,
                                          @RequestParam(required = false) String date,
                                          @RequestParam(required = false) Integer branchId) {
        LocalDate viewDate = date != null ? LocalDate.parse(date) : LocalDate.now();
        
        List<ManagerScheduleDetailDTO> receptionistSchedules = 
                managerScheduleService.getReceptionistSchedulesForDate(viewDate);
        
        if (branchId != null) {
            receptionistSchedules = receptionistSchedules.stream()
                    .filter(s -> s.getBranchId().equals(branchId))
                    .toList();
        }
        
        // Calculate statistics for the template
        int totalAppointmentsHandled = receptionistSchedules.stream()
                .mapToInt(s -> s.getTotalAppointments() != null ? s.getTotalAppointments() : 0)
                .sum();
        long activeSchedules = receptionistSchedules.stream()
                .filter(s -> s.getStatus() != null && "ACTIVE".equals(s.getStatus().name()))
                .count();
        long schedulesWithServiceData = receptionistSchedules.stream()
                .filter(s -> s.getServicesUsed() != null && !s.getServicesUsed().isEmpty())
                .count();

        model.addAttribute("schedules", receptionistSchedules);
        model.addAttribute("totalAppointmentsHandled", totalAppointmentsHandled);
        model.addAttribute("activeSchedules", activeSchedules);
        model.addAttribute("schedulesWithServiceData", schedulesWithServiceData);
        model.addAttribute("viewDate", viewDate);
        model.addAttribute("branches", branchService.getAllBranches());
        model.addAttribute("selectedBranchId", branchId);
        model.addAttribute("pageTitle", "Receptionist Schedules");
        
        return "manager/receptionist-schedules";
    }
    
    /**
     * Get detailed schedule information (AJAX endpoint)
     */
    @GetMapping("/detail/{scheduleId}")
    @ResponseBody
    public ResponseEntity<ManagerScheduleDetailDTO> getScheduleDetail(@PathVariable Integer scheduleId) {
        try {
            ManagerScheduleDetailDTO scheduleDetail = managerScheduleService
                    .getScheduleDetailForManager(scheduleId);
            return ResponseEntity.ok(scheduleDetail);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    /**
     * Branch schedule view
     */
    @GetMapping("/branch/{branchId}")
    public String showBranchSchedules(@PathVariable Integer branchId,
                                    Model model,
                                    @RequestParam(required = false) String startDate,
                                    @RequestParam(required = false) String endDate) {
        LocalDate start = startDate != null ? LocalDate.parse(startDate) : 
                LocalDate.now().with(java.time.DayOfWeek.MONDAY);
        LocalDate end = endDate != null ? LocalDate.parse(endDate) : start.plusDays(6);
        
        List<ManagerScheduleDetailDTO> branchSchedules = managerScheduleService
                .getSchedulesByBranchAndDateRange(branchId, start, end);
        
        // Get service statistics for this branch
        List<ServiceUsageDTO> branchPopularServices = serviceStatisticsService
                .getPopularServicesByBranchInDateRange(branchId, start, end);

        // Calculate statistics for the template
        long technicianCount = branchSchedules.stream()
                .filter(s -> "TECHNICIAN".equals(s.getUserRole()))
                .count();
        long receptionistCount = branchSchedules.stream()
                .filter(s -> "RECEPTIONIST".equals(s.getUserRole()))
                .count();
        int totalAppointments = branchSchedules.stream()
                .mapToInt(s -> s.getTotalAppointments() != null ? s.getTotalAppointments() : 0)
                .sum();
        int totalServicesProvided = branchPopularServices.stream()
                .mapToInt(ServiceUsageDTO::getUsageCount)
                .sum();

        // Get unique dates for grouping
        List<LocalDate> uniqueDates = branchSchedules.stream()
                .map(ManagerScheduleDetailDTO::getWorkDate)
                .distinct()
                .sorted()
                .collect(Collectors.toList());

        // Group schedules by date
        Map<LocalDate, List<ManagerScheduleDetailDTO>> schedulesByDate = branchSchedules.stream()
                .collect(Collectors.groupingBy(ManagerScheduleDetailDTO::getWorkDate));

        model.addAttribute("schedules", branchSchedules);
        model.addAttribute("schedulesByDate", schedulesByDate);
        model.addAttribute("branch", branchService.findById(branchId));
        model.addAttribute("popularServices", branchPopularServices);
        model.addAttribute("technicianCount", technicianCount);
        model.addAttribute("receptionistCount", receptionistCount);
        model.addAttribute("totalAppointments", totalAppointments);
        model.addAttribute("totalServicesProvided", totalServicesProvided);
        model.addAttribute("uniqueDates", uniqueDates);
        model.addAttribute("startDate", start);
        model.addAttribute("endDate", end);
        model.addAttribute("pageTitle", "Branch Schedule Details");
        
        return "manager/branch-schedule-details";
    }
    
    /**
     * Service statistics API endpoint
     */
    @GetMapping("/api/service-stats")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getServiceStatistics(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(required = false) Integer branchId) {
        
        Map<String, Object> serviceStats;
        
        if (branchId != null) {
            List<ServiceUsageDTO> branchServices = serviceStatisticsService
                    .getPopularServicesByBranchInDateRange(branchId, startDate, endDate);
            serviceStats = Map.of(
                    "popularServices", branchServices,
                    "totalServices", branchServices.stream().mapToInt(ServiceUsageDTO::getUsageCount).sum(),
                    "mostPopularService", branchServices.isEmpty() ? "No services" : branchServices.get(0).getServiceName()
            );
        } else {
            serviceStats = serviceStatisticsService.getServiceStatisticsSummary(startDate, endDate);
        }
        
        return ResponseEntity.ok(serviceStats);
    }
    
    /**
     * Schedule statistics API endpoint
     */
    @GetMapping("/api/schedule-stats")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getScheduleStatistics(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        
        Map<String, Object> scheduleStats = managerScheduleService
                .getScheduleStatistics(startDate, endDate);
        
        return ResponseEntity.ok(scheduleStats);
    }
    
    /**
     * Export schedule data
     */
    @GetMapping("/export")
    public ResponseEntity<String> exportScheduleData(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(required = false) Integer branchId,
            @RequestParam(defaultValue = "csv") String format) {
        
        List<ManagerScheduleDetailDTO> schedules;
        
        if (branchId != null) {
            schedules = managerScheduleService.getSchedulesByBranchAndDateRange(branchId, startDate, endDate);
        } else {
            // Get all schedules for the date range
            schedules = managerScheduleService.getTechnicianSchedulesForDate(startDate);
            // Note: This is simplified - in a real implementation, you'd get all dates in range
        }
        
        StringBuilder csv = new StringBuilder();
        csv.append("Date,Employee,Role,Branch,Shift,Start Time,End Time,Total Appointments,Completed Appointments,Most Popular Service\n");
        
        for (ManagerScheduleDetailDTO schedule : schedules) {
            csv.append(schedule.getWorkDate()).append(",")
               .append(schedule.getUserFullName()).append(",")
               .append(schedule.getUserRole()).append(",")
               .append(schedule.getBranchName()).append(",")
               .append(schedule.getShiftType()).append(",")
               .append(schedule.getStartTime()).append(",")
               .append(schedule.getEndTime()).append(",")
               .append(schedule.getTotalAppointments() != null ? schedule.getTotalAppointments() : 0).append(",")
               .append(schedule.getCompletedAppointments() != null ? schedule.getCompletedAppointments() : 0).append(",")
               .append(schedule.getMostPopularService() != null ? schedule.getMostPopularService() : "N/A").append("\n");
        }
        
        return ResponseEntity.ok()
                .header("Content-Type", "text/csv")
                .header("Content-Disposition", "attachment; filename=schedule_report_" + startDate + "_to_" + endDate + ".csv")
                .body(csv.toString());
    }
}
