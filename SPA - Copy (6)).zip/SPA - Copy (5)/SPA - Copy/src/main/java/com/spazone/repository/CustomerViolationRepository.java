package com.spazone.repository;

import com.spazone.entity.CustomerViolation;
import com.spazone.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface CustomerViolationRepository extends JpaRepository<CustomerViolation, Integer> {

    List<CustomerViolation> findByCustomer(User customer);

    List<CustomerViolation> findByCustomerAndViolationType(User customer, String violationType);

    @Query("SELECT COUNT(v) FROM CustomerViolation v WHERE v.customer = :customer AND v.violationType = :violationType AND v.violationDate >= :fromDate")
    long countByCustomerAndViolationTypeAndViolationDateAfter(@Param("customer") User customer, 
                                                              @Param("violationType") String violationType, 
                                                              @Param("fromDate") LocalDateTime fromDate);

    @Query("SELECT v FROM CustomerViolation v WHERE v.customer = :customer AND v.violationType = 'LATE_CANCELLATION' ORDER BY v.violationDate DESC")
    List<CustomerViolation> findLateCancellationsByCustomer(@Param("customer") User customer);

    List<CustomerViolation> findByResolvedFalse();

    List<CustomerViolation> findByCustomerAndResolvedFalse(User customer);
}
