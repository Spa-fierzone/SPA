package com.spazone.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "receptionist_kpi")
public class ReceptionistKPI {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "kpi_id")
    private Integer kpiId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "receptionist_id", nullable = false)
    private User receptionist;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "manager_id", nullable = false)
    private User manager;

    @Column(name = "month", nullable = false)
    private Integer month;

    @Column(name = "year", nullable = false)
    private Integer year;

    // Appointment Handling KPIs
    @Column(name = "target_appointments", nullable = false)
    private Integer targetAppointments;

    @Column(name = "actual_appointments")
    private Integer actualAppointments = 0;

    @Column(name = "target_checkins")
    private Integer targetCheckins;

    @Column(name = "actual_checkins")
    private Integer actualCheckins = 0;

    @Column(name = "target_checkouts")
    private Integer targetCheckouts;

    @Column(name = "actual_checkouts")
    private Integer actualCheckouts = 0;

    // Invoice and Revenue KPIs
    @Column(name = "target_invoices")
    private Integer targetInvoices;

    @Column(name = "actual_invoices")
    private Integer actualInvoices = 0;

    @Column(name = "target_revenue", precision = 12, scale = 2)
    private BigDecimal targetRevenue;

    @Column(name = "actual_revenue", precision = 12, scale = 2)
    private BigDecimal actualRevenue = BigDecimal.ZERO;

    // Performance Metrics
    @Column(name = "average_handling_time", precision = 8, scale = 2)
    private BigDecimal averageHandlingTime; // in minutes

    @Column(name = "customer_satisfaction_score", precision = 5, scale = 2)
    private BigDecimal customerSatisfactionScore;

    @Column(name = "error_rate", precision = 5, scale = 2)
    private BigDecimal errorRate;

    // System Fields
    @Column(name = "status", length = 20, columnDefinition = "NVARCHAR(255)")
    private String status = "active"; // active, inactive

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt = LocalDateTime.now();

    @Column(name = "notes", length = 1000, columnDefinition = "NVARCHAR(1000)")
    private String notes;

    // Constructors
    public ReceptionistKPI() {}

    public ReceptionistKPI(User receptionist, User manager, Integer month, Integer year, 
                          Integer targetAppointments, Integer targetInvoices, BigDecimal targetRevenue) {
        this.receptionist = receptionist;
        this.manager = manager;
        this.month = month;
        this.year = year;
        this.targetAppointments = targetAppointments;
        this.targetInvoices = targetInvoices;
        this.targetRevenue = targetRevenue;
    }

    // Lifecycle callbacks
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Integer getKpiId() {
        return kpiId;
    }

    public void setKpiId(Integer kpiId) {
        this.kpiId = kpiId;
    }

    public User getReceptionist() {
        return receptionist;
    }

    public void setReceptionist(User receptionist) {
        this.receptionist = receptionist;
    }

    public User getManager() {
        return manager;
    }

    public void setManager(User manager) {
        this.manager = manager;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getTargetAppointments() {
        return targetAppointments;
    }

    public void setTargetAppointments(Integer targetAppointments) {
        this.targetAppointments = targetAppointments;
    }

    public Integer getActualAppointments() {
        return actualAppointments;
    }

    public void setActualAppointments(Integer actualAppointments) {
        this.actualAppointments = actualAppointments;
    }

    public Integer getTargetCheckins() {
        return targetCheckins;
    }

    public void setTargetCheckins(Integer targetCheckins) {
        this.targetCheckins = targetCheckins;
    }

    public Integer getActualCheckins() {
        return actualCheckins;
    }

    public void setActualCheckins(Integer actualCheckins) {
        this.actualCheckins = actualCheckins;
    }

    public Integer getTargetCheckouts() {
        return targetCheckouts;
    }

    public void setTargetCheckouts(Integer targetCheckouts) {
        this.targetCheckouts = targetCheckouts;
    }

    public Integer getActualCheckouts() {
        return actualCheckouts;
    }

    public void setActualCheckouts(Integer actualCheckouts) {
        this.actualCheckouts = actualCheckouts;
    }

    public Integer getTargetInvoices() {
        return targetInvoices;
    }

    public void setTargetInvoices(Integer targetInvoices) {
        this.targetInvoices = targetInvoices;
    }

    public Integer getActualInvoices() {
        return actualInvoices;
    }

    public void setActualInvoices(Integer actualInvoices) {
        this.actualInvoices = actualInvoices;
    }

    public BigDecimal getTargetRevenue() {
        return targetRevenue;
    }

    public void setTargetRevenue(BigDecimal targetRevenue) {
        this.targetRevenue = targetRevenue;
    }

    public BigDecimal getActualRevenue() {
        return actualRevenue;
    }

    public void setActualRevenue(BigDecimal actualRevenue) {
        this.actualRevenue = actualRevenue;
    }

    public BigDecimal getAverageHandlingTime() {
        return averageHandlingTime;
    }

    public void setAverageHandlingTime(BigDecimal averageHandlingTime) {
        this.averageHandlingTime = averageHandlingTime;
    }

    public BigDecimal getCustomerSatisfactionScore() {
        return customerSatisfactionScore;
    }

    public void setCustomerSatisfactionScore(BigDecimal customerSatisfactionScore) {
        this.customerSatisfactionScore = customerSatisfactionScore;
    }

    public BigDecimal getErrorRate() {
        return errorRate;
    }

    public void setErrorRate(BigDecimal errorRate) {
        this.errorRate = errorRate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    // Helper methods for KPI calculations
    public Double getAppointmentCompletionPercentage() {
        if (targetAppointments == null || targetAppointments == 0) {
            return 0.0;
        }
        return (actualAppointments != null ? actualAppointments : 0) * 100.0 / targetAppointments;
    }

    public Double getInvoiceCompletionPercentage() {
        if (targetInvoices == null || targetInvoices == 0) {
            return 0.0;
        }
        return (actualInvoices != null ? actualInvoices : 0) * 100.0 / targetInvoices;
    }

    public Double getRevenueCompletionPercentage() {
        if (targetRevenue == null || targetRevenue.compareTo(BigDecimal.ZERO) == 0) {
            return 0.0;
        }
        BigDecimal actual = actualRevenue != null ? actualRevenue : BigDecimal.ZERO;
        return actual.multiply(BigDecimal.valueOf(100)).divide(targetRevenue, 2, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    public boolean isAppointmentTargetAchieved() {
        return actualAppointments != null && actualAppointments >= targetAppointments;
    }

    public boolean isInvoiceTargetAchieved() {
        return actualInvoices != null && targetInvoices != null && actualInvoices >= targetInvoices;
    }

    public boolean isRevenueTargetAchieved() {
        return actualRevenue != null && targetRevenue != null && 
               actualRevenue.compareTo(targetRevenue) >= 0;
    }

    public Double getOverallPerformanceScore() {
        double appointmentScore = getAppointmentCompletionPercentage();
        double invoiceScore = getInvoiceCompletionPercentage();
        double revenueScore = getRevenueCompletionPercentage();
        
        // Weighted average: 40% appointments, 30% invoices, 30% revenue
        return (appointmentScore * 0.4) + (invoiceScore * 0.3) + (revenueScore * 0.3);
    }
}
