package com.spazone.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.spazone.entity.AuditLog;
import com.spazone.repository.AuditLogRepository;
import com.spazone.service.AuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AuditServiceImpl implements AuditService {

    @Autowired
    private AuditLogRepository auditLogRepository;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void logAction(String entityType, Integer entityId, String action, Integer performedBy, String performedByRole) {
        logAction(entityType, entityId, action, performedBy, performedByRole, null);
    }

    @Override
    public void logAction(String entityType, Integer entityId, String action, Integer performedBy, String performedByRole, String reason) {
        logAction(entityType, entityId, action, performedBy, performedByRole, null, null, reason);
    }

    @Override
    public void logAction(String entityType, Integer entityId, String action, Integer performedBy, String performedByRole, 
                         String oldValues, String newValues, String reason) {
        try {
            AuditLog auditLog = new AuditLog(entityType, entityId, action, performedBy, performedByRole, reason);
            auditLog.setOldValues(oldValues);
            auditLog.setNewValues(newValues);
            auditLogRepository.save(auditLog);
        } catch (Exception e) {
            // Log error but don't fail the main operation
            System.err.println("Failed to create audit log: " + e.getMessage());
        }
    }

    @Override
    public void logPaymentAction(Integer invoiceId, String action, Integer performedBy, String reason) {
        logAction("INVOICE", invoiceId, action, performedBy, "SYSTEM", reason);
    }

    @Override
    public void logAppointmentAction(Integer appointmentId, String action, Integer performedBy, String reason) {
        logAction("APPOINTMENT", appointmentId, action, performedBy, "CUSTOMER", reason);
    }

    @Override
    public void logCancellationAction(Integer appointmentId, Integer performedBy, String cancellationType, String reason) {
        String action = "CANCEL_" + cancellationType.toUpperCase();
        logAction("APPOINTMENT", appointmentId, action, performedBy, "CUSTOMER", reason);
    }

    @Override
    public void logRefundAction(Integer invoiceId, Integer performedBy, String reason) {
        logAction("INVOICE", invoiceId, "REFUND", performedBy, "SYSTEM", reason);
    }

    @Override
    public List<AuditLog> getEntityAuditHistory(String entityType, Integer entityId) {
        return auditLogRepository.findByEntityTypeAndEntityIdOrderByCreatedAtDesc(entityType, entityId);
    }

    @Override
    public List<AuditLog> getUserActions(Integer userId, LocalDateTime startDate, LocalDateTime endDate) {
        return auditLogRepository.findByPerformedByAndCreatedAtBetween(userId, startDate, endDate);
    }

    @Override
    public List<AuditLog> getActionsByType(String action) {
        return auditLogRepository.findByAction(action);
    }

    @Override
    public List<AuditLog> getAuditLogsByDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        return auditLogRepository.findByCreatedAtBetween(startDate, endDate);
    }
}
