package com.spazone.controller.admin;

import com.spazone.entity.Branch;
import com.spazone.entity.User;
import com.spazone.exception.BranchValidationException;
import com.spazone.exception.DuplicateResourceException;
import com.spazone.exception.ResourceNotFoundException;
import com.spazone.repository.UserRepository;
import com.spazone.service.BranchService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/admin/branches")
public class BranchAdminController {

    private static final Logger logger = LoggerFactory.getLogger(BranchAdminController.class);

    @Autowired
    private BranchService branchService;

    @Autowired
    private UserRepository userRepository;

    @GetMapping
    public String listBranches(Model model,
                               @RequestParam(defaultValue = "0") int page,
                               @RequestParam(defaultValue = "5") int size,
                               @RequestParam(required = false) String keyword,
                               @RequestParam(required = false) Integer managerId) {

        Pageable pageable = PageRequest.of(page, size);
        Page<Branch> branches = branchService.searchBranches(keyword, managerId, pageable);

        List<User> managers = userRepository.findUsersByRole("MANAGER");

        Map<Integer, String> managerNameMap = managers.stream()
                .collect(Collectors.toMap(User::getUserId, User::getFullName));

        model.addAttribute("branches", branches.getContent());
        model.addAttribute("totalPages", branches.getTotalPages());
        model.addAttribute("currentPage", page);
        model.addAttribute("keyword", keyword);
        model.addAttribute("managerId", managerId);
        model.addAttribute("managers", managers);
        model.addAttribute("managerNameMap", managerNameMap); // thêm vào model

        return "admin/branches/list";
    }


    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("branch", new Branch());
        model.addAttribute("managers", userRepository.findUsersByRole("MANAGER"));
        return "admin/branches/form";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Integer id, Model model) {
        Branch branch = branchService.getById(id);
        if (branch == null) return "redirect:/admin/branches";
        model.addAttribute("branch", branch);
        model.addAttribute("managers", userRepository.findUsersByRole("MANAGER"));
        return "admin/branches/form";
    }

    @PostMapping("/save")
    public String saveBranch(@ModelAttribute Branch branch,
                           @RequestParam Integer managerId,
                           Model model,
                           RedirectAttributes redirectAttributes) {
        try {
            logger.info("Attempting to save branch: {}", branch.getName());

            branch.setManagerId(managerId);
            Branch savedBranch = branchService.save(branch);

            // Success message
            String successMessage = branch.getBranchId() == null ?
                "Tạo chi nhánh '" + savedBranch.getName() + "' thành công!" :
                "Cập nhật chi nhánh '" + savedBranch.getName() + "' thành công!";

            redirectAttributes.addFlashAttribute("successMessage", successMessage);
            logger.info("Successfully saved branch with ID: {}", savedBranch.getBranchId());

            return "redirect:/admin/branches";

        } catch (BranchValidationException e) {
            logger.warn("Branch validation failed: {}", e.getMessage());
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("branch", branch);
            model.addAttribute("managers", userRepository.findUsersByRole("MANAGER"));
            return "admin/branches/form";

        } catch (DuplicateResourceException e) {
            logger.warn("Duplicate resource error: {}", e.getMessage());
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("branch", branch);
            model.addAttribute("managers", userRepository.findUsersByRole("MANAGER"));
            return "admin/branches/form";

        } catch (ResourceNotFoundException e) {
            logger.error("Resource not found: {}", e.getMessage());
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/admin/branches";

        } catch (Exception e) {
            logger.error("Unexpected error while saving branch: {}", e.getMessage(), e);
            model.addAttribute("errorMessage", "Đã xảy ra lỗi hệ thống. Vui lòng thử lại sau.");
            model.addAttribute("branch", branch);
            model.addAttribute("managers", userRepository.findUsersByRole("MANAGER"));
            return "admin/branches/form";
        }
    }

    @PostMapping("/change-status/{id}")
    public String changeStatus(@PathVariable Integer id) {
        branchService.toggleStatus(id);
        return "redirect:/admin/branches";
    }

    @GetMapping("/delete/{id}")
    public String deleteRedirect(@PathVariable Integer id) {
        // Redirect delete requests to toggle status for safety
        branchService.toggleStatus(id);
        return "redirect:/admin/branches";
    }
}
