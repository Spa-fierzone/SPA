package com.spazone.service;

import com.spazone.entity.Appointment;
import com.spazone.entity.Service;
import com.spazone.entity.TreatmentRecord;
import com.spazone.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface TreatmentRecordService {
    TreatmentRecord save(TreatmentRecord record);

    TreatmentRecord findById(Integer id);

    List<TreatmentRecord> findByTechnician(User technician);

    TreatmentRecord findByAppointmentId(Integer appointmentId);

    // Enhanced technician dashboard methods
    List<TreatmentRecord> getRecentTreatmentsByTechnician(Integer technicianId, int limit);

    Page<TreatmentRecord> getTreatmentHistoryByCustomer(Integer customerId, Pageable pageable);

    // Enhanced treatment record system methods
    Page<TreatmentRecord> searchTreatmentHistory(Integer technicianId, String search, String customerName,
                                               String startDate, String endDate, Pageable pageable);

    List<TreatmentRecord> getTreatmentRecordsForExport(Integer technicianId, String startDate, String endDate);

    // Service-specific treatment record methods
    List<TreatmentRecord> findByAppointmentAndService(Appointment appointment, Service service);

    List<TreatmentRecord> findByAppointmentAppointmentId(Integer appointmentId);

    TreatmentRecord createServiceSpecificRecord(Integer appointmentId, Integer serviceId, Integer technicianId);
}
