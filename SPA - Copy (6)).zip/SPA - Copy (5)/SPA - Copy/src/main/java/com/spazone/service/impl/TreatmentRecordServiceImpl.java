package com.spazone.service.impl;

import com.spazone.entity.Appointment;
import com.spazone.entity.TreatmentRecord;
import com.spazone.entity.User;
import com.spazone.repository.AppointmentRepository;
import com.spazone.repository.ServiceRepository;
import com.spazone.repository.TreatmentRecordRepository;
import com.spazone.repository.UserRepository;
import com.spazone.service.TreatmentRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class TreatmentRecordServiceImpl implements TreatmentRecordService {

    @Autowired
    private TreatmentRecordRepository treatmentRecordRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private ServiceRepository serviceRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public TreatmentRecord save(TreatmentRecord record) {
        return treatmentRecordRepository.save(record);
    }

    @Override
    public TreatmentRecord findById(Integer id) {
        return treatmentRecordRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy treatment record ID: " + id));
    }

    @Override
    public List<TreatmentRecord> findByTechnician(User technician) {
        return treatmentRecordRepository.findByTechnician(technician);
    }

    @Override
    public TreatmentRecord findByAppointmentId(Integer appointmentId) {
        return treatmentRecordRepository.findByAppointment_AppointmentId(appointmentId);
    }

    @Override
    public List<TreatmentRecord> getRecentTreatmentsByTechnician(Integer technicianId, int limit) {
        Pageable pageable = PageRequest.of(0, limit);
        return treatmentRecordRepository.findByTechnicianUserIdOrderByTreatmentDateDesc(technicianId, pageable);
    }

    @Override
    public Page<TreatmentRecord> getTreatmentHistoryByCustomer(Integer customerId, Pageable pageable) {
        return treatmentRecordRepository.findByAppointmentCustomerUserIdOrderByTreatmentDateDesc(customerId, pageable);
    }

    @Override
    public Page<TreatmentRecord> searchTreatmentHistory(Integer technicianId, String search, String customerName,
                                                      String startDate, String endDate, Pageable pageable) {
        LocalDateTime startDateTime = null;
        LocalDateTime endDateTime = null;

        if (startDate != null && !startDate.isEmpty()) {
            startDateTime = LocalDate.parse(startDate).atStartOfDay();
        }

        if (endDate != null && !endDate.isEmpty()) {
            endDateTime = LocalDate.parse(endDate).atTime(23, 59, 59);
        }

        return treatmentRecordRepository.searchTreatmentHistory(
                technicianId, search, customerName, startDateTime, endDateTime, pageable);
    }

    @Override
    public List<TreatmentRecord> getTreatmentRecordsForExport(Integer technicianId, String startDate, String endDate) {
        LocalDateTime startDateTime = null;
        LocalDateTime endDateTime = null;

        if (startDate != null && !startDate.isEmpty()) {
            startDateTime = LocalDate.parse(startDate).atStartOfDay();
        }

        if (endDate != null && !endDate.isEmpty()) {
            endDateTime = LocalDate.parse(endDate).atTime(23, 59, 59);
        }

        return treatmentRecordRepository.findTreatmentRecordsForExport(
                technicianId, startDateTime, endDateTime);
    }

    @Override
    public List<TreatmentRecord> findByAppointmentAndService(Appointment appointment, com.spazone.entity.Service service) {
        return treatmentRecordRepository.findByAppointmentAndService(appointment, service);
    }

    @Override
    public List<TreatmentRecord> findByAppointmentAppointmentId(Integer appointmentId) {
        return treatmentRecordRepository.findByAppointmentAppointmentId(appointmentId);
    }

    @Override
    public TreatmentRecord createServiceSpecificRecord(Integer appointmentId, Integer serviceId, Integer technicianId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found with id: " + appointmentId));

        com.spazone.entity.Service service = serviceRepository.findById(serviceId)
                .orElseThrow(() -> new RuntimeException("Service not found with id: " + serviceId));

        User technician = userRepository.findById(technicianId)
                .orElseThrow(() -> new RuntimeException("Technician not found with id: " + technicianId));

        TreatmentRecord record = new TreatmentRecord();
        record.setAppointment(appointment);
        record.setService(service);
        record.setTechnician(technician);
        record.setTreatmentDate(LocalDateTime.now());

        return treatmentRecordRepository.save(record);
    }
}
