package com.spazone.service;

import com.spazone.entity.ChatMessage;
import com.spazone.entity.ChatParticipant;
import com.spazone.entity.ChatRoom;
import com.spazone.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Service interface for chat functionality
 * Provides business logic for chat rooms, messages, and participants
 * Integrates with existing user management and notification systems
 */
public interface ChatService {

    // ===== CHAT ROOM MANAGEMENT =====

    /**
     * Create a new chat room
     */
    ChatRoom createChatRoom(String roomName, String roomType, User creator, Integer branchId, String description);

    /**
     * Get or create direct message room between two users
     */
    ChatRoom getOrCreateDirectMessageRoom(User user1, User user2);

    /**
     * Get chat room by ID with access validation
     */
    Optional<ChatRoom> getChatRoom(Integer roomId, User requestingUser);

    /**
     * Get all accessible chat rooms for a user
     */
    List<ChatRoom> getAccessibleChatRooms(User user);

    /**
     * Get chat rooms with unread messages for a user
     */
    List<ChatRoom> getChatRoomsWithUnreadMessages(User user);

    /**
     * Search chat rooms by name
     */
    List<ChatRoom> searchChatRooms(String searchTerm, User user);

    /**
     * Update chat room information
     */
    ChatRoom updateChatRoom(Integer roomId, String roomName, String description, User requestingUser);

    /**
     * Deactivate chat room
     */
    boolean deactivateChatRoom(Integer roomId, User requestingUser);

    // ===== PARTICIPANT MANAGEMENT =====

    /**
     * Add participant to chat room
     */
    ChatParticipant addParticipant(Integer roomId, Integer userId, String role, User requestingUser);

    /**
     * Remove participant from chat room
     */
    boolean removeParticipant(Integer roomId, Integer userId, User requestingUser);

    /**
     * Update participant role
     */
    boolean updateParticipantRole(Integer roomId, Integer userId, String newRole, User requestingUser);

    /**
     * Get participants in a chat room
     */
    List<ChatParticipant> getChatRoomParticipants(Integer roomId, User requestingUser);

    /**
     * Check if user can access chat room
     */
    boolean canUserAccessRoom(User user, Integer roomId);

    /**
     * Check if user can moderate chat room
     */
    boolean canUserModerateRoom(User user, Integer roomId);

    // ===== MESSAGE MANAGEMENT =====

    /**
     * Send a text message
     */
    ChatMessage sendMessage(Integer roomId, String content, User sender);

    /**
     * Send a file message
     */
    ChatMessage sendFileMessage(Integer roomId, String content, String fileUrl, String fileName, Long fileSize, User sender);

    /**
     * Reply to a message
     */
    ChatMessage replyToMessage(Integer roomId, String content, Integer replyToMessageId, User sender);

    /**
     * Edit a message
     */
    ChatMessage editMessage(Integer messageId, String newContent, User editor);

    /**
     * Delete a message
     */
    boolean deleteMessage(Integer messageId, User requestingUser);

    /**
     * Get messages in a chat room with pagination
     */
    Page<ChatMessage> getChatMessages(Integer roomId, User requestingUser, Pageable pageable);

    /**
     * Get recent messages in a chat room
     */
    List<ChatMessage> getRecentMessages(Integer roomId, User requestingUser, int limit);

    /**
     * Search messages in a chat room
     */
    Page<ChatMessage> searchMessages(Integer roomId, String searchTerm, User requestingUser, Pageable pageable);

    /**
     * Get unread messages for user in room
     */
    List<ChatMessage> getUnreadMessages(Integer roomId, User user);

    /**
     * Get unread message count for user in room
     */
    Long getUnreadMessageCount(Integer roomId, User user);

    /**
     * Mark messages as read
     */
    void markMessagesAsRead(Integer roomId, User user);

    // ===== NOTIFICATION INTEGRATION =====

    /**
     * Send chat notification to offline users
     */
    void sendChatNotification(ChatMessage message);

    /**
     * Send room invitation notification
     */
    void sendRoomInvitationNotification(ChatRoom room, User invitedUser, User invitedBy);

    // ===== UTILITY METHODS =====

    /**
     * Validate message content
     */
    String validateAndSanitizeMessage(String content);

    /**
     * Check if user can send messages to room
     */
    boolean canUserSendMessage(User user, Integer roomId);

    /**
     * Get chat statistics for a room
     */
    Object getChatRoomStatistics(Integer roomId, User requestingUser);

    /**
     * Export chat history
     */
    List<ChatMessage> exportChatHistory(Integer roomId, User requestingUser, LocalDateTime startDate, LocalDateTime endDate);

    // ===== BRANCH-SPECIFIC OPERATIONS =====

    /**
     * Create branch-specific chat room
     */
    ChatRoom createBranchChatRoom(Integer branchId, User creator);

    /**
     * Add all branch staff to branch room
     */
    void addBranchStaffToRoom(Integer roomId, Integer branchId);

    /**
     * Get branch chat rooms
     */
    List<ChatRoom> getBranchChatRooms(Integer branchId, User requestingUser);
}
