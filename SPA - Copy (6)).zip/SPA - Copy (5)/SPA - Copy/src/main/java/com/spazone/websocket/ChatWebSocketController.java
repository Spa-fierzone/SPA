package com.spazone.websocket;

import com.spazone.entity.ChatMessage;
import com.spazone.entity.ChatRoom;
import com.spazone.entity.User;
import com.spazone.service.ChatService;
import com.spazone.service.UserService;
import com.spazone.websocket.dto.ChatMessageDTO;
import com.spazone.websocket.dto.TypingIndicatorDTO;
import com.spazone.websocket.dto.UserStatusDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.annotation.SubscribeMapping;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.context.event.EventListener;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * WebSocket controller for handling real-time chat messages
 * Manages message sending, typing indicators, and user presence
 * Integrates with existing Spring Security authentication
 */
@Controller
public class ChatWebSocketController {

    private static final Logger logger = LoggerFactory.getLogger(ChatWebSocketController.class);

    @Autowired
    private ChatService chatService;

    @Autowired
    private UserService userService;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    @Autowired
    private ChatRateLimiter rateLimiter;

    // Track online users and their sessions
    private final Map<String, String> userSessions = new ConcurrentHashMap<>(); // userId -> sessionId
    private final Map<String, String> sessionUsers = new ConcurrentHashMap<>(); // sessionId -> userId
    private final Map<String, LocalDateTime> userLastSeen = new ConcurrentHashMap<>(); // userId -> lastSeen

    /**
     * Handle incoming chat messages
     */
    @MessageMapping("/chat/send")
    public void sendMessage(@Payload ChatMessageDTO messageDTO, Principal principal, SimpMessageHeaderAccessor headerAccessor) {
        try {
            logger.debug("Received message from user: {} for room: {}", principal.getName(), messageDTO.getRoomId());

            // Get authenticated user
            User sender = getUserFromPrincipal(principal);
            if (sender == null) {
                logger.error("Could not find user for principal: {}", principal.getName());
                return;
            }

            // Check rate limiting
            if (!rateLimiter.allowMessage(sender.getUserId().toString())) {
                logger.warn("Rate limit exceeded for user: {}", sender.getUsername());
                messagingTemplate.convertAndSendToUser(
                    principal.getName(),
                    "/queue/errors",
                    Map.of("error", "Bạn đang gửi tin nhắn quá nhanh. Vui lòng chờ một chút.")
                );
                return;
            }

            // Validate room access
            if (!chatService.canUserSendMessage(sender, messageDTO.getRoomId())) {
                logger.warn("User {} attempted to send message to room {} without permission", 
                           sender.getUsername(), messageDTO.getRoomId());
                return;
            }

            // Send message through service
            ChatMessage savedMessage;
            if (messageDTO.getReplyToMessageId() != null) {
                savedMessage = chatService.replyToMessage(
                    messageDTO.getRoomId(), 
                    messageDTO.getContent(), 
                    messageDTO.getReplyToMessageId(), 
                    sender
                );
            } else {
                savedMessage = chatService.sendMessage(
                    messageDTO.getRoomId(), 
                    messageDTO.getContent(), 
                    sender
                );
            }

            // Create response DTO
            ChatMessageDTO responseDTO = createMessageDTO(savedMessage);

            // Broadcast message to room subscribers
            messagingTemplate.convertAndSend(
                "/topic/chat/" + messageDTO.getRoomId(), 
                responseDTO
            );

            // Update user's last seen
            updateUserLastSeen(sender.getUserId().toString());

            logger.debug("Message sent successfully: {}", savedMessage.getMessageId());

        } catch (Exception e) {
            logger.error("Error sending message: {}", e.getMessage(), e);
            
            // Send error message back to sender
            messagingTemplate.convertAndSendToUser(
                principal.getName(),
                "/queue/errors",
                Map.of("error", "Không thể gửi tin nhắn: " + e.getMessage())
            );
        }
    }

    /**
     * Handle file message sending
     */
    @MessageMapping("/chat/send-file")
    public void sendFileMessage(@Payload ChatMessageDTO messageDTO, Principal principal) {
        try {
            logger.debug("Received file message from user: {} for room: {}", principal.getName(), messageDTO.getRoomId());

            User sender = getUserFromPrincipal(principal);
            if (sender == null) {
                logger.error("Could not find user for principal: {}", principal.getName());
                return;
            }

            if (!chatService.canUserSendMessage(sender, messageDTO.getRoomId())) {
                logger.warn("User {} attempted to send file to room {} without permission", 
                           sender.getUsername(), messageDTO.getRoomId());
                return;
            }

            // Send file message through service
            ChatMessage savedMessage = chatService.sendFileMessage(
                messageDTO.getRoomId(),
                messageDTO.getContent(),
                messageDTO.getFileUrl(),
                messageDTO.getFileName(),
                messageDTO.getFileSize(),
                sender
            );

            // Create response DTO
            ChatMessageDTO responseDTO = createMessageDTO(savedMessage);

            // Broadcast to room
            messagingTemplate.convertAndSend(
                "/topic/chat/" + messageDTO.getRoomId(), 
                responseDTO
            );

            updateUserLastSeen(sender.getUserId().toString());

            logger.info("File message sent successfully: {} - {}", savedMessage.getMessageId(), messageDTO.getFileName());

        } catch (Exception e) {
            logger.error("Error sending file message: {}", e.getMessage(), e);
            
            messagingTemplate.convertAndSendToUser(
                principal.getName(),
                "/queue/errors",
                Map.of("error", "Không thể gửi file: " + e.getMessage())
            );
        }
    }

    /**
     * Handle typing indicators
     */
    @MessageMapping("/chat/typing")
    public void handleTyping(@Payload TypingIndicatorDTO typingDTO, Principal principal) {
        try {
            User user = getUserFromPrincipal(principal);
            if (user == null) return;

            // Check rate limiting for typing indicators
            if (!rateLimiter.allowTyping(user.getUserId().toString())) {
                return; // Silently ignore excessive typing indicators
            }

            if (!chatService.canUserAccessRoom(user, typingDTO.getRoomId())) {
                return;
            }

            // Create typing indicator response
            TypingIndicatorDTO responseDTO = new TypingIndicatorDTO();
            responseDTO.setRoomId(typingDTO.getRoomId());
            responseDTO.setUserId(user.getUserId());
            responseDTO.setUserName(user.getFullName());
            responseDTO.setTyping(typingDTO.isTyping());
            responseDTO.setTimestamp(LocalDateTime.now());

            // Broadcast typing indicator to room (except sender)
            messagingTemplate.convertAndSend(
                "/topic/chat/" + typingDTO.getRoomId() + "/typing", 
                responseDTO
            );

            updateUserLastSeen(user.getUserId().toString());

        } catch (Exception e) {
            logger.error("Error handling typing indicator: {}", e.getMessage());
        }
    }

    /**
     * Handle user status updates
     */
    @MessageMapping("/chat/status")
    public void updateUserStatus(@Payload UserStatusDTO statusDTO, Principal principal) {
        try {
            User user = getUserFromPrincipal(principal);
            if (user == null) return;

            // Update user's online status
            updateUserLastSeen(user.getUserId().toString());

            // Broadcast status update to relevant rooms
            broadcastUserStatusUpdate(user, statusDTO.getStatus());

        } catch (Exception e) {
            logger.error("Error updating user status: {}", e.getMessage());
        }
    }

    /**
     * Handle room subscription
     */
    @SubscribeMapping("/topic/chat/{roomId}")
    public void subscribeToRoom(@DestinationVariable Integer roomId, Principal principal, SimpMessageHeaderAccessor headerAccessor) {
        try {
            User user = getUserFromPrincipal(principal);
            if (user == null) return;

            if (!chatService.canUserAccessRoom(user, roomId)) {
                logger.warn("User {} attempted to subscribe to room {} without permission", 
                           user.getUsername(), roomId);
                return;
            }

            // Track user session
            String sessionId = headerAccessor.getSessionId();
            userSessions.put(user.getUserId().toString(), sessionId);
            sessionUsers.put(sessionId, user.getUserId().toString());
            updateUserLastSeen(user.getUserId().toString());

            // Mark messages as read when user joins room
            chatService.markMessagesAsRead(roomId, user);

            // Notify other users that this user is online
            broadcastUserOnlineStatus(user, true);

            logger.debug("User {} subscribed to room {}", user.getUsername(), roomId);

        } catch (Exception e) {
            logger.error("Error subscribing to room: {}", e.getMessage());
        }
    }

    /**
     * Handle WebSocket disconnect event
     */
    @EventListener
    public void handleWebSocketDisconnectListener(SessionDisconnectEvent event) {
        String sessionId = event.getSessionId();
        handleUserDisconnect(sessionId);
    }

    /**
     * Handle user disconnect
     */
    public void handleUserDisconnect(String sessionId) {
        try {
            String userId = sessionUsers.remove(sessionId);
            if (userId != null) {
                userSessions.remove(userId);
                
                User user = userService.findById(Integer.valueOf(userId));
                if (user != null) {
                    // Broadcast user offline status
                    broadcastUserOnlineStatus(user, false);
                    
                    logger.debug("User {} disconnected", user.getUsername());
                }
            }
        } catch (Exception e) {
            logger.error("Error handling user disconnect: {}", e.getMessage());
        }
    }

    // ===== HELPER METHODS =====

    private User getUserFromPrincipal(Principal principal) {
        if (principal instanceof Authentication) {
            Authentication auth = (Authentication) principal;
            String username = auth.getName();
            return userService.findByUsername(username);
        }
        return null;
    }

    private ChatMessageDTO createMessageDTO(ChatMessage message) {
        ChatMessageDTO dto = new ChatMessageDTO();
        dto.setMessageId(message.getMessageId());
        dto.setRoomId(message.getChatRoom().getRoomId());
        dto.setContent(message.getDisplayContent());
        dto.setMessageType(message.getMessageType());
        dto.setSenderId(message.getSender().getUserId());
        dto.setSenderName(message.getSender().getFullName());
        dto.setSenderAvatar(message.getSender().getProfilePicture());
        dto.setSentAt(message.getSentAt());
        dto.setEdited(message.isEdited());
        dto.setEditedAt(message.getEditedAt());
        
        if (message.getReplyToMessage() != null) {
            dto.setReplyToMessageId(message.getReplyToMessage().getMessageId());
            dto.setReplyToContent(message.getReplyToMessage().getDisplayContent());
            dto.setReplyToSenderName(message.getReplyToMessage().getSender().getFullName());
        }
        
        if (message.hasFile()) {
            dto.setFileUrl(message.getFileUrl());
            dto.setFileName(message.getFileName());
            dto.setFileSize(message.getFileSize());
            dto.setFileSizeFormatted(message.getFileSizeFormatted());
        }
        
        return dto;
    }

    private void updateUserLastSeen(String userId) {
        userLastSeen.put(userId, LocalDateTime.now());
    }

    private void broadcastUserOnlineStatus(User user, boolean isOnline) {
        UserStatusDTO statusDTO = new UserStatusDTO();
        statusDTO.setUserId(user.getUserId());
        statusDTO.setUserName(user.getFullName());
        statusDTO.setStatus(isOnline ? "online" : "offline");
        statusDTO.setLastSeen(userLastSeen.get(user.getUserId().toString()));

        // Broadcast to all accessible rooms for this user
        try {
            chatService.getAccessibleChatRooms(user).forEach(room -> {
                messagingTemplate.convertAndSend(
                    "/topic/chat/" + room.getRoomId() + "/status", 
                    statusDTO
                );
            });
        } catch (Exception e) {
            logger.error("Error broadcasting user status: {}", e.getMessage());
        }
    }

    private void broadcastUserStatusUpdate(User user, String status) {
        UserStatusDTO statusDTO = new UserStatusDTO();
        statusDTO.setUserId(user.getUserId());
        statusDTO.setUserName(user.getFullName());
        statusDTO.setStatus(status);
        statusDTO.setLastSeen(LocalDateTime.now());

        // Broadcast to user's accessible rooms
        try {
            chatService.getAccessibleChatRooms(user).forEach(room -> {
                messagingTemplate.convertAndSend(
                    "/topic/chat/" + room.getRoomId() + "/status", 
                    statusDTO
                );
            });
        } catch (Exception e) {
            logger.error("Error broadcasting status update: {}", e.getMessage());
        }
    }

    // ===== PUBLIC METHODS FOR SESSION MANAGEMENT =====

    public boolean isUserOnline(String userId) {
        return userSessions.containsKey(userId);
    }

    public LocalDateTime getUserLastSeen(String userId) {
        return userLastSeen.get(userId);
    }

    public int getOnlineUserCount() {
        return userSessions.size();
    }
}
