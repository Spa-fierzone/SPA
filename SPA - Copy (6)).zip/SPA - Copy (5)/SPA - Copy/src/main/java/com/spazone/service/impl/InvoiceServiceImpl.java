package com.spazone.service.impl;

import com.spazone.entity.Appointment;
import com.spazone.entity.Branch;
import com.spazone.entity.Invoice;
import com.spazone.entity.User;
import com.spazone.repository.InvoiceRepository;
import com.spazone.repository.ServiceRepository;
import com.spazone.service.EmailService;
import com.spazone.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class InvoiceServiceImpl implements InvoiceService {

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private ServiceRepository serviceRepository;

    @Autowired
    private EmailService emailService;

    @Override
    public Invoice generateInvoiceForAppointment(Appointment appointment) {
        // Calculate total price from all services (supports both legacy and new structure)
        BigDecimal totalPrice = appointment.getTotalPrice();

        if (totalPrice.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Tổng giá trị dịch vụ phải lớn hơn 0.");
        }

        BigDecimal discount = BigDecimal.ZERO;
        BigDecimal tax = totalPrice.multiply(new BigDecimal("0.10"));
        BigDecimal finalAmount = totalPrice.add(tax).subtract(discount);

        Invoice invoice = new Invoice();
        invoice.setAppointment(appointment);
        invoice.setCustomer(appointment.getCustomer());
        invoice.setBranch(appointment.getBranch());
        invoice.setTotalAmount(totalPrice);
        invoice.setDiscountAmount(discount);
        invoice.setTaxAmount(tax);
        invoice.setFinalAmount(finalAmount);
        invoice.setPaymentStatus("unpaid");
        invoice.setInvoiceNumber("INV-" + System.currentTimeMillis());

        return invoiceRepository.save(invoice);
    }


    @Override
    public Invoice getById(Integer id) {
        return invoiceRepository.findById(id).orElse(null);
    }

    @Override
    public void save(Invoice invoice) {
        invoiceRepository.save(invoice);
    }

    @Override
    public List<Invoice> getByCustomer(User customer) {
        return invoiceRepository.findByCustomer(customer);
    }

    @Override
    public Invoice createInvoiceForAppointment(Appointment appointment, String paymentMethod, String notes) {
        // Use total price from all services (supports both legacy and new structure)
        BigDecimal totalPrice = appointment.getTotalPrice();

        Invoice invoice = new Invoice();
        invoice.setAppointment(appointment);
        invoice.setCustomer(appointment.getCustomer());
        invoice.setBranch(appointment.getBranch());
        invoice.setTotalAmount(totalPrice);
        invoice.setDiscountAmount(BigDecimal.ZERO);
        invoice.setTaxAmount(totalPrice.multiply(new BigDecimal("0.1")));
        invoice.setFinalAmount(invoice.getTotalAmount().add(invoice.getTaxAmount()));
        invoice.setPaymentStatus("paid");
        invoice.setPaymentMethod(paymentMethod);
        invoice.setPaymentDate(LocalDateTime.now());
        invoice.setPaymentNotes(notes);
        invoice.setInvoiceNumber("INV-" + System.currentTimeMillis());

        invoiceRepository.save(invoice);

        // Gửi email hóa đơn
        emailService.sendInvoiceEmail(invoice);

        return invoice;
    }

    @Override
    public Invoice createInvoiceForAppointments(List<Appointment> appointments, String paymentMethod, String notes) {
        if (appointments == null || appointments.isEmpty()) {
            throw new IllegalArgumentException("Danh sách lịch hẹn trống");
        }
        // Assume all appointments are for the same customer and branch
        User customer = appointments.get(0).getCustomer();
        Branch branch = appointments.get(0).getBranch();
        BigDecimal totalAmount = BigDecimal.ZERO;
        BigDecimal tax = BigDecimal.ZERO;
        for (Appointment appt : appointments) {
            // Use total price from all services in each appointment
            BigDecimal appointmentPrice = appt.getTotalPrice();
            totalAmount = totalAmount.add(appointmentPrice);
            tax = tax.add(appointmentPrice.multiply(new BigDecimal("0.10")));
        }
        BigDecimal discount = BigDecimal.ZERO;
        BigDecimal finalAmount = totalAmount.add(tax).subtract(discount);
        Invoice invoice = new Invoice();
        // Do NOT set appointments on invoice
        invoice.setCustomer(customer);
        invoice.setBranch(branch);
        invoice.setTotalAmount(totalAmount);
        invoice.setDiscountAmount(discount);
        invoice.setTaxAmount(tax);
        invoice.setFinalAmount(finalAmount);
        invoice.setPaymentStatus("unpaid");
        invoice.setPaymentMethod(paymentMethod);
        invoice.setPaymentNotes(notes);
        invoice.setInvoiceNumber("INV-" + System.currentTimeMillis());
        invoice.setCreatedAt(LocalDateTime.now());
        Invoice saved = invoiceRepository.save(invoice);
        // Optionally, send invoice email
        emailService.sendInvoiceEmail(saved);
        return saved;
    }

    @Override
    public Invoice updateInvoiceForAppointment(Appointment appointment, String paymentMethod, String notes) {
        // Find existing invoice for the appointment
        Invoice existingInvoice = invoiceRepository.findByAppointment(appointment);

        if (existingInvoice == null) {
            // If no invoice exists, create a new one
            return createInvoiceForAppointment(appointment, paymentMethod, notes);
        }

        // Update the existing invoice
        existingInvoice.setPaymentStatus("paid");
        existingInvoice.setPaymentMethod(paymentMethod);
        existingInvoice.setPaymentDate(LocalDateTime.now());
        existingInvoice.setPaymentNotes(notes);

        invoiceRepository.save(existingInvoice);

        // Send email notification
        emailService.sendInvoiceEmail(existingInvoice);

        return existingInvoice;
    }

    @Override
    public Invoice findByAppointment(Appointment appointment) {
        return invoiceRepository.findByAppointment(appointment);
    }
}
