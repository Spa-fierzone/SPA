package com.spazone.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class ManagerProfileDto {
    // Basic user information
    private Integer userId;
    private String username;
    private String email;
    private String fullName;
    private String phone;
    private LocalDate dateOfBirth;
    private String gender;
    private String address;
    private String profilePicture;
    private LocalDateTime createdAt;
    private LocalDateTime lastLogin;
    
    // Employee information
    private String status;
    private Integer branchId;
    private String branchName;
    private BigDecimal baseSalary;
    private LocalDateTime lastCheckIn;
    private LocalDateTime lastCheckOut;
    private BigDecimal totalWorkingHours;
    private BigDecimal performanceScore;
    
    // Manager-specific information
    private Integer teamSize;
    private Integer totalTechnicians;
    private Integer totalReceptionists;
    private Integer activeTechnicians;
    private Integer activeReceptionists;
    
    // Branch performance metrics
    private BigDecimal branchRevenue;
    private BigDecimal monthlyRevenue;
    private BigDecimal yearlyRevenue;
    private Integer totalCustomers;
    private Integer newCustomersThisMonth;
    private Integer totalAppointments;
    private Integer completedAppointments;
    private Integer cancelledAppointments;
    private BigDecimal customerSatisfactionRate;
    private BigDecimal appointmentCompletionRate;
    
    // Team performance
    private BigDecimal averageTeamPerformance;
    private Integer topPerformingTechnician;
    private String topPerformingTechnicianName;
    private BigDecimal topPerformingTechnicianScore;
    private Integer totalServicesProvided;
    private List<String> popularServices;
    
    // Schedule and operations
    private Integer todaySchedules;
    private Integer upcomingSchedules;
    private Integer pendingApprovals;
    private Integer overdueReports;
    
    // Financial overview
    private BigDecimal totalPayroll;
    private BigDecimal averageSalary;
    private BigDecimal bonusesDistributed;
    private BigDecimal operationalCosts;
    
    // Quality metrics
    private BigDecimal averageServiceRating;
    private Integer totalServiceReviews;
    private Integer complaintResolved;
    private Integer pendingComplaints;
    
    // Constructors
    public ManagerProfileDto() {}
    
    // Getters and Setters
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getEmployeeId() {
        return userId != null ? String.format("NV%04d", userId) : "N/A";
    }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }
    
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getProfilePicture() { return profilePicture; }
    public void setProfilePicture(String profilePicture) { this.profilePicture = profilePicture; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getLastLogin() { return lastLogin; }
    public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Integer getBranchId() { return branchId; }
    public void setBranchId(Integer branchId) { this.branchId = branchId; }
    
    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }
    
    public BigDecimal getBaseSalary() { return baseSalary; }
    public void setBaseSalary(BigDecimal baseSalary) { this.baseSalary = baseSalary; }
    
    public LocalDateTime getLastCheckIn() { return lastCheckIn; }
    public void setLastCheckIn(LocalDateTime lastCheckIn) { this.lastCheckIn = lastCheckIn; }
    
    public LocalDateTime getLastCheckOut() { return lastCheckOut; }
    public void setLastCheckOut(LocalDateTime lastCheckOut) { this.lastCheckOut = lastCheckOut; }
    
    public BigDecimal getTotalWorkingHours() { return totalWorkingHours; }
    public void setTotalWorkingHours(BigDecimal totalWorkingHours) { this.totalWorkingHours = totalWorkingHours; }
    
    public BigDecimal getPerformanceScore() { return performanceScore; }
    public void setPerformanceScore(BigDecimal performanceScore) { this.performanceScore = performanceScore; }
    
    public Integer getTeamSize() { return teamSize; }
    public void setTeamSize(Integer teamSize) { this.teamSize = teamSize; }
    
    public Integer getTotalTechnicians() { return totalTechnicians; }
    public void setTotalTechnicians(Integer totalTechnicians) { this.totalTechnicians = totalTechnicians; }
    
    public Integer getTotalReceptionists() { return totalReceptionists; }
    public void setTotalReceptionists(Integer totalReceptionists) { this.totalReceptionists = totalReceptionists; }
    
    public Integer getActiveTechnicians() { return activeTechnicians; }
    public void setActiveTechnicians(Integer activeTechnicians) { this.activeTechnicians = activeTechnicians; }
    
    public Integer getActiveReceptionists() { return activeReceptionists; }
    public void setActiveReceptionists(Integer activeReceptionists) { this.activeReceptionists = activeReceptionists; }
    
    public BigDecimal getBranchRevenue() { return branchRevenue; }
    public void setBranchRevenue(BigDecimal branchRevenue) { this.branchRevenue = branchRevenue; }
    
    public BigDecimal getMonthlyRevenue() { return monthlyRevenue; }
    public void setMonthlyRevenue(BigDecimal monthlyRevenue) { this.monthlyRevenue = monthlyRevenue; }
    
    public BigDecimal getYearlyRevenue() { return yearlyRevenue; }
    public void setYearlyRevenue(BigDecimal yearlyRevenue) { this.yearlyRevenue = yearlyRevenue; }
    
    public Integer getTotalCustomers() { return totalCustomers; }
    public void setTotalCustomers(Integer totalCustomers) { this.totalCustomers = totalCustomers; }
    
    public Integer getNewCustomersThisMonth() { return newCustomersThisMonth; }
    public void setNewCustomersThisMonth(Integer newCustomersThisMonth) { this.newCustomersThisMonth = newCustomersThisMonth; }
    
    public Integer getTotalAppointments() { return totalAppointments; }
    public void setTotalAppointments(Integer totalAppointments) { this.totalAppointments = totalAppointments; }
    
    public Integer getCompletedAppointments() { return completedAppointments; }
    public void setCompletedAppointments(Integer completedAppointments) { this.completedAppointments = completedAppointments; }
    
    public Integer getCancelledAppointments() { return cancelledAppointments; }
    public void setCancelledAppointments(Integer cancelledAppointments) { this.cancelledAppointments = cancelledAppointments; }
    
    public BigDecimal getCustomerSatisfactionRate() { return customerSatisfactionRate; }
    public void setCustomerSatisfactionRate(BigDecimal customerSatisfactionRate) { this.customerSatisfactionRate = customerSatisfactionRate; }
    
    public BigDecimal getAppointmentCompletionRate() { return appointmentCompletionRate; }
    public void setAppointmentCompletionRate(BigDecimal appointmentCompletionRate) { this.appointmentCompletionRate = appointmentCompletionRate; }
    
    public BigDecimal getAverageTeamPerformance() { return averageTeamPerformance; }
    public void setAverageTeamPerformance(BigDecimal averageTeamPerformance) { this.averageTeamPerformance = averageTeamPerformance; }
    
    public Integer getTopPerformingTechnician() { return topPerformingTechnician; }
    public void setTopPerformingTechnician(Integer topPerformingTechnician) { this.topPerformingTechnician = topPerformingTechnician; }
    
    public String getTopPerformingTechnicianName() { return topPerformingTechnicianName; }
    public void setTopPerformingTechnicianName(String topPerformingTechnicianName) { this.topPerformingTechnicianName = topPerformingTechnicianName; }
    
    public BigDecimal getTopPerformingTechnicianScore() { return topPerformingTechnicianScore; }
    public void setTopPerformingTechnicianScore(BigDecimal topPerformingTechnicianScore) { this.topPerformingTechnicianScore = topPerformingTechnicianScore; }
    
    public Integer getTotalServicesProvided() { return totalServicesProvided; }
    public void setTotalServicesProvided(Integer totalServicesProvided) { this.totalServicesProvided = totalServicesProvided; }
    
    public List<String> getPopularServices() { return popularServices; }
    public void setPopularServices(List<String> popularServices) { this.popularServices = popularServices; }
    
    public Integer getTodaySchedules() { return todaySchedules; }
    public void setTodaySchedules(Integer todaySchedules) { this.todaySchedules = todaySchedules; }
    
    public Integer getUpcomingSchedules() { return upcomingSchedules; }
    public void setUpcomingSchedules(Integer upcomingSchedules) { this.upcomingSchedules = upcomingSchedules; }
    
    public Integer getPendingApprovals() { return pendingApprovals; }
    public void setPendingApprovals(Integer pendingApprovals) { this.pendingApprovals = pendingApprovals; }
    
    public Integer getOverdueReports() { return overdueReports; }
    public void setOverdueReports(Integer overdueReports) { this.overdueReports = overdueReports; }
    
    public BigDecimal getTotalPayroll() { return totalPayroll; }
    public void setTotalPayroll(BigDecimal totalPayroll) { this.totalPayroll = totalPayroll; }
    
    public BigDecimal getAverageSalary() { return averageSalary; }
    public void setAverageSalary(BigDecimal averageSalary) { this.averageSalary = averageSalary; }
    
    public BigDecimal getBonusesDistributed() { return bonusesDistributed; }
    public void setBonusesDistributed(BigDecimal bonusesDistributed) { this.bonusesDistributed = bonusesDistributed; }
    
    public BigDecimal getOperationalCosts() { return operationalCosts; }
    public void setOperationalCosts(BigDecimal operationalCosts) { this.operationalCosts = operationalCosts; }
    
    public BigDecimal getAverageServiceRating() { return averageServiceRating; }
    public void setAverageServiceRating(BigDecimal averageServiceRating) { this.averageServiceRating = averageServiceRating; }
    
    public Integer getTotalServiceReviews() { return totalServiceReviews; }
    public void setTotalServiceReviews(Integer totalServiceReviews) { this.totalServiceReviews = totalServiceReviews; }
    
    public Integer getComplaintResolved() { return complaintResolved; }
    public void setComplaintResolved(Integer complaintResolved) { this.complaintResolved = complaintResolved; }
    
    public Integer getPendingComplaints() { return pendingComplaints; }
    public void setPendingComplaints(Integer pendingComplaints) { this.pendingComplaints = pendingComplaints; }
}
