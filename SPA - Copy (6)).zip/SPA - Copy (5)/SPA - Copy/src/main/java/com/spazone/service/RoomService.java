package com.spazone.service;

import com.spazone.entity.Room;
import com.spazone.entity.Branch;
import com.spazone.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class RoomService {
    @Autowired
    private RoomRepository roomRepository;

    public List<Room> findAvailableRooms(Branch branch, LocalDateTime startTime, LocalDateTime endTime) {
        return roomRepository.findAvailableRooms(branch, startTime, endTime);
    }

    public List<Room> findByBranch(Branch branch) {
        return roomRepository.findByBranch(branch);
    }

    public Room findById(Integer id) {
        return roomRepository.findById(id).orElse(null);
    }

    public List<Room> findAll() {
        return roomRepository.findAll();
    }

    public void save(Room room) {
        roomRepository.save(room);
    }

    public void deleteById(Integer id) {
        roomRepository.deleteById(id);
    }

    /**
     * Auto-assign an available room with capacity > 0
     */
    public Room autoAssignRoom(Branch branch, LocalDateTime startTime, LocalDateTime endTime) {
        List<Room> availableRooms = findAvailableRooms(branch, startTime, endTime);
        return availableRooms.stream()
                .filter(room -> room.getCapacity() != null && room.getCapacity() > 0)
                .findFirst()
                .orElse(null);
    }

    /**
     * Decrease room capacity by 1
     */
    @Transactional
    public boolean decreaseCapacity(Integer roomId) {
        Room room = findById(roomId);
        if (room != null && room.getCapacity() != null && room.getCapacity() > 0) {
            room.setCapacity(room.getCapacity() - 1);
            save(room);
            return true;
        }
        return false;
    }

    /**
     * Increase room capacity by 1
     */
    @Transactional
    public boolean increaseCapacity(Integer roomId) {
        Room room = findById(roomId);
        if (room != null && room.getCapacity() != null) {
            room.setCapacity(room.getCapacity() + 1);
            save(room);
            return true;
        }
        return false;
    }

    /**
     * Check if room has available capacity
     */
    public boolean hasAvailableCapacity(Integer roomId) {
        Room room = findById(roomId);
        return room != null && room.getCapacity() != null && room.getCapacity() > 0;
    }
}
