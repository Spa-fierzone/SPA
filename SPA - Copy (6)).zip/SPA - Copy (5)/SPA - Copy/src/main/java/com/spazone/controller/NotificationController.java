package com.spazone.controller;

import com.spazone.entity.Notification;
import com.spazone.entity.User;
import com.spazone.service.NotificationService;
import com.spazone.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.*;
import java.util.stream.Collectors;
import java.util.Map;

@Controller
@RequestMapping("/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private UserService userService;

    /**
     * Show notifications page
     */
    @GetMapping
    public String showNotifications(Model model, Authentication principal,
                                  @RequestParam(defaultValue = "0") int page,
                                  @RequestParam(defaultValue = "10") int size) {
        User currentUser = userService.findByUsername(principal.getName());
        
        Pageable pageable = PageRequest.of(page, size);
        Page<Notification> notifications = notificationService.getNotificationsForUser(currentUser, pageable);
        
        model.addAttribute("notifications", notifications);
        model.addAttribute("unreadCount", notificationService.countUnreadNotifications(currentUser));
        
        return "notifications/list";
    }

    /**
     * Get unread notifications count (AJAX)
     */
    @GetMapping("/unread-count")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getUnreadCount(Authentication principal) {
        User currentUser = userService.findByUsername(principal.getName());
        Long unreadCount = notificationService.countUnreadNotifications(currentUser);
        
        Map<String, Object> response = new HashMap<>();
        response.put("unreadCount", unreadCount);
        
        return ResponseEntity.ok(response);
    }

    /**
     * Get recent unread notifications (AJAX)
     */
    @GetMapping("/recent")
    @ResponseBody
    public ResponseEntity<List<Map<String, Object>>> getRecentNotifications(Authentication principal,
                                                                           @RequestParam(defaultValue = "5") int limit) {
        User currentUser = userService.findByUsername(principal.getName());
        List<Notification> notifications = notificationService.getUnreadNotifications(currentUser);

        // Limit the results
        if (notifications.size() > limit) {
            notifications = notifications.subList(0, limit);
        }

        // Convert to maps to avoid serialization issues
        List<Map<String, Object>> notificationMaps = notifications.stream().map(notification -> {
            Map<String, Object> notificationMap = new HashMap<>();
            notificationMap.put("notificationId", notification.getNotificationId());
            notificationMap.put("title", notification.getTitle());
            notificationMap.put("message", notification.getMessage());
            notificationMap.put("type", notification.getType().toString());
            notificationMap.put("isRead", notification.isRead());
            notificationMap.put("createdAt", notification.getCreatedAt());
            notificationMap.put("actionUrl", notification.getActionUrl());

            // Handle sender safely
            if (notification.getSender() != null) {
                notificationMap.put("senderName", notification.getSender().getFullName());
                notificationMap.put("senderId", notification.getSender().getUserId());
            } else {
                notificationMap.put("senderName", "System");
                notificationMap.put("senderId", null);
            }

            return notificationMap;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(notificationMaps);
    }

    /**
     * Mark notification as read
     */
    @PostMapping("/{notificationId}/read")
    @ResponseBody
    public ResponseEntity<Map<String, String>> markAsRead(@PathVariable Integer notificationId, Authentication principal) {
        try {
            // Verify the notification belongs to the current user
            Notification notification = notificationService.getNotificationById(notificationId);
            User currentUser = userService.findByUsername(principal.getName());
            
            if (!notification.getUser().getUserId().equals(currentUser.getUserId())) {
                return ResponseEntity.badRequest().body(Map.of("error", "Unauthorized"));
            }
            
            notificationService.markAsRead(notificationId);
            return ResponseEntity.ok(Map.of("status", "success"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Mark all notifications as read
     */
    @PostMapping("/mark-all-read")
    @ResponseBody
    public ResponseEntity<Map<String, String>> markAllAsRead(Authentication principal) {
        try {
            User currentUser = userService.findByUsername(principal.getName());
            notificationService.markAllAsRead(currentUser);
            return ResponseEntity.ok(Map.of("status", "success"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Delete notification
     */
    @DeleteMapping("/{notificationId}")
    @ResponseBody
    public ResponseEntity<Map<String, String>> deleteNotification(@PathVariable Integer notificationId, Authentication principal) {
        try {
            // Verify the notification belongs to the current user
            Notification notification = notificationService.getNotificationById(notificationId);
            User currentUser = userService.findByUsername(principal.getName());
            
            if (!notification.getUser().getUserId().equals(currentUser.getUserId())) {
                return ResponseEntity.badRequest().body(Map.of("error", "Unauthorized"));
            }
            
            notificationService.deleteNotification(notificationId);
            return ResponseEntity.ok(Map.of("status", "success"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Admin: Send system alert to all users
     */
    @PostMapping("/admin/system-alert")
    @PreAuthorize("hasRole('ADMIN')")
    @ResponseBody
    public ResponseEntity<Map<String, String>> sendSystemAlert(@RequestParam String title,
                                                              @RequestParam String message,
                                                              @RequestParam(required = false) String role) {
        try {
            if (role != null && !role.isEmpty()) {
                notificationService.sendToUsersWithRole(role, title, message, Notification.NotificationType.SYSTEM_ALERT);
            } else {
                // Send to all users
                List<User> allUsers = userService.getAllUsers();
                notificationService.broadcastNotification(allUsers, title, message, Notification.NotificationType.SYSTEM_ALERT);
            }
            return ResponseEntity.ok(Map.of("status", "success"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Manager: Send notification to team members
     */
    @PostMapping("/manager/team-notification")
    @PreAuthorize("hasRole('MANAGER')")
    @ResponseBody
    public ResponseEntity<Map<String, String>> sendTeamNotification(@RequestParam String title,
                                                                   @RequestParam String message,
                                                                   @RequestParam String type,
                                                                   @RequestParam(required = false) String actionUrl,
                                                                   @RequestParam(required = false) String[] targetRoles,
                                                                   Authentication principal) {
        try {
            User manager = userService.findByUsername(principal.getName());
            Integer branchId = manager.getBranch().getBranchId();

            List<User> targetUsers = new ArrayList<>();

            // If no specific roles are selected, send to all team members (excluding manager)
            if (targetRoles == null || targetRoles.length == 0) {
                List<User> allTeamMembers = userService.getUsersByBranch(branchId);
                targetUsers = allTeamMembers.stream()
                    .filter(user -> !user.getUserId().equals(manager.getUserId()))
                    .collect(Collectors.toList());
            } else {
                // Send to specific roles
                for (String role : targetRoles) {
                    switch (role.toUpperCase()) {
                        case "RECEPTIONIST":
                            targetUsers.addAll(userService.findReceptionistsByBranch(branchId));
                            break;
                        case "TECHNICIAN":
                            targetUsers.addAll(userService.findTechniciansByBranch(branchId));
                            break;
                    }
                }
                // Remove duplicates and exclude manager
                targetUsers = targetUsers.stream()
                    .distinct()
                    .filter(user -> !user.getUserId().equals(manager.getUserId()))
                    .collect(Collectors.toList());
            }

            Notification.NotificationType notificationType = Notification.NotificationType.valueOf(type.toUpperCase());

            // Send notifications to target users
            for (User user : targetUsers) {
                if (actionUrl != null && !actionUrl.trim().isEmpty()) {
                    notificationService.createNotificationWithAction(user, manager, title, message, notificationType, actionUrl);
                } else {
                    notificationService.createNotification(user, manager, title, message, notificationType);
                }
            }

            String roleInfo = (targetRoles != null && targetRoles.length > 0)
                ? " đến " + String.join(", ", targetRoles).toLowerCase()
                : " đến tất cả thành viên";

            return ResponseEntity.ok(Map.of("status", "success",
                "message", "Thông báo nhóm đã được gửi thành công" + roleInfo + " (" + targetUsers.size() + " người)"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Admin: Send system-wide notification
     */
    @PostMapping("/manager/system-alert")
    @PreAuthorize("hasRole('ADMIN')")
    @ResponseBody
    public ResponseEntity<Map<String, String>> sendSystemAlert(@RequestParam String title,
                                                              @RequestParam String message,
                                                              @RequestParam(required = false) String role,
                                                              Authentication principal) {
        try {
            User admin = userService.findByUsername(principal.getName());

            if (role != null && !role.isEmpty()) {
                notificationService.sendToUsersWithRole(role, title, message, Notification.NotificationType.SYSTEM_ALERT);
            } else {
                // Send to all users
                List<User> allUsers = userService.getAllUsers();
                notificationService.broadcastNotification(allUsers, title, message, Notification.NotificationType.SYSTEM_ALERT);
            }

            return ResponseEntity.ok(Map.of("status", "success", "message", "Thông báo hệ thống đã được gửi thành công"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Test endpoint to send a notification to current user (for testing customer notifications)
     */
    @PostMapping("/test-notification")
    @ResponseBody
    public ResponseEntity<Map<String, String>> sendTestNotification(Authentication principal) {
        try {
            User currentUser = userService.findByUsername(principal.getName());

            String title = "Thông báo thử nghiệm";
            String message = "Đây là thông báo thử nghiệm để kiểm tra hệ thống thông báo. Bạn đã nhận được thông báo này thành công!";

            notificationService.createNotification(currentUser, null, title, message, Notification.NotificationType.GENERAL);

            return ResponseEntity.ok(Map.of("status", "success", "message", "Thông báo thử nghiệm đã được gửi thành công"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Get notification details
     */
    @GetMapping("/{notificationId}")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getNotificationDetails(@PathVariable Integer notificationId, Authentication principal) {
        try {
            Notification notification = notificationService.getNotificationById(notificationId);
            User currentUser = userService.findByUsername(principal.getName());

            if (!notification.getUser().getUserId().equals(currentUser.getUserId())) {
                return ResponseEntity.badRequest().build();
            }

            // Mark as read when viewed
            if (!notification.isRead()) {
                notificationService.markAsRead(notificationId);
            }

            // Convert to map to avoid serialization issues
            Map<String, Object> notificationMap = new HashMap<>();
            notificationMap.put("notificationId", notification.getNotificationId());
            notificationMap.put("title", notification.getTitle());
            notificationMap.put("message", notification.getMessage());
            notificationMap.put("type", notification.getType().toString());
            notificationMap.put("isRead", notification.isRead());
            notificationMap.put("createdAt", notification.getCreatedAt());
            notificationMap.put("readAt", notification.getReadAt());
            notificationMap.put("actionUrl", notification.getActionUrl());
            notificationMap.put("expiresAt", notification.getExpiresAt());

            // Handle sender safely
            if (notification.getSender() != null) {
                notificationMap.put("senderName", notification.getSender().getFullName());
                notificationMap.put("senderId", notification.getSender().getUserId());
            } else {
                notificationMap.put("senderName", "System");
                notificationMap.put("senderId", null);
            }

            return ResponseEntity.ok(notificationMap);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Show create notification form
     */
    @GetMapping("/create")
    @PreAuthorize("hasRole('MANAGER') or hasRole('ADMIN')")
    public String showCreateForm(Model model, Authentication principal) {
        User currentUser = userService.findByUsername(principal.getName());
        model.addAttribute("currentUser", currentUser);
        return "notifications/create";
    }


}
