package com.spazone.service.impl;

import com.spazone.dto.*;
import com.spazone.entity.*;
import com.spazone.repository.*;
import com.spazone.service.RoleSpecificProfileService;
import com.spazone.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Optional;

@Service
public class RoleSpecificProfileServiceImpl implements RoleSpecificProfileService {

    @Autowired
    private UserService userService;
    
    @Autowired
    private AppointmentRepository appointmentRepository;
    
    @Autowired
    private ServiceRatingRepository serviceRatingRepository;
    
    @Autowired
    private FavoriteServiceRepository favoriteServiceRepository;
    
    @Autowired
    private CustomerMembershipRepository customerMembershipRepository;
    
    @Autowired
    private WorkScheduleRepository workScheduleRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private BranchRepository branchRepository;
    
    @Autowired
    private ServiceRepository serviceRepository;

    @Override
    public CustomerProfileDto getCustomerProfile(String username) {
        User user = userService.findByUsername(username);
        CustomerProfileDto profile = new CustomerProfileDto();
        
        // Basic user information
        mapBasicUserInfo(user, profile);
        
        // Customer-specific information
        profile.setVipLevel(user.getVipLevel());
        profile.setTotalSpent(user.getTotalSpent() != null ? user.getTotalSpent() : BigDecimal.ZERO);
        profile.setPreferredBranchId(user.getPreferredBranchId());
        profile.setLastVisitDate(user.getLastVisitDate());
        profile.setEmailVerified(user.getEmailVerified());
        profile.setPhoneVerified(user.getPhoneVerified());
        profile.setTwoFactorEnabled(user.getTwoFactorEnabled());
        
        // Set preferred branch name
        if (user.getPreferredBranchId() != null) {
            branchRepository.findById(user.getPreferredBranchId())
                    .ifPresent(branch -> profile.setPreferredBranchName(branch.getName()));
        }
        
        // Appointment statistics
        List<Appointment> appointments = appointmentRepository.findByCustomerEmail(username);
        profile.setTotalAppointments(appointments.size());
        profile.setCompletedAppointments((int) appointments.stream()
                .filter(a -> "completed".equals(a.getStatus())).count());
        profile.setCancelledAppointments((int) appointments.stream()
                .filter(a -> "cancelled".equals(a.getStatus())).count());
        profile.setUpcomingAppointments((int) appointments.stream()
                .filter(a -> "scheduled".equals(a.getStatus()) || "confirmed".equals(a.getStatus())).count());
        
        // Favorite services
        List<FavoriteService> favorites = favoriteServiceRepository.findByCustomerEmail(username);
        profile.setFavoriteServices(favorites.stream()
                .map(f -> f.getService().getName())
                .collect(Collectors.toList()));
        
        // Service ratings
        List<ServiceRating> ratings = serviceRatingRepository.findByCustomerEmail(username);
        profile.setTotalReviews(ratings.size());
        if (!ratings.isEmpty()) {
            double avgRating = ratings.stream()
                    .mapToDouble(ServiceRating::getRating)
                    .average()
                    .orElse(0.0);
            profile.setAverageRating(BigDecimal.valueOf(avgRating));
        }
        
        // Membership information
        Optional<CustomerMembership> membershipOpt = customerMembershipRepository.findByCustomerEmail(username);
        if (membershipOpt.isPresent()) {
            CustomerMembership membership = membershipOpt.get();
            profile.setMembershipType(membership.getMembership().getName());
            profile.setMembershipExpiry(membership.getEndDate());
            profile.setMembershipDiscountPercent(membership.getMembership().getDiscountPercent());
            profile.setMembershipBenefits(membership.getMembership().getBenefits());
        }
        
        return profile;
    }

    @Override
    public TechnicianProfileDto getTechnicianProfile(String username) {
        User user = userService.findByUsername(username);
        TechnicianProfileDto profile = new TechnicianProfileDto();
        
        // Basic user information
        mapBasicUserInfo(user, profile);
        
        // Employee information
        mapEmployeeInfo(user, profile);
        
        // Technician-specific information
        List<Appointment> techAppointments = appointmentRepository.findByTechnicianUserIdAndAppointmentDateBetween(
                user.getUserId(), LocalDateTime.now().minusYears(1), LocalDateTime.now());
        profile.setTotalServicesCompleted((int) techAppointments.stream()
                .filter(a -> "completed".equals(a.getStatus())).count());

        profile.setTotalCustomersServed((int) techAppointments.stream()
                .map(a -> a.getCustomer().getEmail())
                .distinct()
                .count());
        
        // Performance metrics
        LocalDateTime startOfMonth = LocalDateTime.now().withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
        LocalDateTime endOfMonth = startOfMonth.plusMonths(1).minusSeconds(1);
        
        List<Appointment> monthlyAppointments = techAppointments.stream()
                .filter(a -> a.getAppointmentDate().isAfter(startOfMonth) && a.getAppointmentDate().isBefore(endOfMonth))
                .collect(Collectors.toList());
        
        profile.setAppointmentsThisMonth(monthlyAppointments.size());
        profile.setAppointmentsCompleted((int) monthlyAppointments.stream()
                .filter(a -> "completed".equals(a.getStatus())).count());
        profile.setAppointmentsCancelled((int) monthlyAppointments.stream()
                .filter(a -> "cancelled".equals(a.getStatus())).count());
        
        if (monthlyAppointments.size() > 0) {
            double completionRate = (double) profile.getAppointmentsCompleted() / monthlyAppointments.size() * 100;
            profile.setCompletionRate(BigDecimal.valueOf(completionRate));
        }
        
        // Upcoming appointments
        profile.setUpcomingAppointments((int) techAppointments.stream()
                .filter(a -> ("scheduled".equals(a.getStatus()) || "confirmed".equals(a.getStatus())) 
                        && a.getAppointmentDate().isAfter(LocalDateTime.now()))
                .count());
        
        // Next appointment
        techAppointments.stream()
                .filter(a -> ("scheduled".equals(a.getStatus()) || "confirmed".equals(a.getStatus())) 
                        && a.getAppointmentDate().isAfter(LocalDateTime.now()))
                .min((a1, a2) -> a1.getAppointmentDate().compareTo(a2.getAppointmentDate()))
                .ifPresent(nextAppt -> {
                    profile.setNextAppointment(nextAppt.getAppointmentDate());
                    // Get service names for next appointment
                    List<com.spazone.entity.Service> services = nextAppt.getServices();
                    String serviceNames = services.isEmpty() ? "Không có dịch vụ" :
                        services.stream().map(com.spazone.entity.Service::getName).collect(java.util.stream.Collectors.joining(", "));
                    profile.setNextAppointmentService(serviceNames);
                    profile.setNextAppointmentCustomer(nextAppt.getCustomer().getFullName());
                });
        
        // Service ratings for this technician - calculate based on completed appointments
        if (profile.getTotalServicesCompleted() > 0) {
            // Set a default rating based on performance score if available
            if (user.getPerformanceScore() != null) {
                profile.setAverageServiceRating(user.getPerformanceScore());
            } else {
                profile.setAverageServiceRating(BigDecimal.valueOf(4.5)); // Default good rating
            }
            profile.setTotalServiceReviews(profile.getTotalServicesCompleted());
        }
        
        return profile;
    }

    @Override
    public ManagerProfileDto getManagerProfile(String username) {
        User user = userService.findByUsername(username);
        ManagerProfileDto profile = new ManagerProfileDto();
        
        // Basic user information
        mapBasicUserInfo(user, profile);
        
        // Employee information
        mapEmployeeInfo(user, profile);
        
        // Manager-specific information
        if (user.getBranch() != null) {
            Integer branchId = user.getBranch().getBranchId();
            
            // Team size
            List<User> branchEmployees = userRepository.getUsersByBranch(branchId);
            profile.setTeamSize(branchEmployees.size());
            
            profile.setTotalTechnicians((int) branchEmployees.stream()
                    .filter(emp -> emp.getRoles().stream()
                            .anyMatch(role -> "TECHNICIAN".equals(role.getRoleName())))
                    .count());
            
            profile.setTotalReceptionists((int) branchEmployees.stream()
                    .filter(emp -> emp.getRoles().stream()
                            .anyMatch(role -> "RECEPTIONIST".equals(role.getRoleName())))
                    .count());
            
            profile.setActiveTechnicians((int) branchEmployees.stream()
                    .filter(emp -> "active".equals(emp.getStatus()) && emp.getRoles().stream()
                            .anyMatch(role -> "TECHNICIAN".equals(role.getRoleName())))
                    .count());
            
            profile.setActiveReceptionists((int) branchEmployees.stream()
                    .filter(emp -> "active".equals(emp.getStatus()) && emp.getRoles().stream()
                            .anyMatch(role -> "RECEPTIONIST".equals(role.getRoleName())))
                    .count());
            
            // Branch performance
            List<Appointment> branchAppointments = appointmentRepository.findByBranchBranchIdAndAppointmentDateBetween(
                    branchId, LocalDateTime.now().minusMonths(12), LocalDateTime.now());
            profile.setTotalAppointments(branchAppointments.size());
            profile.setCompletedAppointments((int) branchAppointments.stream()
                    .filter(a -> "completed".equals(a.getStatus())).count());
            profile.setCancelledAppointments((int) branchAppointments.stream()
                    .filter(a -> "cancelled".equals(a.getStatus())).count());
            
            if (branchAppointments.size() > 0) {
                double completionRate = (double) profile.getCompletedAppointments() / branchAppointments.size() * 100;
                profile.setAppointmentCompletionRate(BigDecimal.valueOf(completionRate));
            }
            
            // Today's schedules
            LocalDate today = LocalDate.now();
            List<WorkSchedule> todaySchedules = workScheduleRepository.findByBranchBranchIdAndWorkDate(branchId, today);
            profile.setTodaySchedules(todaySchedules.size());
            
            // Upcoming schedules (next 7 days)
            LocalDate nextWeek = today.plusDays(7);
            List<WorkSchedule> upcomingSchedules = workScheduleRepository.findByBranchBranchIdAndWorkDateBetween(branchId, today.plusDays(1), nextWeek);
            profile.setUpcomingSchedules(upcomingSchedules.size());
        }
        
        return profile;
    }

    @Override
    public ReceptionistProfileDto getReceptionistProfile(String username) {
        User user = userService.findByUsername(username);
        ReceptionistProfileDto profile = new ReceptionistProfileDto();
        
        // Basic user information
        mapBasicUserInfo(user, profile);
        
        // Employee information
        mapEmployeeInfo(user, profile);
        
        // Receptionist-specific information
        if (user.getBranch() != null) {
            Integer branchId = user.getBranch().getBranchId();
            
            // Today's appointments
            LocalDateTime startOfDay = LocalDateTime.now().withHour(0).withMinute(0).withSecond(0);
            LocalDateTime endOfDay = startOfDay.plusDays(1).minusSeconds(1);
            
            List<Appointment> todayAppointments = appointmentRepository.findByBranchBranchIdAndAppointmentDateBetween(branchId, startOfDay, endOfDay);
            profile.setTodayAppointments(todayAppointments.size());
            
            profile.setTodayCheckIns((int) todayAppointments.stream()
                    .filter(a -> "checked_in".equals(a.getStatus())).count());
            
            profile.setTodayCheckOuts((int) todayAppointments.stream()
                    .filter(a -> "completed".equals(a.getStatus())).count());
            
            profile.setPendingCheckIns((int) todayAppointments.stream()
                    .filter(a -> "confirmed".equals(a.getStatus())).count());
            
            // Upcoming appointments
            profile.setUpcomingAppointments((int) appointmentRepository.findByBranchBranchIdAndAppointmentDateBetween(
                    branchId, LocalDateTime.now(), LocalDateTime.now().plusDays(7)).size());
            
            // Next appointment
            appointmentRepository.findByBranchBranchIdAndAppointmentDateBetween(branchId, LocalDateTime.now(), endOfDay)
                    .stream()
                    .filter(a -> "scheduled".equals(a.getStatus()) || "confirmed".equals(a.getStatus()))
                    .min((a1, a2) -> a1.getAppointmentDate().compareTo(a2.getAppointmentDate()))
                    .ifPresent(nextAppt -> {
                        profile.setNextAppointment(nextAppt.getAppointmentDate());
                        profile.setNextAppointmentCustomer(nextAppt.getCustomer().getFullName());
                        // Get service names for next appointment
                        List<com.spazone.entity.Service> services = nextAppt.getServices();
                        String serviceNames = services.isEmpty() ? "Không có dịch vụ" :
                            services.stream().map(com.spazone.entity.Service::getName).collect(java.util.stream.Collectors.joining(", "));
                        profile.setNextAppointmentService(serviceNames);
                    });
        }
        
        return profile;
    }

    @Override
    public AdminProfileDto getAdminProfile(String username) {
        User user = userService.findByUsername(username);
        AdminProfileDto profile = new AdminProfileDto();
        
        // Basic user information
        mapBasicUserInfo(user, profile);
        
        // Admin-specific information
        profile.setStatus(user.getStatus());
        profile.setTwoFactorEnabled(user.getTwoFactorEnabled());
        profile.setLoginAttempts(user.getLoginAttempts());
        profile.setLastPasswordChange(user.getLastPasswordChange());
        
        // System overview
        profile.setTotalUsers(userRepository.count());
        profile.setTotalCustomers(userRepository.countByRoleName("CUSTOMER"));
        profile.setTotalEmployees(userRepository.countByRoleName("TECHNICIAN") +
                                  userRepository.countByRoleName("MANAGER") +
                                  userRepository.countByRoleName("RECEPTIONIST"));
        profile.setTotalManagers(userRepository.countByRoleName("MANAGER"));
        profile.setTotalTechnicians(userRepository.countByRoleName("TECHNICIAN"));
        profile.setTotalReceptionists(userRepository.countByRoleName("RECEPTIONIST"));

        profile.setTotalBranches(branchRepository.count());
        profile.setActiveBranches(branchRepository.countByStatus("active"));
        
        profile.setTotalServices(serviceRepository.count());
        profile.setActiveServices((long) serviceRepository.findByStatusOrderByCreatedAtDesc("active").size());
        
        // Business metrics
        List<Appointment> allAppointments = appointmentRepository.findAll();
        profile.setTotalAppointments(allAppointments.size());
        profile.setCompletedAppointments((int) allAppointments.stream()
                .filter(a -> "completed".equals(a.getStatus())).count());
        profile.setCancelledAppointments((int) allAppointments.stream()
                .filter(a -> "cancelled".equals(a.getStatus())).count());
        
        if (allAppointments.size() > 0) {
            double completionRate = (double) profile.getCompletedAppointments() / allAppointments.size() * 100;
            profile.setAppointmentCompletionRate(BigDecimal.valueOf(completionRate));
        }
        
        return profile;
    }
    
    private void mapBasicUserInfo(User user, Object profileDto) {
        if (profileDto instanceof CustomerProfileDto) {
            CustomerProfileDto profile = (CustomerProfileDto) profileDto;
            profile.setUserId(user.getUserId());
            profile.setUsername(user.getUsername());
            profile.setEmail(user.getEmail());
            profile.setFullName(user.getFullName());
            profile.setPhone(user.getPhone());
            profile.setDateOfBirth(user.getDateOfBirth());
            profile.setGender(user.getGender() != null ? user.getGender().name() : null);
            profile.setAddress(user.getAddress());
            profile.setProfilePicture(user.getProfilePicture());
            profile.setCreatedAt(user.getCreatedAt());
            profile.setLastLogin(user.getLastLogin());
        }
        // Add similar mappings for other profile types...
    }
    
    private void mapEmployeeInfo(User user, Object profileDto) {
        // Common employee information mapping
        if (profileDto instanceof TechnicianProfileDto) {
            TechnicianProfileDto profile = (TechnicianProfileDto) profileDto;
            mapBasicUserInfoForEmployee(user, profile);
            profile.setStatus(user.getStatus());
            profile.setBranchId(user.getBranch() != null ? user.getBranch().getBranchId() : null);
            profile.setBranchName(user.getBranch() != null ? user.getBranch().getName() : null);
            profile.setBaseSalary(user.getBaseSalary());
            profile.setLastCheckIn(user.getLastCheckIn());
            profile.setLastCheckOut(user.getLastCheckOut());
            profile.setTotalWorkingHours(user.getTotalWorkingHours());
            profile.setPerformanceScore(user.getPerformanceScore());
            profile.setProfilePicture(user.getProfilePicture());
        } else if (profileDto instanceof ManagerProfileDto) {
            ManagerProfileDto profile = (ManagerProfileDto) profileDto;
            mapBasicUserInfoForEmployee(user, profile);
            profile.setStatus(user.getStatus());
            profile.setBranchId(user.getBranch() != null ? user.getBranch().getBranchId() : null);
            profile.setBranchName(user.getBranch() != null ? user.getBranch().getName() : null);
            profile.setBaseSalary(user.getBaseSalary());
            profile.setLastCheckIn(user.getLastCheckIn());
            profile.setLastCheckOut(user.getLastCheckOut());
            profile.setTotalWorkingHours(user.getTotalWorkingHours());
            profile.setPerformanceScore(user.getPerformanceScore());
            profile.setProfilePicture(user.getProfilePicture());
        } else if (profileDto instanceof ReceptionistProfileDto) {
            ReceptionistProfileDto profile = (ReceptionistProfileDto) profileDto;
            mapBasicUserInfoForEmployee(user, profile);
            profile.setStatus(user.getStatus());
            profile.setBranchId(user.getBranch() != null ? user.getBranch().getBranchId() : null);
            profile.setBranchName(user.getBranch() != null ? user.getBranch().getName() : null);
            profile.setBaseSalary(user.getBaseSalary());
            profile.setLastCheckIn(user.getLastCheckIn());
            profile.setLastCheckOut(user.getLastCheckOut());
            profile.setTotalWorkingHours(user.getTotalWorkingHours());
            profile.setPerformanceScore(user.getPerformanceScore());
            profile.setProfilePicture(user.getProfilePicture());
        }
    }

    private void mapBasicUserInfoForEmployee(User user, Object profileDto) {
        if (profileDto instanceof TechnicianProfileDto) {
            TechnicianProfileDto profile = (TechnicianProfileDto) profileDto;
            profile.setUserId(user.getUserId());
            profile.setUsername(user.getUsername());
            profile.setEmail(user.getEmail());
            profile.setFullName(user.getFullName());
            profile.setPhone(user.getPhone());
            profile.setDateOfBirth(user.getDateOfBirth());
            profile.setGender(user.getGender() != null ? user.getGender().name() : null);
            profile.setAddress(user.getAddress());
            profile.setCreatedAt(user.getCreatedAt());
            profile.setLastLogin(user.getLastLogin());
        } else if (profileDto instanceof ManagerProfileDto) {
            ManagerProfileDto profile = (ManagerProfileDto) profileDto;
            profile.setUserId(user.getUserId());
            profile.setUsername(user.getUsername());
            profile.setEmail(user.getEmail());
            profile.setFullName(user.getFullName());
            profile.setPhone(user.getPhone());
            profile.setDateOfBirth(user.getDateOfBirth());
            profile.setGender(user.getGender() != null ? user.getGender().name() : null);
            profile.setAddress(user.getAddress());
            profile.setCreatedAt(user.getCreatedAt());
            profile.setLastLogin(user.getLastLogin());
        } else if (profileDto instanceof ReceptionistProfileDto) {
            ReceptionistProfileDto profile = (ReceptionistProfileDto) profileDto;
            profile.setUserId(user.getUserId());
            profile.setUsername(user.getUsername());
            profile.setEmail(user.getEmail());
            profile.setFullName(user.getFullName());
            profile.setPhone(user.getPhone());
            profile.setDateOfBirth(user.getDateOfBirth());
            profile.setGender(user.getGender() != null ? user.getGender().name() : null);
            profile.setAddress(user.getAddress());
            profile.setCreatedAt(user.getCreatedAt());
            profile.setLastLogin(user.getLastLogin());
        }
    }
}
