package com.spazone.controller;

import com.spazone.dto.ApiResponse;
import com.spazone.entity.*;
import com.spazone.repository.AppointmentHandledRepository;
import com.spazone.repository.AppointmentRepository;
import com.spazone.repository.BranchRepository;
import com.spazone.repository.UserRepository;
import com.spazone.service.*;
import com.spazone.dto.ValidationResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/reception")
public class ReceptionController {

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private AppointmentHandledRepository appointmentHandledRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private InvoiceService invoiceService;

    @Autowired
    private AppointmentValidationService appointmentValidationService;

    @Autowired
    private SpaServiceService spaServiceService;

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private RoomService roomService;

    @Autowired
    private ReceptionistKPIService receptionistKPIService;

    @Autowired
    private UserService userService;

    @Autowired
    private BranchService branchService;

    @GetMapping("/appointments")
    public String viewTodayAppointments(Model model) {
        model.addAttribute("appointments", appointmentService.getTodayAppointments());
        return "reception/appointments";
    }

    @PostMapping("/appointments/{id}/checkin")
    public String checkIn(@PathVariable Integer id, Authentication authentication) {
        Appointment appointment = appointmentService.checkIn(id);
        String username = authentication.getName();
        User receptionist = userRepository.findByUsername(username).orElse(null);

        if (appointment != null && receptionist != null) {
            AppointmentHandled handled = new AppointmentHandled();
            handled.setAppointment(appointment);
            handled.setReceptionist(receptionist);
            handled.setHandledAt(LocalDateTime.now());
            appointmentHandledRepository.save(handled);

            // Update KPI metrics for current month
            updateReceptionistKPIMetrics(receptionist.getUserId());
        }

        return "redirect:/reception/appointments";
    }

    @PostMapping("/appointments/{id}/checkout")
    public String checkOut(@PathVariable Integer id) {
        appointmentService.checkOut(id);
        return "redirect:/reception/appointments";
    }

    @GetMapping("/invoices/pending")
    public String viewPendingAppointments(Model model) {
        List<Appointment> pendingAppointments = appointmentRepository.findScheduledAppointmentsWithUnpaidInvoice();
        model.addAttribute("appointments", pendingAppointments);
        return "reception/pending-invoices";
    }

    @PostMapping("/invoices/create")
    public String createInvoice(@RequestParam("appointmentId") Integer appointmentId,
                                @RequestParam("notes") String notes,
                                Authentication authentication,
                                RedirectAttributes redirectAttributes) {
        Appointment appointment = appointmentService.findById(appointmentId);
        invoiceService.updateInvoiceForAppointment(appointment, "CASH", notes);

        // Update KPI metrics for invoice creation
        String username = authentication.getName();
        User receptionist = userRepository.findByUsername(username).orElse(null);
        if (receptionist != null) {
            updateReceptionistKPIMetrics(receptionist.getUserId());
        }

        redirectAttributes.addFlashAttribute("success",
            "✅ Thanh toán thành công! Hóa đơn cho khách hàng " + appointment.getCustomer().getFullName() +
            " đã được cập nhật và email xác nhận đã được gửi.");
        return "redirect:/reception/invoices/pending";
    }

    @GetMapping("/appointments/create")
    public String showCreateAppointmentForm(@RequestParam(value = "branchId", required = false) Integer branchId,
                                            @RequestParam(value = "datePart", required = false) String datePart,
                                            @RequestParam(value = "timePart", required = false) String timePart,
                                            Model model,
                                            Authentication authentication) {
        // Get current receptionist and their branch
        String username = authentication.getName();
        User receptionist = userRepository.findByUsername(username).orElse(null);

        if (receptionist == null || receptionist.getBranch() == null) {
            model.addAttribute("errorMessage", "Bạn chưa được phân công vào chi nhánh nào. Vui lòng liên hệ quản lý.");
            return "reception/appointment-create-new";
        }

        Integer receptionistBranchId = receptionist.getBranch().getBranchId();

        // Filter services by receptionist's branch only
        List<Service> branchServices = spaServiceService.findAllActive()
                .stream()
                .filter(service -> service.getBranch().getBranchId().equals(receptionistBranchId))
                .collect(Collectors.toList());

        model.addAttribute("services", branchServices);
        model.addAttribute("customers", userRepository.findAllCustomers());
        // Filter technicians by receptionist's branch only
        model.addAttribute("technicians", userRepository.findByBranchIdAndRoleName(receptionistBranchId, "TECHNICIAN"));
        model.addAttribute("receptionistBranch", receptionist.getBranch());
        model.addAttribute("availableRooms", java.util.Collections.emptyList());

        if (branchId != null && datePart != null && timePart != null) {
            var branch = branchRepository.findById(branchId).orElse(null);
            if (branch != null) {
                java.time.LocalDateTime startTime = java.time.LocalDateTime.parse(datePart + "T" + timePart);
                java.time.LocalDateTime endTime = startTime.plusHours(1); // or use service duration if available
                // Only get the first available room to avoid NonUniqueResultException
                var availableRooms = roomService.findAvailableRooms(branch, startTime, endTime);
                if (availableRooms != null && !availableRooms.isEmpty()) {
                    model.addAttribute("availableRooms", java.util.Collections.singletonList(availableRooms.get(0)));
                } else {
                    model.addAttribute("availableRooms", java.util.Collections.emptyList());
                }
            } else {
                model.addAttribute("availableRooms", java.util.Collections.emptyList());
            }
        } else {
            model.addAttribute("availableRooms", java.util.Collections.emptyList());
        }
        return "reception/appointment-create-new";
    }

    @PostMapping("/appointments/create")
    public String createAppointment(@RequestParam Integer customerId,
                                    @RequestParam(value = "serviceIds", required = false) List<Integer> serviceIds,
                                    @RequestParam(value = "serviceQuantities", required = false) List<Integer> serviceQuantities,
                                    @RequestParam(value = "serviceId", required = false) Integer singleServiceId, // For backward compatibility
                                    @RequestParam String appointmentDateTime,
                                    @RequestParam Integer technicianId,
                                    @RequestParam(required = false) Integer roomId,
                                    RedirectAttributes redirectAttributes,
                                    Authentication authentication) {
        try {
            // Get current receptionist and their branch
            String username = authentication.getName();
            User receptionist = userRepository.findByUsername(username).orElse(null);

            if (receptionist == null || receptionist.getBranch() == null) {
                redirectAttributes.addFlashAttribute("errorMessage", "Bạn chưa được phân công vào chi nhánh nào.");
                return "redirect:/reception/appointments/create";
            }

            Integer branchId = receptionist.getBranch().getBranchId();

            // Handle both single service (backward compatibility) and multiple services
            List<Integer> finalServiceIds = new ArrayList<>();
            List<Integer> finalServiceQuantities = new ArrayList<>();

            if (serviceIds != null && !serviceIds.isEmpty()) {
                // Multiple services mode
                finalServiceIds = serviceIds;
                finalServiceQuantities = serviceQuantities != null ? serviceQuantities :
                    serviceIds.stream().map(id -> 1).collect(Collectors.toList()); // Default quantity = 1
            } else if (singleServiceId != null) {
                // Single service mode (backward compatibility)
                finalServiceIds.add(singleServiceId);
                finalServiceQuantities.add(1);
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Vui lòng chọn ít nhất một dịch vụ.");
                return "redirect:/reception/appointments/create";
            }

            // Validate services belong to receptionist's branch
            List<Service> selectedServices = new ArrayList<>();
            int totalDuration = 0;
            BigDecimal totalPrice = BigDecimal.ZERO;

            for (int i = 0; i < finalServiceIds.size(); i++) {
                Integer serviceId = finalServiceIds.get(i);
                Integer quantity = i < finalServiceQuantities.size() ? finalServiceQuantities.get(i) : 1;

                Service service = spaServiceService.getServiceById(serviceId);
                if (service == null) {
                    redirectAttributes.addFlashAttribute("errorMessage", "Dịch vụ không tồn tại: " + serviceId);
                    return "redirect:/reception/appointments/create";
                }

                // Validate service belongs to receptionist's branch
                if (!service.getBranch().getBranchId().equals(branchId)) {
                    redirectAttributes.addFlashAttribute("errorMessage",
                        "Dịch vụ '" + service.getName() + "' không thuộc chi nhánh của bạn.");
                    return "redirect:/reception/appointments/create";
                }

                selectedServices.add(service);
                totalDuration += service.getDuration() * quantity;
                totalPrice = totalPrice.add(service.getPrice().multiply(BigDecimal.valueOf(quantity)));
            }

            // Parse appointment date time
            LocalDateTime startTime = LocalDateTime.parse(appointmentDateTime);
            LocalDateTime endTime = startTime.plusMinutes(totalDuration);
            Branch branch = branchService.getById(branchId);

            // BUSINESS RULE VALIDATION: Check for conflicts before creating appointment
            ValidationResult validation = appointmentValidationService.validateForCreation(
                technicianId, roomId, startTime, endTime);

            if (!validation.isValid()) {
                String errorMessage = validation.getFormattedErrorMessage();

                // Add suggested time slots if available
                if (validation.hasSuggestions()) {
                    List<LocalDateTime> suggestions = appointmentValidationService.getSuggestedTimeSlots(
                        technicianId, roomId, startTime, totalDuration, null);

                    if (!suggestions.isEmpty()) {
                        StringBuilder suggestionText = new StringBuilder("\n\nGợi ý thời gian khả dụng:\n");
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm dd/MM/yyyy");
                        for (int i = 0; i < Math.min(3, suggestions.size()); i++) {
                            suggestionText.append("- ").append(suggestions.get(i).format(formatter)).append("\n");
                        }
                        errorMessage += suggestionText.toString();
                    }
                }

                redirectAttributes.addFlashAttribute("errorMessage", errorMessage);
                return "redirect:/reception/appointments/create";
            }

            // Room validation if room is selected
            Room selectedRoom = null;
            if (roomId != null) {
                selectedRoom = roomService.findById(roomId);
                if (selectedRoom == null) {
                    redirectAttributes.addFlashAttribute("errorMessage", "Phòng được chọn không tồn tại.");
                    return "redirect:/reception/appointments/create";
                }

                // Check if room is available
                List<Room> availableRooms = roomService.findAvailableRooms(branch, startTime, endTime);
                if (!availableRooms.contains(selectedRoom)) {
                    redirectAttributes.addFlashAttribute("errorMessage",
                        "Phòng " + selectedRoom.getName() + " đã được đặt trong thời gian này. Vui lòng chọn phòng khác.");
                    return "redirect:/reception/appointments/create";
                }
            }

            // Create appointment with multiple services
            Appointment appointment = createAppointmentWithMultipleServices(
                customerId, finalServiceIds, finalServiceQuantities,
                appointmentDateTime, technicianId, branchId, selectedRoom);

            if (appointment != null) {
                // Generate invoice for the appointment
                try {
                    invoiceService.generateInvoiceForAppointment(appointment);
                    redirectAttributes.addFlashAttribute("success",
                        "Lịch hẹn với " + finalServiceIds.size() + " dịch vụ và hóa đơn đã được tạo thành công.");
                } catch (Exception e) {
                    // If invoice creation fails, still show success for appointment but warn about invoice
                    redirectAttributes.addFlashAttribute("success",
                        "Lịch hẹn đã được tạo thành công, nhưng tạo hóa đơn thất bại: " + e.getMessage());
                }
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Không thể tạo lịch hẹn. Vui lòng thử lại.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error creating appointment: " + e.getMessage());
        }
        return "redirect:/reception/appointments";
    }


    @GetMapping("/appointments/weekly")
    public String showWeeklyAppointments(@RequestParam(required = false) String weekStart,
                                        Model model,
                                        Authentication authentication) {
        // Calculate week start (Monday) and end (Sunday)
        LocalDate weekStartDate;
        if (weekStart != null && !weekStart.isEmpty()) {
            weekStartDate = LocalDate.parse(weekStart);
        } else {
            weekStartDate = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        }

        LocalDate weekEndDate = weekStartDate.plusDays(6);

        // Get weekly appointments
        List<Appointment> weeklyAppointments = appointmentService.getWeeklyAppointments(weekStartDate);

        // Organize appointments by day for easier template processing
        List<List<Appointment>> appointmentsByDay = new java.util.ArrayList<>();
        for (int i = 0; i < 7; i++) {
            LocalDate currentDay = weekStartDate.plusDays(i);
            List<Appointment> dayAppointments = weeklyAppointments.stream()
                .filter(appt -> appt.getAppointmentDate().toLocalDate().equals(currentDay))
                .collect(java.util.stream.Collectors.toList());
            appointmentsByDay.add(dayAppointments);
        }

        // Calculate previous and next week dates for navigation
        LocalDate previousWeek = weekStartDate.minusWeeks(1);
        LocalDate nextWeek = weekStartDate.plusWeeks(1);

        model.addAttribute("appointments", weeklyAppointments);
        model.addAttribute("appointmentsByDay", appointmentsByDay);
        model.addAttribute("weekStart", weekStartDate);
        model.addAttribute("weekEnd", weekEndDate);
        model.addAttribute("previousWeek", previousWeek);
        model.addAttribute("nextWeek", nextWeek);

        return "reception/weekly-appointments";
    }

    @GetMapping("/appointments/available-rooms")
    @ResponseBody
    public List<Room> getAvailableRoomsForReception(@RequestParam(required = false) Integer branchId,
                                                   @RequestParam(required = false) String datePart,
                                                   @RequestParam(required = false) String timePart,
                                                   @RequestParam(required = false) Integer serviceId) {
        try {
            // Return empty list if required parameters are missing
            if (branchId == null || datePart == null || timePart == null || serviceId == null) {
                return new ArrayList<>();
            }

            LocalDateTime startTime = LocalDateTime.parse(datePart + "T" + timePart);
            Service service = spaServiceService.getServiceById(serviceId);
            LocalDateTime endTime = startTime.plusMinutes(service.getDuration());
            Branch branch = branchService.getById(branchId);

            return roomService.findAvailableRooms(branch, startTime, endTime);
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    @PostMapping("/appointments/{id}/cancel")
    public String cancelAppointment(@PathVariable Integer id,
                                    @RequestParam String cancellationReason,
                                    Authentication authentication,
                                    RedirectAttributes redirectAttributes) {
        boolean success = appointmentService.cancelAppointment(id, cancellationReason);

        if (success) {
            // Update KPI metrics for cancellation handling
            String username = authentication.getName();
            User receptionist = userRepository.findByUsername(username).orElse(null);
            if (receptionist != null) {
                updateReceptionistKPIMetrics(receptionist.getUserId());
            }

            redirectAttributes.addFlashAttribute("success", "Hủy lịch hẹn thành công. Capacity phòng đã được hoàn lại.");
        } else {
            redirectAttributes.addFlashAttribute("error", "Không thể hủy lịch hẹn.");
        }
        return "redirect:/reception/appointments";
    }

    // KPI Dashboard for Receptionists
    @GetMapping("/kpi")
    public String viewMyKPI(@RequestParam(value = "month", required = false) Integer month,
                           @RequestParam(value = "year", required = false) Integer year,
                           Authentication authentication,
                           Model model) {

        // Get current receptionist
        String username = authentication.getName();
        User currentReceptionist = userService.findByUsername(username);

        LocalDate now = LocalDate.now();
        if (month == null) month = now.getMonthValue();
        if (year == null) year = now.getYear();

        // Get KPI for current receptionist
        List<ReceptionistKPI> kpis = receptionistKPIService.getKPIsByReceptionistAndMonthAndYear(
            currentReceptionist.getUserId(), month, year);

        // Get current KPI
        ReceptionistKPI currentKPI = null;
        if (!kpis.isEmpty()) {
            currentKPI = kpis.get(0);
        }

        // Get KPI history (last 6 months)
        List<ReceptionistKPI> kpiHistory = receptionistKPIService.getKPIHistoryByReceptionist(
            currentReceptionist.getUserId(), 6);

        // Get performance trends
        List<Object[]> trends = receptionistKPIService.getPerformanceTrendsByReceptionist(
            currentReceptionist.getUserId());

        model.addAttribute("currentKPI", currentKPI);
        model.addAttribute("kpiHistory", kpiHistory);
        model.addAttribute("performanceTrends", trends);
        model.addAttribute("selectedMonth", month);
        model.addAttribute("selectedYear", year);
        model.addAttribute("currentReceptionist", currentReceptionist);

        return "reception/kpi-dashboard";
    }

    // Enhanced check-in with validation
    @PostMapping("/appointments/{id}/checkin-enhanced")
    @ResponseBody
    public ResponseEntity<?> enhancedCheckIn(@PathVariable Integer id, Authentication authentication) {
        try {
            // Check if check-in is allowed
            if (!appointmentService.canCheckIn(id)) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Không thể check-in vào thời điểm này. Vui lòng kiểm tra lại thời gian hẹn."));
            }

            Appointment appointment = appointmentService.checkIn(id);
            if (appointment == null) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Không tìm thấy lịch hẹn hoặc lịch hẹn đã được check-in."));
            }

            // Record receptionist handling
            String username = authentication.getName();
            User receptionist = userRepository.findByUsername(username).orElse(null);

            if (receptionist != null) {
                AppointmentHandled handled = new AppointmentHandled();
                handled.setAppointment(appointment);
                handled.setReceptionist(receptionist);
                handled.setHandledAt(LocalDateTime.now());
                appointmentHandledRepository.save(handled);

                // Update KPI metrics
                updateReceptionistKPIMetrics(receptionist.getUserId());
            }

            // Notify technician
            appointmentService.notifyTechnicianOfCheckin(appointment);

            return ResponseEntity.ok(new ApiResponse(true,
                    "Check-in thành công cho khách hàng " + appointment.getCustomer().getFullName()));

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Lỗi hệ thống: " + e.getMessage()));
        }
    }

    // Get checked-in appointments
    @GetMapping("/appointments/checked-in")
    public String viewCheckedInAppointments(Model model, Authentication authentication) {
        String username = authentication.getName();
        User receptionist = userRepository.findByUsername(username).orElse(null);

        List<Appointment> checkedInAppointments;
        if (receptionist != null && receptionist.getBranch() != null) {
            checkedInAppointments = appointmentService.getCheckedInAppointmentsByBranch(
                    receptionist.getBranch().getBranchId());
        } else {
            checkedInAppointments = appointmentService.getCheckedInAppointments();
        }

        model.addAttribute("appointments", checkedInAppointments);
        return "reception/checked-in-appointments";
    }

    // Add services to unpaid appointment
    @PostMapping("/appointments/{id}/add-services")
    @ResponseBody
    public ResponseEntity<?> addServicesToUnpaidAppointment(
            @PathVariable Integer id,
            @RequestParam("serviceIds") List<Integer> serviceIds,
            Authentication authentication) {
        try {
            // Check if services can be added to this appointment
            if (!appointmentService.canAddServicesToUnpaidAppointment(id)) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Không thể thêm dịch vụ vào lịch hẹn này. Hóa đơn có thể đã được thanh toán."));
            }

            // Validate service IDs
            if (serviceIds == null || serviceIds.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Vui lòng chọn ít nhất một dịch vụ để thêm."));
            }

            // Check technician availability for extended time
            Appointment appointment = appointmentService.findById(id);
            List<Service> servicesToAdd = serviceIds.stream()
                    .map(serviceId -> spaServiceService.getServiceById(serviceId))
                    .toList();

            int additionalMinutes = servicesToAdd.stream()
                    .mapToInt(Service::getDuration)
                    .sum();

            if (!appointmentService.checkTechnicianAvailabilityForExtension(id, additionalMinutes)) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Kỹ thuật viên không rảnh để thực hiện thêm dịch vụ trong thời gian này."));
            }

            // Add services to appointment
            appointmentService.addServicesToAppointment(id, serviceIds);

            // Notify technician about service addition
            appointmentService.notifyTechnicianOfServiceAddition(appointment, servicesToAdd);

            // Update KPI metrics
            String username = authentication.getName();
            User receptionist = userRepository.findByUsername(username).orElse(null);
            if (receptionist != null) {
                updateReceptionistKPIMetrics(receptionist.getUserId());
            }

            return ResponseEntity.ok(new ApiResponse(true,
                    "Đã thêm " + serviceIds.size() + " dịch vụ vào lịch hẹn thành công."));

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Lỗi khi thêm dịch vụ: " + e.getMessage()));
        }
    }

    // Create separate appointment for paid invoice scenario
    @PostMapping("/appointments/{id}/add-services-separate")
    @ResponseBody
    public ResponseEntity<?> createSeparateAppointmentForServices(
            @PathVariable Integer id,
            @RequestParam("serviceIds") List<Integer> serviceIds,
            Authentication authentication) {
        try {
            // Validate service IDs
            if (serviceIds == null || serviceIds.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Vui lòng chọn ít nhất một dịch vụ để thêm."));
            }

            // Create separate appointment for additional services
            Appointment newAppointment = appointmentService.createAdditionalServiceAppointment(id, serviceIds);

            // Update KPI metrics
            String username = authentication.getName();
            User receptionist = userRepository.findByUsername(username).orElse(null);
            if (receptionist != null) {
                updateReceptionistKPIMetrics(receptionist.getUserId());
            }

            return ResponseEntity.ok(new ApiResponse(true,
                    "Đã tạo lịch hẹn mới #" + newAppointment.getAppointmentId() +
                    " cho " + serviceIds.size() + " dịch vụ bổ sung."));

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Lỗi khi tạo lịch hẹn mới: " + e.getMessage()));
        }
    }

    // Get available services for adding to appointment
    @GetMapping("/appointments/{id}/available-services")
    @ResponseBody
    public ResponseEntity<?> getAvailableServicesForAppointment(@PathVariable Integer id) {
        try {
            Appointment appointment = appointmentService.findById(id);
            if (appointment == null) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Không tìm thấy lịch hẹn."));
            }

            // Get all active services for the branch and convert to DTO to avoid circular reference
            List<Service> services = spaServiceService.findAllActive()
                    .stream()
                    .filter(service -> service.getBranch().getBranchId().equals(appointment.getBranch().getBranchId()))
                    .toList();

            // Convert to simple DTO to avoid Jackson circular reference
            List<Map<String, Object>> availableServices = services.stream()
                    .map(service -> {
                        Map<String, Object> serviceDto = new HashMap<>();
                        serviceDto.put("serviceId", service.getServiceId());
                        serviceDto.put("name", service.getName());
                        serviceDto.put("description", service.getDescription());
                        serviceDto.put("price", service.getPrice());
                        serviceDto.put("duration", service.getDuration());
                        serviceDto.put("status", service.getStatus());
                        serviceDto.put("imageUrl", service.getImageUrl());
                        serviceDto.put("branchId", service.getBranch() != null ? service.getBranch().getBranchId() : null);
                        serviceDto.put("branchName", service.getBranch() != null ? service.getBranch().getName() : null);
                        serviceDto.put("categoryId", service.getCategory() != null ? service.getCategory().getCategoryId() : null);
                        serviceDto.put("categoryName", service.getCategory() != null ? service.getCategory().getName() : null);
                        return serviceDto;
                    })
                    .collect(Collectors.toList());

            return ResponseEntity.ok(availableServices);

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Lỗi khi lấy danh sách dịch vụ: " + e.getMessage()));
        }
    }

    // Enhanced Service Management Endpoints for Appointment Edit

    @GetMapping("/appointments/{id}/invoice-status")
    @ResponseBody
    public ResponseEntity<?> getAppointmentInvoiceStatus(@PathVariable Integer id) {
        try {
            Appointment appointment = appointmentService.findById(id);
            if (appointment == null) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Không tìm thấy lịch hẹn."));
            }

            // Get invoice for this appointment
            com.spazone.entity.Invoice invoice = invoiceService.findByAppointment(appointment);

            if (invoice == null) {
                Map<String, Object> response = new java.util.HashMap<>();
                response.put("success", true);
                response.put("status", "no_invoice");
                response.put("message", "Chưa có hóa đơn");
                return ResponseEntity.ok(response);
            }

            Map<String, Object> response = new java.util.HashMap<>();
            response.put("success", true);
            response.put("status", invoice.getPaymentStatus());
            response.put("amount", invoice.getTotalAmount());
            response.put("invoiceId", invoice.getInvoiceId());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Lỗi khi lấy trạng thái hóa đơn: " + e.getMessage()));
        }
    }

    @GetMapping("/appointments/{id}/services")
    @ResponseBody
    public ResponseEntity<?> getAppointmentServices(@PathVariable Integer id) {
        try {
            Appointment appointment = appointmentService.findById(id);
            if (appointment == null) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Không tìm thấy lịch hẹn."));
            }

            List<Map<String, Object>> services = appointment.getAppointmentServices().stream()
                    .map(aps -> {
                        Map<String, Object> serviceMap = new java.util.HashMap<>();
                        serviceMap.put("serviceId", aps.getService().getServiceId());
                        serviceMap.put("name", aps.getService().getName());
                        serviceMap.put("price", aps.getService().getPrice());
                        serviceMap.put("duration", aps.getService().getDuration());
                        serviceMap.put("quantity", aps.getQuantity());
                        return serviceMap;
                    })
                    .collect(Collectors.toList());

            Map<String, Object> response = new java.util.HashMap<>();
            response.put("success", true);
            response.put("services", services);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Lỗi khi lấy danh sách dịch vụ: " + e.getMessage()));
        }
    }

    @PostMapping("/appointments/{id}/services/add")
    @ResponseBody
    public ResponseEntity<?> addServiceToAppointmentEdit(
            @PathVariable Integer id,
            @RequestBody Map<String, Object> request,
            Authentication authentication) {
        try {
            Integer serviceId = (Integer) request.get("serviceId");
            Integer quantity = (Integer) request.get("quantity");

            if (serviceId == null || quantity == null || quantity < 1 || quantity > 10) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Dữ liệu không hợp lệ."));
            }

            // Check if appointment can be modified
            if (!appointmentService.canAddServicesToUnpaidAppointment(id)) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Không thể thêm dịch vụ vào lịch hẹn này. Hóa đơn có thể đã được thanh toán."));
            }

            // BUSINESS RULE VALIDATION: Check for conflicts when adding service
            Appointment appointment = appointmentService.findById(id);
            Service service = spaServiceService.getServiceById(serviceId);

            // Calculate new end time with additional service
            int additionalMinutes = service.getDuration() * quantity;
            LocalDateTime currentEndTime = appointment.getEndTime();
            LocalDateTime newEndTime = currentEndTime.plusMinutes(additionalMinutes);

            // Validate technician and room availability for extended time
            ValidationResult validation = appointmentValidationService.validateForEditing(
                id, appointment.getTechnician().getUserId(),
                appointment.getRoom() != null ? appointment.getRoom().getId() : null,
                appointment.getStartTime(), newEndTime);

            if (!validation.isValid()) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, validation.getFormattedErrorMessage()));
            }

            // Add service to appointment
            appointmentService.addServiceToAppointment(id, serviceId, quantity);

            // Update invoice after service addition
            try {
                Appointment updatedAppointment = appointmentService.findById(id);
                // Calculate correct total price manually
                BigDecimal correctTotalPrice = updatedAppointment.getAppointmentServices().stream()
                        .map(aps -> {
                            BigDecimal price = aps.getCustomPrice() != null ? aps.getCustomPrice() : aps.getService().getPrice();
                            return price.multiply(BigDecimal.valueOf(aps.getQuantity()));
                        })
                        .reduce(BigDecimal.ZERO, BigDecimal::add);

                updateInvoiceAfterServiceChange(updatedAppointment, correctTotalPrice);
            } catch (Exception e) {
                System.err.println("Warning: Could not update invoice after service addition: " + e.getMessage());
                // Continue execution - service addition was successful even if invoice update failed
            }

            // Update KPI metrics
            String username = authentication.getName();
            User receptionist = userRepository.findByUsername(username).orElse(null);
            if (receptionist != null) {
                updateReceptionistKPIMetrics(receptionist.getUserId());
            }

            return ResponseEntity.ok(new ApiResponse(true, "Đã thêm dịch vụ và cập nhật hóa đơn thành công."));

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Lỗi khi thêm dịch vụ: " + e.getMessage()));
        }
    }

    @PostMapping("/appointments/{id}/services/update-quantity")
    @ResponseBody
    public ResponseEntity<?> updateServiceQuantity(
            @PathVariable Integer id,
            @RequestBody Map<String, Object> request,
            Authentication authentication) {
        try {
            Integer serviceId = (Integer) request.get("serviceId");
            Integer quantity = (Integer) request.get("quantity");

            if (serviceId == null || quantity == null || quantity < 1 || quantity > 10) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Dữ liệu không hợp lệ."));
            }

            // Check if appointment can be modified
            if (!appointmentService.canAddServicesToUnpaidAppointment(id)) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Không thể sửa đổi lịch hẹn này. Hóa đơn có thể đã được thanh toán."));
            }

            // Update service quantity
            Appointment appointment = appointmentService.findById(id);
            Service service = spaServiceService.getServiceById(serviceId);

            // Update service quantity using proper service method
            System.out.println("Updating quantity for appointment " + id + ", service " + serviceId + " to quantity " + quantity);
            try {
                // Do everything in a single service call to avoid transaction nesting
                appointmentService.updateServiceQuantityAndRecalculate(id, serviceId, quantity);
                System.out.println("Successfully updated service quantity and recalculated totals");
            } catch (Exception e) {
                System.err.println("Error updating service quantity: " + e.getMessage());
                return ResponseEntity.internalServerError()
                        .body(new ApiResponse(false, "Lỗi khi cập nhật số lượng dịch vụ: " + e.getMessage()));
            }

            // Update invoice after quantity change - will be handled in service method
            // No need to call updateInvoiceAfterServiceChange here as it's handled in updateServiceQuantityAndRecalculate

            // Update KPI metrics
            String username = authentication.getName();
            User receptionist = userRepository.findByUsername(username).orElse(null);
            if (receptionist != null) {
                updateReceptionistKPIMetrics(receptionist.getUserId());
            }

            return ResponseEntity.ok(new ApiResponse(true, "Đã cập nhật số lượng dịch vụ và hóa đơn thành công."));

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Lỗi khi cập nhật số lượng: " + e.getMessage()));
        }
    }

    @PostMapping("/appointments/{id}/services/remove")
    @ResponseBody
    public ResponseEntity<?> removeServiceFromAppointment(
            @PathVariable Integer id,
            @RequestBody Map<String, Object> request,
            Authentication authentication) {
        try {
            Integer serviceId = (Integer) request.get("serviceId");

            if (serviceId == null) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Dữ liệu không hợp lệ."));
            }

            // Check if appointment can be modified
            if (!appointmentService.canAddServicesToUnpaidAppointment(id)) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Không thể sửa đổi lịch hẹn này. Hóa đơn có thể đã được thanh toán."));
            }

            Appointment appointment = appointmentService.findById(id);

            // Check if this is the last service
            if (appointment.getAppointmentServices().size() <= 1) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Không thể xóa dịch vụ cuối cùng. Lịch hẹn phải có ít nhất một dịch vụ."));
            }

            // Remove the service from database using proper service method
            System.out.println("Removing service " + serviceId + " from appointment " + id);
            try {
                // Do everything in a single service call to avoid transaction nesting
                appointmentService.removeServiceAndRecalculate(id, serviceId);
                System.out.println("Successfully removed service and recalculated totals");
            } catch (Exception e) {
                System.err.println("Error removing service from appointment: " + e.getMessage());
                return ResponseEntity.internalServerError()
                        .body(new ApiResponse(false, "Lỗi khi xóa dịch vụ: " + e.getMessage()));
            }

            // Update invoice after service removal - will be handled in service method
            // No need to call updateInvoiceAfterServiceChange here as it's handled in removeServiceAndRecalculate

            // Update KPI metrics
            String username = authentication.getName();
            User receptionist = userRepository.findByUsername(username).orElse(null);
            if (receptionist != null) {
                updateReceptionistKPIMetrics(receptionist.getUserId());
            }

            return ResponseEntity.ok(new ApiResponse(true, "Đã xóa dịch vụ và cập nhật hóa đơn thành công."));

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Lỗi khi xóa dịch vụ: " + e.getMessage()));
        }
    }

    // Enhanced Appointment Creation for Paid Invoices
    @GetMapping("/appointments/create-additional")
    public String showCreateAdditionalAppointmentForm(
            @RequestParam Integer originalAppointmentId,
            Model model,
            Authentication authentication) {
        try {
            // Get original appointment
            Appointment originalAppointment = appointmentService.findById(originalAppointmentId);
            if (originalAppointment == null) {
                model.addAttribute("error", "Không tìm thấy lịch hẹn gốc.");
                return "redirect:/reception/appointments";
            }

            // Get receptionist's branch
            String username = authentication.getName();
            User receptionist = userRepository.findByUsername(username).orElse(null);
            Branch branch = receptionist != null ? receptionist.getBranch() : null;

            if (branch == null) {
                model.addAttribute("error", "Không thể xác định chi nhánh của lễ tân.");
                return "redirect:/reception/appointments";
            }

            // Get available services for the branch
            List<Service> services = spaServiceService.findAllActive()
                    .stream()
                    .filter(service -> service.getBranch().getBranchId().equals(branch.getBranchId()))
                    .collect(Collectors.toList());

            // Get available technicians
            List<User> technicians = userService.findTechniciansByBranch(branch.getBranchId());

            // Prepare model
            model.addAttribute("originalAppointment", originalAppointment);
            model.addAttribute("services", services);
            model.addAttribute("technicians", technicians);
            model.addAttribute("branch", branch);

            return "reception/appointment-create-additional";

        } catch (Exception e) {
            model.addAttribute("error", "Lỗi khi tải form tạo lịch hẹn: " + e.getMessage());
            return "redirect:/reception/appointments";
        }
    }

    @PostMapping("/appointments/create-additional")
    @ResponseBody
    public ResponseEntity<?> createAdditionalAppointment(
            @RequestParam Integer originalAppointmentId,
            @RequestParam List<Integer> serviceIds,
            @RequestParam(required = false) Integer technicianId,
            @RequestParam(defaultValue = "immediate") String schedulingType,
            Authentication authentication) {
        try {
            if (serviceIds == null || serviceIds.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Vui lòng chọn ít nhất một dịch vụ."));
            }

            // Create new appointment for additional services
            Appointment newAppointment = appointmentService.createAdditionalServiceAppointment(originalAppointmentId, serviceIds);

            // Update KPI metrics
            String username = authentication.getName();
            User receptionist = userRepository.findByUsername(username).orElse(null);
            if (receptionist != null) {
                updateReceptionistKPIMetrics(receptionist.getUserId());
            }

            return ResponseEntity.ok(new ApiResponse(true,
                    "Đã tạo lịch hẹn mới #" + newAppointment.getAppointmentId() +
                    " cho " + serviceIds.size() + " dịch vụ bổ sung."));

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Lỗi khi tạo lịch hẹn mới: " + e.getMessage()));
        }
    }

    // Helper method to update invoice after service changes
    private void updateInvoiceAfterServiceChange(Appointment appointment, BigDecimal correctTotalPrice) {
        try {
            // Find existing invoice for this appointment
            Invoice existingInvoice = invoiceService.findByAppointment(appointment);

            if (existingInvoice != null) {
                // Check if invoice is already paid
                if ("paid".equals(existingInvoice.getPaymentStatus())) {
                    System.out.println("Invoice already paid, cannot update: " + existingInvoice.getInvoiceId());
                    return;
                }

                // Use the correctly calculated total price
                BigDecimal newSubtotal = correctTotalPrice;

                // Calculate tax (assuming 10% VAT)
                BigDecimal taxRate = new BigDecimal("0.10");
                BigDecimal newTax = newSubtotal.multiply(taxRate);
                BigDecimal newFinalAmount = newSubtotal.add(newTax);

                // Update invoice amounts using correct method names
                existingInvoice.setTotalAmount(newSubtotal);
                existingInvoice.setTaxAmount(newTax);
                existingInvoice.setFinalAmount(newFinalAmount);
                existingInvoice.setUpdatedAt(LocalDateTime.now());

                // Save updated invoice
                invoiceService.save(existingInvoice);

                System.out.println("Updated invoice " + existingInvoice.getInvoiceId() +
                                 " with correct final amount: " + newFinalAmount +
                                 " (subtotal: " + newSubtotal + ", tax: " + newTax + ")");
            } else {
                // No existing invoice, generate new one
                invoiceService.generateInvoiceForAppointment(appointment);
                System.out.println("Generated new invoice for appointment: " + appointment.getAppointmentId());
            }

        } catch (Exception e) {
            System.err.println("Error updating invoice after service change: " + e.getMessage());
            throw e; // Re-throw to be handled by caller
        }
    }

    // Test endpoint to check connection pool health
    @GetMapping("/appointments/test-connection")
    @ResponseBody
    public ResponseEntity<?> testConnectionPool() {
        try {
            System.out.println("Testing connection pool...");

            // Simple database query to test connection
            long count = appointmentRepository.count();

            return ResponseEntity.ok(new ApiResponse(true,
                    "Connection pool is healthy. Total appointments: " + count));

        } catch (Exception e) {
            System.err.println("Connection pool test failed: " + e.getMessage());
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Connection pool test failed: " + e.getMessage()));
        }
    }

    // Test endpoint for appointment validation
    @GetMapping("/appointments/validate-time")
    @ResponseBody
    public ResponseEntity<?> validateAppointmentTime(@RequestParam Integer technicianId,
                                                    @RequestParam(required = false) Integer roomId,
                                                    @RequestParam String startTime,
                                                    @RequestParam String endTime,
                                                    @RequestParam(required = false) Integer excludeAppointmentId) {
        try {
            LocalDateTime start = LocalDateTime.parse(startTime);
            LocalDateTime end = LocalDateTime.parse(endTime);

            ValidationResult validation = appointmentValidationService.validateAppointmentScheduling(
                technicianId, roomId, start, end, excludeAppointmentId);

            Map<String, Object> response = new HashMap<>();
            response.put("valid", validation.isValid());
            response.put("errors", validation.getErrorMessages());
            response.put("conflicts", validation.getConflicts());

            if (!validation.isValid()) {
                List<LocalDateTime> suggestions = appointmentValidationService.getSuggestedTimeSlots(
                    technicianId, roomId, start,
                    (int) java.time.Duration.between(start, end).toMinutes(),
                    excludeAppointmentId);
                response.put("suggestions", suggestions);
            }

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Validation error: " + e.getMessage()));
        }
    }

    // Endpoint for editing appointment details (time, technician, room)
    @PostMapping("/appointments/{id}/edit")
    @ResponseBody
    public ResponseEntity<?> editAppointmentDetails(@PathVariable Integer id,
                                                   @RequestBody Map<String, Object> request,
                                                   Authentication authentication) {
        try {
            // Get current receptionist and validate permissions
            String username = authentication.getName();
            User receptionist = userRepository.findByUsername(username).orElse(null);

            if (receptionist == null || receptionist.getBranch() == null) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Bạn chưa được phân công vào chi nhánh nào."));
            }

            Appointment appointment = appointmentService.findById(id);
            if (appointment == null) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponse(false, "Không tìm thấy lịch hẹn."));
            }

            boolean appointmentChanged = false;
            LocalDateTime newStartTime = appointment.getStartTime();
            LocalDateTime newEndTime = appointment.getEndTime();
            Integer newTechnicianId = appointment.getTechnician().getUserId();
            Integer newRoomId = appointment.getRoom() != null ? appointment.getRoom().getId() : null;

            // Update start time if provided
            if (request.containsKey("startTime") && request.get("startTime") != null) {
                String startTimeStr = (String) request.get("startTime");
                newStartTime = LocalDateTime.parse(startTimeStr);

                // Calculate new end time based on appointment duration
                int totalDuration = appointment.getTotalDuration();
                newEndTime = newStartTime.plusMinutes(totalDuration);
                appointmentChanged = true;
            }

            // Update technician if provided
            if (request.containsKey("technicianId") && request.get("technicianId") != null) {
                newTechnicianId = (Integer) request.get("technicianId");
                if (!newTechnicianId.equals(appointment.getTechnician().getUserId())) {
                    appointmentChanged = true;
                }
            }

            // Update room if provided
            if (request.containsKey("roomId")) {
                Object roomIdObj = request.get("roomId");
                newRoomId = roomIdObj != null ? (Integer) roomIdObj : null;

                Integer currentRoomId = appointment.getRoom() != null ? appointment.getRoom().getId() : null;
                if (!Objects.equals(newRoomId, currentRoomId)) {
                    appointmentChanged = true;
                }
            }

            // BUSINESS RULE VALIDATION: Check for conflicts if anything changed
            if (appointmentChanged) {
                ValidationResult validation = appointmentValidationService.validateForEditing(
                    id, newTechnicianId, newRoomId, newStartTime, newEndTime);

                if (!validation.isValid()) {
                    return ResponseEntity.badRequest()
                            .body(new ApiResponse(false, validation.getFormattedErrorMessage()));
                }

                // Apply changes if validation passed
                appointment.setStartTime(newStartTime);
                appointment.setEndTime(newEndTime);
                appointment.setAppointmentDate(newStartTime);

                // Update technician if changed
                if (!newTechnicianId.equals(appointment.getTechnician().getUserId())) {
                    User newTechnician = userRepository.findById(newTechnicianId).orElse(null);
                    if (newTechnician != null) {
                        appointment.setTechnician(newTechnician);
                    }
                }

                // Update room if changed
                Integer currentRoomId = appointment.getRoom() != null ? appointment.getRoom().getId() : null;
                if (!Objects.equals(newRoomId, currentRoomId)) {
                    if (newRoomId != null) {
                        Room newRoom = roomService.findById(newRoomId);
                        appointment.setRoom(newRoom);
                    } else {
                        appointment.setRoom(null);
                    }
                }

                // Save changes
                appointmentService.update(appointment);

                return ResponseEntity.ok(new ApiResponse(true, "Cập nhật lịch hẹn thành công."));
            } else {
                return ResponseEntity.ok(new ApiResponse(true, "Không có thay đổi nào được thực hiện."));
            }

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Lỗi khi cập nhật lịch hẹn: " + e.getMessage()));
        }
    }

    // Helper method to create appointment with multiple services
    private Appointment createAppointmentWithMultipleServices(Integer customerId, List<Integer> serviceIds,
                                                             List<Integer> serviceQuantities, String appointmentDateTime,
                                                             Integer technicianId, Integer branchId, Room selectedRoom) {
        try {
            // Create appointment with first service (for compatibility with existing system)
            Integer primaryServiceId = serviceIds.get(0);
            boolean success = appointmentService.createAppointment(customerId, primaryServiceId, appointmentDateTime, technicianId, branchId);

            if (!success) {
                return null;
            }

            // Find the created appointment
            Appointment appointment = appointmentService.findLatestAppointment(customerId, primaryServiceId, technicianId, branchId);
            if (appointment == null) {
                return null;
            }

            // Set room if selected
            if (selectedRoom != null) {
                appointment.setRoom(selectedRoom);
                appointmentService.update(appointment);
            }

            // Add additional services (if any)
            for (int i = 1; i < serviceIds.size(); i++) {
                Integer serviceId = serviceIds.get(i);
                Integer quantity = i < serviceQuantities.size() ? serviceQuantities.get(i) : 1;

                try {
                    appointmentService.addServiceToAppointment(appointment.getAppointmentId(), serviceId, quantity);
                    System.out.println("Added service " + serviceId + " with quantity " + quantity + " to appointment " + appointment.getAppointmentId());
                } catch (Exception e) {
                    System.err.println("Failed to add service " + serviceId + " to appointment: " + e.getMessage());
                    // Continue with other services
                }
            }

            // Update quantities for all services (including the primary one if quantity > 1)
            for (int i = 0; i < serviceIds.size(); i++) {
                Integer serviceId = serviceIds.get(i);
                Integer quantity = i < serviceQuantities.size() ? serviceQuantities.get(i) : 1;

                if (quantity > 1) {
                    try {
                        appointmentService.updateServiceQuantityAndRecalculate(appointment.getAppointmentId(), serviceId, quantity);
                        System.out.println("Updated service " + serviceId + " quantity to " + quantity + " in appointment " + appointment.getAppointmentId());
                    } catch (Exception e) {
                        System.err.println("Failed to update quantity for service " + serviceId + ": " + e.getMessage());
                    }
                }
            }

            // Recalculate totals and update duration
            try {
                appointmentService.recalculateAppointmentTotals(appointment.getAppointmentId());
                appointmentService.updateAppointmentDuration(appointment.getAppointmentId());
            } catch (Exception e) {
                System.err.println("Failed to recalculate appointment totals: " + e.getMessage());
            }

            return appointment;

        } catch (Exception e) {
            System.err.println("Error creating appointment with multiple services: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    // Helper method to update KPI metrics
    private void updateReceptionistKPIMetrics(Integer receptionistId) {
        try {
            LocalDate now = LocalDate.now();
            receptionistKPIService.updateActualMetrics(receptionistId, now.getMonthValue(), now.getYear());
        } catch (Exception e) {
            // Log error but don't interrupt the main flow
            System.err.println("Error updating KPI metrics: " + e.getMessage());
        }
    }
}
