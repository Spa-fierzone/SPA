package com.spazone.service;

import com.spazone.entity.Notification;
import com.spazone.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;

public interface NotificationService {

    /**
     * Create and save a new notification
     */
    Notification createNotification(User user, String title, String message, Notification.NotificationType type);

    /**
     * Create notification with sender
     */
    Notification createNotification(User user, User sender, String title, String message, Notification.NotificationType type);

    /**
     * Create notification with related entity
     */
    Notification createNotificationWithEntity(User user, User sender, String title, String message, 
                                            Notification.NotificationType type, String entityType, Integer entityId);

    /**
     * Create notification with action URL
     */
    Notification createNotificationWithAction(User user, User sender, String title, String message, 
                                            Notification.NotificationType type, String actionUrl);

    /**
     * Get all notifications for a user
     */
    List<Notification> getNotificationsForUser(User user);

    /**
     * Get notifications for a user with pagination
     */
    Page<Notification> getNotificationsForUser(User user, Pageable pageable);

    /**
     * Get unread notifications for a user
     */
    List<Notification> getUnreadNotifications(User user);

    /**
     * Count unread notifications for a user
     */
    Long countUnreadNotifications(User user);

    /**
     * Mark notification as read
     */
    void markAsRead(Integer notificationId);

    /**
     * Mark all notifications as read for a user
     */
    void markAllAsRead(User user);

    /**
     * Delete notification
     */
    void deleteNotification(Integer notificationId);

    /**
     * Get notification by ID
     */
    Notification getNotificationById(Integer notificationId);

    /**
     * Send schedule change notification
     */
    void sendScheduleChangeNotification(User employee, User manager, String scheduleDetails);

    /**
     * Send appointment update notification
     */
    void sendAppointmentUpdateNotification(User customer, String appointmentDetails, String status);

    /**
     * Send treatment record update notification
     */
    void sendTreatmentRecordUpdateNotification(User customer, User technician, String treatmentDetails);

    /**
     * Send user role change notification
     */
    void sendUserRoleChangeNotification(User user, String oldRole, String newRole, User changedBy);

    /**
     * Send password change notification
     */
    void sendPasswordChangeNotification(User user);

    /**
     * Send system alert notification
     */
    void sendSystemAlert(List<User> users, String title, String message);

    /**
     * Send reminder notification
     */
    void sendReminder(User user, String title, String message, LocalDateTime reminderTime);

    /**
     * Send approval request notification
     */
    void sendApprovalRequest(User approver, User requester, String requestDetails, String actionUrl);

    /**
     * Clean up old notifications
     */
    void cleanupOldNotifications(int daysToKeep);

    /**
     * Get recent notifications (last N days)
     */
    List<Notification> getRecentNotifications(User user, int days);

    /**
     * Get notifications by type
     */
    List<Notification> getNotificationsByType(User user, Notification.NotificationType type);

    /**
     * Broadcast notification to multiple users
     */
    void broadcastNotification(List<User> users, String title, String message, Notification.NotificationType type);

    /**
     * Send notification to all managers
     */
    void sendToAllManagers(String title, String message, Notification.NotificationType type);

    /**
     * Send notification to all users with specific role
     */
    void sendToUsersWithRole(String roleName, String title, String message, Notification.NotificationType type);

    /**
     * Send welcome notification to new customer
     */
    void sendWelcomeNotification(User customer);
}
