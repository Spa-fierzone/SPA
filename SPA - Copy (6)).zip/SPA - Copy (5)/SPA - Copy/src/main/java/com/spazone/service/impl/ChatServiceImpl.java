package com.spazone.service.impl;

import com.spazone.entity.*;
import com.spazone.repository.ChatMessageRepository;
import com.spazone.repository.ChatParticipantRepository;
import com.spazone.repository.ChatRoomRepository;
import com.spazone.service.ChatService;
import com.spazone.service.NotificationService;
import com.spazone.service.UserService;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Implementation of ChatService interface
 * Provides comprehensive chat functionality with security and business logic
 * Integrates with existing SpaZone user management and notification systems
 */
@Service
@Transactional
public class ChatServiceImpl implements ChatService {

    private static final Logger logger = LoggerFactory.getLogger(ChatServiceImpl.class);

    @Autowired
    private ChatRoomRepository chatRoomRepository;

    @Autowired
    private ChatParticipantRepository chatParticipantRepository;

    @Autowired
    private ChatMessageRepository chatMessageRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private NotificationService notificationService;

    // ===== CHAT ROOM MANAGEMENT =====

    @Override
    public ChatRoom createChatRoom(String roomName, String roomType, User creator, Integer branchId, String description) {
        logger.info("Creating chat room: {} of type: {} by user: {}", roomName, roomType, creator.getUsername());

        // Validate room creation permissions
        if (!canUserCreateRoom(creator, roomType)) {
            throw new AccessDeniedException("User không có quyền tạo phòng chat loại: " + roomType);
        }

        ChatRoom chatRoom = new ChatRoom();
        chatRoom.setRoomName(roomName);
        chatRoom.setRoomType(roomType);
        chatRoom.setCreatedBy(creator);
        chatRoom.setRoomDescription(description);

        // Set branch if provided and user has access
        if (branchId != null) {
            if (creator.getBranch() == null || !creator.getBranch().getBranchId().equals(branchId)) {
                if (!hasRole(creator, "ADMIN")) {
                    throw new AccessDeniedException("User không có quyền tạo phòng chat cho chi nhánh khác");
                }
            }
            chatRoom.setBranch(creator.getBranch());
        }

        // Set max participants based on room type
        switch (roomType) {
            case "DIRECT":
                chatRoom.setMaxParticipants(2);
                break;
            case "SYSTEM":
                chatRoom.setMaxParticipants(1000);
                break;
            default:
                chatRoom.setMaxParticipants(50);
        }

        ChatRoom savedRoom = chatRoomRepository.save(chatRoom);

        // Add creator as admin participant
        addParticipantInternal(savedRoom, creator, "ADMIN");

        logger.info("Created chat room with ID: {}", savedRoom.getRoomId());
        return savedRoom;
    }

    @Override
    public ChatRoom getOrCreateDirectMessageRoom(User user1, User user2) {
        logger.debug("Getting or creating direct message room between {} and {}", user1.getUsername(), user2.getUsername());

        // Check if users can communicate directly
        if (!canUsersCommunicateDirectly(user1, user2)) {
            throw new AccessDeniedException("Users không thể giao tiếp trực tiếp với nhau");
        }

        // Try to find existing direct message room
        Optional<ChatRoom> existingRoom = chatRoomRepository.findDirectMessageRoom(user1.getUserId(), user2.getUserId());
        
        if (existingRoom.isPresent()) {
            logger.debug("Found existing direct message room: {}", existingRoom.get().getRoomId());
            return existingRoom.get();
        }

        // Create new direct message room
        String roomName = user1.getFullName() + " & " + user2.getFullName();
        ChatRoom directRoom = createChatRoom(roomName, "DIRECT", user1, null, "Tin nhắn trực tiếp");

        // Add second user as member
        addParticipantInternal(directRoom, user2, "MEMBER");

        logger.info("Created new direct message room: {}", directRoom.getRoomId());
        return directRoom;
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ChatRoom> getChatRoom(Integer roomId, User requestingUser) {
        if (!canUserAccessRoom(requestingUser, roomId)) {
            return Optional.empty();
        }
        return chatRoomRepository.findById(roomId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ChatRoom> getAccessibleChatRooms(User user) {
        Integer branchId = user.getBranch() != null ? user.getBranch().getBranchId() : null;
        return chatRoomRepository.findAccessibleRooms(user.getUserId(), branchId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ChatRoom> getChatRoomsWithUnreadMessages(User user) {
        return chatRoomRepository.findRoomsWithUnreadMessages(user.getUserId());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ChatRoom> searchChatRooms(String searchTerm, User user) {
        List<ChatRoom> allRooms = chatRoomRepository.searchRoomsByName(searchTerm);
        // Filter rooms user can access
        return allRooms.stream()
                .filter(room -> canUserAccessRoom(user, room.getRoomId()))
                .toList();
    }

    @Override
    public ChatRoom updateChatRoom(Integer roomId, String roomName, String description, User requestingUser) {
        ChatRoom room = chatRoomRepository.findById(roomId)
                .orElseThrow(() -> new IllegalArgumentException("Phòng chat không tồn tại"));

        if (!canUserModerateRoom(requestingUser, roomId)) {
            throw new AccessDeniedException("Không có quyền chỉnh sửa phòng chat này");
        }

        room.setRoomName(roomName);
        room.setRoomDescription(description);
        
        return chatRoomRepository.save(room);
    }

    @Override
    public boolean deactivateChatRoom(Integer roomId, User requestingUser) {
        ChatRoom room = chatRoomRepository.findById(roomId)
                .orElseThrow(() -> new IllegalArgumentException("Phòng chat không tồn tại"));

        if (!canUserModerateRoom(requestingUser, roomId) && !hasRole(requestingUser, "ADMIN")) {
            throw new AccessDeniedException("Không có quyền xóa phòng chat này");
        }

        room.setIsActive(false);
        chatRoomRepository.save(room);
        
        logger.info("Deactivated chat room: {} by user: {}", roomId, requestingUser.getUsername());
        return true;
    }

    // ===== PARTICIPANT MANAGEMENT =====

    @Override
    public ChatParticipant addParticipant(Integer roomId, Integer userId, String role, User requestingUser) {
        if (!canUserModerateRoom(requestingUser, roomId)) {
            throw new AccessDeniedException("Không có quyền thêm thành viên vào phòng chat này");
        }

        ChatRoom room = chatRoomRepository.findById(roomId)
                .orElseThrow(() -> new IllegalArgumentException("Phòng chat không tồn tại"));

        User userToAddOpt = userService.findById(userId);
        if (userToAddOpt == null) {
            throw new IllegalArgumentException("User không tồn tại");
        }
        User userToAdd = userToAddOpt;

        return addParticipantInternal(room, userToAdd, role);
    }

    @Override
    public boolean removeParticipant(Integer roomId, Integer userId, User requestingUser) {
        if (!canUserModerateRoom(requestingUser, roomId)) {
            throw new AccessDeniedException("Không có quyền xóa thành viên khỏi phòng chat này");
        }

        int updated = chatParticipantRepository.removeParticipant(roomId, userId);
        
        if (updated > 0) {
            logger.info("Removed participant {} from room {} by user {}", userId, roomId, requestingUser.getUsername());
        }
        
        return updated > 0;
    }

    @Override
    public boolean updateParticipantRole(Integer roomId, Integer userId, String newRole, User requestingUser) {
        if (!canUserModerateRoom(requestingUser, roomId)) {
            throw new AccessDeniedException("Không có quyền thay đổi vai trò thành viên");
        }

        int updated = chatParticipantRepository.updateParticipantRole(roomId, userId, newRole);
        
        if (updated > 0) {
            logger.info("Updated participant {} role to {} in room {} by user {}", 
                       userId, newRole, roomId, requestingUser.getUsername());
        }
        
        return updated > 0;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ChatParticipant> getChatRoomParticipants(Integer roomId, User requestingUser) {
        if (!canUserAccessRoom(requestingUser, roomId)) {
            throw new AccessDeniedException("Không có quyền xem danh sách thành viên");
        }
        
        return chatParticipantRepository.findByChatRoomRoomIdAndIsActiveTrueOrderByJoinedAtAsc(roomId);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean canUserAccessRoom(User user, Integer roomId) {
        Integer branchId = user.getBranch() != null ? user.getBranch().getBranchId() : null;
        boolean canAccess = chatRoomRepository.canUserAccessRoom(user.getUserId(), branchId, roomId);

        // If user can access the room, ensure they are added as participant for BRANCH/SYSTEM rooms
        if (canAccess) {
            ensureUserIsParticipant(user, roomId);
        }

        return canAccess;
    }

    /**
     * Ensure user is added as participant for rooms they can access
     */
    @Transactional
    private void ensureUserIsParticipant(User user, Integer roomId) {
        try {
            Optional<ChatRoom> roomOpt = chatRoomRepository.findById(roomId);
            if (roomOpt.isEmpty()) {
                return;
            }

            ChatRoom room = roomOpt.get();

            // For BRANCH and SYSTEM rooms, auto-add users as participants
            if ("BRANCH".equals(room.getRoomType()) || "SYSTEM".equals(room.getRoomType())) {
                Optional<ChatParticipant> existingParticipant = chatParticipantRepository
                        .findByChatRoomRoomIdAndUserUserId(roomId, user.getUserId());

                if (existingParticipant.isEmpty()) {
                    // Add user as participant
                    String role = hasRole(user, "MANAGER") ? "MODERATOR" : "MEMBER";
                    addParticipantInternal(room, user, role);
                    logger.debug("Auto-added user {} as participant to {} room {}",
                               user.getUsername(), room.getRoomType(), roomId);
                } else if (!existingParticipant.get().getIsActive()) {
                    // Reactivate participant
                    ChatParticipant participant = existingParticipant.get();
                    participant.setIsActive(true);
                    participant.setJoinedAt(LocalDateTime.now());
                    chatParticipantRepository.save(participant);
                    logger.debug("Reactivated user {} as participant to room {}",
                               user.getUsername(), roomId);
                }
            }
        } catch (Exception e) {
            logger.error("Error ensuring user {} is participant in room {}: {}",
                       user.getUsername(), roomId, e.getMessage());
        }
    }

    @Override
    @Transactional(readOnly = true)
    public boolean canUserModerateRoom(User user, Integer roomId) {
        return chatParticipantRepository.canUserModerateRoom(roomId, user.getUserId()) || hasRole(user, "ADMIN");
    }

    // ===== HELPER METHODS =====

    private boolean canUserCreateRoom(User user, String roomType) {
        switch (roomType) {
            case "DIRECT":
                return true; // All staff can create direct messages
            case "BRANCH":
                return false; // Auto-created
            case "GROUP":
                return hasRole(user, "MANAGER") || hasRole(user, "ADMIN");
            case "SYSTEM":
                return hasRole(user, "ADMIN");
            default:
                return false;
        }
    }

    private boolean canUsersCommunicateDirectly(User user1, User user2) {
        // Same branch users can communicate
        if (user1.getBranch() != null && user2.getBranch() != null && 
            user1.getBranch().getBranchId().equals(user2.getBranch().getBranchId())) {
            return true;
        }
        
        // Managers can communicate across branches
        return hasRole(user1, "MANAGER") || hasRole(user1, "ADMIN") ||
               hasRole(user2, "MANAGER") || hasRole(user2, "ADMIN");
    }

    private boolean hasRole(User user, String roleName) {
        return user.getRoles().stream()
                .anyMatch(role -> roleName.equals(role.getRoleName()));
    }

    private ChatParticipant addParticipantInternal(ChatRoom room, User user, String role) {
        // Check if participant already exists
        Optional<ChatParticipant> existing = chatParticipantRepository.findByChatRoomRoomIdAndUserUserId(
                room.getRoomId(), user.getUserId());

        if (existing.isPresent()) {
            ChatParticipant participant = existing.get();
            if (!participant.getIsActive()) {
                // Reactivate participant
                participant.setIsActive(true);
                participant.setJoinedAt(LocalDateTime.now());
                return chatParticipantRepository.save(participant);
            }
            return participant;
        }

        // Create new participant
        ChatParticipant participant = new ChatParticipant(room, user, role);
        return chatParticipantRepository.save(participant);
    }

    // ===== MESSAGE MANAGEMENT =====

    @Override
    public ChatMessage sendMessage(Integer roomId, String content, User sender) {
        if (!canUserSendMessage(sender, roomId)) {
            throw new AccessDeniedException("Không có quyền gửi tin nhắn trong phòng chat này");
        }

        ChatRoom room = chatRoomRepository.findById(roomId)
                .orElseThrow(() -> new IllegalArgumentException("Phòng chat không tồn tại"));

        String sanitizedContent = validateAndSanitizeMessage(content);

        ChatMessage message = new ChatMessage(room, sender, sanitizedContent);
        ChatMessage savedMessage = chatMessageRepository.save(message);

        // Update room's updated_at timestamp
        room.setUpdatedAt(LocalDateTime.now());
        chatRoomRepository.save(room);

        // Send notifications to offline users
        sendChatNotification(savedMessage);

        logger.debug("Message sent in room {} by user {}", roomId, sender.getUsername());
        return savedMessage;
    }

    @Override
    public ChatMessage sendFileMessage(Integer roomId, String content, String fileUrl, String fileName, Long fileSize, User sender) {
        if (!canUserSendMessage(sender, roomId)) {
            throw new AccessDeniedException("Không có quyền gửi file trong phòng chat này");
        }

        ChatRoom room = chatRoomRepository.findById(roomId)
                .orElseThrow(() -> new IllegalArgumentException("Phòng chat không tồn tại"));

        String sanitizedContent = validateAndSanitizeMessage(content);

        ChatMessage message = new ChatMessage(room, sender, sanitizedContent);

        // Determine message type based on file extension
        String messageType = determineMessageType(fileName);
        message.setMessageType(messageType);
        message.setFileUrl(fileUrl);
        message.setFileName(fileName);
        message.setFileSize(fileSize);

        ChatMessage savedMessage = chatMessageRepository.save(message);

        // Update room timestamp
        room.setUpdatedAt(LocalDateTime.now());
        chatRoomRepository.save(room);

        // Send notifications
        sendChatNotification(savedMessage);

        logger.info("File message sent in room {} by user {}: {}", roomId, sender.getUsername(), fileName);
        return savedMessage;
    }

    @Override
    public ChatMessage replyToMessage(Integer roomId, String content, Integer replyToMessageId, User sender) {
        if (!canUserSendMessage(sender, roomId)) {
            throw new AccessDeniedException("Không có quyền gửi tin nhắn trong phòng chat này");
        }

        ChatRoom room = chatRoomRepository.findById(roomId)
                .orElseThrow(() -> new IllegalArgumentException("Phòng chat không tồn tại"));

        ChatMessage replyToMessage = chatMessageRepository.findById(replyToMessageId)
                .orElseThrow(() -> new IllegalArgumentException("Tin nhắn được trả lời không tồn tại"));

        // Verify reply message is in the same room
        if (!replyToMessage.getChatRoom().getRoomId().equals(roomId)) {
            throw new IllegalArgumentException("Không thể trả lời tin nhắn từ phòng chat khác");
        }

        String sanitizedContent = validateAndSanitizeMessage(content);

        ChatMessage message = new ChatMessage(room, sender, sanitizedContent);
        message.setReplyToMessage(replyToMessage);

        ChatMessage savedMessage = chatMessageRepository.save(message);

        // Update room timestamp
        room.setUpdatedAt(LocalDateTime.now());
        chatRoomRepository.save(room);

        // Send notifications
        sendChatNotification(savedMessage);

        logger.debug("Reply message sent in room {} by user {}", roomId, sender.getUsername());
        return savedMessage;
    }

    @Override
    public ChatMessage editMessage(Integer messageId, String newContent, User editor) {
        ChatMessage message = chatMessageRepository.findById(messageId)
                .orElseThrow(() -> new IllegalArgumentException("Tin nhắn không tồn tại"));

        // Only sender can edit their own messages
        if (!message.getSender().getUserId().equals(editor.getUserId())) {
            throw new AccessDeniedException("Chỉ có thể chỉnh sửa tin nhắn của chính mình");
        }

        // Cannot edit deleted messages
        if (Boolean.TRUE.equals(message.getIsDeleted())) {
            throw new IllegalArgumentException("Không thể chỉnh sửa tin nhắn đã bị xóa");
        }

        String sanitizedContent = validateAndSanitizeMessage(newContent);
        message.editMessage(sanitizedContent);

        ChatMessage savedMessage = chatMessageRepository.save(message);

        logger.debug("Message {} edited by user {}", messageId, editor.getUsername());
        return savedMessage;
    }

    @Override
    public boolean deleteMessage(Integer messageId, User requestingUser) {
        ChatMessage message = chatMessageRepository.findById(messageId)
                .orElseThrow(() -> new IllegalArgumentException("Tin nhắn không tồn tại"));

        // User can delete their own messages or moderators can delete any message
        boolean canDelete = message.getSender().getUserId().equals(requestingUser.getUserId()) ||
                           canUserModerateRoom(requestingUser, message.getChatRoom().getRoomId());

        if (!canDelete) {
            throw new AccessDeniedException("Không có quyền xóa tin nhắn này");
        }

        message.markAsDeleted();
        chatMessageRepository.save(message);

        logger.info("Message {} deleted by user {}", messageId, requestingUser.getUsername());
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ChatMessage> getChatMessages(Integer roomId, User requestingUser, Pageable pageable) {
        if (!canUserAccessRoom(requestingUser, roomId)) {
            throw new AccessDeniedException("Không có quyền xem tin nhắn trong phòng chat này");
        }

        return chatMessageRepository.findByChatRoomRoomIdAndIsDeletedFalseOrderBySentAtDesc(roomId, pageable);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ChatMessage> getRecentMessages(Integer roomId, User requestingUser, int limit) {
        if (!canUserAccessRoom(requestingUser, roomId)) {
            throw new AccessDeniedException("Không có quyền xem tin nhắn trong phòng chat này");
        }

        Pageable pageable = PageRequest.of(0, limit);
        return chatMessageRepository.findRecentMessages(roomId, pageable);
    }

    private String determineMessageType(String fileName) {
        if (fileName == null) return "TEXT";

        String lowerFileName = fileName.toLowerCase();
        if (lowerFileName.endsWith(".jpg") || lowerFileName.endsWith(".jpeg") ||
            lowerFileName.endsWith(".png") || lowerFileName.endsWith(".gif")) {
            return "IMAGE";
        }
        return "FILE";
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ChatMessage> searchMessages(Integer roomId, String searchTerm, User requestingUser, Pageable pageable) {
        if (!canUserAccessRoom(requestingUser, roomId)) {
            throw new AccessDeniedException("Không có quyền tìm kiếm tin nhắn trong phòng chat này");
        }

        return chatMessageRepository.searchMessagesInRoom(roomId, searchTerm, pageable);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ChatMessage> getUnreadMessages(Integer roomId, User user) {
        if (!canUserAccessRoom(user, roomId)) {
            return List.of();
        }

        return chatMessageRepository.findUnreadMessages(user.getUserId(), roomId);
    }

    @Override
    @Transactional(readOnly = true)
    public Long getUnreadMessageCount(Integer roomId, User user) {
        if (!canUserAccessRoom(user, roomId)) {
            return 0L;
        }

        return chatMessageRepository.countUnreadMessages(user.getUserId(), roomId);
    }

    @Override
    public void markMessagesAsRead(Integer roomId, User user) {
        if (!canUserAccessRoom(user, roomId)) {
            return;
        }

        chatParticipantRepository.updateLastReadTime(roomId, user.getUserId(), LocalDateTime.now());
        logger.debug("Marked messages as read for user {} in room {}", user.getUsername(), roomId);
    }

    // ===== NOTIFICATION INTEGRATION =====

    @Override
    public void sendChatNotification(ChatMessage message) {
        try {
            // Get participants who should receive notifications
            List<ChatParticipant> participants = chatParticipantRepository
                    .findByChatRoomRoomIdAndNotificationsEnabledTrueAndIsActiveTrue(message.getChatRoom().getRoomId());

            for (ChatParticipant participant : participants) {
                // Don't notify the sender
                if (participant.getUser().getUserId().equals(message.getSender().getUserId())) {
                    continue;
                }

                // Create notification
                String title = "Tin nhắn mới từ " + message.getSender().getFullName();
                String content = message.getChatRoom().getRoomName() + ": " +
                               (message.getMessageContent().length() > 100 ?
                                message.getMessageContent().substring(0, 100) + "..." :
                                message.getMessageContent());

                notificationService.createNotificationWithAction(
                    participant.getUser(),
                    message.getSender(),
                    title,
                    content,
                    Notification.NotificationType.CHAT_MESSAGE,
                    "/chat?room=" + message.getChatRoom().getRoomId()
                );
            }
        } catch (Exception e) {
            logger.error("Error sending chat notifications for message {}: {}", message.getMessageId(), e.getMessage());
        }
    }

    @Override
    public void sendRoomInvitationNotification(ChatRoom room, User invitedUser, User invitedBy) {
        try {
            String title = "Lời mời tham gia phòng chat";
            String content = invitedBy.getFullName() + " đã mời bạn tham gia phòng chat: " + room.getRoomName();

            notificationService.createNotificationWithAction(
                invitedUser,
                invitedBy,
                title,
                content,
                Notification.NotificationType.CHAT_ROOM_INVITE,
                "/chat?room=" + room.getRoomId()
            );
        } catch (Exception e) {
            logger.error("Error sending room invitation notification: {}", e.getMessage());
        }
    }

    // ===== UTILITY METHODS =====

    @Override
    public String validateAndSanitizeMessage(String content) {
        if (content == null || content.trim().isEmpty()) {
            throw new IllegalArgumentException("Nội dung tin nhắn không được để trống");
        }

        if (content.length() > 4000) {
            throw new IllegalArgumentException("Tin nhắn quá dài (tối đa 4000 ký tự)");
        }

        // Sanitize HTML but preserve Vietnamese characters
        return Jsoup.clean(content, org.jsoup.safety.Safelist.basic());
    }

    @Override
    @Transactional(readOnly = true)
    public boolean canUserSendMessage(User user, Integer roomId) {
        // First check if user can access the room
        if (!canUserAccessRoom(user, roomId)) {
            return false;
        }

        // Get the room to check its type
        Optional<ChatRoom> roomOpt = chatRoomRepository.findById(roomId);
        if (roomOpt.isEmpty()) {
            return false;
        }

        ChatRoom room = roomOpt.get();

        // For SYSTEM and BRANCH rooms, access permission is enough
        if ("SYSTEM".equals(room.getRoomType()) || "BRANCH".equals(room.getRoomType())) {
            return true;
        }

        // For DIRECT and GROUP rooms, user must be a participant
        return chatParticipantRepository.isUserParticipant(roomId, user.getUserId());
    }

    @Override
    @Transactional(readOnly = true)
    public Object getChatRoomStatistics(Integer roomId, User requestingUser) {
        if (!canUserAccessRoom(requestingUser, roomId)) {
            throw new AccessDeniedException("Không có quyền xem thống kê phòng chat này");
        }

        return chatMessageRepository.getMessageStatistics(roomId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ChatMessage> exportChatHistory(Integer roomId, User requestingUser, LocalDateTime startDate, LocalDateTime endDate) {
        if (!canUserModerateRoom(requestingUser, roomId)) {
            throw new AccessDeniedException("Không có quyền xuất lịch sử chat");
        }

        if (endDate == null) {
            endDate = LocalDateTime.now();
        }
        if (startDate == null) {
            startDate = endDate.minusMonths(1); // Default to last month
        }

        return chatMessageRepository.findAllMessagesForExport(roomId);
    }

    // ===== BRANCH-SPECIFIC OPERATIONS =====

    @Override
    public ChatRoom createBranchChatRoom(Integer branchId, User creator) {
        if (!hasRole(creator, "ADMIN") &&
            (creator.getBranch() == null || !creator.getBranch().getBranchId().equals(branchId))) {
            throw new AccessDeniedException("Không có quyền tạo phòng chat cho chi nhánh này");
        }

        // Check if branch room already exists
        List<ChatRoom> existingRooms = chatRoomRepository.findByBranchBranchIdAndRoomTypeAndIsActiveTrue(branchId, "BRANCH");
        Optional<ChatRoom> existingRoom = existingRooms.stream().findFirst();
        if (existingRoom.isPresent()) {
            return existingRoom.get();
        }

        String roomName = "Chi nhánh " + creator.getBranch().getName();
        ChatRoom branchRoom = createChatRoom(roomName, "BRANCH", creator, branchId,
                                           "Kênh thảo luận chính của chi nhánh");

        // Add all branch staff
        addBranchStaffToRoom(branchRoom.getRoomId(), branchId);

        return branchRoom;
    }

    @Override
    public void addBranchStaffToRoom(Integer roomId, Integer branchId) {
        try {
            List<User> branchStaff = userService.findActiveUsersByBranch(branchId);

            for (User staff : branchStaff) {
                // Skip if already participant
                if (chatParticipantRepository.isUserParticipant(roomId, staff.getUserId())) {
                    continue;
                }

                ChatRoom room = chatRoomRepository.findById(roomId).orElse(null);
                if (room != null) {
                    String role = hasRole(staff, "MANAGER") ? "MODERATOR" : "MEMBER";
                    addParticipantInternal(room, staff, role);
                }
            }

            logger.info("Added branch staff to room {}", roomId);
        } catch (Exception e) {
            logger.error("Error adding branch staff to room {}: {}", roomId, e.getMessage());
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<ChatRoom> getBranchChatRooms(Integer branchId, User requestingUser) {
        if (!hasRole(requestingUser, "ADMIN") &&
            (requestingUser.getBranch() == null || !requestingUser.getBranch().getBranchId().equals(branchId))) {
            throw new AccessDeniedException("Không có quyền xem phòng chat của chi nhánh này");
        }

        return chatRoomRepository.findByBranchBranchIdAndIsActiveTrue(branchId);
    }
}
