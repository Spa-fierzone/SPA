package com.spazone.controller;

import com.spazone.entity.Branch;
import com.spazone.entity.Service;
import com.spazone.entity.ServiceCategory;
import com.spazone.entity.ServiceRating;
import com.spazone.entity.User;
import com.spazone.exception.DuplicateResourceException;
import com.spazone.exception.ManagerImageUploadException;
import com.spazone.exception.ResourceNotFoundException;
import com.spazone.exception.ServiceValidationException;
import com.spazone.repository.ServiceCategoryRepository;
import com.spazone.repository.ServiceRatingRepository;
import com.spazone.service.*;
import com.spazone.util.FileValidationUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.http.ResponseEntity;
import java.util.HashMap;
import java.util.Map;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/manager/services")
@PreAuthorize("hasRole('MANAGER')")
public class ManagerServiceController {

    private static final Logger logger = LoggerFactory.getLogger(ManagerServiceController.class);

    @Autowired
    private SpaServiceService spaServiceService;

    @Autowired
    private ServiceRatingService serviceRatingService;

    @Autowired
    private ServiceRatingRepository serviceRatingRepository;

    @Autowired
    private ManagerServiceAnalyticsService analyticsService;

    @Autowired
    private UserService userService;

    @Autowired
    private BranchService branchService;

    @Autowired
    private ServiceCategoryRepository categoryRepository;

    @Autowired
    private CloudinaryService cloudinaryService;

    @Autowired
    private FileValidationUtil fileValidationUtil;

    // ==================== HELPER METHODS ====================

    /**
     * Get manager's branch (the branch that this manager manages)
     */
    private Branch getManagerBranch(Authentication authentication) {
        User manager = userService.findByUsername(authentication.getName());
        if (manager == null) {
            return null;
        }

        // Find the branch where this manager is assigned as manager
        List<Branch> managedBranches = branchService.findByManagerId(manager.getUserId());

        if (managedBranches.isEmpty()) {
            logger.warn("Manager {} is not assigned to any branch", manager.getUsername());
            return null;
        }

        if (managedBranches.size() > 1) {
            logger.warn("Manager {} is assigned to multiple branches, using the first one", manager.getUsername());
        }

        return managedBranches.get(0);
    }

    /**
     * Validate if service belongs to manager's branch
     */
    private boolean validateServiceAccess(Integer serviceId, Branch managerBranch) {
        if (serviceId == null || managerBranch == null) {
            return false;
        }
        return spaServiceService.validateManagerAccess(serviceId, managerBranch.getBranchId());
    }

    // ==================== SERVICE MANAGEMENT ENDPOINTS ====================

    /**
     * Service Management - Main management page
     */
    @GetMapping("/manage")
    public String serviceManagement(Model model,
                                  @RequestParam(defaultValue = "0") int page,
                                  @RequestParam(defaultValue = "10") int size,
                                  @RequestParam(required = false) String keyword,
                                  Authentication authentication) {

        Branch managerBranch = getManagerBranch(authentication);
        if (managerBranch == null) {
            model.addAttribute("errorMessage", "Bạn chưa được phân công quản lý chi nhánh nào. Vui lòng liên hệ quản trị viên.");
            return "error/access-denied";
        }

        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        Page<Service> services = spaServiceService.searchByNameAndBranchId(keyword, managerBranch.getBranchId(), pageable);

        model.addAttribute("services", services);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", services.getTotalPages());
        model.addAttribute("keyword", keyword);
        model.addAttribute("managerBranch", managerBranch);

        return "manager/service-manage";
    }

    /**
     * Show create service form
     */
    @GetMapping("/create")
    public String createForm(Model model, Authentication authentication) {
        Branch managerBranch = getManagerBranch(authentication);
        if (managerBranch == null) {
            model.addAttribute("errorMessage", "Bạn chưa được phân công quản lý chi nhánh nào. Vui lòng liên hệ quản trị viên.");
            return "error/access-denied";
        }

        Service service = new Service();
        service.setBranch(managerBranch); // Pre-set the branch

        model.addAttribute("service", service);
        model.addAttribute("categories", categoryRepository.findAllOrderByName());
        model.addAttribute("managerBranch", managerBranch);
        model.addAttribute("isEdit", false);

        return "manager/service-form";
    }

    /**
     * Show edit service form
     */
    @GetMapping("/edit/{serviceId}")
    public String editForm(@PathVariable Integer serviceId, Model model,
                          Authentication authentication, RedirectAttributes redirectAttributes) {

        Branch managerBranch = getManagerBranch(authentication);
        if (managerBranch == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Bạn chưa được phân công quản lý chi nhánh nào. Vui lòng liên hệ quản trị viên.");
            return "redirect:/manager/services/manage";
        }

        // Validate access
        if (!validateServiceAccess(serviceId, managerBranch)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Bạn không có quyền chỉnh sửa dịch vụ này");
            return "redirect:/manager/services/manage";
        }

        try {
            Service service = spaServiceService.getById(serviceId);

            model.addAttribute("service", service);
            model.addAttribute("categories", categoryRepository.findAllOrderByName());
            model.addAttribute("managerBranch", managerBranch);
            model.addAttribute("isEdit", true);

            return "manager/service-form";

        } catch (ResourceNotFoundException e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Không tìm thấy dịch vụ");
            return "redirect:/manager/services/manage";
        }
    }

    /**
     * Handle create/update service
     */
    @PostMapping("/save")
    public String saveService(@ModelAttribute Service service,
                             @RequestParam("imageFile") MultipartFile imageFile,
                             Authentication authentication,
                             Model model,
                             RedirectAttributes redirectAttributes) {

        Branch managerBranch = getManagerBranch(authentication);
        if (managerBranch == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Bạn chưa được phân công quản lý chi nhánh nào. Vui lòng liên hệ quản trị viên.");
            return "redirect:/manager/services/manage";
        }

        try {
            boolean isUpdate = service.getServiceId() != null;

            if (isUpdate) {
                // Validate access for update
                if (!validateServiceAccess(service.getServiceId(), managerBranch)) {
                    redirectAttributes.addFlashAttribute("errorMessage", "Bạn không có quyền chỉnh sửa dịch vụ này");
                    return "redirect:/manager/services/manage";
                }
            } else {
                // For new service, ensure it's assigned to manager's branch
                service.setBranch(managerBranch);
            }

            // Handle image upload
            if (!imageFile.isEmpty()) {
                logger.info("Processing image upload for service: {}", service.getName());
                logger.info("Image file details - Name: {}, Size: {}, ContentType: {}",
                    imageFile.getOriginalFilename(), imageFile.getSize(), imageFile.getContentType());
                fileValidationUtil.validateOptionalImageFile(imageFile);
                String imageUrl = cloudinaryService.uploadImage(imageFile);
                service.setImageUrl(imageUrl);
                logger.info("Image uploaded successfully: {}", imageUrl);
                logger.info("Service imageUrl after setting: {}", service.getImageUrl());
            } else if (isUpdate) {
                // For updates, preserve existing image if no new image is provided
                Service existingService = spaServiceService.getById(service.getServiceId());
                service.setImageUrl(existingService.getImageUrl());
                logger.info("Preserved existing image URL: {}", existingService.getImageUrl());
            } else {
                logger.info("No image file provided for new service");
            }

            logger.info("Service before saving - ID: {}, Name: {}, ImageURL: {}",
                service.getServiceId(), service.getName(), service.getImageUrl());

            Service savedService = spaServiceService.save(service);

            logger.info("Service after saving - ID: {}, Name: {}, ImageURL: {}",
                savedService.getServiceId(), savedService.getName(), savedService.getImageUrl());

            String message = isUpdate ? "Cập nhật dịch vụ thành công" : "Tạo dịch vụ mới thành công";
            redirectAttributes.addFlashAttribute("successMessage", message);

            logger.info("Manager {} {} service: {}",
                       authentication.getName(),
                       isUpdate ? "updated" : "created",
                       savedService.getName());

            return "redirect:/manager/services/manage";

        } catch (ManagerImageUploadException e) {
            logger.warn("Image upload validation failed: {}", e.getMessage());
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("service", service);
            model.addAttribute("categories", categoryRepository.findAllOrderByName());
            model.addAttribute("managerBranch", managerBranch);
            model.addAttribute("isEdit", service.getServiceId() != null);
            return "manager/service-form";

        } catch (ServiceValidationException e) {
            logger.warn("Service validation failed: {}", e.getMessage());
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("service", service);
            model.addAttribute("categories", categoryRepository.findAllOrderByName());
            model.addAttribute("managerBranch", managerBranch);
            model.addAttribute("isEdit", service.getServiceId() != null);
            return "manager/service-form";

        } catch (DuplicateResourceException e) {
            logger.warn("Duplicate resource error: {}", e.getMessage());
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("service", service);
            model.addAttribute("categories", categoryRepository.findAllOrderByName());
            model.addAttribute("managerBranch", managerBranch);
            model.addAttribute("isEdit", service.getServiceId() != null);
            return "manager/service-form";

        } catch (Exception e) {
            logger.error("Error saving service: {}", e.getMessage(), e);
            model.addAttribute("errorMessage", "Có lỗi xảy ra khi lưu dịch vụ. Vui lòng thử lại sau.");
            model.addAttribute("service", service);
            model.addAttribute("categories", categoryRepository.findAllOrderByName());
            model.addAttribute("managerBranch", managerBranch);
            model.addAttribute("isEdit", service.getServiceId() != null);
            return "manager/service-form";
        }
    }

    /**
     * AJAX endpoint for service creation/update
     */
    @PostMapping("/save-ajax")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> saveServiceAjax(@ModelAttribute Service service,
                                                              @RequestParam("imageFile") MultipartFile imageFile,
                                                              Authentication authentication) {

        Branch managerBranch = getManagerBranch(authentication);
        if (managerBranch == null) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", "Bạn chưa được phân công quản lý chi nhánh nào. Vui lòng liên hệ quản trị viên."
            ));
        }

        try {
            boolean isUpdate = service.getServiceId() != null;

            if (isUpdate) {
                // Validate access for update
                if (!validateServiceAccess(service.getServiceId(), managerBranch)) {
                    return ResponseEntity.badRequest().body(Map.of(
                        "success", false,
                        "message", "Bạn không có quyền chỉnh sửa dịch vụ này"
                    ));
                }
            } else {
                // For new service, ensure it's assigned to manager's branch
                service.setBranch(managerBranch);
            }

            // Handle image upload
            if (!imageFile.isEmpty()) {
                logger.info("Processing image upload for service: {}", service.getName());
                logger.info("Image file details - Name: {}, Size: {}, ContentType: {}",
                    imageFile.getOriginalFilename(), imageFile.getSize(), imageFile.getContentType());
                fileValidationUtil.validateOptionalImageFile(imageFile);
                String imageUrl = cloudinaryService.uploadImage(imageFile);
                service.setImageUrl(imageUrl);
                logger.info("Image uploaded successfully: {}", imageUrl);
                logger.info("Service imageUrl after setting: {}", service.getImageUrl());
            } else if (isUpdate) {
                // For updates, preserve existing image if no new image is provided
                Service existingService = spaServiceService.getById(service.getServiceId());
                service.setImageUrl(existingService.getImageUrl());
                logger.info("Preserved existing image URL: {}", existingService.getImageUrl());
            } else {
                logger.info("No image file provided for new service");
            }

            logger.info("Service before saving - ID: {}, Name: {}, ImageURL: {}",
                service.getServiceId(), service.getName(), service.getImageUrl());

            Service savedService = spaServiceService.save(service);

            logger.info("Service after saving - ID: {}, Name: {}, ImageURL: {}",
                savedService.getServiceId(), savedService.getName(), savedService.getImageUrl());

            String message = isUpdate ? "Cập nhật dịch vụ thành công" : "Tạo dịch vụ mới thành công";

            logger.info("Manager {} {} service: {}",
                       authentication.getName(),
                       isUpdate ? "updated" : "created",
                       savedService.getName());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", message);
            response.put("serviceId", savedService.getServiceId());
            response.put("serviceName", savedService.getName());
            response.put("isUpdate", isUpdate);

            return ResponseEntity.ok(response);

        } catch (ManagerImageUploadException e) {
            logger.warn("Image upload validation failed: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));

        } catch (ServiceValidationException e) {
            logger.warn("Service validation failed: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));

        } catch (DuplicateResourceException e) {
            logger.warn("Duplicate resource error: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));

        } catch (Exception e) {
            logger.error("Error saving service: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", "Có lỗi xảy ra khi lưu dịch vụ. Vui lòng thử lại sau."
            ));
        }
    }

    /**
     * Toggle service status (active/inactive)
     */
    @PostMapping("/toggle-status/{serviceId}")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> toggleServiceStatus(@PathVariable Integer serviceId,
                                                                  Authentication authentication) {
        try {
            Branch managerBranch = getManagerBranch(authentication);
            if (managerBranch == null) {
                return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Bạn chưa được phân công quản lý chi nhánh nào. Vui lòng liên hệ quản trị viên."
                ));
            }

            // Validate access
            if (!validateServiceAccess(serviceId, managerBranch)) {
                return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Bạn không có quyền thay đổi trạng thái dịch vụ này"
                ));
            }

            spaServiceService.toggleStatus(serviceId);

            logger.info("Manager {} toggled status for service ID: {}", authentication.getName(), serviceId);

            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Thay đổi trạng thái dịch vụ thành công"
            ));

        } catch (ResourceNotFoundException e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", "Không tìm thấy dịch vụ"
            ));
        } catch (Exception e) {
            logger.error("Error toggling service status: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", "Có lỗi xảy ra khi thay đổi trạng thái dịch vụ"
            ));
        }
    }

    // ==================== ANALYTICS ENDPOINTS (EXISTING) ====================

    /**
     * Service Dashboard - Main overview page
     */
    @GetMapping
    public String serviceDashboard(Model model,
                                 @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                                 @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        
        // Default to last 30 days if no dates provided
        if (startDate == null) startDate = LocalDate.now().minusDays(30);
        if (endDate == null) endDate = LocalDate.now();
        
        // Get dashboard data
        Map<String, Object> dashboardData = analyticsService.getServiceDashboardData(startDate, endDate);
        
        model.addAttribute("dashboardData", dashboardData);
        model.addAttribute("startDate", startDate);
        model.addAttribute("endDate", endDate);
        
        return "manager/service-dashboard";
    }
    
    /**
     * Service List with Performance Metrics
     */
    @GetMapping("/list")
    public String serviceList(Model model,
                            @RequestParam(defaultValue = "0") int page,
                            @RequestParam(defaultValue = "10") int size,
                            @RequestParam(required = false) String keyword) {
        
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        Page<Service> services = spaServiceService.searchByName(keyword, page, size);
        
        // Add performance metrics for each service
        List<Service> serviceList = services.getContent();
        for (Service service : serviceList) {
            // Add review statistics using ServiceRating
            List<ServiceRating> ratings = serviceRatingService.getRatingsByService(service);
            double avgRating = ratings.stream()
                    .mapToInt(ServiceRating::getRating)
                    .average()
                    .orElse(0.0);
            service.setFavorite(avgRating > 4.0); // Use favorite field to indicate high rating
        }
        
        model.addAttribute("services", services);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", services.getTotalPages());
        model.addAttribute("keyword", keyword);
        
        return "manager/service-list";
    }
    
    /**
     * Service Detail with Analytics
     */
    @GetMapping("/detail/{serviceId}")
    public String serviceDetail(@PathVariable Integer serviceId,
                              Model model,
                              @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                              @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        
        if (startDate == null) startDate = LocalDate.now().minusDays(30);
        if (endDate == null) endDate = LocalDate.now();
        
        Service service = spaServiceService.getById(serviceId);
        Map<String, Object> performanceMetrics = analyticsService.getServicePerformanceMetrics(serviceId, startDate, endDate);
        
        // Get recent ratings for this service
        List<ServiceRating> recentRatings = serviceRatingService.getRatingsByService(service);
        
        model.addAttribute("service", service);
        model.addAttribute("performanceMetrics", performanceMetrics);
        model.addAttribute("recentRatings", recentRatings);
        model.addAttribute("startDate", startDate);
        model.addAttribute("endDate", endDate);
        
        return "manager/service-detail";
    }
    
    /**
     * Service Ratings Management
     */
    @GetMapping("/reviews")
    public String reviewsManagement(Model model,
                                  @RequestParam(defaultValue = "0") int page,
                                  @RequestParam(defaultValue = "10") int size,
                                  @RequestParam(required = false) Integer serviceId,
                                  @RequestParam(required = false) Integer minRating,
                                  @RequestParam(required = false) Integer maxRating,
                                  @RequestParam(required = false) String keyword) {

        // Get all ratings and filter them
        List<ServiceRating> allRatings = serviceRatingRepository.findAll();

        // Apply filters
        List<ServiceRating> filteredRatings = allRatings.stream()
                .filter(rating -> serviceId == null || rating.getService().getServiceId().equals(serviceId))
                .filter(rating -> minRating == null || rating.getRating() >= minRating)
                .filter(rating -> maxRating == null || rating.getRating() <= maxRating)
                .filter(rating -> keyword == null || keyword.isEmpty() ||
                        (rating.getComment() != null && rating.getComment().toLowerCase().contains(keyword.toLowerCase())))
                .sorted((r1, r2) -> r2.getCreatedAt().compareTo(r1.getCreatedAt()))
                .collect(Collectors.toList());

        // Manual pagination
        int start = page * size;
        int end = Math.min(start + size, filteredRatings.size());
        List<ServiceRating> pageRatings = filteredRatings.subList(start, end);
        int totalPages = (int) Math.ceil((double) filteredRatings.size() / size);

        // Get all services for filter dropdown
        List<Service> allServices = spaServiceService.findAllActive();

        model.addAttribute("ratings", pageRatings);
        model.addAttribute("allServices", allServices);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("serviceId", serviceId);
        model.addAttribute("minRating", minRating);
        model.addAttribute("maxRating", maxRating);
        model.addAttribute("keyword", keyword);

        return "manager/service-reviews";
    }
    
    /**
     * Service Analytics Page
     */
    @GetMapping("/analytics")
    public String serviceAnalytics(Model model,
                                 @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                                 @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        
        if (startDate == null) startDate = LocalDate.now().minusDays(30);
        if (endDate == null) endDate = LocalDate.now();
        
        Map<String, Object> analyticsData = analyticsService.getServiceDashboardData(startDate, endDate);
        
        model.addAttribute("analyticsData", analyticsData);
        model.addAttribute("startDate", startDate);
        model.addAttribute("endDate", endDate);
        
        return "manager/service-analytics";
    }
    
    /**
     * Delete Rating (for inappropriate content)
     */
    @PostMapping("/reviews/{ratingId}/delete")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> deleteRating(@PathVariable Integer ratingId,
                                                           Authentication authentication) {
        try {
            ServiceRating rating = serviceRatingRepository.findById(ratingId)
                    .orElseThrow(() -> new RuntimeException("Rating not found"));

            serviceRatingRepository.delete(rating);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Rating deleted successfully"
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Error deleting rating: " + e.getMessage()
            ));
        }
    }
    
    /**
     * Get Service Analytics Data (AJAX)
     */
    @GetMapping("/api/analytics")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getAnalyticsData(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        
        Map<String, Object> analyticsData = analyticsService.getServiceDashboardData(startDate, endDate);
        return ResponseEntity.ok(analyticsData);
    }
}
