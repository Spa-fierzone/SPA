package com.spazone.websocket.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;

/**
 * Data Transfer Object for typing indicators in WebSocket communication
 * Used to show when users are typing in chat rooms
 */
public class TypingIndicatorDTO {

    private Integer roomId;
    private Integer userId;
    private String userName;
    private boolean typing;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime timestamp;

    // Constructors
    public TypingIndicatorDTO() {
        this.timestamp = LocalDateTime.now();
    }

    public TypingIndicatorDTO(Integer roomId, Integer userId, String userName, boolean typing) {
        this.roomId = roomId;
        this.userId = userId;
        this.userName = userName;
        this.typing = typing;
        this.timestamp = LocalDateTime.now();
    }

    // Getters and Setters
    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public boolean isTyping() {
        return typing;
    }

    public void setTyping(boolean typing) {
        this.typing = typing;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "TypingIndicatorDTO{" +
                "roomId=" + roomId +
                ", userId=" + userId +
                ", userName='" + userName + '\'' +
                ", typing=" + typing +
                ", timestamp=" + timestamp +
                '}';
    }
}
