package com.spazone.util;

import com.spazone.dto.CreateUserDto;
import com.spazone.entity.User;
import com.spazone.exception.UserValidationException;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.regex.Pattern;

/**
 * Utility class for user validation operations
 */
@Component
public class UserValidationUtil {
    
    // Validation constants
    private static final int MIN_USERNAME_LENGTH = 3;
    private static final int MAX_USERNAME_LENGTH = 50;
    private static final int MIN_FULLNAME_LENGTH = 2;
    private static final int MAX_FULLNAME_LENGTH = 100;
    private static final int MAX_ADDRESS_LENGTH = 500;
    
    // Vietnamese phone number pattern (10-11 digits, starting with 0)
    private static final Pattern PHONE_PATTERN = Pattern.compile("^0[0-9]{9,10}$");
    
    // Email pattern
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
    );
    
    // Username pattern (alphanumeric and underscore only)
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_]+$");
    
    // Minimum age for employees (18 years)
    private static final int MIN_AGE_YEARS = 18;
    
    // Maximum age for employees (65 years)
    private static final int MAX_AGE_YEARS = 65;
    
    // Salary ranges by role (in VND)
    private static final BigDecimal MIN_MANAGER_SALARY = new BigDecimal("10000000"); // 10M
    private static final BigDecimal MAX_MANAGER_SALARY = new BigDecimal("50000000"); // 50M
    private static final BigDecimal MIN_TECHNICIAN_SALARY = new BigDecimal("8000000"); // 8M
    private static final BigDecimal MAX_TECHNICIAN_SALARY = new BigDecimal("25000000"); // 25M
    private static final BigDecimal MIN_RECEPTIONIST_SALARY = new BigDecimal("6000000"); // 6M
    private static final BigDecimal MAX_RECEPTIONIST_SALARY = new BigDecimal("15000000"); // 15M
    
    /**
     * Validates user data for create operation
     * @param dto the user DTO to validate
     * @throws UserValidationException if validation fails
     */
    public void validateUserForCreate(CreateUserDto dto) {
        validateBasicUserFields(dto);
        validateBusinessRules(dto);
    }
    
    /**
     * Validates user data for update operation
     * @param user the existing user
     * @param dto the user DTO to validate
     * @throws UserValidationException if validation fails
     */
    public void validateUserForUpdate(User user, CreateUserDto dto) {
        validateBasicUserFields(dto);
        validateBusinessRules(dto);
        
        // Additional update-specific validations can be added here
        // For example, role change restrictions, etc.
    }
    
    /**
     * Validates basic user fields
     */
    private void validateBasicUserFields(CreateUserDto dto) {
        // Username validation
        validateUsername(dto.getUsername());
        
        // Email validation
        validateEmail(dto.getEmail());
        
        // Password validation (handled by PasswordValidator)
        if (dto.getPassword() == null || dto.getPassword().trim().isEmpty()) {
            throw new UserValidationException("Mật khẩu không được để trống");
        }
        
        // Full name validation
        validateFullName(dto.getFullName());
        
        // Phone validation
        validatePhone(dto.getPhone());
        
        // Gender validation
        validateGender(dto.getGender());
        
        // Date of birth validation
        validateDateOfBirth(dto.getDateOfBirth());
        
        // Address validation
        validateAddress(dto.getAddress());
        
        // Role validation
        validateRole(dto.getRole());
        
        // Branch validation
        validateBranch(dto.getBranchId(), dto.getRole());
        
        // Salary validation
        validateSalary(dto.getBaseSalary(), dto.getRole());
    }
    
    /**
     * Validates username
     */
    public void validateUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            throw new UserValidationException("Tên đăng nhập không được để trống");
        }
        
        String trimmedUsername = username.trim();
        
        if (trimmedUsername.length() < MIN_USERNAME_LENGTH) {
            throw new UserValidationException("Tên đăng nhập phải có ít nhất " + MIN_USERNAME_LENGTH + " ký tự");
        }
        
        if (trimmedUsername.length() > MAX_USERNAME_LENGTH) {
            throw new UserValidationException("Tên đăng nhập không được vượt quá " + MAX_USERNAME_LENGTH + " ký tự");
        }
        
        if (!USERNAME_PATTERN.matcher(trimmedUsername).matches()) {
            throw new UserValidationException("Tên đăng nhập chỉ được chứa chữ cái, số và dấu gạch dưới");
        }
    }
    
    /**
     * Validates email
     */
    public void validateEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            throw new UserValidationException("Email không được để trống");
        }
        
        String trimmedEmail = email.trim();
        
        if (!EMAIL_PATTERN.matcher(trimmedEmail).matches()) {
            throw new UserValidationException("Định dạng email không hợp lệ");
        }
    }
    
    /**
     * Validates full name
     */
    public void validateFullName(String fullName) {
        if (fullName == null || fullName.trim().isEmpty()) {
            throw new UserValidationException("Họ tên không được để trống");
        }
        
        String trimmedName = fullName.trim();
        
        if (trimmedName.length() < MIN_FULLNAME_LENGTH) {
            throw new UserValidationException("Họ tên phải có ít nhất " + MIN_FULLNAME_LENGTH + " ký tự");
        }
        
        if (trimmedName.length() > MAX_FULLNAME_LENGTH) {
            throw new UserValidationException("Họ tên không được vượt quá " + MAX_FULLNAME_LENGTH + " ký tự");
        }
    }
    
    /**
     * Validates Vietnamese phone number
     */
    public void validatePhone(String phone) {
        if (phone != null && !phone.trim().isEmpty()) {
            String trimmedPhone = phone.trim();
            if (!PHONE_PATTERN.matcher(trimmedPhone).matches()) {
                throw new UserValidationException("Số điện thoại phải có 10-11 chữ số và bắt đầu bằng số 0");
            }
        }
    }
    
    /**
     * Validates gender
     */
    public void validateGender(String gender) {
        if (gender == null || gender.trim().isEmpty()) {
            throw new UserValidationException("Giới tính không được để trống");
        }
        
        String upperGender = gender.trim().toUpperCase();
        if (!upperGender.equals("MALE") && !upperGender.equals("FEMALE") && !upperGender.equals("OTHER")) {
            throw new UserValidationException("Giới tính phải là MALE, FEMALE hoặc OTHER");
        }
    }
    
    /**
     * Validates date of birth
     */
    public void validateDateOfBirth(LocalDate dateOfBirth) {
        if (dateOfBirth != null) {
            LocalDate now = LocalDate.now();
            int age = now.getYear() - dateOfBirth.getYear();
            
            // Adjust age if birthday hasn't occurred this year
            if (dateOfBirth.getDayOfYear() > now.getDayOfYear()) {
                age--;
            }
            
            if (age < MIN_AGE_YEARS) {
                throw new UserValidationException("Nhân viên phải từ " + MIN_AGE_YEARS + " tuổi trở lên");
            }
            
            if (age > MAX_AGE_YEARS) {
                throw new UserValidationException("Nhân viên không được quá " + MAX_AGE_YEARS + " tuổi");
            }
            
            if (dateOfBirth.isAfter(now)) {
                throw new UserValidationException("Ngày sinh không được là ngày trong tương lai");
            }
        }
    }
    
    /**
     * Validates address
     */
    public void validateAddress(String address) {
        if (address != null && !address.trim().isEmpty()) {
            if (address.trim().length() > MAX_ADDRESS_LENGTH) {
                throw new UserValidationException("Địa chỉ không được vượt quá " + MAX_ADDRESS_LENGTH + " ký tự");
            }
        }
    }
    
    /**
     * Validates role
     */
    public void validateRole(String role) {
        if (role == null || role.trim().isEmpty()) {
            throw new UserValidationException("Vai trò không được để trống");
        }
        
        String upperRole = role.trim().toUpperCase();
        if (!upperRole.equals("MANAGER") && !upperRole.equals("TECHNICIAN") && 
            !upperRole.equals("RECEPTIONIST") && !upperRole.equals("CUSTOMER") && !upperRole.equals("VIP")) {
            throw new UserValidationException("Vai trò không hợp lệ");
        }
    }
    
    /**
     * Validates branch assignment
     */
    public void validateBranch(Integer branchId, String role) {
        if (role == null) {
            return; // Role validation will catch this
        }
        
        String upperRole = role.trim().toUpperCase();
        
        // Staff roles require branch assignment
        if (upperRole.equals("MANAGER") || upperRole.equals("TECHNICIAN") || upperRole.equals("RECEPTIONIST")) {
            if (branchId == null) {
                throw new UserValidationException("Nhân viên phải được phân công vào chi nhánh");
            }
            
            if (branchId <= 0) {
                throw new UserValidationException("Chi nhánh không hợp lệ");
            }
        }
        
        // Customer roles should not have branch assignment
        if ((upperRole.equals("CUSTOMER") || upperRole.equals("VIP")) && branchId != null) {
            throw new UserValidationException("Khách hàng không được phân công vào chi nhánh");
        }
    }
    
    /**
     * Validates salary based on role
     */
    public void validateSalary(BigDecimal salary, String role) {
        if (role == null || salary == null) {
            return; // Other validations will handle null checks
        }
        
        String upperRole = role.trim().toUpperCase();
        
        // Only staff roles have salary
        if (upperRole.equals("CUSTOMER") || upperRole.equals("VIP")) {
            return; // Customers don't have salary
        }
        
        if (salary.compareTo(BigDecimal.ZERO) <= 0) {
            throw new UserValidationException("Lương cơ bản phải lớn hơn 0");
        }
        
        // Validate salary ranges by role
        switch (upperRole) {
            case "MANAGER":
                if (salary.compareTo(MIN_MANAGER_SALARY) < 0 || salary.compareTo(MAX_MANAGER_SALARY) > 0) {
                    throw new UserValidationException("Lương quản lý phải từ " + 
                        formatCurrency(MIN_MANAGER_SALARY) + " đến " + formatCurrency(MAX_MANAGER_SALARY) + " VNĐ");
                }
                break;
            case "TECHNICIAN":
                if (salary.compareTo(MIN_TECHNICIAN_SALARY) < 0 || salary.compareTo(MAX_TECHNICIAN_SALARY) > 0) {
                    throw new UserValidationException("Lương kỹ thuật viên phải từ " + 
                        formatCurrency(MIN_TECHNICIAN_SALARY) + " đến " + formatCurrency(MAX_TECHNICIAN_SALARY) + " VNĐ");
                }
                break;
            case "RECEPTIONIST":
                if (salary.compareTo(MIN_RECEPTIONIST_SALARY) < 0 || salary.compareTo(MAX_RECEPTIONIST_SALARY) > 0) {
                    throw new UserValidationException("Lương lễ tân phải từ " + 
                        formatCurrency(MIN_RECEPTIONIST_SALARY) + " đến " + formatCurrency(MAX_RECEPTIONIST_SALARY) + " VNĐ");
                }
                break;
        }
    }
    
    /**
     * Validates business rules
     */
    private void validateBusinessRules(CreateUserDto dto) {
        // Add any additional business rules here
        // For example: one manager per branch, etc.
    }
    
    /**
     * Formats currency for display
     */
    private String formatCurrency(BigDecimal amount) {
        return String.format("%,d", amount.longValue());
    }
}
