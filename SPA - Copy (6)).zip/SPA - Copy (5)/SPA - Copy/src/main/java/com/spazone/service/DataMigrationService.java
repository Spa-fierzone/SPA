package com.spazone.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class DataMigrationService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * Fix null booking_enabled values in users table
     * This prevents NullPointerException when checking booking restrictions
     */
    @Transactional
    public void fixNullBookingEnabledValues() {
        try {
            // Update null booking_enabled to true (default value)
            int updatedBookingEnabled = jdbcTemplate.update(
                "UPDATE users SET booking_enabled = true WHERE booking_enabled IS NULL"
            );
            
            // Update null late_cancellation_count to 0 (default value)
            int updatedCancellationCount = jdbcTemplate.update(
                "UPDATE users SET late_cancellation_count = 0 WHERE late_cancellation_count IS NULL"
            );
            
            System.out.println("Data migration completed:");
            System.out.println("- Updated " + updatedBookingEnabled + " users with null booking_enabled");
            System.out.println("- Updated " + updatedCancellationCount + " users with null late_cancellation_count");
            
        } catch (Exception e) {
            System.err.println("Error during data migration: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Check if migration is needed
     */
    public boolean isMigrationNeeded() {
        try {
            Integer nullBookingEnabledCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM users WHERE booking_enabled IS NULL", 
                Integer.class
            );
            
            Integer nullCancellationCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM users WHERE late_cancellation_count IS NULL", 
                Integer.class
            );
            
            return (nullBookingEnabledCount != null && nullBookingEnabledCount > 0) ||
                   (nullCancellationCount != null && nullCancellationCount > 0);
                   
        } catch (Exception e) {
            System.err.println("Error checking migration status: " + e.getMessage());
            return false;
        }
    }
}
