package com.spazone.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "services")
public class Service {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer serviceId;

    @Column(columnDefinition = "NVARCHAR(255)")
    private String name;

    @Column(length = 4000, columnDefinition = "NVARCHAR(4000)")
    private String description;

    private int duration; // in minutes

    private BigDecimal price;

    @Column(name = "image_url", columnDefinition = "NVARCHAR(255)")
    private String imageUrl;

    @Column(columnDefinition = "NVARCHAR(255)")
    private String status = "active";

    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime updatedAt = LocalDateTime.now();

    @ManyToOne
    @JoinColumn(name = "category_id")
    private ServiceCategory category;

    @ManyToOne
    @JoinColumn(name = "branch_id")
    private Branch branch;

    @Transient
    private boolean favorite;

    // Bidirectional relationship with appointments
    @OneToMany(mappedBy = "service", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<AppointmentServiceEntity> appointmentServices = new ArrayList<>();

    @PreUpdate
    public void updateTimestamp() {
        updatedAt = LocalDateTime.now();
    }

    public Service() {
    }

    public Service(Integer serviceId, String name, String description, int duration, BigDecimal price, String imageUrl, String status, LocalDateTime createdAt, LocalDateTime updatedAt, ServiceCategory category, Branch branch) {
        this.serviceId = serviceId;
        this.name = name;
        this.description = description;
        this.duration = duration;
        this.price = price;
        this.imageUrl = imageUrl;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.category = category;
        this.branch = branch;
    }

    public Integer getServiceId() {
        return serviceId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getDuration() {
        return duration;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getStatus() {
        return status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public ServiceCategory getCategory() {
        return category;
    }

    public boolean isFavorite() {
        return favorite;
    }

    public void setServiceId(Integer serviceId) {
        this.serviceId = serviceId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public void setCategory(ServiceCategory category) {
        this.category = category;
    }

    public Branch getBranch() {
        return branch;
    }

    public void setBranch(Branch branch) {
        this.branch = branch;
    }

    public void setFavorite(boolean favorite) {
        this.favorite = favorite;
    }

    public List<AppointmentServiceEntity> getAppointmentServices() {
        return appointmentServices;
    }

    public void setAppointmentServices(List<AppointmentServiceEntity> appointmentServices) {
        this.appointmentServices = appointmentServices;
    }
}
