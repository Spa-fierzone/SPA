package com.spazone.service;

import com.spazone.dto.ManagerScheduleDetailDTO;
import com.spazone.dto.ManagerScheduleDetailDTO.AppointmentDetailDTO;
import com.spazone.dto.ManagerScheduleDetailDTO.ServiceUsageDTO;
import com.spazone.dto.ManagerScheduleDetailDTO.TreatmentRecordDTO;
import com.spazone.entity.Appointment;
import com.spazone.entity.TreatmentRecord;
import com.spazone.entity.WorkSchedule;
import com.spazone.repository.AppointmentRepository;
import com.spazone.repository.TreatmentRecordRepository;
import com.spazone.repository.WorkScheduleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ManagerScheduleService {
    
    @Autowired
    private WorkScheduleRepository workScheduleRepository;
    
    @Autowired
    private AppointmentRepository appointmentRepository;
    
    @Autowired
    private TreatmentRecordRepository treatmentRecordRepository;
    
    @Autowired
    private ServiceStatisticsService serviceStatisticsService;
    
    /**
     * Get detailed schedule information for managers including treatment orders
     */
    public ManagerScheduleDetailDTO getScheduleDetailForManager(Integer scheduleId) {
        WorkSchedule schedule = workScheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new RuntimeException("Schedule not found"));
        
        ManagerScheduleDetailDTO detailDTO = new ManagerScheduleDetailDTO(schedule);
        
        // Get appointments for this technician on this date
        LocalDateTime startOfDay = schedule.getWorkDate().atStartOfDay();
        LocalDateTime endOfDay = schedule.getWorkDate().atTime(23, 59, 59);
        
        List<Appointment> appointments = appointmentRepository
                .findByTechnicianUserIdAndAppointmentDateBetween(
                        schedule.getUser().getUserId(), startOfDay, endOfDay);
        
        // Convert appointments to DTOs with treatment records
        List<AppointmentDetailDTO> appointmentDetails = new ArrayList<>();
        for (Appointment appointment : appointments) {
            AppointmentDetailDTO appointmentDTO = new AppointmentDetailDTO(appointment);
            
            // Get treatment record for this appointment
            TreatmentRecord treatmentRecord = treatmentRecordRepository
                    .findByAppointment_AppointmentId(appointment.getAppointmentId());
            
            if (treatmentRecord != null) {
                appointmentDTO.setTreatmentRecord(new TreatmentRecordDTO(treatmentRecord));
            }
            
            appointmentDetails.add(appointmentDTO);
        }
        
        detailDTO.setAppointments(appointmentDetails);
        
        // Calculate appointment statistics
        detailDTO.setTotalAppointments(appointments.size());
        detailDTO.setCompletedAppointments((int) appointments.stream()
                .filter(app -> "completed".equals(app.getStatus()))
                .count());
        detailDTO.setPendingAppointments((int) appointments.stream()
                .filter(app -> "scheduled".equals(app.getStatus()) || "confirmed".equals(app.getStatus()))
                .count());
        
        // Get service usage statistics
        List<ServiceUsageDTO> servicesUsed = serviceStatisticsService
                .getServiceUsageByTechnicianAndDate(schedule.getUser().getUserId(), schedule.getWorkDate());
        detailDTO.setServicesUsed(servicesUsed);
        
        // Get most popular service
        String mostPopularService = serviceStatisticsService
                .getMostPopularServiceByTechnicianAndDate(schedule.getUser().getUserId(), schedule.getWorkDate());
        detailDTO.setMostPopularService(mostPopularService);
        
        // Get total services provided
        Integer totalServicesProvided = serviceStatisticsService
                .getTotalServicesProvidedByTechnicianAndDate(schedule.getUser().getUserId(), schedule.getWorkDate());
        detailDTO.setTotalServicesProvided(totalServicesProvided);
        
        return detailDTO;
    }
    
    /**
     * Get all technician schedules for a specific date with basic info
     */
    public List<ManagerScheduleDetailDTO> getTechnicianSchedulesForDate(LocalDate date) {
        List<WorkSchedule> schedules = workScheduleRepository.findByWorkDateAndUserRoles(date, "TECHNICIAN");
        
        return schedules.stream()
                .map(schedule -> {
                    ManagerScheduleDetailDTO dto = new ManagerScheduleDetailDTO(schedule);
                    
                    // Add basic appointment count
                    LocalDateTime startOfDay = date.atStartOfDay();
                    LocalDateTime endOfDay = date.atTime(23, 59, 59);
                    
                    List<Appointment> appointments = appointmentRepository
                            .findByTechnicianUserIdAndAppointmentDateBetween(
                                    schedule.getUser().getUserId(), startOfDay, endOfDay);
                    
                    dto.setTotalAppointments(appointments.size());
                    dto.setCompletedAppointments((int) appointments.stream()
                            .filter(app -> "completed".equals(app.getStatus()))
                            .count());
                    
                    return dto;
                })
                .collect(Collectors.toList());
    }
    
    /**
     * Get all receptionist schedules for a specific date with basic info
     */
    public List<ManagerScheduleDetailDTO> getReceptionistSchedulesForDate(LocalDate date) {
        List<WorkSchedule> schedules = workScheduleRepository.findByWorkDateAndUserRoles(date, "RECEPTIONIST");
        
        return schedules.stream()
                .map(schedule -> {
                    ManagerScheduleDetailDTO dto = new ManagerScheduleDetailDTO(schedule);
                    
                    // For receptionists, we'll count appointments they helped create on this date
                    LocalDateTime startOfDay = date.atStartOfDay();
                    LocalDateTime endOfDay = date.atTime(23, 59, 59);
                    
                    List<Appointment> appointmentsCreated = appointmentRepository
                            .findByCreatedAtBetween(startOfDay, endOfDay);
                    
                    dto.setTotalAppointments(appointmentsCreated.size());
                    
                    // Get service statistics for receptionist
                    List<ServiceUsageDTO> servicesUsed = serviceStatisticsService
                            .getServiceUsageByReceptionistAndDate(schedule.getUser().getUserId(), date);
                    dto.setServicesUsed(servicesUsed);
                    
                    return dto;
                })
                .collect(Collectors.toList());
    }
    
    /**
     * Get schedules for a specific branch and date range
     */
    public List<ManagerScheduleDetailDTO> getSchedulesByBranchAndDateRange(
            Integer branchId, LocalDate startDate, LocalDate endDate) {
        
        List<WorkSchedule> schedules = workScheduleRepository
                .findByBranchBranchIdAndWorkDateBetween(branchId, startDate, endDate);
        
        return schedules.stream()
                .map(schedule -> {
                    ManagerScheduleDetailDTO dto = new ManagerScheduleDetailDTO(schedule);
                    
                    // Add basic appointment statistics
                    LocalDateTime startOfDay = schedule.getWorkDate().atStartOfDay();
                    LocalDateTime endOfDay = schedule.getWorkDate().atTime(23, 59, 59);
                    
                    if ("TECHNICIAN".equals(dto.getUserRole())) {
                        List<Appointment> appointments = appointmentRepository
                                .findByTechnicianUserIdAndAppointmentDateBetween(
                                        schedule.getUser().getUserId(), startOfDay, endOfDay);
                        
                        dto.setTotalAppointments(appointments.size());
                        dto.setCompletedAppointments((int) appointments.stream()
                                .filter(app -> "completed".equals(app.getStatus()))
                                .count());
                    }
                    
                    return dto;
                })
                .collect(Collectors.toList());
    }
    
    /**
     * Get schedule statistics for a specific date range
     */
    public Map<String, Object> getScheduleStatistics(LocalDate startDate, LocalDate endDate) {
        List<WorkSchedule> schedules = workScheduleRepository
                .findByWorkDateBetween(startDate, endDate);
        
        long totalSchedules = schedules.size();
        long technicianSchedules = schedules.stream()
                .filter(s -> s.getUser().getRoles().stream()
                        .anyMatch(role -> "TECHNICIAN".equals(role.getRoleName())))
                .count();
        long receptionistSchedules = schedules.stream()
                .filter(s -> s.getUser().getRoles().stream()
                        .anyMatch(role -> "RECEPTIONIST".equals(role.getRoleName())))
                .count();
        
        // Get service statistics
        Map<String, Object> serviceStats = serviceStatisticsService
                .getServiceStatisticsSummary(startDate, endDate);
        
        return Map.of(
                "totalSchedules", totalSchedules,
                "technicianSchedules", technicianSchedules,
                "receptionistSchedules", receptionistSchedules,
                "serviceStatistics", serviceStats
        );
    }
}
