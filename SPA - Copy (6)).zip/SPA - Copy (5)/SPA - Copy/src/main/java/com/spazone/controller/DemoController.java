package com.spazone.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Controller for demo pages and component showcases
 */
@Controller
@RequestMapping("/demo")
public class DemoController {

    /**
     * Show star rating component demo page
     */
    @GetMapping("/star-rating")
    public String starRatingDemo() {
        return "demo/star-rating-demo";
    }
}
