package com.spazone.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.LocalDateTime;

/**
 * Data Transfer Object for ChatMessage REST API responses
 * Used for returning message information in API calls
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatMessageResponseDTO {

    private Integer messageId;
    private Integer roomId;
    private String content;
    private String messageType;

    // Sender information
    private Integer senderId;
    private String senderName;
    private String senderAvatar;

    // Timestamps
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime sentAt;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime editedAt;

    private boolean edited;

    // Reply information
    private Integer replyToMessageId;
    private String replyToContent;
    private String replyToSenderName;

    // File information
    private String fileUrl;
    private String fileName;
    private Long fileSize;
    private String fileSizeFormatted;

    // Constructors
    public ChatMessageResponseDTO() {
    }

    // Getters and Setters
    public Integer getMessageId() {
        return messageId;
    }

    public void setMessageId(Integer messageId) {
        this.messageId = messageId;
    }

    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public Integer getSenderId() {
        return senderId;
    }

    public void setSenderId(Integer senderId) {
        this.senderId = senderId;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getSenderAvatar() {
        return senderAvatar;
    }

    public void setSenderAvatar(String senderAvatar) {
        this.senderAvatar = senderAvatar;
    }

    public LocalDateTime getSentAt() {
        return sentAt;
    }

    public void setSentAt(LocalDateTime sentAt) {
        this.sentAt = sentAt;
    }

    public LocalDateTime getEditedAt() {
        return editedAt;
    }

    public void setEditedAt(LocalDateTime editedAt) {
        this.editedAt = editedAt;
    }

    public boolean isEdited() {
        return edited;
    }

    public void setEdited(boolean edited) {
        this.edited = edited;
    }

    public Integer getReplyToMessageId() {
        return replyToMessageId;
    }

    public void setReplyToMessageId(Integer replyToMessageId) {
        this.replyToMessageId = replyToMessageId;
    }

    public String getReplyToContent() {
        return replyToContent;
    }

    public void setReplyToContent(String replyToContent) {
        this.replyToContent = replyToContent;
    }

    public String getReplyToSenderName() {
        return replyToSenderName;
    }

    public void setReplyToSenderName(String replyToSenderName) {
        this.replyToSenderName = replyToSenderName;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getFileSizeFormatted() {
        return fileSizeFormatted;
    }

    public void setFileSizeFormatted(String fileSizeFormatted) {
        this.fileSizeFormatted = fileSizeFormatted;
    }

    // Helper methods
    public boolean isTextMessage() {
        return "TEXT".equals(messageType);
    }

    public boolean isFileMessage() {
        return "FILE".equals(messageType);
    }

    public boolean isImageMessage() {
        return "IMAGE".equals(messageType);
    }

    public boolean isSystemMessage() {
        return "SYSTEM".equals(messageType);
    }

    public boolean isReply() {
        return replyToMessageId != null;
    }

    public boolean hasFile() {
        return fileUrl != null && !fileUrl.trim().isEmpty();
    }

    @Override
    public String toString() {
        return "ChatMessageResponseDTO{" +
                "messageId=" + messageId +
                ", roomId=" + roomId +
                ", messageType='" + messageType + '\'' +
                ", senderId=" + senderId +
                ", sentAt=" + sentAt +
                '}';
    }
}
