package com.spazone.controller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for automatic room selection functionality in single-service appointment booking
 */
@ExtendWith(MockitoExtension.class)
public class SingleServiceAutoRoomTest {

    @Test
    public void testAutoTechnicianTriggersAutoRoom() {
        // Test that when "Auto-select technician" is chosen, room selection becomes automatic
        
        String technicianId = ""; // Empty means auto-select
        assertTrue(shouldAutoSelectRoom(technicianId));
        assertTrue(shouldDisableRoomDropdown(technicianId));
        assertTrue(shouldShowAutoRoomIndicators(technicianId));
    }

    @Test
    public void testManualTechnicianEnablesManualRoom() {
        // Test that when a specific technician is chosen, room selection becomes manual
        
        String technicianId = "123"; // Specific technician
        assertFalse(shouldAutoSelectRoom(technicianId));
        assertFalse(shouldDisableRoomDropdown(technicianId));
        assertFalse(shouldShowAutoRoomIndicators(technicianId));
    }

    @Test
    public void testRoomAutoSelectionLogic() {
        // Test the logic for automatically selecting the first available room
        
        String[] availableRooms = {"Room A", "Room B", "Room C"};
        String selectedRoom = getAutoSelectedRoom(availableRooms);
        
        assertEquals("Room A", selectedRoom, "Should auto-select the first available room");
    }

    @Test
    public void testNoRoomsAvailable() {
        // Test behavior when no rooms are available for auto-selection
        
        String[] availableRooms = {};
        String selectedRoom = getAutoSelectedRoom(availableRooms);
        
        assertNull(selectedRoom, "Should return null when no rooms available");
        assertFalse(shouldShowRoomSelection(availableRooms));
    }

    @Test
    public void testRoomSelectionWithSingleService() {
        // Test that room selection considers the single service
        
        String serviceId = "1";
        String branchId = "1";
        String date = "2024-01-15";
        String time = "10:00";
        
        assertTrue(shouldLoadRooms(serviceId, branchId, date, time));
        
        // Test with missing data
        assertFalse(shouldLoadRooms("", branchId, date, time)); // No service
        assertFalse(shouldLoadRooms(serviceId, "", date, time)); // No branch
        assertFalse(shouldLoadRooms(serviceId, branchId, "", time)); // No date
        assertFalse(shouldLoadRooms(serviceId, branchId, date, "")); // No time
    }

    @Test
    public void testFormSubmissionWithAutoRoom() {
        // Test that form submission works correctly with auto-selected room
        
        String autoRoomId = "101";
        assertTrue(canSubmitFormWithAutoRoom(autoRoomId));
        
        // Test disabled room dropdown submission
        assertTrue(shouldTemporarilyEnableRoomDropdown(true));
        assertFalse(shouldTemporarilyEnableRoomDropdown(false));
    }

    @Test
    public void testTechnicianChangeTriggersRoomUpdate() {
        // Test that changing technician selection triggers room update
        
        String previousTechnician = "123";
        String newTechnician = ""; // Auto-select
        
        assertTrue(shouldUpdateRoomsOnTechnicianChange(previousTechnician, newTechnician));
        
        // Test reverse change
        assertTrue(shouldUpdateRoomsOnTechnicianChange("", "456"));
    }

    @Test
    public void testVisualFeedbackForAutoRoom() {
        // Test visual feedback elements for auto room selection
        
        // Auto-selection state
        assertTrue(shouldShowAutoRoomLabel(true));
        assertTrue(shouldShowAutoRoomText(true));
        assertFalse(shouldShowManualRoomText(true));
        assertTrue(shouldAddAutoRoomStyling(true));
        
        // Manual selection state
        assertFalse(shouldShowAutoRoomLabel(false));
        assertFalse(shouldShowAutoRoomText(false));
        assertTrue(shouldShowManualRoomText(false));
        assertFalse(shouldAddAutoRoomStyling(false));
    }

    @Test
    public void testSingleServiceSpecificLogic() {
        // Test logic specific to single-service booking
        
        String serviceId = "1";
        assertTrue(shouldUseServiceIdInRoomQuery(serviceId));
        
        // Test that single service booking uses different API endpoint
        String expectedEndpoint = "/appointments/api/rooms/available";
        assertEquals(expectedEndpoint, getRoomApiEndpoint());
    }

    @Test
    public void testConsistencyWithMultiServiceForm() {
        // Test that single-service form behaves consistently with multi-service form
        
        // Same auto-selection logic
        assertTrue(shouldAutoSelectRoom(""));
        assertFalse(shouldAutoSelectRoom("123"));
        
        // Same visual styling
        assertTrue(shouldUseConsistentStyling());
        
        // Same form submission handling
        assertTrue(shouldHandleDisabledDropdownConsistently());
    }

    @Test
    public void testFormValidationWithAutoRoom() {
        // Test form validation when room is auto-selected
        
        String autoRoomId = "101";
        String manualRoomId = "";
        
        assertTrue(isValidRoomSelection(autoRoomId, true)); // Auto-selected room
        assertTrue(isValidRoomSelection("102", false)); // Manual with selection
        
        // Room selection is optional in single-service form
        assertTrue(isValidRoomSelection("", false)); // Manual without selection
    }

    // Helper methods for testing logic

    private boolean shouldAutoSelectRoom(String technicianId) {
        return technicianId == null || technicianId.isEmpty();
    }

    private boolean shouldDisableRoomDropdown(String technicianId) {
        return shouldAutoSelectRoom(technicianId);
    }

    private boolean shouldShowAutoRoomIndicators(String technicianId) {
        return shouldAutoSelectRoom(technicianId);
    }

    private String getAutoSelectedRoom(String[] availableRooms) {
        if (availableRooms.length == 0) return null;
        return availableRooms[0]; // Select first available room
    }

    private boolean shouldShowRoomSelection(String[] availableRooms) {
        return availableRooms.length > 0;
    }

    private boolean shouldLoadRooms(String serviceId, String branchId, String date, String time) {
        return serviceId != null && !serviceId.isEmpty() &&
               branchId != null && !branchId.isEmpty() &&
               date != null && !date.isEmpty() &&
               time != null && !time.isEmpty();
    }

    private boolean canSubmitFormWithAutoRoom(String roomId) {
        return roomId != null && !roomId.isEmpty();
    }

    private boolean shouldTemporarilyEnableRoomDropdown(boolean wasDisabled) {
        return wasDisabled;
    }

    private boolean shouldUpdateRoomsOnTechnicianChange(String oldTechnician, String newTechnician) {
        return !oldTechnician.equals(newTechnician);
    }

    private boolean shouldShowAutoRoomLabel(boolean isAutoMode) {
        return isAutoMode;
    }

    private boolean shouldShowAutoRoomText(boolean isAutoMode) {
        return isAutoMode;
    }

    private boolean shouldShowManualRoomText(boolean isAutoMode) {
        return !isAutoMode;
    }

    private boolean shouldAddAutoRoomStyling(boolean isAutoMode) {
        return isAutoMode;
    }

    private boolean shouldUseServiceIdInRoomQuery(String serviceId) {
        return serviceId != null && !serviceId.isEmpty();
    }

    private String getRoomApiEndpoint() {
        return "/appointments/api/rooms/available";
    }

    private boolean shouldUseConsistentStyling() {
        // Should use same CSS classes and styling as multi-service form
        return true;
    }

    private boolean shouldHandleDisabledDropdownConsistently() {
        // Should handle disabled dropdown submission same way as multi-service form
        return true;
    }

    private boolean isValidRoomSelection(String roomId, boolean isAutoSelected) {
        if (isAutoSelected) {
            return roomId != null && !roomId.isEmpty();
        } else {
            // For single-service manual selection, room is optional
            return true;
        }
    }

    @Test
    public void testEdgeCases() {
        // Test edge cases specific to single-service booking
        
        // Null technician ID
        assertTrue(shouldAutoSelectRoom(null));
        
        // Empty technician ID
        assertTrue(shouldAutoSelectRoom(""));
        
        // Whitespace technician ID
        assertFalse(shouldAutoSelectRoom("   ")); // Whitespace is considered a value
        
        // Valid technician ID
        assertFalse(shouldAutoSelectRoom("123"));
    }

    @Test
    public void testRoomSelectionPriority() {
        // Test room selection priority logic for single service
        
        String[] rooms = {"Standard Room", "VIP Room", "Deluxe Room"};
        String selected = getAutoSelectedRoom(rooms);
        
        // Should always select the first room in the list
        assertEquals("Standard Room", selected);
    }

    @Test
    public void testSingleServiceApiIntegration() {
        // Test API integration specific to single-service booking
        
        String serviceId = "1";
        String branchId = "1";
        String date = "2024-01-15";
        String time = "10:00";
        
        String expectedUrl = String.format(
            "/appointments/api/rooms/available?branchId=%s&datePart=%s&timePart=%s&serviceId=%s",
            branchId, date, time, serviceId
        );
        
        assertEquals(expectedUrl, buildRoomApiUrl(branchId, date, time, serviceId));
    }

    private String buildRoomApiUrl(String branchId, String date, String time, String serviceId) {
        return String.format(
            "/appointments/api/rooms/available?branchId=%s&datePart=%s&timePart=%s&serviceId=%s",
            branchId, date, time, serviceId
        );
    }

    @Test
    public void testFeatureParityWithMultiService() {
        // Test that single-service form has feature parity with multi-service form
        
        // Auto-room selection logic should be identical
        assertTrue(hasFeatureParity("auto-room-selection"));
        
        // Visual styling should be consistent
        assertTrue(hasFeatureParity("visual-styling"));
        
        // Form submission handling should be consistent
        assertTrue(hasFeatureParity("form-submission"));
        
        // Event handling should be consistent
        assertTrue(hasFeatureParity("event-handling"));
    }

    private boolean hasFeatureParity(String feature) {
        // In a real implementation, this would check that the feature
        // works consistently between single and multi-service forms
        return true;
    }
}
