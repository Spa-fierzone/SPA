package com.spazone.controller;

import com.spazone.entity.*;
import com.spazone.repository.AppointmentRepository;
import com.spazone.service.*;
import com.spazone.dto.ApiResponse;
import com.spazone.dto.ValidationResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AutoTechnicianAssignmentTest {

    @Mock
    private AppointmentService appointmentService;

    @Mock
    private UserService userService;

    @Mock
    private BranchService branchService;

    @Mock
    private SpaServiceService spaServiceService;

    @Mock
    private RoomService roomService;

    @Mock
    private AppointmentRepository appointmentRepository;

    @Mock
    private AppointmentValidationService appointmentValidationService;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private AppointmentController appointmentController;

    private User testCustomer;
    private User testTechnician1;
    private User testTechnician2;
    private Branch testBranch;
    private Service testService;
    private Room testRoom;

    @BeforeEach
    void setUp() {
        // Create test customer
        testCustomer = new User();
        testCustomer.setUserId(1);
        testCustomer.setUsername("customer1");
        testCustomer.setFullName("Test Customer");

        // Create test technicians
        testTechnician1 = new User();
        testTechnician1.setUserId(2);
        testTechnician1.setUsername("technician1");
        testTechnician1.setFullName("Test Technician 1");

        testTechnician2 = new User();
        testTechnician2.setUserId(3);
        testTechnician2.setUsername("technician2");
        testTechnician2.setFullName("Test Technician 2");

        // Create test branch
        testBranch = new Branch();
        testBranch.setBranchId(1);
        testBranch.setName("Test Branch");

        // Create test service
        testService = new Service();
        testService.setServiceId(1);
        testService.setName("Test Service");
        testService.setDuration(60);

        // Create test room
        testRoom = new Room();
        testRoom.setId(1);
        testRoom.setName("Test Room");

        // Mock authentication
        when(authentication.getName()).thenReturn("customer1");
        when(userService.findByUsername("customer1")).thenReturn(testCustomer);
    }

    @Test
    void testAutoTechnicianAssignment_Success() {
        // Arrange
        List<Integer> serviceIds = Arrays.asList(1);
        Integer branchId = 1;
        Integer technicianId = null; // Auto-assign
        String datePart = "2024-12-01";
        String timePart = "10:00";

        when(branchService.getById(branchId)).thenReturn(testBranch);
        when(spaServiceService.getServiceById(1)).thenReturn(testService);
        when(userService.findTechniciansByBranch(branchId)).thenReturn(Arrays.asList(testTechnician1, testTechnician2));
        when(appointmentRepository.findConflictingAppointments(any(), any(), any())).thenReturn(Collections.emptyList());
        when(roomService.autoAssignRoom(any(), any(), any())).thenReturn(testRoom);
        
        // Mock validation to pass
        ValidationResult validationResult = mock(ValidationResult.class);
        when(validationResult.isValid()).thenReturn(true);
        when(appointmentValidationService.validateForCreation(any(), any(), any(), any())).thenReturn(validationResult);

        // Act
        ResponseEntity<?> response = appointmentController.submitSingleAppointmentWithServices(
                serviceIds, branchId, technicianId, datePart, timePart, null, null, authentication);

        // Assert
        assertTrue(response.getStatusCode().is2xxSuccessful());
        ApiResponse apiResponse = (ApiResponse) response.getBody();
        assertTrue(apiResponse.isSuccess());
        
        // Verify that technician assignment was attempted
        verify(userService).findTechniciansByBranch(branchId);
        verify(appointmentRepository, atLeastOnce()).findConflictingAppointments(any(), any(), any());
    }

    @Test
    void testAutoTechnicianAssignment_NoAvailableTechnicians() {
        // Arrange
        List<Integer> serviceIds = Arrays.asList(1);
        Integer branchId = 1;
        Integer technicianId = null; // Auto-assign
        String datePart = "2024-12-01";
        String timePart = "10:00";

        when(branchService.getById(branchId)).thenReturn(testBranch);
        when(spaServiceService.getServiceById(1)).thenReturn(testService);
        when(userService.findTechniciansByBranch(branchId)).thenReturn(Collections.emptyList());

        // Act
        ResponseEntity<?> response = appointmentController.submitSingleAppointmentWithServices(
                serviceIds, branchId, technicianId, datePart, timePart, null, null, authentication);

        // Assert
        assertTrue(response.getStatusCode().is4xxClientError());
        ApiResponse apiResponse = (ApiResponse) response.getBody();
        assertFalse(apiResponse.isSuccess());
        assertTrue(apiResponse.getMessage().contains("Không có kỹ thuật viên nào tại chi nhánh này"));
    }

    @Test
    void testAutoTechnicianAssignment_AllTechniciansConflicted() {
        // Arrange
        List<Integer> serviceIds = Arrays.asList(1);
        Integer branchId = 1;
        Integer technicianId = null; // Auto-assign
        String datePart = "2024-12-01";
        String timePart = "10:00";

        when(branchService.getById(branchId)).thenReturn(testBranch);
        when(spaServiceService.getServiceById(1)).thenReturn(testService);
        when(userService.findTechniciansByBranch(branchId)).thenReturn(Arrays.asList(testTechnician1, testTechnician2));
        
        // Mock conflicts for all technicians
        Appointment conflictingAppointment = new Appointment();
        when(appointmentRepository.findConflictingAppointments(any(), any(), any()))
                .thenReturn(Arrays.asList(conflictingAppointment));

        // Act
        ResponseEntity<?> response = appointmentController.submitSingleAppointmentWithServices(
                serviceIds, branchId, technicianId, datePart, timePart, null, null, authentication);

        // Assert
        assertTrue(response.getStatusCode().is4xxClientError());
        ApiResponse apiResponse = (ApiResponse) response.getBody();
        assertFalse(apiResponse.isSuccess());
        assertTrue(apiResponse.getMessage().contains("Không có kỹ thuật viên nào rảnh tại thời gian đã chọn"));
    }

    @Test
    void testManualTechnicianAssignment_Success() {
        // Arrange
        List<Integer> serviceIds = Arrays.asList(1);
        Integer branchId = 1;
        Integer technicianId = 2; // Manual assignment
        String datePart = "2024-12-01";
        String timePart = "10:00";

        when(branchService.getById(branchId)).thenReturn(testBranch);
        when(spaServiceService.getServiceById(1)).thenReturn(testService);
        when(userService.getUserById(technicianId)).thenReturn(testTechnician1);
        when(appointmentRepository.findConflictingAppointments(any(), any(), any())).thenReturn(Collections.emptyList());
        when(roomService.autoAssignRoom(any(), any(), any())).thenReturn(testRoom);
        
        // Mock validation to pass
        ValidationResult validationResult = mock(ValidationResult.class);
        when(validationResult.isValid()).thenReturn(true);
        when(appointmentValidationService.validateForCreation(any(), any(), any(), any())).thenReturn(validationResult);

        // Act
        ResponseEntity<?> response = appointmentController.submitSingleAppointmentWithServices(
                serviceIds, branchId, technicianId, datePart, timePart, null, null, authentication);

        // Assert
        assertTrue(response.getStatusCode().is2xxSuccessful());
        ApiResponse apiResponse = (ApiResponse) response.getBody();
        assertTrue(apiResponse.isSuccess());
        
        // Verify that specific technician was used
        verify(userService).getUserById(technicianId);
        verify(userService, never()).findTechniciansByBranch(any());
    }

    @Test
    void testValidationWithAutoTechnician() {
        // Test that validation is called with the assigned technician ID, not null
        
        // Arrange
        List<Integer> serviceIds = Arrays.asList(1);
        Integer branchId = 1;
        Integer technicianId = null; // Auto-assign
        String datePart = "2024-12-01";
        String timePart = "10:00";

        when(branchService.getById(branchId)).thenReturn(testBranch);
        when(spaServiceService.getServiceById(1)).thenReturn(testService);
        when(userService.findTechniciansByBranch(branchId)).thenReturn(Arrays.asList(testTechnician1));
        when(appointmentRepository.findConflictingAppointments(any(), any(), any())).thenReturn(Collections.emptyList());
        when(roomService.autoAssignRoom(any(), any(), any())).thenReturn(testRoom);
        
        // Mock validation to pass
        ValidationResult validationResult = mock(ValidationResult.class);
        when(validationResult.isValid()).thenReturn(true);
        when(appointmentValidationService.validateForCreation(any(), any(), any(), any())).thenReturn(validationResult);

        // Act
        appointmentController.submitSingleAppointmentWithServices(
                serviceIds, branchId, technicianId, datePart, timePart, null, null, authentication);

        // Assert - Verify validation was called with actual technician ID, not null
        verify(appointmentValidationService).validateForCreation(
                eq(testTechnician1.getUserId()), // Should be the assigned technician's ID
                any(),
                any(),
                any()
        );
    }

    @Test
    void testValidationFailure() {
        // Test that validation failure is handled correctly
        
        // Arrange
        List<Integer> serviceIds = Arrays.asList(1);
        Integer branchId = 1;
        Integer technicianId = null; // Auto-assign
        String datePart = "2024-12-01";
        String timePart = "10:00";

        when(branchService.getById(branchId)).thenReturn(testBranch);
        when(spaServiceService.getServiceById(1)).thenReturn(testService);
        when(userService.findTechniciansByBranch(branchId)).thenReturn(Arrays.asList(testTechnician1));
        when(appointmentRepository.findConflictingAppointments(any(), any(), any())).thenReturn(Collections.emptyList());
        when(roomService.autoAssignRoom(any(), any(), any())).thenReturn(testRoom);
        
        // Mock validation to fail
        ValidationResult validationResult = mock(ValidationResult.class);
        when(validationResult.isValid()).thenReturn(false);
        when(validationResult.getFormattedErrorMessage()).thenReturn("Validation failed");
        when(appointmentValidationService.validateForCreation(any(), any(), any(), any())).thenReturn(validationResult);

        // Act
        ResponseEntity<?> response = appointmentController.submitSingleAppointmentWithServices(
                serviceIds, branchId, technicianId, datePart, timePart, null, null, authentication);

        // Assert
        assertTrue(response.getStatusCode().is4xxClientError());
        ApiResponse apiResponse = (ApiResponse) response.getBody();
        assertFalse(apiResponse.isSuccess());
        assertEquals("Validation failed", apiResponse.getMessage());
    }

    @Test
    void testAutoRoomAssignment() {
        // Test that room is auto-assigned when not provided
        
        // Arrange
        List<Integer> serviceIds = Arrays.asList(1);
        Integer branchId = 1;
        Integer technicianId = null; // Auto-assign
        String datePart = "2024-12-01";
        String timePart = "10:00";

        when(branchService.getById(branchId)).thenReturn(testBranch);
        when(spaServiceService.getServiceById(1)).thenReturn(testService);
        when(userService.findTechniciansByBranch(branchId)).thenReturn(Arrays.asList(testTechnician1));
        when(appointmentRepository.findConflictingAppointments(any(), any(), any())).thenReturn(Collections.emptyList());
        when(roomService.autoAssignRoom(any(), any(), any())).thenReturn(testRoom);
        
        // Mock validation to pass
        ValidationResult validationResult = mock(ValidationResult.class);
        when(validationResult.isValid()).thenReturn(true);
        when(appointmentValidationService.validateForCreation(any(), any(), any(), any())).thenReturn(validationResult);

        // Act
        appointmentController.submitSingleAppointmentWithServices(
                serviceIds, branchId, technicianId, datePart, timePart, null, null, authentication);

        // Assert
        verify(roomService).autoAssignRoom(eq(testBranch), any(), any());
    }
}
