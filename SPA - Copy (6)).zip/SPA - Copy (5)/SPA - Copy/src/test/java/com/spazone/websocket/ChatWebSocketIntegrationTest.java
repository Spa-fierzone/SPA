package com.spazone.websocket;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.spazone.entity.User;
import com.spazone.service.UserService;
import com.spazone.websocket.dto.ChatMessageDTO;
import com.spazone.websocket.dto.TypingIndicatorDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.stomp.*;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;

import java.lang.reflect.Type;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for WebSocket chat functionality
 * Tests real WebSocket connections and message flow
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = {
    "spring.datasource.url=jdbc:h2:mem:testdb",
    "spring.jpa.hibernate.ddl-auto=create-drop"
})
class ChatWebSocketIntegrationTest {

    @LocalServerPort
    private int port;

    @Autowired
    private UserService userService;

    private WebSocketStompClient stompClient;
    private StompSession stompSession;
    private ObjectMapper objectMapper;
    private final BlockingQueue<ChatMessageDTO> messageQueue = new LinkedBlockingQueue<>();
    private final BlockingQueue<TypingIndicatorDTO> typingQueue = new LinkedBlockingQueue<>();

    @BeforeEach
    void setUp() throws Exception {
        stompClient = new WebSocketStompClient(new StandardWebSocketClient());
        stompClient.setMessageConverter(new MappingJackson2MessageConverter());
        objectMapper = new ObjectMapper();

        String url = "ws://localhost:" + port + "/ws/chat";
        
        StompSessionHandler sessionHandler = new TestStompSessionHandler();
        stompSession = stompClient.connect(url, sessionHandler).get(5, TimeUnit.SECONDS);
        
        assertTrue(stompSession.isConnected());
    }

    @Test
    void testWebSocketConnection() {
        assertTrue(stompSession.isConnected());
    }

    @Test
    void testSendMessage() throws Exception {
        // Given
        Integer roomId = 1;
        String messageContent = "Test message";
        
        // Subscribe to room messages
        stompSession.subscribe("/topic/chat/" + roomId, new StompFrameHandler() {
            @Override
            public Type getPayloadType(StompHeaders headers) {
                return ChatMessageDTO.class;
            }

            @Override
            public void handleFrame(StompHeaders headers, Object payload) {
                messageQueue.offer((ChatMessageDTO) payload);
            }
        });

        // When
        ChatMessageDTO messageDTO = new ChatMessageDTO();
        messageDTO.setRoomId(roomId);
        messageDTO.setContent(messageContent);
        
        stompSession.send("/app/chat/send", messageDTO);

        // Then
        ChatMessageDTO receivedMessage = messageQueue.poll(5, TimeUnit.SECONDS);
        assertNotNull(receivedMessage);
        assertEquals(messageContent, receivedMessage.getContent());
        assertEquals(roomId, receivedMessage.getRoomId());
    }

    @Test
    void testTypingIndicator() throws Exception {
        // Given
        Integer roomId = 1;
        
        // Subscribe to typing indicators
        stompSession.subscribe("/topic/chat/" + roomId + "/typing", new StompFrameHandler() {
            @Override
            public Type getPayloadType(StompHeaders headers) {
                return TypingIndicatorDTO.class;
            }

            @Override
            public void handleFrame(StompHeaders headers, Object payload) {
                typingQueue.offer((TypingIndicatorDTO) payload);
            }
        });

        // When
        TypingIndicatorDTO typingDTO = new TypingIndicatorDTO();
        typingDTO.setRoomId(roomId);
        typingDTO.setTyping(true);
        
        stompSession.send("/app/chat/typing", typingDTO);

        // Then
        TypingIndicatorDTO receivedTyping = typingQueue.poll(5, TimeUnit.SECONDS);
        assertNotNull(receivedTyping);
        assertTrue(receivedTyping.isTyping());
        assertEquals(roomId, receivedTyping.getRoomId());
    }

    @Test
    void testMultipleClients() throws Exception {
        // Create second client
        WebSocketStompClient client2 = new WebSocketStompClient(new StandardWebSocketClient());
        client2.setMessageConverter(new MappingJackson2MessageConverter());
        
        String url = "ws://localhost:" + port + "/ws/chat";
        StompSession session2 = client2.connect(url, new TestStompSessionHandler()).get(5, TimeUnit.SECONDS);
        
        assertTrue(session2.isConnected());
        
        // Both clients subscribe to same room
        Integer roomId = 1;
        BlockingQueue<ChatMessageDTO> queue1 = new LinkedBlockingQueue<>();
        BlockingQueue<ChatMessageDTO> queue2 = new LinkedBlockingQueue<>();
        
        stompSession.subscribe("/topic/chat/" + roomId, new StompFrameHandler() {
            @Override
            public Type getPayloadType(StompHeaders headers) {
                return ChatMessageDTO.class;
            }

            @Override
            public void handleFrame(StompHeaders headers, Object payload) {
                queue1.offer((ChatMessageDTO) payload);
            }
        });
        
        session2.subscribe("/topic/chat/" + roomId, new StompFrameHandler() {
            @Override
            public Type getPayloadType(StompHeaders headers) {
                return ChatMessageDTO.class;
            }

            @Override
            public void handleFrame(StompHeaders headers, Object payload) {
                queue2.offer((ChatMessageDTO) payload);
            }
        });

        // Client 1 sends message
        ChatMessageDTO messageDTO = new ChatMessageDTO();
        messageDTO.setRoomId(roomId);
        messageDTO.setContent("Multi-client test");
        
        stompSession.send("/app/chat/send", messageDTO);

        // Both clients should receive the message
        ChatMessageDTO message1 = queue1.poll(5, TimeUnit.SECONDS);
        ChatMessageDTO message2 = queue2.poll(5, TimeUnit.SECONDS);
        
        assertNotNull(message1);
        assertNotNull(message2);
        assertEquals("Multi-client test", message1.getContent());
        assertEquals("Multi-client test", message2.getContent());
        
        session2.disconnect();
    }

    @Test
    void testErrorHandling() throws Exception {
        // Subscribe to error queue
        BlockingQueue<Object> errorQueue = new LinkedBlockingQueue<>();
        
        stompSession.subscribe("/user/queue/errors", new StompFrameHandler() {
            @Override
            public Type getPayloadType(StompHeaders headers) {
                return Object.class;
            }

            @Override
            public void handleFrame(StompHeaders headers, Object payload) {
                errorQueue.offer(payload);
            }
        });

        // Send invalid message (empty content)
        ChatMessageDTO invalidMessage = new ChatMessageDTO();
        invalidMessage.setRoomId(1);
        invalidMessage.setContent(""); // Empty content should trigger error
        
        stompSession.send("/app/chat/send", invalidMessage);

        // Should receive error message
        Object error = errorQueue.poll(5, TimeUnit.SECONDS);
        assertNotNull(error);
    }

    @Test
    void testRoomSubscription() throws Exception {
        // Test subscribing to a specific room
        Integer roomId = 1;
        BlockingQueue<Object> subscriptionQueue = new LinkedBlockingQueue<>();
        
        StompSession.Subscription subscription = stompSession.subscribe("/topic/chat/" + roomId, new StompFrameHandler() {
            @Override
            public Type getPayloadType(StompHeaders headers) {
                return Object.class;
            }

            @Override
            public void handleFrame(StompHeaders headers, Object payload) {
                subscriptionQueue.offer(payload);
            }
        });

        assertNotNull(subscription);
        assertTrue(subscription.getSubscriptionId() != null);
        
        // Unsubscribe
        subscription.unsubscribe();
    }

    @Test
    void testConnectionResilience() throws Exception {
        // Test that connection can handle disconnection and reconnection
        assertTrue(stompSession.isConnected());
        
        // Disconnect
        stompSession.disconnect();
        assertFalse(stompSession.isConnected());
        
        // Reconnect
        String url = "ws://localhost:" + port + "/ws/chat";
        stompSession = stompClient.connect(url, new TestStompSessionHandler()).get(5, TimeUnit.SECONDS);
        assertTrue(stompSession.isConnected());
    }

    @Test
    void testConcurrentMessages() throws Exception {
        // Test sending multiple messages concurrently
        Integer roomId = 1;
        int messageCount = 10;
        BlockingQueue<ChatMessageDTO> concurrentQueue = new LinkedBlockingQueue<>();
        
        stompSession.subscribe("/topic/chat/" + roomId, new StompFrameHandler() {
            @Override
            public Type getPayloadType(StompHeaders headers) {
                return ChatMessageDTO.class;
            }

            @Override
            public void handleFrame(StompHeaders headers, Object payload) {
                concurrentQueue.offer((ChatMessageDTO) payload);
            }
        });

        // Send multiple messages
        for (int i = 0; i < messageCount; i++) {
            ChatMessageDTO messageDTO = new ChatMessageDTO();
            messageDTO.setRoomId(roomId);
            messageDTO.setContent("Concurrent message " + i);
            
            stompSession.send("/app/chat/send", messageDTO);
        }

        // Verify all messages are received
        int receivedCount = 0;
        while (receivedCount < messageCount) {
            ChatMessageDTO message = concurrentQueue.poll(2, TimeUnit.SECONDS);
            if (message != null) {
                receivedCount++;
                assertTrue(message.getContent().startsWith("Concurrent message"));
            } else {
                break;
            }
        }
        
        assertEquals(messageCount, receivedCount);
    }

    // Helper class for STOMP session handling
    private static class TestStompSessionHandler extends StompSessionHandlerAdapter {
        @Override
        public void afterConnected(StompSession session, StompHeaders connectedHeaders) {
            System.out.println("Connected to WebSocket");
        }

        @Override
        public void handleException(StompSession session, StompCommand command, StompHeaders headers, byte[] payload, Throwable exception) {
            System.err.println("WebSocket exception: " + exception.getMessage());
        }

        @Override
        public void handleTransportError(StompSession session, Throwable exception) {
            System.err.println("WebSocket transport error: " + exception.getMessage());
        }
    }
}
