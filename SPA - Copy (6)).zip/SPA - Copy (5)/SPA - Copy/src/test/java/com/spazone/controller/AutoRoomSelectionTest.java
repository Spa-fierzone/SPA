package com.spazone.controller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for automatic room selection functionality in multi-service appointment booking
 */
@ExtendWith(MockitoExtension.class)
public class AutoRoomSelectionTest {

    @Test
    public void testAutoTechnicianTriggersAutoRoom() {
        // Test that when "Auto-select technician" is chosen, room selection becomes automatic
        
        String technicianId = ""; // Empty means auto-select
        assertTrue(shouldAutoSelectRoom(technicianId));
        assertTrue(shouldDisableRoomDropdown(technicianId));
        assertTrue(shouldShowAutoRoomIndicators(technicianId));
    }

    @Test
    public void testManualTechnicianEnablesManualRoom() {
        // Test that when a specific technician is chosen, room selection becomes manual
        
        String technicianId = "123"; // Specific technician
        assertFalse(shouldAutoSelectRoom(technicianId));
        assertFalse(shouldDisableRoomDropdown(technicianId));
        assertFalse(shouldShowAutoRoomIndicators(technicianId));
    }

    @Test
    public void testRoomAutoSelectionLogic() {
        // Test the logic for automatically selecting the first available room
        
        String[] availableRooms = {"Room A", "Room B", "Room C"};
        String selectedRoom = getAutoSelectedRoom(availableRooms);
        
        assertEquals("Room A", selectedRoom, "Should auto-select the first available room");
    }

    @Test
    public void testNoRoomsAvailable() {
        // Test behavior when no rooms are available for auto-selection
        
        String[] availableRooms = {};
        String selectedRoom = getAutoSelectedRoom(availableRooms);
        
        assertNull(selectedRoom, "Should return null when no rooms available");
        assertFalse(shouldShowRoomSelection(availableRooms));
    }

    @Test
    public void testRoomSelectionWithServices() {
        // Test that room selection considers selected services
        
        String[] serviceIds = {"1", "2", "3"};
        String branchId = "1";
        String date = "2024-01-15";
        String time = "10:00";
        
        assertTrue(shouldLoadRooms(serviceIds, branchId, date, time));
        
        // Test with missing data
        assertFalse(shouldLoadRooms(new String[]{}, branchId, date, time)); // No services
        assertFalse(shouldLoadRooms(serviceIds, "", date, time)); // No branch
        assertFalse(shouldLoadRooms(serviceIds, branchId, "", time)); // No date
        assertFalse(shouldLoadRooms(serviceIds, branchId, date, "")); // No time
    }

    @Test
    public void testFormSubmissionWithAutoRoom() {
        // Test that form submission works correctly with auto-selected room
        
        String autoRoomId = "101";
        assertTrue(canSubmitFormWithAutoRoom(autoRoomId));
        
        // Test disabled room dropdown submission
        assertTrue(shouldTemporarilyEnableRoomDropdown(true));
        assertFalse(shouldTemporarilyEnableRoomDropdown(false));
    }

    @Test
    public void testTechnicianChangeTriggersRoomUpdate() {
        // Test that changing technician selection triggers room update
        
        String previousTechnician = "123";
        String newTechnician = ""; // Auto-select
        
        assertTrue(shouldUpdateRoomsOnTechnicianChange(previousTechnician, newTechnician));
        
        // Test reverse change
        assertTrue(shouldUpdateRoomsOnTechnicianChange("", "456"));
    }

    @Test
    public void testVisualFeedbackForAutoRoom() {
        // Test visual feedback elements for auto room selection
        
        // Auto-selection state
        assertTrue(shouldShowAutoRoomLabel(true));
        assertTrue(shouldShowAutoRoomText(true));
        assertFalse(shouldShowManualRoomText(true));
        assertTrue(shouldAddAutoRoomStyling(true));
        
        // Manual selection state
        assertFalse(shouldShowAutoRoomLabel(false));
        assertFalse(shouldShowAutoRoomText(false));
        assertTrue(shouldShowManualRoomText(false));
        assertFalse(shouldAddAutoRoomStyling(false));
    }

    @Test
    public void testIntegrationWithBranchSelection() {
        // Test that auto room selection works with auto branch selection
        
        String autoBranchId = "1";
        String autoTechnicianId = "";
        
        assertTrue(shouldIntegrateWithAutoBranch(autoBranchId, autoTechnicianId));
        assertTrue(shouldLoadRoomsForAutoBranch(autoBranchId));
    }

    @Test
    public void testServiceChangeTriggersRoomUpdate() {
        // Test that service selection/deselection triggers room update
        
        assertTrue(shouldUpdateRoomsOnServiceChange());
        assertTrue(shouldUpdateRoomsOnServiceDeselection());
        assertTrue(shouldUpdateRoomsOnServiceFilter());
    }

    @Test
    public void testUserExperienceMessages() {
        // Test user messages for auto room selection
        
        String roomName = "Phòng VIP 1";
        String successMessage = getAutoRoomMessage(roomName);
        assertTrue(successMessage.contains("Phòng tự động chọn"));
        assertTrue(successMessage.contains(roomName));
        
        String noRoomsMessage = getNoRoomsMessage();
        assertTrue(noRoomsMessage.contains("Không có phòng khả dụng"));
    }

    // Helper methods for testing logic

    private boolean shouldAutoSelectRoom(String technicianId) {
        return technicianId == null || technicianId.isEmpty();
    }

    private boolean shouldDisableRoomDropdown(String technicianId) {
        return shouldAutoSelectRoom(technicianId);
    }

    private boolean shouldShowAutoRoomIndicators(String technicianId) {
        return shouldAutoSelectRoom(technicianId);
    }

    private String getAutoSelectedRoom(String[] availableRooms) {
        if (availableRooms.length == 0) return null;
        return availableRooms[0]; // Select first available room
    }

    private boolean shouldShowRoomSelection(String[] availableRooms) {
        return availableRooms.length > 0;
    }

    private boolean shouldLoadRooms(String[] serviceIds, String branchId, String date, String time) {
        return serviceIds.length > 0 && 
               branchId != null && !branchId.isEmpty() &&
               date != null && !date.isEmpty() &&
               time != null && !time.isEmpty();
    }

    private boolean canSubmitFormWithAutoRoom(String roomId) {
        return roomId != null && !roomId.isEmpty();
    }

    private boolean shouldTemporarilyEnableRoomDropdown(boolean wasDisabled) {
        return wasDisabled;
    }

    private boolean shouldUpdateRoomsOnTechnicianChange(String oldTechnician, String newTechnician) {
        return !oldTechnician.equals(newTechnician);
    }

    private boolean shouldShowAutoRoomLabel(boolean isAutoMode) {
        return isAutoMode;
    }

    private boolean shouldShowAutoRoomText(boolean isAutoMode) {
        return isAutoMode;
    }

    private boolean shouldShowManualRoomText(boolean isAutoMode) {
        return !isAutoMode;
    }

    private boolean shouldAddAutoRoomStyling(boolean isAutoMode) {
        return isAutoMode;
    }

    private boolean shouldIntegrateWithAutoBranch(String branchId, String technicianId) {
        return branchId != null && !branchId.isEmpty() && shouldAutoSelectRoom(technicianId);
    }

    private boolean shouldLoadRoomsForAutoBranch(String branchId) {
        return branchId != null && !branchId.isEmpty();
    }

    private boolean shouldUpdateRoomsOnServiceChange() {
        return true; // Always update rooms when services change
    }

    private boolean shouldUpdateRoomsOnServiceDeselection() {
        return true; // Always update rooms when services are deselected
    }

    private boolean shouldUpdateRoomsOnServiceFilter() {
        return true; // Always update rooms when services are filtered
    }

    private String getAutoRoomMessage(String roomName) {
        return String.format("Phòng tự động chọn: %s", roomName);
    }

    private String getNoRoomsMessage() {
        return "Không có phòng khả dụng cho thời gian đã chọn";
    }

    @Test
    public void testEdgeCases() {
        // Test edge cases
        
        // Null technician ID
        assertTrue(shouldAutoSelectRoom(null));
        
        // Empty technician ID
        assertTrue(shouldAutoSelectRoom(""));
        
        // Whitespace technician ID
        assertFalse(shouldAutoSelectRoom("   ")); // Whitespace is considered a value
        
        // Valid technician ID
        assertFalse(shouldAutoSelectRoom("123"));
    }

    @Test
    public void testRoomSelectionPriority() {
        // Test room selection priority logic
        
        String[] rooms = {"Standard Room", "VIP Room", "Deluxe Room"};
        String selected = getAutoSelectedRoom(rooms);
        
        // Should always select the first room in the list
        assertEquals("Standard Room", selected);
    }

    @Test
    public void testFormValidationWithAutoRoom() {
        // Test form validation when room is auto-selected
        
        String autoRoomId = "101";
        String manualRoomId = "";
        
        assertTrue(isValidRoomSelection(autoRoomId, true)); // Auto-selected room
        assertFalse(isValidRoomSelection(manualRoomId, false)); // Manual but empty
        assertTrue(isValidRoomSelection("102", false)); // Manual with selection
    }

    private boolean isValidRoomSelection(String roomId, boolean isAutoSelected) {
        if (isAutoSelected) {
            return roomId != null && !roomId.isEmpty();
        } else {
            // For manual selection, room is required if not auto-selected
            return roomId != null && !roomId.isEmpty();
        }
    }
}
