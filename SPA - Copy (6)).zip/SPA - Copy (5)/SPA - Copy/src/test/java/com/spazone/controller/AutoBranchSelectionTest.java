package com.spazone.controller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for automatic branch selection functionality in multi-service appointment booking
 */
@ExtendWith(MockitoExtension.class)
public class AutoBranchSelectionTest {

    @Test
    public void testSingleBranchServiceSelection() {
        // Test that when all selected services are from the same branch,
        // the appointment branch should be auto-selected and disabled
        
        // Simulate service selection from branch 1
        String branchId1 = "1";
        String branchName1 = "Chi nhánh 1";
        
        // All services from same branch should result in auto-selection
        assertTrue(shouldAutoSelectBranch(branchId1, branchId1, branchId1));
        assertEquals(branchId1, getExpectedBranchSelection(branchId1, branchId1, branchId1));
    }

    @Test
    public void testMultipleBranchServiceSelection() {
        // Test that when services are from different branches,
        // an error should be shown and the last service should be deselected
        
        String branchId1 = "1";
        String branchId2 = "2";
        
        // Services from different branches should not be allowed
        assertFalse(shouldAutoSelectBranch(branchId1, branchId2));
        assertNull(getExpectedBranchSelection(branchId1, branchId2));
    }

    @Test
    public void testNoServiceSelection() {
        // Test that when no services are selected,
        // the branch dropdown should be enabled for manual selection
        
        assertFalse(shouldAutoSelectBranch());
        assertNull(getExpectedBranchSelection());
    }

    @Test
    public void testServiceDeselection() {
        // Test that when all services are deselected,
        // the branch dropdown should return to manual selection mode
        
        // Initially auto-selected
        assertTrue(shouldAutoSelectBranch("1", "1"));
        
        // After deselection, should return to manual
        assertFalse(shouldAutoSelectBranch());
    }

    @Test
    public void testBranchFilterSynchronization() {
        // Test that the service filter branch dropdown should sync
        // with the appointment branch dropdown when auto-selected
        
        String selectedBranch = "1";
        assertTrue(shouldSyncBranchFilter(selectedBranch));
    }

    @Test
    public void testFormSubmissionWithDisabledBranch() {
        // Test that form submission works correctly when branch dropdown is disabled
        
        String autoBranchId = "1";
        assertTrue(canSubmitFormWithDisabledBranch(autoBranchId));
    }

    @Test
    public void testCrossBranchValidation() {
        // Test validation logic for cross-branch service selection
        
        // Same branch - valid
        assertTrue(isValidBranchCombination("1", "1", "1"));
        
        // Different branches - invalid
        assertFalse(isValidBranchCombination("1", "2"));
        assertFalse(isValidBranchCombination("1", "1", "2"));
        
        // Empty selection - valid (manual selection)
        assertTrue(isValidBranchCombination());
    }

    @Test
    public void testUserExperienceMessages() {
        // Test that appropriate user messages are shown
        
        // Auto-selection success message
        String successMessage = getAutoSelectionMessage("1", "Chi nhánh Quận 1");
        assertTrue(successMessage.contains("Chi nhánh tự động chọn"));
        assertTrue(successMessage.contains("Chi nhánh Quận 1"));
        
        // Cross-branch error message
        String errorMessage = getCrossBranchErrorMessage("Chi nhánh 1", "Chi nhánh 2");
        assertTrue(errorMessage.contains("nhiều chi nhánh"));
        assertTrue(errorMessage.contains("Chi nhánh 1"));
        assertTrue(errorMessage.contains("Chi nhánh 2"));
    }

    @Test
    public void testVisualFeedback() {
        // Test visual feedback elements
        
        // Auto-selected state
        assertTrue(shouldShowAutoLabel(true));
        assertTrue(shouldShowHelpText(true));
        assertTrue(shouldDisableBranchSelect(true));
        assertTrue(shouldAddLightBackground(true));
        
        // Manual selection state
        assertFalse(shouldShowAutoLabel(false));
        assertFalse(shouldShowHelpText(false));
        assertFalse(shouldDisableBranchSelect(false));
        assertFalse(shouldAddLightBackground(false));
    }

    // Helper methods for testing logic

    private boolean shouldAutoSelectBranch(String... branchIds) {
        if (branchIds.length == 0) return false;

        String firstBranch = branchIds[0];
        if (firstBranch == null || firstBranch.isEmpty()) return false;

        for (String branchId : branchIds) {
            if (branchId == null || !firstBranch.equals(branchId)) {
                return false;
            }
        }
        return true;
    }

    private String getExpectedBranchSelection(String... branchIds) {
        if (branchIds.length == 0) return null;

        String firstBranch = branchIds[0];
        if (firstBranch == null || firstBranch.isEmpty()) return null;

        for (String branchId : branchIds) {
            if (branchId == null || !firstBranch.equals(branchId)) {
                return null; // Cross-branch selection not allowed
            }
        }
        return firstBranch;
    }

    private boolean shouldSyncBranchFilter(String selectedBranch) {
        return selectedBranch != null && !selectedBranch.isEmpty();
    }

    private boolean canSubmitFormWithDisabledBranch(String branchId) {
        // Should be able to submit if branch is auto-selected
        return branchId != null && !branchId.isEmpty();
    }

    private boolean isValidBranchCombination(String... branchIds) {
        if (branchIds.length == 0) return true; // No selection is valid
        
        String firstBranch = branchIds[0];
        for (String branchId : branchIds) {
            if (!firstBranch.equals(branchId)) {
                return false;
            }
        }
        return true;
    }

    private String getAutoSelectionMessage(String branchId, String branchName) {
        return String.format("Chi nhánh tự động chọn: %s", branchName);
    }

    private String getCrossBranchErrorMessage(String... branchNames) {
        return String.format("Không thể chọn dịch vụ từ nhiều chi nhánh khác nhau. Chi nhánh hiện tại: %s", 
                           String.join(", ", branchNames));
    }

    private boolean shouldShowAutoLabel(boolean isAutoSelected) {
        return isAutoSelected;
    }

    private boolean shouldShowHelpText(boolean isAutoSelected) {
        return isAutoSelected;
    }

    private boolean shouldDisableBranchSelect(boolean isAutoSelected) {
        return isAutoSelected;
    }

    private boolean shouldAddLightBackground(boolean isAutoSelected) {
        return isAutoSelected;
    }

    @Test
    public void testEdgeCases() {
        // Test edge cases
        
        // Null branch IDs
        assertFalse(shouldAutoSelectBranch((String) null));
        
        // Empty branch IDs
        assertFalse(shouldAutoSelectBranch(""));
        
        // Mixed null and valid branch IDs
        assertFalse(isValidBranchCombination("1", null, "1"));
    }

    @Test
    public void testServiceQuantityChanges() {
        // Test that quantity changes don't affect branch selection
        // (since branch is determined by service selection, not quantity)
        
        String branchId = "1";
        
        // Quantity changes should not affect branch auto-selection
        assertTrue(shouldAutoSelectBranch(branchId, branchId));
        
        // Branch should remain auto-selected regardless of quantity
        assertEquals(branchId, getExpectedBranchSelection(branchId, branchId));
    }

    @Test
    public void testServiceFiltering() {
        // Test that service filtering properly handles branch selection
        
        // When services are filtered out and deselected,
        // branch selection should be re-evaluated
        assertTrue(shouldReEvaluateBranchOnFilter());
    }

    private boolean shouldReEvaluateBranchOnFilter() {
        // When filtering causes service deselection,
        // branch selection should be re-evaluated
        return true;
    }
}
