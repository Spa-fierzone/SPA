# Room Availability Logic Fix

## Vấn đề đã được khắc phục

### Mô tả vấn đề:
- Khi tạo appointment mới, room có capacity khả dụng nhưng không hiển thị trong danh sách available rooms
- Cụ thể: Room có appointment lúc 11:11CH với status 'cancelled' hoặc 'completed' vẫn bị loại trừ khỏi danh sách available rooms
- Điều này dẫn đến việc room có capacity > 0 nhưng không thể được assign cho appointment mới

### Nguyên nhân:
Query trong `RoomRepository.findAvailableRooms()` loại trừ **tất cả** các room có appointment trong khoảng thời gian đó, bất kể appointment có status gì:

```sql
SELECT r FROM Room r WHERE r.branch = :branch AND r.status = 'available' AND r.capacity > 0 AND r.id NOT IN (
    SELECT a.room.id FROM Appointment a WHERE a.branch = :branch AND a.room IS NOT NULL 
    AND ((a.startTime < :endTime AND a.endTime > :startTime))
)
```

**Vấn đề:** Query này không filter theo status của appointment, nên:
- Appointment với status 'cancelled', 'completed', 'CHECKED_OUT' vẫn làm room bị loại trừ
- Trong khi đó, khi appointment bị cancel/complete, room capacity đã được restore lại
- Kết quả: Room có capacity nhưng không available

## Giải pháp đã áp dụng

### Thay đổi trong RoomRepository.java:
Sửa query để chỉ loại trừ những room có appointment với status **đang active**:

```sql
SELECT r FROM Room r WHERE r.branch = :branch AND r.status = 'available' AND r.capacity > 0 AND r.id NOT IN (
    SELECT a.room.id FROM Appointment a WHERE a.branch = :branch AND a.room IS NOT NULL 
    AND a.status IN ('scheduled', 'confirmed', 'CHECK_IN', 'CHECKED_IN')
    AND ((a.startTime < :endTime AND a.endTime > :startTime))
)
```

### Các status được xử lý:
- **Active statuses (loại trừ room):** 'scheduled', 'confirmed', 'CHECK_IN', 'CHECKED_IN'
- **Inactive statuses (không loại trừ room):** 'cancelled', 'CHECKED_OUT', 'completed'

### Files đã thay đổi:
1. `src/main/java/com/spazone/repository/RoomRepository.java`
   - Sửa method `findAvailableRooms()`
   - Sửa method `findOneAvailableRoom()`

2. `src/test/java/com/spazone/service/RoomCapacityTest.java`
   - Thêm test case `testRoomAvailabilityWithCancelledAppointment()`

## Kết quả

### Trước khi fix:
- Room có appointment cancelled/completed vẫn bị loại trừ khỏi available rooms
- Capacity > 0 nhưng room không thể assign cho appointment mới
- Lỗi: "Không có phòng nào khả dụng cho thời gian này"

### Sau khi fix:
- Room với appointment cancelled/completed có thể được assign cho appointment mới
- Logic capacity hoạt động đúng
- Room availability chính xác theo trạng thái thực tế của appointment

## Testing

Đã test thành công với:
- `mvn test -Dtest=RoomCapacityTest` - PASS (7 tests)
- Test case mới verify rằng room với cancelled appointment vẫn available

## Tác động

### Positive:
- ✅ Room availability logic chính xác hơn
- ✅ Tận dụng tối đa capacity của room
- ✅ Không còn lỗi "không có phòng khả dụng" khi room thực sự available
- ✅ Logic capacity vẫn hoạt động đúng

### Risk Assessment:
- ⚠️ Cần đảm bảo tất cả appointment status được handle đúng
- ⚠️ Cần monitor để đảm bảo không có side effect

## Recommendation

1. **Monitor production:** Theo dõi room assignment sau khi deploy
2. **Data validation:** Kiểm tra data để đảm bảo không có appointment status bất thường
3. **Future enhancement:** Có thể thêm enum cho appointment status để tránh hardcode string
