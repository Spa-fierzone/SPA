-- =============================================
-- SPA MANAGEMENT DATABASE SCRIPT
-- Essential Components Only with Unicode Support
-- =============================================

-- 1. CREATE DATABASE
CREATE DATABASE [spa_management]
GO

USE [spa_management]
GO

-- 2. CREATE SEQUENCE
CREATE SEQUENCE [dbo].[appointment_handled_seq]
AS [bigint]
START WITH 1
INCREMENT BY 50
MINVALUE -9223372036854775808
MAXVALUE 9223372036854775807
CACHE
GO

-- 3. CREATE TABLES

-- Table: roles
CREATE TABLE [dbo].[roles](
	[role_id] [int] IDENTITY(1,1) NOT NULL,
	[description] [nvarchar](255) NULL,
	[role_name] [nvarchar](50) NOT NULL,
	PRIMARY KEY CLUSTERED ([role_id] ASC),
	UNIQUE ([role_name])
)
GO

-- Table: branches
CREATE TABLE [dbo].[branches](
	[branch_id] [int] IDENTITY(1,1) NOT NULL,
	[address] [nvarchar](255) NULL,
	[capacity] [int] NULL,
	[created_at] [datetime2](6) NULL,
	[email] [nvarchar](255) NULL,
	[holiday_schedule] [nvarchar](255) NULL,
	[is_active] [bit] NULL,
	[manager_id] [int] NULL,
	[name] [nvarchar](255) NULL,
	[opening_hours] [nvarchar](255) NULL,
	[operating_hours] [nvarchar](255) NULL,
	[phone] [nvarchar](255) NULL,
	[status] [nvarchar](255) NULL,
	[updated_at] [datetime2](6) NULL,
	PRIMARY KEY CLUSTERED ([branch_id] ASC)
)
GO

-- Table: users
CREATE TABLE [dbo].[users](
	[user_id] [int] IDENTITY(1,1) NOT NULL,
	[address] [nvarchar](4000) NULL,
	[base_salary] [numeric](10, 2) NULL,
	[created_at] [datetime2](6) NOT NULL,
	[date_of_birth] [date] NULL,
	[email] [nvarchar](100) NOT NULL,
	[email_verified] [bit] NULL,
	[enabled] [bit] NOT NULL,
	[full_name] [nvarchar](100) NOT NULL,
	[gender] [nvarchar](10) NULL,
	[last_check_in] [datetime2](6) NULL,
	[last_check_out] [datetime2](6) NULL,
	[last_login] [datetime2](6) NULL,
	[last_login_attempt] [datetime2](6) NULL,
	[last_password_change] [datetime2](6) NULL,
	[last_visit_date] [datetime2](6) NULL,
	[login_attempts] [int] NULL,
	[otp_code] [nvarchar](10) NULL,
	[otp_expiry] [datetime2](6) NULL,
	[password] [nvarchar](255) NOT NULL,
	[performance_score] [numeric](5, 2) NULL,
	[phone] [nvarchar](20) NULL,
	[phone_verified] [bit] NULL,
	[preferred_branch_id] [int] NULL,
	[profile_picture] [nvarchar](255) NULL,
	[reset_password_token] [nvarchar](255) NULL,
	[reset_password_token_expiry] [datetime2](6) NULL,
	[status] [nvarchar](20) NULL,
	[total_spent] [numeric](10, 2) NULL,
	[total_working_hours] [numeric](10, 2) NULL,
	[two_factor_enabled] [bit] NULL,
	[two_factor_secret] [nvarchar](100) NULL,
	[updated_at] [datetime2](6) NOT NULL,
	[username] [nvarchar](50) NOT NULL,
	[verification_token] [nvarchar](255) NULL,
	[verification_token_expiry] [datetime2](6) NULL,
	[vip_level] [nvarchar](20) NULL,
	[branch_id] [int] NULL,
	PRIMARY KEY CLUSTERED ([user_id] ASC),
	UNIQUE ([email]),
	UNIQUE ([username])
)
GO

-- Table: user_roles
CREATE TABLE [dbo].[user_roles](
	[user_id] [int] NOT NULL,
	[role_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([user_id] ASC, [role_id] ASC)
)
GO

-- Table: service_categories
CREATE TABLE [dbo].[service_categories](
	[category_id] [int] IDENTITY(1,1) NOT NULL,
	[created_at] [datetime2](6) NULL,
	[description] [nvarchar](4000) NULL,
	[name] [nvarchar](255) NULL,
	[parent_category_id] [int] NULL,
	PRIMARY KEY CLUSTERED ([category_id] ASC)
)
GO

-- Table: services
CREATE TABLE [dbo].[services](
	[service_id] [int] IDENTITY(1,1) NOT NULL,
	[created_at] [datetime2](6) NULL,
	[description] [nvarchar](4000) NULL,
	[duration] [int] NOT NULL,
	[image_url] [nvarchar](255) NULL,
	[name] [nvarchar](255) NULL,
	[price] [numeric](38, 2) NULL,
	[status] [nvarchar](255) NULL,
	[updated_at] [datetime2](6) NULL,
	[category_id] [int] NULL,
	[branch_id] [int] NULL,
	PRIMARY KEY CLUSTERED ([service_id] ASC)
)
GO

-- Table: rooms
CREATE TABLE [dbo].[rooms](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[capacity] [int] NULL,
	[description] [nvarchar](1000) NULL,
	[name] [nvarchar](100) NOT NULL,
	[status] [nvarchar](20) NULL,
	[branch_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([id] ASC)
)
GO

-- Table: appointments
CREATE TABLE [dbo].[appointments](
	[appointment_id] [int] IDENTITY(1,1) NOT NULL,
	[appointment_date] [datetime2](6) NULL,
	[cancellation_reason] [nvarchar](4000) NULL,
	[check_in_time] [datetime2](6) NULL,
	[check_out_time] [datetime2](6) NULL,
	[checkin_time] [datetime2](6) NULL,
	[checkout_time] [datetime2](6) NULL,
	[created_at] [datetime2](6) NULL,
	[end_time] [datetime2](6) NULL,
	[notes] [nvarchar](4000) NULL,
	[reminder_method] [nvarchar](255) NULL,
	[reminder_sent] [bit] NULL,
	[reminder_sent_at] [datetime2](6) NULL,
	[special_requests] [nvarchar](4000) NULL,
	[start_time] [datetime2](6) NULL,
	[status] [nvarchar](255) NULL,
	[updated_at] [datetime2](6) NULL,
	[branch_id] [int] NOT NULL,
	[customer_id] [int] NOT NULL,
	[preferred_technician_id] [int] NULL,
	[room_id] [int] NULL,
	[service_id] [int] NOT NULL,
	[technician_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([appointment_id] ASC)
)
GO

-- Table: appointment_handled
CREATE TABLE [dbo].[appointment_handled](
	[id] [bigint] NOT NULL,
	[handled_at] [datetime2](6) NULL,
	[appointment_appointment_id] [int] NULL,
	[receptionist_user_id] [int] NULL,
	PRIMARY KEY CLUSTERED ([id] ASC)
)
GO

-- Table: appointment_services
CREATE TABLE [dbo].[appointment_services](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[created_at] [datetime2](6) NULL,
	[custom_price] [numeric](10, 2) NULL,
	[notes] [nvarchar](1000) NULL,
	[quantity] [int] NULL,
	[appointment_id] [int] NOT NULL,
	[service_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([id] ASC)
)
GO

-- Table: attendances
CREATE TABLE [dbo].[attendances](
	[attendance_id] [int] IDENTITY(1,1) NOT NULL,
	[break_end] [datetime2](6) NULL,
	[break_start] [datetime2](6) NULL,
	[check_in_time] [datetime2](6) NULL,
	[check_out_time] [datetime2](6) NULL,
	[created_at] [datetime2](6) NULL,
	[early_leave_minutes] [int] NULL,
	[ip_address] [nvarchar](45) NULL,
	[late_minutes] [int] NULL,
	[location] [nvarchar](255) NULL,
	[notes] [nvarchar](4000) NULL,
	[overtime_hours] [numeric](5, 2) NULL,
	[status] [nvarchar](20) NULL,
	[total_hours] [numeric](5, 2) NULL,
	[updated_at] [datetime2](6) NULL,
	[work_date] [date] NOT NULL,
	[branch_id] [int] NOT NULL,
	[user_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([attendance_id] ASC)
)
GO

-- Table: blog
CREATE TABLE [dbo].[blog](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[author] [nvarchar](255) NOT NULL,
	[content] [nvarchar](max) NULL,
	[published_date] [date] NOT NULL,
	[title] [nvarchar](255) NOT NULL,
	PRIMARY KEY CLUSTERED ([id] ASC)
)
GO

-- Table: customer_memberships
CREATE TABLE [dbo].[customer_memberships](
	[customer_membership_id] [int] IDENTITY(1,1) NOT NULL,
	[created_at] [datetime2](6) NULL,
	[end_date] [datetime2](6) NULL,
	[purchase_date] [datetime2](6) NULL,
	[start_date] [datetime2](6) NULL,
	[status] [nvarchar](255) NULL,
	[updated_at] [datetime2](6) NULL,
	[used_bookings_this_month] [int] NULL,
	[customer_id] [int] NOT NULL,
	[membership_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([customer_membership_id] ASC)
)
GO

-- Table: favorite_services
CREATE TABLE [dbo].[favorite_services](
	[favorite_id] [int] IDENTITY(1,1) NOT NULL,
	[created_at] [datetime2](6) NULL,
	[customer_id] [int] NOT NULL,
	[service_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([favorite_id] ASC)
)
GO

-- Table: invoices
CREATE TABLE [dbo].[invoices](
	[invoice_id] [int] IDENTITY(1,1) NOT NULL,
	[created_at] [datetime2](6) NULL,
	[discount_amount] [numeric](38, 2) NULL,
	[final_amount] [numeric](38, 2) NULL,
	[invoice_number] [nvarchar](255) NULL,
	[payment_channel] [nvarchar](255) NULL,
	[payment_date] [datetime2](6) NULL,
	[payment_method] [nvarchar](255) NULL,
	[payment_notes] [nvarchar](4000) NULL,
	[payment_reference] [nvarchar](255) NULL,
	[payment_status] [nvarchar](255) NULL,
	[tax_amount] [numeric](38, 2) NULL,
	[total_amount] [numeric](38, 2) NULL,
	[updated_at] [datetime2](6) NULL,
	[appointment_id] [int] NOT NULL,
	[branch_id] [int] NOT NULL,
	[customer_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([invoice_id] ASC),
	UNIQUE ([appointment_id])
)
GO

-- Table: memberships
CREATE TABLE [dbo].[memberships](
	[membership_id] [int] IDENTITY(1,1) NOT NULL,
	[benefits] [nvarchar](4000) NULL,
	[created_at] [datetime2](6) NULL,
	[description] [nvarchar](4000) NULL,
	[discount_percent] [int] NULL,
	[duration_months] [int] NULL,
	[free_consultation] [bit] NULL,
	[max_bookings_per_month] [int] NULL,
	[name] [nvarchar](255) NULL,
	[price] [numeric](38, 2) NULL,
	[priority_booking] [bit] NULL,
	[status] [nvarchar](255) NULL,
	[updated_at] [datetime2](6) NULL,
	PRIMARY KEY CLUSTERED ([membership_id] ASC)
)
GO

-- Table: membership_orders
CREATE TABLE [dbo].[membership_orders](
	[order_id] [int] IDENTITY(1,1) NOT NULL,
	[created_at] [datetime2](6) NULL,
	[discount_amount] [numeric](38, 2) NULL,
	[final_price] [numeric](38, 2) NULL,
	[order_code] [bigint] NOT NULL,
	[original_price] [numeric](38, 2) NULL,
	[paid_at] [datetime2](6) NULL,
	[payment_method] [nvarchar](255) NULL,
	[payment_transaction_id] [nvarchar](255) NULL,
	[status] [nvarchar](255) NULL,
	[updated_at] [datetime2](6) NULL,
	[customer_id] [int] NOT NULL,
	[membership_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([order_id] ASC),
	UNIQUE ([order_code])
)
GO

-- Table: notifications
CREATE TABLE [dbo].[notifications](
	[notification_id] [int] IDENTITY(1,1) NOT NULL,
	[action_url] [nvarchar](500) NULL,
	[created_at] [datetime2](6) NOT NULL,
	[expires_at] [datetime2](6) NULL,
	[is_read] [bit] NULL,
	[content] [nvarchar](4000) NOT NULL,
	[read_at] [datetime2](6) NULL,
	[related_entity_id] [int] NULL,
	[related_entity_type] [nvarchar](50) NULL,
	[title] [nvarchar](255) NOT NULL,
	[type] [nvarchar](255) NOT NULL,
	[sender_id] [int] NULL,
	[recipient_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([notification_id] ASC)
)
GO

-- Table: payment_transactions
CREATE TABLE [dbo].[payment_transactions](
	[transaction_id] [int] IDENTITY(1,1) NOT NULL,
	[amount] [numeric](38, 2) NULL,
	[notes] [nvarchar](4000) NULL,
	[payment_channel] [nvarchar](255) NULL,
	[payment_date] [datetime2](6) NULL,
	[payment_method] [nvarchar](255) NULL,
	[status] [nvarchar](255) NULL,
	[transaction_reference] [nvarchar](255) NULL,
	[invoice_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([transaction_id] ASC)
)
GO

-- Table: receptionist_kpi
CREATE TABLE [dbo].[receptionist_kpi](
	[kpi_id] [int] IDENTITY(1,1) NOT NULL,
	[actual_appointments] [int] NULL,
	[actual_checkins] [int] NULL,
	[actual_checkouts] [int] NULL,
	[actual_invoices] [int] NULL,
	[actual_revenue] [numeric](12, 2) NULL,
	[average_handling_time] [numeric](8, 2) NULL,
	[created_at] [datetime2](6) NOT NULL,
	[customer_satisfaction_score] [numeric](5, 2) NULL,
	[error_rate] [numeric](5, 2) NULL,
	[month] [int] NOT NULL,
	[notes] [nvarchar](1000) NULL,
	[status] [nvarchar](20) NULL,
	[target_appointments] [int] NOT NULL,
	[target_checkins] [int] NULL,
	[target_checkouts] [int] NULL,
	[target_invoices] [int] NULL,
	[target_revenue] [numeric](12, 2) NULL,
	[updated_at] [datetime2](6) NOT NULL,
	[year] [int] NOT NULL,
	[manager_id] [int] NOT NULL,
	[receptionist_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([kpi_id] ASC)
)
GO

-- Table: salary_records
CREATE TABLE [dbo].[salary_records](
	[salary_id] [int] IDENTITY(1,1) NOT NULL,
	[base_salary] [numeric](10, 2) NOT NULL,
	[bonus] [numeric](10, 2) NULL,
	[commission] [numeric](10, 2) NULL,
	[created_at] [datetime2](6) NULL,
	[deductions] [numeric](10, 2) NULL,
	[month] [int] NOT NULL,
	[net_salary] [numeric](10, 2) NOT NULL,
	[notes] [nvarchar](4000) NULL,
	[overtime_pay] [numeric](10, 2) NULL,
	[payment_date] [date] NULL,
	[status] [nvarchar](20) NULL,
	[updated_at] [datetime2](6) NULL,
	[year] [int] NOT NULL,
	[branch_id] [int] NOT NULL,
	[user_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([salary_id] ASC)
)
GO

-- Table: salary_settings
CREATE TABLE [dbo].[salary_settings](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[attendance_bonus] [float] NULL,
	[commission_per_customer] [float] NULL,
	[commission_per_service] [float] NULL,
	[penalty] [float] NULL,
	[rating_bonus] [float] NULL,
	[revenue_bonus] [float] NULL,
	[role] [nvarchar](255) NOT NULL,
	PRIMARY KEY CLUSTERED ([id] ASC)
)
GO

-- Table: service_rating
CREATE TABLE [dbo].[service_rating](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[comment] [nvarchar](255) NULL,
	[created_at] [datetime2](6) NULL,
	[rating] [int] NOT NULL,
	[customer_id] [int] NULL,
	[service_id] [int] NULL,
	PRIMARY KEY CLUSTERED ([id] ASC)
)
GO

-- Table: service_reviews
CREATE TABLE [dbo].[service_reviews](
	[review_id] [int] IDENTITY(1,1) NOT NULL,
	[comment] [nvarchar](4000) NULL,
	[created_at] [datetime2](6) NULL,
	[rating] [int] NULL,
	[status] [nvarchar](255) NULL,
	[updated_at] [datetime2](6) NULL,
	[appointment_id] [int] NULL,
	[customer_id] [int] NOT NULL,
	[service_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([review_id] ASC)
)
GO

-- Table: service_schedule
CREATE TABLE [dbo].[service_schedule](
	[schedule_id] [int] IDENTITY(1,1) NOT NULL,
	[created_at] [datetime2](6) NULL,
	[day_of_week] [int] NULL,
	[end_time] [datetime2](6) NULL,
	[is_active] [bit] NULL,
	[start_time] [datetime2](6) NULL,
	[branch_id] [int] NULL,
	[service_id] [int] NULL,
	[technician_id] [int] NULL,
	PRIMARY KEY CLUSTERED ([schedule_id] ASC)
)
GO

-- Table: treatment_records
CREATE TABLE [dbo].[treatment_records](
	[record_id] [int] IDENTITY(1,1) NOT NULL,
	[after_image_url] [nvarchar](255) NULL,
	[before_image_url] [nvarchar](255) NULL,
	[created_at] [datetime2](6) NULL,
	[customer_feedback] [nvarchar](4000) NULL,
	[follow_up_notes] [nvarchar](4000) NULL,
	[next_appointment_recommendation] [date] NULL,
	[post_treatment_notes] [nvarchar](4000) NULL,
	[pre_treatment_notes] [nvarchar](4000) NULL,
	[treatment_date] [datetime2](6) NULL,
	[treatment_progress] [int] NULL,
	[updated_at] [datetime2](6) NULL,
	[appointment_id] [int] NOT NULL,
	[technician_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([record_id] ASC)
)
GO

-- Table: user_kpi
CREATE TABLE [dbo].[user_kpi](
	[kpi_id] [int] IDENTITY(1,1) NOT NULL,
	[actual_appointments] [int] NULL,
	[created_at] [datetime2](6) NOT NULL,
	[month] [int] NOT NULL,
	[status] [nvarchar](20) NULL,
	[target_appointments] [int] NOT NULL,
	[updated_at] [datetime2](6) NOT NULL,
	[year] [int] NOT NULL,
	[manager_id] [int] NOT NULL,
	[technician_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([kpi_id] ASC)
)
GO

-- Table: work_schedules
CREATE TABLE [dbo].[work_schedules](
	[schedule_id] [int] IDENTITY(1,1) NOT NULL,
	[break_end] [time](7) NULL,
	[break_start] [time](7) NULL,
	[created_at] [datetime2](6) NOT NULL,
	[created_by] [int] NULL,
	[end_time] [time](7) NOT NULL,
	[is_recurring] [bit] NULL,
	[notes] [nvarchar](1000) NULL,
	[recurring_end_date] [date] NULL,
	[recurring_pattern] [nvarchar](50) NULL,
	[shift_type] [nvarchar](255) NOT NULL,
	[start_time] [time](7) NOT NULL,
	[status] [nvarchar](255) NOT NULL,
	[updated_at] [datetime2](6) NOT NULL,
	[updated_by] [int] NULL,
	[work_date] [date] NOT NULL,
	[branch_id] [int] NOT NULL,
	[user_id] [int] NOT NULL,
	PRIMARY KEY CLUSTERED ([schedule_id] ASC)
)
GO

-- 4. INSERT INITIAL DATA

-- Insert roles
SET IDENTITY_INSERT [dbo].[roles] ON
INSERT [dbo].[roles] ([role_id], [description], [role_name]) VALUES (1, N'Branch Manager Role', N'MANAGER')
INSERT [dbo].[roles] ([role_id], [description], [role_name]) VALUES (2, N'Technician Role', N'TECHNICIAN')
INSERT [dbo].[roles] ([role_id], [description], [role_name]) VALUES (3, NULL, N'CUSTOMER')
INSERT [dbo].[roles] ([role_id], [description], [role_name]) VALUES (4, N'Administrator Role', N'ADMIN')
INSERT [dbo].[roles] ([role_id], [description], [role_name]) VALUES (5, N'Receptionist Role', N'RECEPTIONIST')
SET IDENTITY_INSERT [dbo].[roles] OFF
GO

-- Insert sample users
SET IDENTITY_INSERT [dbo].[users] ON
INSERT [dbo].[users] ([user_id], [address], [base_salary], [created_at], [date_of_birth], [email], [email_verified], [enabled], [full_name], [gender], [last_check_in], [last_check_out], [last_login], [last_login_attempt], [last_password_change], [last_visit_date], [login_attempts], [otp_code], [otp_expiry], [password], [performance_score], [phone], [phone_verified], [preferred_branch_id], [profile_picture], [reset_password_token], [reset_password_token_expiry], [status], [total_spent], [total_working_hours], [two_factor_enabled], [two_factor_secret], [updated_at], [username], [verification_token], [verification_token_expiry], [vip_level], [branch_id]) VALUES
(1, N'Địa chỉ số 1', NULL, CAST(N'2025-07-21T14:56:37.5748780' AS DateTime2), CAST(N'1990-01-01' AS Date), N'manager1@spa.com', 0, 1, N'Manager 1', N'MALE', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, N'$2a$10$SWpDK0GoeoTecKa2FOtoB.mHnTXUVWrbQSnKCmn6IMgbjh2HjARmm', NULL, N'0901000001', 0, NULL, NULL, NULL, NULL, N'active', NULL, NULL, 0, NULL, CAST(N'2025-07-21T14:56:37.5748780' AS DateTime2), N'manager1', NULL, NULL, N'regular', NULL),
(2, N'Địa chỉ số 2', NULL, CAST(N'2025-07-21T14:56:37.7488830' AS DateTime2), CAST(N'1990-01-02' AS Date), N'manager2@spa.com', 0, 1, N'Manager 2', N'MALE', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, N'$2a$10$g2sklbWQNi3eJVjQ6Bb24OgIYh3qLx2aH2be86ORR99UuuDsAwGYW', NULL, N'0901000002', 0, NULL, NULL, NULL, NULL, N'active', NULL, NULL, 0, NULL, CAST(N'2025-07-21T14:56:37.7488830' AS DateTime2), N'manager2', NULL, NULL, N'regular', NULL),
(3, N'Kỹ thuật viên số 1', NULL, CAST(N'2025-07-21T14:56:38.3558210' AS DateTime2), CAST(N'1992-02-01' AS Date), N'tech1@spa.com', 0, 1, N'Technician 1', N'FEMALE', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, N'$2a$10$T36aVAKLDDZTG8P7o3gls.BdeLUiX2C.m1xet019DigQ0PsobaIom', NULL, N'0902000001', 0, NULL, NULL, NULL, NULL, N'active', NULL, NULL, 0, NULL, CAST(N'2025-07-21T14:56:38.3558210' AS DateTime2), N'tech1', NULL, NULL, N'regular', NULL),
(4, N'326 cụm 4 thôn 3 xã Thạch Hòa huyện Thạch Thất', NULL, CAST(N'2025-07-21T15:11:51.4353110' AS DateTime2), CAST(N'2003-01-10' AS Date), N'thinhtran9797yb@gmail.com', 1, 1, N'Trần Thịnh', N'MALE', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, N'$2a$10$pRwa5AQkTQmA.NqkjBhcQ.dZe/Q7r2xFlfvdPa01xdl7oXakmti2i', NULL, N'0342617981', 0, NULL, NULL, NULL, NULL, N'active', NULL, NULL, 0, NULL, CAST(N'2025-07-21T15:12:18.5186880' AS DateTime2), N'thinh@gmail.com', NULL, NULL, N'regular', NULL),
(5, N'123 Admin Street, Admin District', NULL, CAST(N'2025-07-21T15:29:07.6348440' AS DateTime2), CAST(N'1985-01-15' AS Date), N'admin@spa.com', 0, 1, N'System Administrator', N'MALE', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, N'$2a$10$seDgRJA/c3ukEG57yZPaqOrX8tSZk4VGdXpesXYgujHLK8k62ZlCC', NULL, N'0901000001', 0, NULL, NULL, NULL, NULL, N'active', NULL, NULL, 0, NULL, CAST(N'2025-07-21T15:29:07.6348440' AS DateTime2), N'admin', NULL, NULL, N'regular', NULL),
(6, N'456 Reception Street, District 1', NULL, CAST(N'2025-07-21T15:29:07.7648240' AS DateTime2), CAST(N'1995-03-10' AS Date), N'receptionist1@spa.com', 0, 1, N'Receptionist 1', N'FEMALE', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, N'$2a$10$iE1HvPRv2dgfAyvSJs09re/FgL3xTljRPv8q4uPwirdRnZ/Tz4b6K', NULL, N'0902000001', 0, NULL, NULL, NULL, NULL, N'active', NULL, NULL, 0, NULL, CAST(N'2025-07-21T15:29:07.7648240' AS DateTime2), N'receptionist1', NULL, NULL, N'regular', NULL)
SET IDENTITY_INSERT [dbo].[users] OFF
GO

-- Insert user roles
INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (1, 1)
INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (2, 1)
INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (3, 2)
INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (4, 3)
INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (5, 4)
INSERT [dbo].[user_roles] ([user_id], [role_id]) VALUES (6, 5)
GO

-- Insert sample notification
SET IDENTITY_INSERT [dbo].[notifications] ON
INSERT [dbo].[notifications] ([notification_id], [action_url], [created_at], [expires_at], [is_read], [content], [read_at], [related_entity_id], [related_entity_type], [title], [type], [sender_id], [recipient_id]) VALUES
(1, N'/services', CAST(N'2025-07-21T15:12:18.5077220' AS DateTime2), NULL, 1, N'Chào mừng Trần Thịnh đến với SpaZone! Cảm ơn bạn đã đăng ký tài khoản. Hãy khám phá các dịch vụ spa tuyệt vời của chúng tôi. Bạn có thể đặt lịch hẹn, xem lịch sử điều trị và nhận thông báo quan trọng tại đây.', CAST(N'2025-07-21T15:12:42.3704800' AS DateTime2), NULL, NULL, N'Chào mừng đến với SpaZone!', N'GENERAL', NULL, 4)
SET IDENTITY_INSERT [dbo].[notifications] OFF
GO

-- 5. CREATE FOREIGN KEY RELATIONSHIPS

-- User relationships
ALTER TABLE [dbo].[users] ADD CONSTRAINT [FK_users_branch] FOREIGN KEY([branch_id]) REFERENCES [dbo].[branches] ([branch_id])
GO

ALTER TABLE [dbo].[user_roles] ADD CONSTRAINT [FK_user_roles_user] FOREIGN KEY([user_id]) REFERENCES [dbo].[users] ([user_id])
GO

ALTER TABLE [dbo].[user_roles] ADD CONSTRAINT [FK_user_roles_role] FOREIGN KEY([role_id]) REFERENCES [dbo].[roles] ([role_id])
GO

-- Service relationships
ALTER TABLE [dbo].[services] ADD CONSTRAINT [FK_services_category] FOREIGN KEY([category_id]) REFERENCES [dbo].[service_categories] ([category_id])
GO

ALTER TABLE [dbo].[services] ADD CONSTRAINT [FK_services_branch] FOREIGN KEY([branch_id]) REFERENCES [dbo].[branches] ([branch_id])
GO

ALTER TABLE [dbo].[service_categories] ADD CONSTRAINT [FK_service_categories_parent] FOREIGN KEY([parent_category_id]) REFERENCES [dbo].[service_categories] ([category_id])
GO

-- Room relationships
ALTER TABLE [dbo].[rooms] ADD CONSTRAINT [FK_rooms_branch] FOREIGN KEY([branch_id]) REFERENCES [dbo].[branches] ([branch_id])
GO

-- Appointment relationships
ALTER TABLE [dbo].[appointments] ADD CONSTRAINT [FK_appointments_branch] FOREIGN KEY([branch_id]) REFERENCES [dbo].[branches] ([branch_id])
GO

ALTER TABLE [dbo].[appointments] ADD CONSTRAINT [FK_appointments_customer] FOREIGN KEY([customer_id]) REFERENCES [dbo].[users] ([user_id])
GO

ALTER TABLE [dbo].[appointments] ADD CONSTRAINT [FK_appointments_technician] FOREIGN KEY([technician_id]) REFERENCES [dbo].[users] ([user_id])
GO

ALTER TABLE [dbo].[appointments] ADD CONSTRAINT [FK_appointments_preferred_technician] FOREIGN KEY([preferred_technician_id]) REFERENCES [dbo].[users] ([user_id])
GO

ALTER TABLE [dbo].[appointments] ADD CONSTRAINT [FK_appointments_room] FOREIGN KEY([room_id]) REFERENCES [dbo].[rooms] ([id])
GO

ALTER TABLE [dbo].[appointments] ADD CONSTRAINT [FK_appointments_service] FOREIGN KEY([service_id]) REFERENCES [dbo].[services] ([service_id])
GO

-- Appointment handled relationships
ALTER TABLE [dbo].[appointment_handled] ADD CONSTRAINT [FK_appointment_handled_appointment] FOREIGN KEY([appointment_appointment_id]) REFERENCES [dbo].[appointments] ([appointment_id])
GO

ALTER TABLE [dbo].[appointment_handled] ADD CONSTRAINT [FK_appointment_handled_receptionist] FOREIGN KEY([receptionist_user_id]) REFERENCES [dbo].[users] ([user_id])
GO

-- Appointment services relationships
ALTER TABLE [dbo].[appointment_services] ADD CONSTRAINT [FK_appointment_services_appointment] FOREIGN KEY([appointment_id]) REFERENCES [dbo].[appointments] ([appointment_id])
GO

ALTER TABLE [dbo].[appointment_services] ADD CONSTRAINT [FK_appointment_services_service] FOREIGN KEY([service_id]) REFERENCES [dbo].[services] ([service_id])
GO

-- Attendance relationships
ALTER TABLE [dbo].[attendances] ADD CONSTRAINT [FK_attendances_branch] FOREIGN KEY([branch_id]) REFERENCES [dbo].[branches] ([branch_id])
GO

ALTER TABLE [dbo].[attendances] ADD CONSTRAINT [FK_attendances_user] FOREIGN KEY([user_id]) REFERENCES [dbo].[users] ([user_id])
GO

-- Customer membership relationships
ALTER TABLE [dbo].[customer_memberships] ADD CONSTRAINT [FK_customer_memberships_customer] FOREIGN KEY([customer_id]) REFERENCES [dbo].[users] ([user_id])
GO

ALTER TABLE [dbo].[customer_memberships] ADD CONSTRAINT [FK_customer_memberships_membership] FOREIGN KEY([membership_id]) REFERENCES [dbo].[memberships] ([membership_id])
GO

-- Favorite services relationships
ALTER TABLE [dbo].[favorite_services] ADD CONSTRAINT [FK_favorite_services_customer] FOREIGN KEY([customer_id]) REFERENCES [dbo].[users] ([user_id])
GO

ALTER TABLE [dbo].[favorite_services] ADD CONSTRAINT [FK_favorite_services_service] FOREIGN KEY([service_id]) REFERENCES [dbo].[services] ([service_id])
GO

-- Invoice relationships
ALTER TABLE [dbo].[invoices] ADD CONSTRAINT [FK_invoices_appointment] FOREIGN KEY([appointment_id]) REFERENCES [dbo].[appointments] ([appointment_id])
GO

ALTER TABLE [dbo].[invoices] ADD CONSTRAINT [FK_invoices_branch] FOREIGN KEY([branch_id]) REFERENCES [dbo].[branches] ([branch_id])
GO

ALTER TABLE [dbo].[invoices] ADD CONSTRAINT [FK_invoices_customer] FOREIGN KEY([customer_id]) REFERENCES [dbo].[users] ([user_id])
GO

-- Membership order relationships
ALTER TABLE [dbo].[membership_orders] ADD CONSTRAINT [FK_membership_orders_customer] FOREIGN KEY([customer_id]) REFERENCES [dbo].[users] ([user_id])
GO

ALTER TABLE [dbo].[membership_orders] ADD CONSTRAINT [FK_membership_orders_membership] FOREIGN KEY([membership_id]) REFERENCES [dbo].[memberships] ([membership_id])
GO

-- Notification relationships
ALTER TABLE [dbo].[notifications] ADD CONSTRAINT [FK_notifications_sender] FOREIGN KEY([sender_id]) REFERENCES [dbo].[users] ([user_id])
GO

ALTER TABLE [dbo].[notifications] ADD CONSTRAINT [FK_notifications_recipient] FOREIGN KEY([recipient_id]) REFERENCES [dbo].[users] ([user_id])
GO

-- Payment transaction relationships
ALTER TABLE [dbo].[payment_transactions] ADD CONSTRAINT [FK_payment_transactions_invoice] FOREIGN KEY([invoice_id]) REFERENCES [dbo].[invoices] ([invoice_id])
GO

-- Receptionist KPI relationships
ALTER TABLE [dbo].[receptionist_kpi] ADD CONSTRAINT [FK_receptionist_kpi_manager] FOREIGN KEY([manager_id]) REFERENCES [dbo].[users] ([user_id])
GO

ALTER TABLE [dbo].[receptionist_kpi] ADD CONSTRAINT [FK_receptionist_kpi_receptionist] FOREIGN KEY([receptionist_id]) REFERENCES [dbo].[users] ([user_id])
GO

-- Salary record relationships
ALTER TABLE [dbo].[salary_records] ADD CONSTRAINT [FK_salary_records_branch] FOREIGN KEY([branch_id]) REFERENCES [dbo].[branches] ([branch_id])
GO

ALTER TABLE [dbo].[salary_records] ADD CONSTRAINT [FK_salary_records_user] FOREIGN KEY([user_id]) REFERENCES [dbo].[users] ([user_id])
GO

-- Service rating relationships
ALTER TABLE [dbo].[service_rating] ADD CONSTRAINT [FK_service_rating_customer] FOREIGN KEY([customer_id]) REFERENCES [dbo].[users] ([user_id])
GO

ALTER TABLE [dbo].[service_rating] ADD CONSTRAINT [FK_service_rating_service] FOREIGN KEY([service_id]) REFERENCES [dbo].[services] ([service_id])
GO

-- Service review relationships
ALTER TABLE [dbo].[service_reviews] ADD CONSTRAINT [FK_service_reviews_appointment] FOREIGN KEY([appointment_id]) REFERENCES [dbo].[appointments] ([appointment_id])
GO

ALTER TABLE [dbo].[service_reviews] ADD CONSTRAINT [FK_service_reviews_customer] FOREIGN KEY([customer_id]) REFERENCES [dbo].[users] ([user_id])
GO

ALTER TABLE [dbo].[service_reviews] ADD CONSTRAINT [FK_service_reviews_service] FOREIGN KEY([service_id]) REFERENCES [dbo].[services] ([service_id])
GO

-- Service schedule relationships
ALTER TABLE [dbo].[service_schedule] ADD CONSTRAINT [FK_service_schedule_branch] FOREIGN KEY([branch_id]) REFERENCES [dbo].[branches] ([branch_id])
GO

ALTER TABLE [dbo].[service_schedule] ADD CONSTRAINT [FK_service_schedule_service] FOREIGN KEY([service_id]) REFERENCES [dbo].[services] ([service_id])
GO

ALTER TABLE [dbo].[service_schedule] ADD CONSTRAINT [FK_service_schedule_technician] FOREIGN KEY([technician_id]) REFERENCES [dbo].[users] ([user_id])
GO

-- Treatment record relationships
ALTER TABLE [dbo].[treatment_records] ADD CONSTRAINT [FK_treatment_records_appointment] FOREIGN KEY([appointment_id]) REFERENCES [dbo].[appointments] ([appointment_id])
GO

ALTER TABLE [dbo].[treatment_records] ADD CONSTRAINT [FK_treatment_records_technician] FOREIGN KEY([technician_id]) REFERENCES [dbo].[users] ([user_id])
GO

-- User KPI relationships
ALTER TABLE [dbo].[user_kpi] ADD CONSTRAINT [FK_user_kpi_manager] FOREIGN KEY([manager_id]) REFERENCES [dbo].[users] ([user_id])
GO

ALTER TABLE [dbo].[user_kpi] ADD CONSTRAINT [FK_user_kpi_technician] FOREIGN KEY([technician_id]) REFERENCES [dbo].[users] ([user_id])
GO

-- Work schedule relationships
ALTER TABLE [dbo].[work_schedules] ADD CONSTRAINT [FK_work_schedules_branch] FOREIGN KEY([branch_id]) REFERENCES [dbo].[branches] ([branch_id])
GO

ALTER TABLE [dbo].[work_schedules] ADD CONSTRAINT [FK_work_schedules_user] FOREIGN KEY([user_id]) REFERENCES [dbo].[users] ([user_id])
GO

-- Work schedule created/updated by relationships
ALTER TABLE [dbo].[work_schedules] ADD CONSTRAINT [FK_work_schedules_created_by] FOREIGN KEY([created_by]) REFERENCES [dbo].[users] ([user_id])
GO

ALTER TABLE [dbo].[work_schedules] ADD CONSTRAINT [FK_work_schedules_updated_by] FOREIGN KEY([updated_by]) REFERENCES [dbo].[users] ([user_id])
GO
