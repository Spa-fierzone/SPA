# Manager Service Management Implementation

## Overview
This implementation provides comprehensive service management functionality for managers, allowing them to view, create, update, and activate/deactivate services within their assigned branch.

## Features Implemented

### 1. Service Management Interface
- **View Services**: Managers can view all services in their branch with pagination and search
- **Create Services**: Create new services assigned to manager's branch
- **Update Services**: Edit existing services (only those belonging to manager's branch)
- **Toggle Status**: Activate/deactivate services (active/inactive)

### 2. Security & Authorization
- All endpoints protected with `@PreAuthorize("hasRole('MANAGER')")`
- Branch-level access control ensures managers can only manage services in their branch
- Validation prevents unauthorized access to services from other branches

### 3. User Interface
- **Service Management Page** (`/manager/services/manage`): List view with search, pagination, and action buttons
- **Service Form Page** (`/manager/services/create` & `/manager/services/edit/{id}`): Create/edit form with validation
- Responsive design with Bootstrap 5
- Vietnamese language support
- Real-time image preview for service images

## Technical Implementation

### Backend Changes

#### 1. SpaServiceService Interface
Added new methods for branch-specific operations:
```java
Page<Service> findByBranchId(Integer branchId, Pageable pageable);
Page<Service> searchByNameAndBranchId(String keyword, Integer branchId, Pageable pageable);
List<Service> findActiveByBranchId(Integer branchId);
boolean validateManagerAccess(Integer serviceId, Integer managerBranchId);
```

#### 2. SpaServiceServiceImpl Implementation
- Implemented branch-specific service queries using existing repository methods
- Added manager access validation logic
- Proper logging and error handling

#### 3. ManagerServiceController Enhancements
Added new endpoints:
- `GET /manager/services/manage` - Service management list page
- `GET /manager/services/create` - Create service form
- `GET /manager/services/edit/{id}` - Edit service form
- `POST /manager/services/save` - Handle create/update operations
- `POST /manager/services/toggle-status/{id}` - Toggle service status (AJAX)

Helper methods:
- `getManagerBranch(Authentication)` - Get the branch that the current manager manages (using Branch.managerId)
- `validateServiceAccess(Integer, Branch)` - Validate service access permissions

### Frontend Implementation

#### 1. Service Management Page (`service-manage.html`)
- Responsive card-based layout for service display
- Search functionality with keyword filtering
- Pagination controls
- Action buttons for edit, toggle status, and view details
- AJAX-based status toggling with confirmation dialogs
- Empty state handling

#### 2. Service Form Page (`service-form.html`)
- Comprehensive form with all service fields
- Client-side validation with Vietnamese error messages
- Real-time image preview functionality
- Responsive design with proper field grouping
- Loading states for form submission

## Validation & Business Rules

### Service Validation
- **Name**: 2-255 characters, unique within branch (case-insensitive)
- **Price**: 10,000 - 10,000,000 VNĐ
- **Duration**: 15-480 minutes, must be multiples of 15
- **Description**: 10-4,000 characters (required for active services)
- **Category**: Must be selected from available categories
- **Branch**: Automatically assigned to manager's branch

### Access Control
- Managers can only view/edit services in the branch they manage (Branch.managerId = Manager.userId)
- Service creation automatically assigns to the branch that the manager manages
- Status changes only allowed for services in the manager's branch
- Proper error messages for unauthorized access attempts and unassigned managers

## Database Schema
Uses existing database structure:
- `services` table with `branch_id` foreign key pointing to the branch
- `service_categories` table for categorization
- `branches` table with `manager_id` foreign key pointing to the manager user
- `users` table containing manager information
- Manager-branch relationship: `branches.manager_id` → `users.user_id`

## URL Structure
```
/manager/services/manage          - Service management list
/manager/services/create          - Create service form
/manager/services/edit/{id}       - Edit service form
/manager/services/save            - Handle form submission
/manager/services/toggle-status/{id} - Toggle service status (AJAX)
```

## Error Handling
- Comprehensive exception handling with Vietnamese error messages
- Validation errors displayed on forms
- Access denied redirects with appropriate messages
- AJAX error handling for status toggle operations

## Testing
- Unit tests for service layer methods
- Validation tests for access control
- Mock-based testing using Mockito
- Test coverage for edge cases and error scenarios

## Usage Instructions

### For Managers:
1. Navigate to `/manager/services/manage` to view all services
2. Use search box to filter services by name
3. Click "Thêm Dịch vụ" to create new services
4. Click edit button to modify existing services
5. Click toggle button to activate/deactivate services
6. All operations are restricted to your assigned branch

### For Developers:
1. Service validation follows existing patterns in `ServiceValidationUtil`
2. Branch-specific queries use existing `ServiceRepository` methods
3. Follow established error handling patterns with Vietnamese messages
4. UI components follow Bootstrap 5 conventions
5. AJAX operations include proper error handling and loading states

## Future Enhancements
- Service analytics integration
- Bulk operations (activate/deactivate multiple services)
- Service image upload functionality
- Service scheduling and availability management
- Integration with appointment system for service usage tracking
